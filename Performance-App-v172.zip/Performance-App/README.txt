Performance App v172 — Desktop audit corrections / Design Principles Revision 36

Extract the ZIP and open index.html in desktop Chrome or Edge. Keep index.html, assets and manifest.webmanifest together. No workbook, review data or audit folders are bundled.

Text navigation is sticky on loaded workspaces. The original four-square monthly shortcut is only on search home. Existing report contents and chart designs are retained.

Named-record count metrics now use the same title eligibility for totals, status/quarter breakdowns, percentages and exact drills. Raw imported rows remain available for review. Monthly financial sums retain their documented all-row scope, and the council register retains its broader scope. Source workbook formulas are not edited by the app.

Monthly PDF navigation reference footers are omitted; screen links remain. Council uses one logical table per year within each follow-up population. Special-project PDF keeps fitting fields/cards together and repeats project identity on unavoidable continuation. Diagnostics use imported headings and actual missing-status record targets. Entity presentation and true-zero formatting use shared roles.

Legacy aggregate history without compatible record eligibility is unavailable for affected detail metrics; upload the previous workbook to recompute comparable figures. This avoids showing changes caused solely by a definition change.

PDF only: full content-height export; A4 landscape for agenda, council decisions and special projects. No PowerPoint export. Desktop is the design/testing target.

Verified with desktop Chromium and actual native PDF downloads under a local test server. Actual extracted-file Chrome/Edge compatibility, real prior-month movements, Excel recalculation and Power Query refresh remain outside certification. Keep normal browser security settings.
