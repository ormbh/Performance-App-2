Performance App v174 — Desktop consistency / Design Principles Revision 38

Extract the complete ZIP and open index.html in desktop Chrome or Edge. Keep the 23 runtime files together. No workbook, sample data, audit folders or tests are bundled.

The monthly page is the dashboard visual reference; annual agenda is the formal-report reference. Projects and entities use the approved revised compositions. Four project filters and five entity filters retain their source scope. Contents belong only to agenda, council decisions and special projects.

Projects retain source-scaled month bars, quarter/year totals, independent recorded progress, finance definitions, manager/priority analyses and record routes. Secondary analyses remain available on screen and included in full PDF. Project and entity record browsing is paged on desktop; full PDF contains every matching record.

Workspace logos retain the shared 192px placement. The search-home four-square shortcut remains captionless and opens the monthly report. Equivalent controls, dialogs, tables, badges and print roles follow the revised principles. Monthly bars keep their approved thin treatment with no added in-bar numerals.

PDF only: full content-height export for other pages; A4 landscape for agenda, council decisions and special projects. No PowerPoint export. Desktop only; mobile/tablet testing is excluded. Application-only navigation/drill commands are omitted from PDF; genuine internal PDF destinations remain.

Source identities, eligibility, comparisons and calculations remain unchanged. Source workbooks are not edited. Named-project financial scope remains distinct from monthly all-row financial sums.

Verification uses the supplied dummy workbook, not operational figures. Native exports and browser-served desktop behavior are tested. This environment blocks direct file:// loading before the app starts, so actual extracted-file Chrome/Edge behavior remains unverified. No genuine previous-month workbook, Excel/Power Query refresh, copied-Arabic reading-order or PDF accessibility certification is claimed. See the separately supplied verification notes and principles.
