Performance App v164

Extract the complete folder and open index.html. Keep assets and manifest.webmanifest beside it, then select your report workbook. No workbook is included.

PDF downloads support legacy Office square bullets while preserving source text and the approved Arabic fonts. Council decisions retain the issuing-body charts and approved six-column table. The clean package includes the app, required fonts/assets and license notices only.

Design principles and verification notes are published separately in the repository docs folder. Readable development source is retained separately in archive/development.
