/* Agenda PDF composition. Reuse the rendered source records and chart cells;
 * paginate measured native elements without changing report scope or counts. */
(function (S) {
  'use strict';
  var PX_MM = 96 / 25.4, CONTENT_MM = 182;
  function applies(state) {
    return !!(state && (state.screen === 'agenda' || state.screen === 'reports' && state.report && state.report.kind === 'agenda'));
  }
  function element(doc, tag, name, text) {
    var el = doc.createElement(tag); if (name) el.className = name;
    if (text != null) el.textContent = text; return el;
  }
  function header(state) {
    var display = S.reportDisplay.get(state), entity = S.views.agendaPage.entityText(state), e = S.util.esc;
    return '<img class="ag-pdf-logo" src="assets/img/tec-red.png" alt="المجلس التنفيذي — The Executive Council">' +
      '<div class="ag-pdf-title"><h1>' + e(display.title) + '</h1>' +
      (entity ? '<p class="ag-pdf-entity">' + e(entity) + '</p>' : '') +
      '<p class="ag-pdf-period">' + e(display.period) + '</p></div>';
  }
  function prepare(artifact, state) {
    if (!applies(state)) return false;
    var root = artifact.root, doc = artifact.document, overview = root.querySelector('.ag-matrix-overview');
    if (!overview) throw new Error('تعذّر تجهيز مخطط الأجندة للتصدير.');
    var groups = Array.from(root.querySelectorAll('.ag-table-section')).filter(function (section) { return section.querySelector('.ag-table'); });
    var definitions = root.querySelector('.ag-definitions');
    var editorial = Array.from(root.querySelectorAll('#agenda-editorial .ag-editorial-section'));
    var documentRoot = element(doc, 'div', 'ag-pdf-document'); documentRoot.dir = 'rtl';
    var first = element(doc, 'section', 'ag-pdf-first-block');
    var masthead = element(doc, 'header', 'tec-print-first-header ag-pdf-masthead'); masthead.innerHTML = header(state);
    first.appendChild(masthead); first.appendChild(overview.cloneNode(true)); documentRoot.appendChild(first);
    var expectedKeys = [];
    groups.forEach(function (source) {
      var group = element(doc, 'section', 'ag-pdf-table-group'), heading = source.querySelector(':scope > h2');
      if (!heading && source.closest('#agenda-emerging')) heading = source.closest('#agenda-emerging').querySelector(':scope > h2');
      var cohort = source.closest('#report-table,#agenda-other');
      var cohortHeading = cohort && cohort.querySelector(':scope > .ag-cohort-heading');
      if (heading) group.appendChild(element(doc, 'h2', 'ag-pdf-group-title',
        (cohortHeading ? cohortHeading.textContent.trim() + ' · ' : '') + heading.textContent.trim()));
      var table = source.querySelector('.ag-table').cloneNode(true);
      table.classList.add('ag-pdf-table');
      Array.from(table.querySelectorAll('tbody tr')).forEach(function (row) { expectedKeys.push(row.dataset.record); });
      group.appendChild(table); documentRoot.appendChild(group);
    });
    if (definitions) { var copy = definitions.cloneNode(true); copy.classList.add('ag-pdf-tail'); documentRoot.appendChild(copy); }
    editorial.forEach(function (section) { var copy = section.cloneNode(true); copy.classList.add('ag-pdf-tail'); documentRoot.appendChild(copy); });
    root.replaceChildren(documentRoot);
    artifact.agenda = { expectedKeys:expectedKeys, contentHeightMM:CONTENT_MM };
    artifact.report = documentRoot;
    return true;
  }
  function collect(artifact, bounds) {
    if (!artifact.agenda) return null;
    var root = artifact.root, tables = Array.from(root.querySelectorAll('.ag-pdf-table-group')).map(function (group) {
      var table = group.querySelector('table'), heading = group.querySelector('.ag-pdf-group-title');
      return { rect:bounds(group), heading:heading && bounds(heading), head:table.tHead && bounds(table.tHead),
        rows:Array.from(table.tBodies[0].rows).map(function (row) { return { rect:bounds(row), key:row.dataset.record }; }) };
    });
    return { first:bounds(root.querySelector('.ag-pdf-first-block')), tables:tables,
      tails:Array.from(root.querySelectorAll('.ag-pdf-tail')).map(bounds),
      expectedKeys:artifact.agenda.expectedKeys, contentHeightMM:artifact.agenda.contentHeightMM };
  }
  function fit(artifact) {
    if (!artifact.agenda) return;
    var first = artifact.root.querySelector('.ag-pdf-first-block'), capacity = CONTENT_MM * PX_MM;
    // Long saved titles and entity names can need extra header lines. Preserve
    // every word and the approved type sizes; reclaim only vertical whitespace.
    if (first.getBoundingClientRect().height > capacity + .5) first.dataset.agendaSpacing = 'compact';
    if (first.getBoundingClientRect().height > capacity + .5) first.dataset.agendaSpacing = 'compact-plus';
  }
  function pagePlan(data) {
    var agenda = data.agenda, capacity = agenda.contentHeightMM * PX_MM, gap = 5 * PX_MM;
    var plans = [{regions:[], agenda:true}], page = plans[0], cursor = 0, keys = [];
    function next() { page = {regions:[], agenda:true}; plans.push(page); cursor = 0; }
    function place(rect) { page.regions.push({source:rect,x:rect.x,y:cursor}); cursor += rect.h; }
    function room(height) { if (cursor && cursor + height > capacity + .2) next(); }
    function slice(rect, keepHeader) {
      var from = rect.y, end = rect.y + rect.h;
      while (from < end - .1) {
        var available = capacity - cursor, cut = Math.min(end, from + available);
        var crossing = data.lines.filter(function (line) { return line.x < rect.x + rect.w && line.x + line.w > rect.x && line.y < cut - .1 && line.y + line.h > cut + .1; });
        if (crossing.length) cut = Math.min.apply(null, crossing.map(function (line) { return line.y; }));
        if (cut <= from + .5) { next(); if (keepHeader) place(keepHeader); continue; }
        place({x:rect.x,y:from,w:rect.w,h:cut-from}); from = cut;
        if (from < end - .1) { next(); if (keepHeader) place(keepHeader); }
      }
    }
    if (agenda.first.h > capacity + .5) throw new Error('يتجاوز ملخص الأجندة مساحة الصفحة الأولى؛ يرجى تقليل طول عنوان التقرير أو الفترة المعروضة.');
    place(agenda.first);
    if (agenda.tables.length) next();
    agenda.tables.forEach(function (group) {
      if (!group.rows.length) return;
      var head = group.head, firstRow = group.rows[0].rect;
      var start = group.heading ? group.heading.y : head.y;
      var lead = {x:group.rect.x,y:start,w:group.rect.w,h:firstRow.y-start};
      var firstNeed = lead.h + Math.min(firstRow.h, capacity - lead.h);
      room((cursor ? gap : 0) + firstNeed);
      if (cursor) cursor += gap;
      place(lead);
      group.rows.forEach(function (row) {
        if (cursor + row.rect.h > capacity + .2 && row.rect.h <= capacity - (head ? head.h : 0)) { next(); if (head) place(head); }
        if (cursor + row.rect.h > capacity + .2) slice(row.rect, head); else place(row.rect);
        keys.push(row.key);
      });
    });
    agenda.tails.forEach(function (rect) {
      room((cursor ? gap : 0) + Math.min(rect.h, capacity));
      if (cursor) cursor += gap;
      if (rect.h > capacity) slice(rect, null); else place(rect);
    });
    if (JSON.stringify(keys) !== JSON.stringify(agenda.expectedKeys)) throw new Error('تعذّر التحقق من اكتمال صفوف الأجندة في PDF.');
    if (plans.some(function (p) { return p.regions.some(function (r) { return r.y + r.source.h > capacity + .5; }); })) throw new Error('تعذّر ضبط هوامش تقرير الأجندة.');
    return plans;
  }
  S.agendaPrint = {applies:applies, header:header, prepare:prepare, fit:fit, collect:collect, pagePlan:pagePlan};
})(window.Saytara = window.Saytara || {});
