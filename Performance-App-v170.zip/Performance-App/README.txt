Performance App v170

Extract the ZIP and keep index.html, assets and manifest.webmanifest together. No workbook is bundled.

Council performance uses the approved 2026 mold rule: official letter/unit email are included; closed/cancelled follow-up requires a 2026 letter date, a decision-letter reference containing 2026, or meeting year 2026. A nonblank subject is required. Blank/unsupported follow-up is excluded from performance counts and remains in the register/data checks. Execution status never overrides eligibility.

Use the same rule for both comparison workbooks. Legacy embedded previous-month totals may use an older definition. The full entity register remains intentionally broader. The reporting-year rule is explicitly 2026.

Hosted Chromium and native PDFs were tested using separate synthetic data. Excel recalculation/Power Query refresh, direct-file browser behavior and other browsers were not certified. Existing versioned local workbook retention and same-tab/new-tab behavior are preserved.
