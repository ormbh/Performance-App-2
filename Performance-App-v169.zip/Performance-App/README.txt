Performance App v169

Extract this ZIP and keep index.html, assets and manifest.webmanifest together. Select your report workbook; no source data is included.

Comparison drills normally stay in the same tab. Use the explicit new-tab control or Ctrl/Meta/middle click when needed. Supported browser storage retains the binary workbook pair locally, with a version and a 24-hour expiry. Older tabs identify newer versions; refresh them explicitly. End the session in comparison file settings to remove its stored files. Blocked/quota-limited browsers show a fallback message.

Hosted Chromium was verified. The managed test browser blocks file:// navigation, so direct-file behavior and other browsers are not certified. Full audit evidence and native PDF examples accompany the repository release.
