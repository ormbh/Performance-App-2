---
name: tec-desktop-design
description: Apply the approved desktop-only TEC/Saytara component, chart and PDF standard while preserving source definitions and approved page compositions.
---

# TEC Desktop Design

Read references/TEC-Apple-Inspired-Design-Principles.md before changing this project. Revision35 is the current standard; the latest explicit owner instruction overrides historical documents and generic skills.

Use desktop only. Retain existing responsive code without mobile/tablet optimization or testing. Report exports are PDF only: full PDF print for other pages; A4 landscape exclusively for agenda, council decisions and special projects. No PowerPoint controls, generation or tests.

Preserve approved page/chart composition. Data/calculation fixes do not authorize visual changes, and approval for one page does not extend to another. Illustrate a new visual direction before implementing it. The explicitly approved v171 correction restores pre-v166 monthly thin strips while preserving the three detailed chart types.

Reuse the shared navigation, ten text-only menu destinations, grid menu trigger, filters, button states, typography, status appearances, legends and footer rules. Preserve metric eligibility, raw identities, missing/zero distinctions, source notes and selected scope. Keep CSV source/diagnostic functions separate from report presentation.

Use focused existing fixtures and the Saytara QA/export workflows, overridden by this desktop/PDF scope. Inspect actual native PDFs, Arabic text, totals, filters, record order, pagination, empty states, long full-width continuation and shared-component regressions. A document update is not evidence of an implementation pass. Current verification is Verification-v171.md; historical evidence is provenance.
