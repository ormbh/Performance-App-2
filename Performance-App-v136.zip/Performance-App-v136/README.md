# Performance App v136

Extract the complete ZIP, then open `index.html` with its `assets` folder beside it.
All scripts, images and approved fonts are bundled locally. Select your report
workbook on the upload page. Workbook processing stays on your device.

## Approved TEC design

This release implements the approved design in the app, including the monthly
and projects dashboards, their browser reports, search, search results and upload.
The consolidated Revision 11 formatting standard is included as **DESIGN-STANDARD.md**. The monthly report now defaults to a continuous digital PDF with roomier spacing; selectable A4 paper output remains available. v136 browser, source and native PDF checks pass.
The latest approved Google-like search layout supplements that standard.

- DIN Next Arabic Regular headings: page 38px (search home 36px), portfolio 30px and card 28px.
  DIN Next LT Arabic Regular figures: 34–40px; special-project subgroup totals and status figures remain 28px. Subgroup names are 18px Dubai Regular. Dubai Regular supporting text;
  table names, notes and status text 16px, table headings Dubai Bold 18px, explanations 14px,
  agenda category labels (الأجندة المعتمدة / المواضيع المستجدة) 18px,
  monthly dashboard short value/status labels and strategy metric names 16px, change arrows 15px and metadata 14px. Table names/notes and essential explanations use Ink #4F4E4E; neutral differences and secondary metadata use Taupe #756B5F.
- Names remain neutral and regular. Approved status badges are informational,
  with separate accessible drilldown controls. Completed work is green, including
  legislation completed after its deadline; unfinished late work is red.
- Shared report headers retain the official logo, a 38px title and only the
  cutoff date below it. Primary navigation uses Search plus the current-page link with a
  current-page underline; other destinations and utilities remain in the app menu.
  Search home uses the menu only; search results use one current Search link.
  The home title is moved 4px upward from v132, preserving the logo, field and action positions. All three report destinations appear as direct links in both the search and shared page menus. Print actions sit together, followed by separate sector/unit/entity filters.
  Project type, priority, quarter, status and manager filters use an additional
  disclosure. Closing it preserves selections. Clearing scope preserves the file,
  report date, historical comparison and saved display/print preferences.
- Shared controls use readable labels, 44px minimum action targets, approved normal,
  hover, pressed and disabled states, and visible keyboard focus. Menus dismiss
  outside or on Escape; keyboard menu navigation and mobile filter focus are retained.
- Generic explanatory subtitles beneath titles are removed. Actual table notes,
  field/value labels, required dates, source caveats and meaningful definitions remain, except the approved removal of passive financial numeric-availability annotations.
  Screen footers show only the copyright line.
- Monthly content uses the available width at 100% browser zoom. Executive
  portfolios remain on the right, projects on the left and strategy below
  legislation. Short labels remain above their figures, including on mobile; the main total label stays below its total. Valid historical changes remain below their values. Empty status
  and priority groups stay hidden; zero counts use a dash while meaningful
  source progress of 0% is retained.
- Financial bars use solid fills, including partial numeric coverage: allocation remains Taupe, spending Teal and the unused track Linen. Hatching and passive numeric-availability notes are removed on screen and in print. Actual notes, diagnostic drilldowns, metric definitions, financial ratios and missing-value exclusions remain.
- Projects keep the approved paired sections and chart scales. Priority charts
  fit their visible content without internal vertical scrollbars. The follow-up
  table includes late, frozen, cancelled and transferred projects in that order.
- Search has a centered TEC logo, a pill-shaped search field and two primary
  tasks. Results use the approved six-column table with native details, filters,
  sorting, column customization, pagination, CSV and print of all matches.
  On mobile, the readable table scrolls inside its own labelled region.
- Upload uses the approved panel, drop zone and button hierarchy while retaining
  native selection, drag/drop, local processing, busy-state guards and error
  recovery. Invalid replacement files do not discard the current workbook.
- The strategy card omits the repeated coverage/unmeasured-count, result-count and target-count notes on screen and in both output formats. Main values, measurement bar and valid changes remain; figures/changes align when side by side.
- SLC stays first at the physical left of each mixed-language caption, followed by isolated Arabic. On phones, legislation metrics reflow into two columns without shrinking 16px labels.
- Legislation timing labels read **SLC منجز ضمن موعد** and **SLC منجز بعد موعد**. The repeated SLC comparison paragraph is removed; timing formulas and source notes are retained.
- Monthly digital output defaults to **PDF متصل — صفحة واحدة**: a custom 260mm-wide PDF with 12mm margins, 236mm content width and a height measured from the complete report. Projects remain left, executive portfolios right and the full-width followup table below. Digital spacing uses 5mm card/followup padding, a 6mm column gap, 4mm stacked-card gap, 3mm below card headings, 2.5mm above metric rows/bars and 3mm table-cell padding. The document uses one header/footer and retains the approved print fonts without zoom or font shrink.
- Monthly **A4 عمودي — للطباعة** remains selectable for physical paper. All paper modes remain A4 only: agenda, council and HH use landscape; projects (including the project report), entities, comparison, search and other views use portrait. A4 margins remain 10mm. Monthly A4 retains its paired portfolios/full-width followups and 4mm column gap; other portrait views retain their own flow. Fitting cards stay together; oversized content continues readably. A3 remains unavailable.
- If a continuous monthly page would exceed 5080mm, the current print session automatically uses A4 portrait pages and shows an explanatory toast. All records, notes, values and scope are preserved; the saved format preference is unchanged. This is an unusually long-report fallback, not a truncation or text-shrink option.
- The compliance audit corrects primary/filter interaction states, disabled fills, export loading indication, native chart status colors and number fonts, HH figure fonts/surfaces and ring fit, task-page print cleanup, wrapped checks badges and comparison/table pagination.
- Browser reports have their own readable print scale. Monthly continuous output grows its measured page height; A4 output uses content-driven pagination.
  Table body, names, notes and in-table statuses are 12pt (16 CSS px); column headings
  remain 13.5pt Dubai Bold. Screen table/status text remains 16px.
  The first page has only the official logo and one title including the actual
  report date. The ordinary continuous monthly PDF has one masthead and footer.
  In paginated A4 output, later pages have no report masthead; table column headings repeat.
  Each output footer has only copyright and the renderer-generated page X of Y.
  The entity filter and its selected value are omitted from print headers;
  the selected scope still filters the report and actual row entity names remain.

## Data and workflows

Source records, matching keys, calculation models, chart eligibility, ranking,
filters and historical comparison rules retain their definitions. A presentation
change does not create a status, replace missing data with zero or invent an arrow.
Search includes all matching source records; the follow-up tables retain their
separate eligibility rules. Missing/unknown statuses remain distinct.

The app reads cached Excel formula results; it does not refresh Excel formulas
or Power Query. Existing note/history storage is retained; the monthly output-format preference is stored separately. To use the
new version, keep the old folder until you have checked your notes/settings in
this browser. Browser file-origin storage may vary when the folder moves.

On the monthly page, select **طباعة / حفظ PDF**. Under **إعدادات الطباعة**, use **تنسيق التقرير** to choose:

- **PDF متصل — صفحة واحدة** for the continuous digital document. It is the default when no current format preference is saved. Choose **Save as PDF** in the browser dialog to preserve its custom size and measured height.
- **A4 عمودي — للطباعة** for physical paper. This selection is retained as your monthly format preference; its page count grows with the content.

Other report pages retain **طباعة التقرير** and their approved A4 orientation. Projects retain their comfortable/compact spacing options and A4 portrait paper mode.

Disable the browser’s own headers/footers to avoid adding its URL, date or title. The app’s counters require a current browser with CSS page-margin support; prior browser/PDF checks used Chromium 151. The continuous monthly format is a digital custom-size page, not an A3 choice. Approved text sizes and selected source scope remain the same in digital and paper output; A4 page count is not forced to match an earlier preview.

## Verification and maintenance

**v136 browser, source and native PDF checks pass.** Its completed browser/source-regression, continuous PDF, selected A4, height-limit fallback, upload and PDF checks belong in **VERIFICATION-v136.md**. No unrun check is recorded here as a pass. **VERIFICATION-v135.md** and earlier verification files are historical evidence for their own releases.

Screen/PDF verification uses an explicitly illustrative test workbook; that workbook and its test records are not bundled. The operational workbook visible in the user's screenshots was not supplied. v136 numerical regression uses the frozen illustrative fixture, not an unseen production workbook. Native Windows file opening and physical printing were not tested. Direct file navigation is blocked by the managed browser policy; the extracted app was tested through local HTTP.

Readable source modules are included. Rebuild with
`python tools/build-bundles.py`; check them with
`python tools/build-bundles.py --check`. `release-manifest.json` records the SHA-256
of every release file except itself. **FONT-ASSETS.md** identifies bundled fonts.
