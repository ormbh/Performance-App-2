/*
 * Performance reporting · shared view pieces
 * Status chips, timing badges, progress bars and the tooltip registry.
 */
(function (S) {
  'use strict';

  var U = S.util, SC = S.schema;

  var HEALTH = {
    delayed: { ar: 'متأخر', icon: 'clock-alert' },
    doneOnTime: { ar: 'ضمن الموعد بحسب المؤشر', icon: 'check' },
    doneLate: { ar: 'تجاوز الموعد', icon: 'check-clock' },
    clear: { ar: 'بدون تأخير', icon: 'check-circle' }
  };

  /* Native HTML/PDF chart identity only. Source status labels, categories and
   * the independent PowerPoint/export palettes remain unchanged. */
  var CHART_STATUS_COLORS = {
    done:'#01831E', delayed:'#C00000', ready:'#ABA394',
    progress:'#756B5F', review:'#756B5F', hold:'#651D32',
    cancelled:'#651D32', transferred:'#115E67',
    notStarted:'#ABA394', other:'#C8C7C7'
  };
  function chartStatusColor(label) {
    var category = S.rules.catOf(label);
    if (['مجمّد','مجمد'].map(U.key).indexOf(U.key(label)) >= 0) category = 'hold';
    return CHART_STATUS_COLORS[category] || CHART_STATUS_COLORS.other;
  }
  function chartStatusInk(label) {
    var fill = chartStatusColor(label);
    return fill === '#ABA394' || fill === '#C8C7C7' ? '#333333' : '#FCFBFB';
  }

  // Generated UI wording only; workbook labels, values and identifiers stay literal.
  function recordWord(pf, form) {
    var words = S.terms.words(pf);
    return words[form || 'definite'] || words.definite;
  }

  // Type belongs to generated field labels, never to the source title value.
  function contentLabel(itemOrPf) {
    var pf = typeof itemOrPf === 'string' ? itemOrPf : itemOrPf && itemOrPf.pf;
    return SC.PF[pf] ? recordWord(pf, 'definite') : 'العنوان';
  }
  function contentHeader(items, fallbackPortfolios) {
    var rows = Array.isArray(items) ? items : [];
    var types = rows.length ? rows : U.selection(fallbackPortfolios);
    var labels = Array.from(new Set(types.map(contentLabel)));
    return labels.length === 1 ? labels[0] : 'العنوان';
  }

  function statusChip(it, size) {
    if (!it.statusLabel) return '';
    var cat = it.statusCat;
    // The approved stylesheet owns the category treatment; source labels stay literal.
    return '<span class="st st-' + cat + (size ? ' st-' + size : '') + '">' +
      '<span dir="auto">' + U.esc(it.statusLabel) + '</span></span>';
  }

  function healthChip(key, n, size) {
    var h = HEALTH[key];
    if (!h) return '';
    return '<span class="hl hl-' + key + (size ? ' hl-' + size : '') + '">' + U.icon(h.icon, size === 'lg' ? 15 : 14) + h.ar +
      (n != null && n !== '' ? ' <span class="num">' + U.esc(n) + '</span>' : '') + '</span>';
  }

  /* Status plus timing; a status that already says "متأخر" is not repeated. */
  function chips(it, size) {
    var dup = it.statusCat === 'delayed' && it.health === 'delayed';
    return statusChip(it, size) + (it.health && !dup ? healthChip(it.health, null, size) : '');
  }

  /* Progress cell: % complete for projects and decisions, result vs target for KPIs. */
  function progressReading(value) {
    var text=U.displayNumber(value,1,'%');
    return U.esc(text);
  }
  function progress(it, big) {
    if (it.pf === 'kpi') {
      var r = it.calc.resultRecorded, t = it.calc.targetRecorded;
      if (r == null) return '<span class="prog-none">' + (it.c.result ? 'نتيجة غير رقمية' : 'غير مسجل') + '</span>';
      var rp = Math.round(r * 100), tp = t != null ? Math.round(t * 100) : null;
      var fill = tp == null ? 'var(--info)' : rp >= tp ? 'var(--ok)' : 'var(--warn)';
      return '<div class="prog' + (big ? ' prog-lg' : '') + '"><div class="prog-label">' + progressReading(r*100) + (tp != null ? ' · المستهدف ' + progressReading(t*100) : '') + '</div>' +
        '<div class="prog-bar"><span style="width:' + Math.max(0, Math.min(100, rp)) + '%;background:' + fill + '"></span>' +
        (tp != null ? '<i class="prog-mark" style="inset-inline-start:' + Math.max(0, Math.min(100, tp)) + '%" title="المستهدف"></i>' : '') + '</div></div>';
    }
    if (it.progress == null) {
      var has = it.pf === 'special' || it.pf === 'secretariat' || it.pf === 'council';
      return '<span class="prog-none">' + (has ? 'غير مسجلة' : '—') + '</span>';
    }
    var p = Math.round(it.progress);
    var col = it.statusCat === 'done' ? 'var(--status-completed)' : it.health === 'delayed' || it.statusCat === 'delayed' ? 'var(--status-late)' : 'var(--info)';
    return '<div class="prog' + (big ? ' prog-lg' : '') + '"><div class="prog-label">' + progressReading(it.progress) + '</div>' +
      '<div class="prog-bar"><span style="width:' + Math.max(0, Math.min(100, p)) + '%;background:' + col + '"></span></div></div>';
  }

  function pfName(pf) { return SC.PF[pf] ? SC.PF[pf].ar : pf; }

  function drillCue() { return ''; }

  /* File names mix Arabic, digits and ".xlsx"; keep the extension in its own
     left-to-right run so "سبتمبر 2026.xlsx" does not show as "xlsx.2026". */
  function fileName(name) {
    var n = String(name || ''), dot = n.lastIndexOf('.');
    if (U.dirOf(n) === 'ltr' || dot <= 0) return '<bdi dir="' + U.dirOf(n) + '">' + U.esc(n) + '</bdi>';
    return '<bdi dir="rtl">' + U.esc(n.slice(0, dot)) + '</bdi><bdi dir="ltr">' + U.esc(n.slice(dot)) + '</bdi>';
  }

  /* Only the exact legal line belongs in the shared screen footer. */
  function slcCaption(label) {
    var caption=String(label==null?'':label);
    if (!/^SLC /.test(caption)) return U.esc(caption);
    return '<span class="tec-slc-caption" dir="ltr"><bdi dir="ltr">SLC</bdi> <span dir="rtl">'+U.esc(caption.slice(4))+'</span></span>';
  }
  function searchSource(state) { return ''; }
  // Legal release year is separate from the selected reporting/calculation year.
  function copyrightText() { return 'الأمانة العامة للمجلس التنفيذي لإمارة دبي · حقوق النشر © 2026 · جميع الحقوق محفوظة'; }
  function sourceFooter(state) {
    return '<footer class="app-source-footer" aria-label="حقوق النشر"><style>:root{--app-footer-context:'+JSON.stringify(copyrightText())+';}</style><div class="app-source-footer-in"><p class="app-footer-copyright">'+U.esc(copyrightText())+'</p></div></footer>';
  }

  // Approved shared workspace: real routes and existing commands remain available
  // in one app menu, while primary navigation and print actions stay compact.
  function workspaceHeader(state, current, options) {
    options = options || {};
    var hasData=!!state.data, busy=!!state.reporting, monthly=current==='dashboard';
    var date=hasData&&U.validDateSerial(state.data.today)?U.fmtDate(state.data.today):'لم يُحدَّد';
    function destination(screen,action,label,currentKey,report) {
      var patch=report?Object.assign({},state,{report:Object.assign({},state.report,{kind:report})}):state;
      var href=S.app&&S.app.href?S.app.href(screen,patch):'#/'+screen;
      return '<a href="'+U.esc(href)+'" data-screen-link="'+screen+'" data-act="'+action+'"'+(report?' data-report="'+report+'"':'')+' class="'+(currentKey?'tec-primary-link'+(current===currentKey?' is-current':''):'tec-command')+'"'+((currentKey&&current===currentKey)||(!currentKey&&state.screen===screen&&(!report||state.report.kind===report))?' aria-current="page"':'')+(currentKey?'':' role="menuitem"')+'>'+U.esc(label)+'</a>';
    }
    function command(action,label,icon,extra) {
      var downloading=busy&&icon==='download';
      var graphic=downloading?'<span class="tec-command-spinner" role="status" aria-label="جارٍ إعداد PowerPoint…"></span>':U.icon(icon,20);
      return '<button type="button" class="tec-command" role="menuitem" data-act="'+action+'"'+(busy?' disabled':'')+(downloading?' aria-busy="true"':'')+'>'+graphic+'<span>'+U.esc(label)+'</span>'+(extra||'')+'</button>';
    }
    var masthead=options.masthead||'';
    if(monthly) masthead='<div class="wb-reference-title"><h1>التقرير الشهري للأداء والتنفيذ</h1><p class="wb-reference-context">حتى تاريخ <bdi dir="ltr">'+U.esc(date)+'</bdi></p></div>';
    var commands='',actions='',primary='';
    if(hasData){
      // Visible links identify the search entry point and the current page only.
      // All destinations stay available in the app menu on every loaded page.
      primary=destination('home','go-home','البحث','search');
      var currentDestination={dashboard:['dashboard','go-dash','اللوحة الشهرية'],projects:['projects','go-projects','محفظة المشاريع'],entities:['entities','go-entities','تقرير الجهات'],comparison:['comparison','go-comparison','المقارنة الشهرية'],checks:['checks','go-checks','ملاحظات البيانات'],upload:['upload','change-file','رفع ملف التقرير'],reports:['reports','show-report',S.views.reports.title(state.report.kind)]}[current];
      if(currentDestination)primary+=destination(currentDestination[0],currentDestination[1],currentDestination[2],current,current==='reports'?state.report.kind:null);
      commands=destination('home','go-home','البحث')+destination('dashboard','go-dash','اللوحة الشهرية')+destination('projects','go-projects','محفظة المشاريع')+destination('entities','go-entities','تقرير الجهات')+destination('comparison','go-comparison','المقارنة الشهرية');
      ['agenda','council','hh'].forEach(function(k){commands+=destination('reports','show-report',S.views.reports.title(k),null,k);});
      if(current==='projects')commands+=command('projects-report','تقرير المشاريع','file');
      if(current==='reports'&&['hh','agenda','council'].includes(state.report.kind))commands+=command(state.report.kind==='hh'?'hh-report':state.report.kind==='council'?'council-report':'agenda-report','تنزيل PowerPoint','download');
      if(current==='comparison')commands+=command('reset-comparison','مسح المقارنة','refresh');
      var issueCount=(state.data.issues||[]).filter(function(x){return x.sev!=='info';}).length;
      commands+=command('go-checks','ملاحظات البيانات','warn','<bdi class="badge">'+U.metricText(issueCount)+'</bdi>')+command('change-file','تغيير الملف','upload');
      if(['dashboard','projects','reports','entities'].includes(current)){
        actions='<div class="tec-workspace-task-actions monthly-print-control"><button type="button" class="btn tec-primary-action" data-act="print"'+(busy?' disabled':'')+'>'+U.icon('print',20)+'<span>'+(monthly?'طباعة / حفظ PDF':'طباعة التقرير')+'</span></button>';
        var settings=monthly?'monthly-settings':current==='projects'||(current==='reports'&&state.report.kind==='projects')?'project-print-settings':null;
        if(settings)actions+='<button type="button" class="btn tec-secondary-action" data-act="'+settings+'" aria-haspopup="dialog" aria-controls="'+(monthly?'monthly-report-settings':'project-print-settings')+'" aria-expanded="'+!!(monthly?state.monthly&&state.monthly.settingsOpen:state.projectPrint&&state.projectPrint.settingsOpen)+'"'+(busy?' disabled':'')+'><span>إعدادات الطباعة</span>'+U.icon('down',20)+'</button>';
        actions+='</div>';
      }
    }
    var brandScreen=hasData?'dashboard':'upload';
    return '<a class="app-skip-link" href="#app-main" data-act="skip-content">انتقل إلى المحتوى</a><header class="app-header tec-workspace-header'+(options.masthead?' app-project-header':'')+(monthly?' wb-reference-header':'')+(state.navOpen?' is-nav-open':'')+'"><div class="app-header-in tec-workspace-in"><div class="tec-workspace-masthead'+(masthead?'':' tec-brand-only')+'">'+masthead+'<a class="tec-workspace-brand wb-brand" href="#/'+brandScreen+'" data-screen-link="'+brandScreen+'" data-act="'+(hasData?'go-dash':'change-file')+'" aria-label="'+(hasData?'التقرير الشهري':'رفع الملف')+'"><img class="tec-logo" src="assets/img/tec-red.png" alt="المجلس التنفيذي — The Executive Council"></a></div>'+(hasData?'<div class="tec-workspace-toolbar"><div class="tec-workspace-navigation"><nav class="tec-primary-navigation" aria-label="التنقل الرئيسي">'+primary+'</nav><div class="tec-app-menu-wrap"><button type="button" class="tec-app-menu-trigger" data-act="toggle-nav" aria-label="صفحات التطبيق" aria-haspopup="menu" aria-controls="tec-app-menu" aria-expanded="'+!!state.navOpen+'">'+U.icon('grid',20)+'</button><div id="tec-app-menu" class="tec-app-menu" role="menu" aria-label="صفحات التطبيق"'+(state.navOpen?'':' hidden')+'>'+commands+'</div></div></div>'+actions+'</div>':'')+'</div></header>';
  }
  function monthlyReferenceHeader(state) { return workspaceHeader(state,'dashboard'); }
  function appHeader(state,current,options) { return workspaceHeader(state,current,options); }

  function workspaceFilters(state,options) {
    var id=options.id||'dashboard',projects=id==='projects',ident='filters-'+id+'-extra',open=!!(state.filterPanels&&state.filterPanels[id]);
    var controls=options.body||'',core=[],extra=[];
    // The markup is generated by multiSelect below. Partition existing live fields
    // without changing option identities, aliases, counts or dependent filtering.
    var box=document.createElement('div');box.innerHTML=controls;
    var wraps=Array.from(box.querySelectorAll('.multi-wrap'));
    wraps.forEach(function(w){var key=w.getAttribute('data-multi-wrap').split(':').pop();( ['sector','unit','entity'].includes(key)?core:extra).push(w.outerHTML);});
    if(!wraps.length)core=[controls];
    var active=Math.max(0,Number(options.activeCount)||0);
    return '<section class="tec-workspace-filters'+(projects?' tec-project-filters':'')+'" data-filter-panel="'+id+'" aria-label="'+U.esc(options.title||'نطاق التقرير')+'"><div class="tec-core-filter-fields">'+core.join('')+'</div><div class="tec-filter-summary-row"><p class="tec-filter-scope" role="status" aria-live="polite" aria-atomic="true"><span>النطاق: </span><bdi dir="auto">'+U.esc(options.summary||'جميع القطاعات والوحدات والجهات')+'</bdi></p><div class="tec-filter-tools">'+(active&&options.resetAction?'<button type="button" class="tec-text-action ui-filter-reset" data-act="'+U.esc(options.resetAction)+'"'+(state.reporting?' disabled':'')+'>مسح التصفية</button>':'')+(projects?'<button type="button" class="tec-text-action ui-filter-toggle" data-act="toggle-filters" data-filter-panel="'+id+'" aria-controls="'+ident+'" aria-expanded="'+open+'"><span class="ui-filter-toggle-label">'+(open?'إغلاق التصفية':'المزيد من التصفية')+'</span>'+U.icon(open?'up':'down',20)+'</button>':'')+'</div></div>'+(projects?'<div class="tec-extra-filter-fields ui-filter-body" id="'+ident+'"'+(open?'':' hidden')+'>'+extra.join('')+'</div>':'')+'</section>';
  }
  function monthlyReferenceFilters(state, controls, summary, active) {
    return workspaceFilters(state,{id:'dashboard',title:'نطاق التقرير الشهري',body:controls,summary:summary,activeCount:active,resetAction:'reset-dashboard-filters'});
  }

  // All report kinds use the same scope controls and reset action. Extra
  // controls are supplied by the owning report; dashboard markup is unchanged.
  function reportFilterControls(state, dashboard, extra) {
    return state.report.kind==='council' ? S.views.dashboard.filterBar(state,dashboard,true,extra) : S.views.dashboard.filterBar(state,dashboard,true)+(extra||'');
  }
  // Both binary leadership values mean an unconstrained report, including
  // records whose source flag is blank. Keep explicit single/blank values.
  function reportLeadSelection(value) {
    var selected=U.selection(value),keys=selected.map(S.filterOptions.key);
    return keys.includes(S.filterOptions.key('نعم'))&&keys.includes(S.filterOptions.key('لا'))?'':U.selectionState(selected);
  }
  // One disclosure pattern across views. Opening is a presentation preference;
  // it never changes selections, result counts, routing, or export scope.
  function filterPanel(state, options) {
    if(options.id==='projects')return workspaceFilters(state,options);
    var id=String(options.id||'scope').replace(/[^a-z0-9-]/gi,'-');
    var open=!!(state.filterPanels&&state.filterPanels[id]);
    var heading='filters-'+id+'-title', controls='filters-'+id+'-controls';
    var active=Math.max(0,Number(options.activeCount)||0);
    return '<section class="ui-filter-panel'+(open?' is-open':'')+'" data-filter-panel="'+id+'" aria-labelledby="'+heading+'">'+
      '<div class="ui-filter-header"><div class="ui-filter-title"><h2 id="'+heading+'" class="visually-hidden">'+U.esc(options.title||'عوامل التصفية')+'</h2><span class="ui-scope-label">النطاق</span><p class="ui-filter-summary" role="status" aria-live="polite" aria-atomic="true"><bdi dir="auto">'+U.esc(options.summary||'الكل')+'</bdi></p></div>'+
      '<div class="ui-filter-actions">'+(active&&options.resetAction?'<button type="button" class="dbtn ui-filter-reset" data-act="'+U.esc(options.resetAction)+'"'+(state.reporting?' disabled':'')+'>'+U.esc(options.resetLabel||'مسح التصفية')+'</button>':'')+'<button type="button" class="dbtn ui-filter-toggle" data-act="toggle-filters" data-filter-panel="'+id+'" aria-expanded="'+open+'" aria-controls="'+controls+'"><span class="ui-filter-toggle-label">'+(open?'إغلاق التصفية':'تصفية')+'</span>'+(active?'<span class="ui-filter-count" aria-label="'+U.esc('عدد عوامل التصفية النشطة: '+active)+'">'+U.fmtN(active)+'</span>':'')+U.icon(open?'up':'down',18)+'</button></div></div>'+
      '<div class="ui-filter-body" id="'+controls+'"'+(open?'':' hidden')+'>'+(options.body||'')+'</div></section>';
  }
  function multiSelect(state,id,label,value,values) {
    var F=S.filterOptions,sel=U.selection(id==='r:lead'?reportLeadSelection(value):value),opts=F.group(F.sourceAliases(state,id,F.organizationOptions(state,id,values)),sel,id),groups=F.selectionGroups(sel,opts,id),open=state.menu===id;
    state.multiOptions=state.multiOptions||{};state.multiOptions[id]=opts;
    var ident='multi-'+id.replace(/[^a-z0-9-]/gi,'-'),allLabels={sector:'جميع القطاعات',unit:'جميع الوحدات',entity:'جميع الجهات'},allText=allLabels[id.split(':').pop()]||'الكل',text=groups.length===1?groups[0].label:groups.length?'القيم المحددة: '+groups.length:allText;
    var mobile=window.matchMedia&&window.matchMedia('(max-width:599px)').matches,tag='dialog';
    var query=state.multiSearch&&state.multiSearch[id]||'',needle=U.norm(F.display(query)),matching=opts.filter(function(o){return F.matches(o,query);}).length;
    return '<div class="menu-wrap multi-wrap" data-multi-wrap="'+U.esc(id)+'"><button type="button" class="dbtn multi-trigger'+(groups.length?' is-active':'')+'" data-act="menu" data-menu="'+U.esc(id)+'" aria-expanded="'+open+'"'+(open?' aria-controls="'+ident+'"':'')+' aria-label="'+U.esc(label+': '+(groups.length?F.text(sel,opts,null,id):allText))+'"'+(state.reporting?' disabled':'')+'><span class="muted">'+U.esc(label)+'</span><b dir="auto">'+U.esc(text)+'</b>'+U.icon('down',16)+'</button>'+(open?'<'+tag+' id="'+ident+'" class="menu menu-check multi-menu'+(mobile?' mobile-filter-sheet':'')+'" '+(mobile?'aria-modal="true"':'role="group"')+' aria-label="'+U.esc(label)+'"><div class="multi-menu-heading"><strong>'+U.esc(label)+'</strong><button type="button" class="multi-close" data-act="close-multi" data-multi="'+U.esc(id)+'" aria-label="إغلاق خيارات '+U.esc(label)+'">'+U.icon('x',18)+'</button></div><label class="multi-search-label"><span class="visually-hidden">البحث في خيارات '+U.esc(label)+'</span><input type="search" data-multi-search="'+U.esc(id)+'" value="'+U.esc(query)+'" placeholder="البحث في الخيارات" aria-controls="'+ident+'-options"></label><div class="multi-actions"><button type="button" data-act="multi-all" data-multi="'+U.esc(id)+'">تحديد الكل</button><button type="button" data-act="multi-clear" data-multi="'+U.esc(id)+'">مسح التحديد</button><span class="multi-selected-count">'+(groups.length?U.fmtN(groups.length)+' محدد':'الكل')+'</span></div><div class="multi-options" id="'+ident+'-options">'+opts.map(function(o){return '<label class="opt'+(o.stale?' is-stale':'')+'"'+(!F.matches(o,query)?' hidden':'')+'><input type="checkbox" data-change="multi" data-multi="'+U.esc(id)+'" data-v="'+U.esc(o.v)+'"'+(o.selected&&!o.partial?' checked':'')+(o.partial?' data-multi-partial="true" aria-checked="mixed"':'')+'><span class="opt-l" dir="auto">'+U.esc(o.label)+(o.partial?'<small class="multi-partial-note"> · تحديد جزئي محفوظ</small>':'')+'</span>'+(o.n==null?'':'<span class="opt-n">'+U.metricText(o.n)+'</span>')+'</label>';}).join('')+'</div><p class="multi-empty" role="status"'+(matching?' hidden':'')+'>'+(opts.length?'لا توجد خيارات مطابقة للبحث':'لا توجد قيم ضمن النطاق الحالي')+'</p>'+'<button type="button" class="btn tec-primary-action multi-done" data-act="close-multi" data-multi="'+U.esc(id)+'">تم</button>'+'</'+tag+'>':'')+'</div>';
  }

  /* Tooltips: views register {title, def, now, base} and mark the element with data-tip. */
  var tips = {};
  var tipSeq = 0;
  function tip(t) { var id = 't' + (++tipSeq); tips[id] = t; return ' data-tip="' + id + '"'; }
  function resetTips() { tips = {}; tipSeq = 0; S.ui.tips = tips; }

  S.views = S.views || {};
  S.ui = {
    slcCaption:slcCaption,
    recordWord:recordWord, contentLabel:contentLabel, contentHeader:contentHeader, chartStatusColor:chartStatusColor, chartStatusInk:chartStatusInk, drillCue:drillCue, filterPanel:filterPanel, reportFilterControls:reportFilterControls, reportLeadSelection:reportLeadSelection, multiSelect:multiSelect, statusChip: statusChip, healthChip: healthChip, chips: chips, progress: progress,
    pfName: pfName, fileName: fileName, searchSource:searchSource, sourceFooter:sourceFooter, copyrightText:copyrightText, workspaceHeader:workspaceHeader, workspaceFilters:workspaceFilters, appHeader: appHeader, monthlyReferenceHeader:monthlyReferenceHeader, monthlyReferenceFilters:monthlyReferenceFilters, HEALTH: HEALTH, tip: tip, resetTips: resetTips, tips: tips
  };
})(window.Saytara = window.Saytara || {});
