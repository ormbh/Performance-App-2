/* Reference portfolio layouts with source-scoped values and guarded history. */
(function(S){
 'use strict';
 var U=S.util;
 function render(state,m,h,options){
  var E=U.esc;
  options=options||{};
  if(!m||!m.total)return '<section class="pd-empty"><h2>لا توجد مشاريع ضمن هذا النطاق</h2><button type="button" class="dbtn" data-act="'+E(h.resetAction||'projects-reset')+'">مسح التصفية</button></section>';
  function num(v){return U.metricText(v);}
  function pct(v){return v===0?'0%':U.displayNumber(v,1,'%');}
  function cash(v,divisor){return v===0?'-':U.displayNumber(typeof v==='number'&&divisor?v/divisor:v,divisor&&divisor>1?1:2);}
  function moneyUnit(divisor){return (divisor===1000000?'مليون ':divisor===1000?'ألف ':'')+'درهم';}
  function finite(v){return typeof v==='number'&&Number.isFinite(v);}
  function value(metric){return metric&&metric.available!==false&&finite(metric.value)?metric.value:null;}
  function semantic(v,kind){return v===0?'صفر':!finite(v)?'غير متاح':kind==='money'?cash(v)+' درهم إماراتي':kind==='percent'?pct(v):num(v);}
  function drill(text,id,label,cls){return id?'<button type="button" class="pd-drill '+(cls||'')+'"'+h.attrs('delivery',id)+' aria-label="'+E(label+' · يعرض المشاريع المطابقة')+'"><bdi dir="auto">'+E(text)+'</bdi></button>':'<span class="'+(cls||'')+'"><bdi dir="auto">'+E(text)+'</bdi></span>';}
  function count(v,id,label,cls){return drill(num(v),v==null?null:id,label+': '+semantic(v),'pd-count '+(cls||''));}
  /* Direction is a numeric fact; tone requires an explicit metric polarity.
   * Counts and financial measures are neutral unless a defined completion or
   * follow-up metric supplies higher/lower polarity at its call site. */
  function delta(d,label,kind,polarity){
   if(!d||!d.available||d.delta===0||!finite(d.delta))return '';
   var v=U.displayNumber(Math.abs(d.delta),kind==='money'?2:kind==='percent'?1:0),unit=kind==='money'?' درهم':kind==='percent'?' نقطة مئوية':'',tone='neutral';
   if(polarity==='higher')tone=d.delta>0?'positive':'negative';
   else if(polarity==='lower')tone=d.delta<0?'positive':'negative';
   return '<span class="pd-delta" data-direction="'+(d.delta>0?'up':'down')+'" data-tone="'+tone+'" aria-label="'+E(label+': '+(d.delta>0?'زيادة ':'انخفاض ')+v+unit)+'"><span aria-hidden="true">'+(d.delta>0?'↑':'↓')+'</span><bdi dir="ltr">'+E((d.delta>0?'+':'−')+v)+'</bdi>'+(unit?'<span>'+E(unit)+'</span>':'')+'</span>';
  }
  function coverage(metric){if(!metric||metric.known==null||metric.total===0||metric.known===metric.total)return '';return '<small class="pd-coverage">'+E('قيم متاحة: '+num(metric.known)+' من '+num(metric.total))+'</small>';}
  function budgetCell(g,divisor){var b=g.budget||{};return drill(cash(b.value,divisor),b.value==null?null:b.id,g.name+'، الموازنة المعتمدة: '+semantic(b.value,'money'),'pd-budget-value')+delta(g.changes&&g.changes.budget,g.name+'، الموازنة المعتمدة','money','neutral');}
  function head(title,note,id){return '<header class="pd-section-head"><h2'+(id?' id="'+E(id)+'"':'')+'>'+E(title)+'</h2></header>';}
  function labelText(label){return typeof label==='string'?label:label.text;}
  var tableIndex=0;
  function table(rows,labels,cells,title,extra,after,columns){var kind=(extra||'').split(/\s+/)[0],hintId='pd-scroll-hint-'+(++tableIndex);return '<div class="pd-table-region" data-pd-table-kind="'+E(kind)+'" role="region" tabindex="0" aria-label="'+E(title)+'" aria-describedby="'+hintId+'"><table class="pd-table '+(extra||'')+'" role="table"><caption class="visually-hidden">'+E(title)+'</caption>'+(columns?'<colgroup>'+columns.map(function(width){return '<col style="width:'+width+'%">';}).join('')+'</colgroup>':'')+'<thead role="rowgroup"><tr role="row">'+labels.map(function(label){return '<th scope="col" role="columnheader"><span>'+E(labelText(label))+'</span>'+(typeof label==='object'&&label.sub?'<small>'+E(label.sub)+'</small>':'')+'</th>';}).join('')+'</tr></thead><tbody role="rowgroup">'+rows.map(function(row){return '<tr role="row"'+(row.id?' data-group-id="'+E(row.id)+'"':'')+(row.item?' data-project-key="'+E(row.item.key)+'"':'')+(row.rowClass||row.depth?' class="'+E(row.rowClass||(row.depth?'pd-child-row':''))+'"':'')+'>'+cells(row).map(function(v,i){return '<'+(i===0?'th scope="row" role="rowheader"':'td role="cell"')+' data-label="'+E(labelText(labels[i]))+'">'+v+'</'+(i===0?'th':'td')+'>';}).join('')+'</tr>';}).join('')+'</tbody></table>'+(after||'')+'</div><p class="pd-scroll-hint" id="'+hintId+'" data-pd-table-kind="'+E(kind)+'">مرّر الجدول أفقياً لعرض بقية الأعمدة.</p>';}
  function nameCell(g){return drill(g.depth&&g.priorityName?g.priorityName:g.name,g.id,g.name,'pd-group-name')+(g.previousOnly?'<small class="pd-source-sector">ورد في اللقطة السابقة فقط</small>':'');}

  /* A single numeric scale per chart. Signed money grows either side of zero. */
  function scale(values,kind){
   var known=values.filter(finite),min=known.length?Math.min.apply(null,[0].concat(known)):0,max=known.length?Math.max.apply(null,[0].concat(known)):0;
   var magnitude=Math.max(Math.abs(min),Math.abs(max)),divisor=kind==='money'?(magnitude>=1000000?1000000:magnitude>=1000?1000:1):1;
   return {min:min,max:max,span:max-min||1,kind:kind,available:known.length>0,zero:(0-min)/(max-min||1)*100,divisor:divisor};
  }
  function bar(v,s,id,label,cls){
   if(!finite(v))return '<span class="pd-plot pd-plot-unavailable" role="img" aria-label="'+E(label+': غير متاح')+'"><bdi>—</bdi></span>';
   var end=(v-s.min)/s.span*100,left=Math.min(s.zero,end),width=Math.abs(end-s.zero);
   var plot='<span class="pd-plot" dir="ltr" aria-hidden="true"><span class="pd-zero-line" style="left:'+s.zero+'%"></span><span class="pd-bar-fill '+(cls||'')+'" style="left:'+left+'%;width:'+width+'%"></span></span>';
   return id?'<button type="button" class="pd-bar-button"'+h.attrs('delivery',id)+' aria-label="'+E(label+': '+semantic(v,s.kind==='money'?'money':'')+' · يعرض المشاريع المطابقة')+'">'+plot+'</button>':'<span class="pd-bar-static" role="img" aria-label="'+E(label+': '+semantic(v,s.kind==='money'?'money':''))+'">'+plot+'</span>';
  }
  var o=m.overall||{},history=m.history||{};

  /* Each status is one row on common count and budget scales. Progress is
   * a mean of recorded percentages, never inferred from the status label. */
  function metricChart(g,kind,s){
   var metric=kind==='money'?g.budget:null,v=kind==='money'?value(metric):g.available===false?null:g.value==null?g.total:g.value;
   var label=g.name||g.label,change=g.changes&&(kind==='money'?g.changes.budget:g.changes.total)||kind!=='money'&&g.change;
   return '<div class="pd-metric-chart"><div class="pd-metric-value">'+(kind==='money'?drill(cash(v,s.divisor),v==null?null:metric&&metric.id,label+'، الموازنة المعتمدة: '+semantic(v,'money'),'pd-budget-value'):count(v,g.id,label+'، عدد المشاريع'))+delta(change,label+(kind==='money'?'، الموازنة المعتمدة':'، عدد المشاريع'),kind,kind!=='money'&&g.key==='completed'?'higher':'neutral')+'</div>'+(g.rowClass==='pd-total-row'?'':bar(v,s,v==null?null:kind==='money'?metric&&metric.id:g.id,label+(kind==='money'?'، الموازنة المعتمدة':'، عدد المشاريع'),g.key==='completed'?'pd-completed-fill':kind==='money'?'pd-neutral-fill':''))+'</div>';
  }
  function progressTrack(v,id,label,change,metric){
   var valid=finite(v)&&v>=0&&v<=100,visible=drill(pct(valid?v:null),valid?id:null,label+': '+semantic(valid?v:null,'percent'),'pd-progress-value');
   return '<div class="pd-progress">'+visible+delta(change,label,'percent','higher')+(valid?'<span class="pd-progress-track" role="img" aria-label="'+E(label+': '+pct(v))+'"><span class="pd-progress-fill" style="width:'+v+'%"></span></span>':'<small class="pd-unavailable">غير متاح</small>')+coverage(metric)+'</div>';
  }
  var statusSequence=['completed','active','notStarted','suspended','transferred','cancelled','unknown'];
  var statuses=(m.statuses||[]).filter(function(g){return g.key!=='unknown'&&g.total>0&&g.available!==false;}).slice().sort(function(a,b){return statusSequence.indexOf(a.key)-statusSequence.indexOf(b.key);}),statusScale=scale(statuses.map(function(g){return g.available===false?null:g.value==null?g.total:g.value;}),'count'),statusBudgetScale=scale(statuses.map(function(g){return value(g.budget);}),'money');
  var hiddenStatus=(m.statuses||[]).find(function(g){return g.key==='unknown';}),statusMissing=hiddenStatus&&hiddenStatus.total>0?'<p class="pd-footnote pd-missing-classification">'+drill('حالة غير مسجلة أو غير محسومة: '+num(hiddenStatus.total),hiddenStatus.id,'مشاريع دون حالة محسومة')+' · مشمولة في الإجمالي.</p>':'';
  var statusRows=statuses.concat([Object.assign({},o,{name:'الإجمالي',rowClass:'pd-total-row'})]);
  var statusChart=table(statusRows,[{text:'الحالة'},{text:'العدد #',sub:'مشروع'},{text:'الموازنة',sub:moneyUnit(statusBudgetScale.divisor)},{text:'متوسط الإنجاز %',sub:'النسب المسجلة'}],function(g){return [nameCell(g),metricChart(g,'count',statusScale),metricChart(g,'money',statusBudgetScale),g.rowClass==='pd-total-row'?drill(pct(g.progress&&g.progress.value),g.progress&&g.progress.value==null?null:g.progress&&g.progress.id,'الإجمالي، متوسط الإنجاز المسجل','pd-progress-value')+delta(g.changes&&g.changes.progress,'الإجمالي، متوسط الإنجاز المسجل','percent','higher')+coverage(g.progress):progressTrack(g.progress&&g.progress.value,g.progress&&g.progress.id,g.name+'، متوسط الإنجاز المسجل',g.changes&&g.changes.progress,g.progress)];},'حالة المشاريع وعددها والموازنة ومتوسط الإنجاز المسجل','pd-combined-status-table');
  function scaleRange(s,kind){return s.available?'<bdi dir="ltr">'+E(s.min===0?'0':kind==='money'?cash(s.min,s.divisor):num(s.min))+'–'+E(s.max===0?'0':kind==='money'?cash(s.max,s.divisor):num(s.max))+'</bdi> '+E(kind==='money'?moneyUnit(s.divisor):'مشروع'):'غير متاح';}
  var delivery='<section class="pd-panel pd-delivery" data-pd-chart-area="delivery" aria-labelledby="pd-delivery-title">'+head('حالة المشاريع','العدد والموازنة ومتوسط نسب الإنجاز المسجلة','pd-delivery-title')+statusChart+statusMissing+'<p class="pd-footnote pd-scale-note">مقياس أشرطة العدد: '+scaleRange(statusScale,'count')+'؛ الموازنة: '+scaleRange(statusBudgetScale,'money')+'؛ متوسط الإنجاز: <bdi dir="ltr">0–100%</bdi>.</p><p class="pd-footnote">متوسط الإنجاز متوسط نسب المصدر، وليس نسبة عدد المشاريع المنجزة. الموازنة تجمع القيم المسجلة فقط؛ الناقص لا يتحول إلى صفر.</p></section>';

  var statusStyles={completed:'completed',active:'working',notStarted:'notstarted',suspended:'suspended',cancelled:'cancelled',transferred:'transferred',unknown:'unknown'};
  var statusNames={completed:'منجز',active:'قيد العمل',notStarted:'لم يبدأ',suspended:'مجمّد',cancelled:'ملغى',transferred:'منقول',unknown:'حالة غير محسومة'};
  var statusOrder=['completed','active','notStarted','suspended','transferred','cancelled','unknown'];
  function stackLegend(parts,kind,divisor){return '<div class="pd-stack-legend">'+parts.map(function(p){return '<span class="pd-legend-item"><span class="pd-legend-swatch '+E(p.cls||'')+'"'+(p.color?' style="--pd-series-color:'+E(p.color)+'"':'')+' aria-hidden="true"></span>'+drill(p.label,p.value==null?null:p.id,p.label+': '+semantic(p.value,kind),'pd-legend-label')+'<bdi dir="ltr">'+E(kind==='money'?cash(p.value,divisor):num(p.value))+'</bdi>'+delta(p.change,p.label,kind,p.key==='completed'?'higher':'neutral')+'</span>';}).join('')+'</div>';}
  function stack(parts,max,label,kind,empty,divisor){
   var known=parts.filter(function(p){return finite(p.value);}),positive=known.filter(function(p){return p.value>0;});
   if(empty)return '<small class="pd-stack-empty">لا توجد مشاريع</small>';
   if(!known.length)return '<small class="pd-unavailable">القيم غير متاحة للرسم</small>'+stackLegend(parts,kind,divisor);
   if(known.some(function(p){return p.value<0;}))return '<small class="pd-unavailable">قيم مالية سالبة في المصدر؛ يعرض التفصيل دون شريط تجميعي.</small>'+stackLegend(parts,kind,divisor);
   var plot=positive.length&&max>0?'<div class="pd-stack" role="img" aria-label="'+E(label+'؛ '+positive.map(function(p){return p.label+': '+semantic(p.value,kind);}).join('، '))+'">'+positive.map(function(p){return '<span class="pd-stack-segment '+E(p.cls||'')+'" style="width:'+(p.value/max*100)+'%;'+(p.color?'--pd-series-color:'+E(p.color)+';':'')+'" aria-hidden="true"></span>';}).join('')+'</div>':'<small class="pd-stack-zero">القيم المسجلة صفر؛ لا شريط</small>';
   return stackLegend(parts,kind,divisor)+plot;
  }
  function statusParts(g){return statusOrder.filter(function(k){return k!=='unknown'&&finite(g.statusCounts&&g.statusCounts[k])&&g.statusCounts[k]>0;}).map(function(k){return {key:k,label:statusNames[k],value:g.statusCounts[k],id:g.statusIds&&g.statusIds[k],cls:'pd-status-'+statusStyles[k],change:g.changes&&g.changes.statusCounts&&g.changes.statusCounts[k]};});}
  function scheduleCells(g){var quarter=g.rowClass&&g.rowClass.indexOf('pd-quarter-row')>=0,progress=g.progress&&g.progress.value;return [nameCell(g),count(g.available===false?null:g.total,g.id,g.name+'، عدد المشاريع')+delta(g.changes&&g.changes.total,g.name+'، عدد المشاريع','count','neutral'),quarter?'<span class="pd-quarter-caption">'+E(g.total?'إجمالي الربع':'لا توجد مشاريع')+'</span>':g.total&&!statusParts(g).length?'<small class="pd-unavailable">حالات المصدر غير متاحة</small>':stack(statusParts(g),g.total,g.name+'، توزيع حالات المشاريع داخل الشهر','count',g.total===0),quarter?drill(pct(progress),progress==null?null:g.progress&&g.progress.id,g.name+'، متوسط الإنجاز','pd-progress-value')+delta(g.changes&&g.changes.progress,g.name+'، متوسط الإنجاز','percent','higher')+coverage(g.progress):progressTrack(progress,g.progress&&g.progress.id,g.name+'، متوسط الإنجاز',g.changes&&g.changes.progress,g.progress)];}
  var monthNames=['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
  var calculationYear=finite(m.cutoff)?U.ymd(m.cutoff).y:null;
  var schedule=(m.scheduleYears||[]).map(function(y){var rows=[];(y.quarters||[]).filter(function(q){return y.year===calculationYear||q.total>0||q.previousOnly;}).forEach(function(q){rows.push(Object.assign({},q,{name:'Q'+q.quarter,rowClass:'pd-quarter-row'+(q.total?'':' pd-quarter-empty')}));(q.months||[]).filter(function(mon){return mon.total>0||mon.previousOnly;}).forEach(function(mon){rows.push(Object.assign({},mon,{name:monthNames[mon.month-1]||mon.name,rowClass:'pd-month-row'}));});});return '<div class="pd-year-group"><div class="pd-scope-totals"><div>'+drill(String(y.year),y.id,'مشاريع '+y.year,'pd-year-heading')+'</div><div>'+count(y.total,y.id,'مشاريع '+y.year)+'<span> مشروعاً</span>'+delta(y.changes&&y.changes.total,'مشاريع '+y.year,'count','neutral')+'</div></div>'+table(rows,[{text:'الربع / الشهر'},{text:'العدد #'},{text:'توزيع الحالات',sub:'داخل الشهر · الأرقام عدد المشاريع'},{text:'متوسط الإنجاز %'}],scheduleCells,'تقدم المشاريع في سنة '+y.year+' بحسب الربع والشهر','pd-schedule-table')+'</div>';}).join('');
  var undated=m.undatedSchedule;
  if(undated&&(undated.total>0||undated.available===false||undated.previousOnly))schedule+='<div class="pd-schedule-unscheduled">'+table([Object.assign({},undated,{name:'دون موعد انتهاء صالح'})],['الربع / الشهر','العدد · مشروع','الحالات · عدد المشاريع','متوسط الإنجاز المسجل %'],scheduleCells,'المشاريع دون موعد انتهاء صالح','pd-schedule-table')+'</div>';
  var scheduleHtml='<section class="pd-panel pd-schedule" data-pd-chart-area="schedule" aria-labelledby="pd-schedule-title">'+head('تقدم المشاريع حسب الربع والشهر','','pd-schedule-title')+(schedule||'<p class="pd-unavailable">حقل موعد الانتهاء غير متاح في المصدر.</p>')+(hiddenStatus&&hiddenStatus.total>0?'<p class="pd-footnote pd-missing-classification">الحالات غير المصنفة مشمولة في الإجمالي ولا تمثل بسلسلة حالة.</p>':'')+'<p class="pd-footnote">بحسب موعد انتهاء المشروع'+(finite(m.cutoff)?' · تاريخ التقرير: '+E(U.fmtDate(m.cutoff)):'')+'<br>الإجمالي '+E(num(o.total))+' مشروعاً<br>كل شريط يوزع حالات مشاريع الشهر بنسبة <bdi dir="ltr">100%</bdi>؛ العدد منفصل، ولا تُقارن أعداد الأشهر بطول الشريط. متوسط الربع من نسب مشاريعه المسجلة. — لا توجد مشاريع.</p></section>';

  /* Priority-first bars use actual type × priority intersections. */
  var extraColors=['#651D32','#333333','#ABA394','#808080','#C8C7C7'];
  function typeStyle(k){if(k==='Strategic')return {cls:'pd-type-strategic'};if(k==='Operational')return {cls:'pd-type-operational'};if(!k)return {cls:'pd-type-unknown'};var hash=0;for(var i=0;i<k.length;i++)hash=(hash*31+k.charCodeAt(i))>>>0;return {cls:'pd-type-extra',color:extraColors[hash%extraColors.length]};}
  var prioritySequence=['H','M','L'],priorities=(m.priorities||[]).filter(function(g){return prioritySequence.indexOf(g.key)>=0&&g.total>0&&g.available!==false;}).slice().sort(function(a,b){var x=prioritySequence.indexOf(a.key),y=prioritySequence.indexOf(b.key);return (x<0?3:x)-(y<0?3:y);});
  function typeParts(g,kind){return (g.children||[]).filter(function(c){return c.total>0;}).map(function(c){var style=typeStyle(c.typeKey||''),metric=kind==='money'?c.budget:null;return {label:c.typeName||c.name,value:kind==='money'?value(metric):c.available===false?null:c.total,id:kind==='money'?metric&&metric.id:c.id,cls:style.cls,color:style.color,change:c.changes&&(kind==='money'?c.changes.budget:c.changes.total)};});}
  function priorityChart(kind){
   var maxima=priorities.map(function(g){return typeParts(g,kind).reduce(function(n,p){return n+(finite(p.value)&&p.value>0?p.value:0);},0);}),max=maxima.length?Math.max.apply(null,maxima):0;
   var step=max>0?Math.pow(10,Math.floor(Math.log10(max))-1)*5:1;max=max>0?Math.ceil(max/step)*step:0;
   var divisor=kind==='money'?(max>=1000000?1000000:max>=1000?1000:1):1;
   var title=kind==='money'?'الموازنة حسب الأولوية والنوع':'عدد المشاريع حسب الأولوية والنوع';
   var rows=priorities.map(function(g){return g;});
   var chartAxis=max>0?'<div class="pd-stack-axis" aria-label="'+E('مقياس '+title)+'"><span></span><div><bdi dir="ltr">0</bdi><bdi dir="ltr">'+E(kind==='money'?cash(max/2,divisor):num(max/2))+'</bdi><bdi dir="ltr">'+E(kind==='money'?cash(max,divisor):num(max))+'</bdi></div><span></span></div>':'';
   var chart=table(rows,[{text:'الأولوية'},{text:kind==='money'?moneyUnit(divisor):'عدد المشاريع'},{text:'المجموع'}],function(g){var parts=typeParts(g,kind);return [(g.key?drill(g.key,g.id,g.name,'pd-priority-code')+'<small>'+E(g.name)+'</small>':nameCell(g)),g.available===false?'<small class="pd-unavailable">حقلا النوع والأولوية غير متاحين</small>':stack(parts,max,title+' · '+g.name,kind,g.total===0,divisor),kind==='money'?budgetCell(g,divisor):count(g.total,g.id,g.name+'، عدد المشاريع')+delta(g.changes&&g.changes.total,g.name+'، عدد المشاريع','count','neutral')];},title,'pd-priority-table',chartAxis);
   var unclassified=(m.priorities||[]).filter(function(g){return prioritySequence.indexOf(g.key)<0&&g.total>0;});
   var missing=unclassified.length?'<p class="pd-footnote pd-missing-classification">'+unclassified.map(function(g){return drill('أولوية غير مصنفة H / M / L: '+num(g.total),g.id,'مشاريع خارج تصنيف الأولوية H / M / L');}).join(' · ')+' · مشمولة في الإجمالي.</p>':'';
   return '<div class="pd-priority-view">'+head(title,'')+(priorities.length?chart:'<p class="pd-unavailable">لا توجد مشاريع بأولوية H أو M أو L ضمن النطاق.</p>')+missing+'<div class="pd-priority-total"><span>الإجمالي '+(kind==='money'?budgetCell(Object.assign({name:'المحفظة'},o),divisor)+' '+E(moneyUnit(divisor)):count(o.total,o.id,'إجمالي المشاريع')+' مشروعاً'+delta(o.changes&&o.changes.total,'إجمالي المشاريع','count','neutral'))+'</span></div></div>';
  }
  var priorityCounts='<section class="pd-panel pd-classification pd-priority-counts" data-pd-chart-area="priority-counts" aria-label="عدد المشاريع حسب الأولوية والنوع">'+priorityChart('count')+'<p class="pd-footnote">الأعداد من تقاطع الأولوية والنوع في سجلات المصدر.</p></section>';
  var priorityBudget='<section class="pd-panel pd-classification pd-priority-budget" data-pd-chart-area="priority-budget" aria-label="الموازنة حسب الأولوية والنوع">'+priorityChart('money')+'<p class="pd-footnote">الموازنات من الحقول المسجلة في المصدر فقط.</p></section>';

  var financeBudget=value(o.budget),financeDivisor=finite(financeBudget)&&Math.abs(financeBudget)>=1000000?1000000:finite(financeBudget)&&Math.abs(financeBudget)>=1000?1000:1,financeUnit=moneyUnit(financeDivisor);
  function financeLabel(seg){return seg.key==='workDone'?'قيمة الأعمال المنجزة':seg.label||'القيمة المالية';}
  function financePanel(panel,title,cls){
   if(!panel)return '<div class="pd-finance-block"><h3>'+E(title)+'</h3><p class="pd-unavailable">الحقول اللازمة لهذا العرض غير متاحة.</p></div>';
   var basis=panel.basis||{},segments=panel.segments||[],valid=panel.available&&finite(basis.value)&&basis.value>0,flags=panel.flags||{},excluded=panel.excluded||{};
   var safe=valid&&segments.every(function(seg){return finite(seg.ratio)&&seg.ratio>=0&&seg.ratio<=100;})&&segments.reduce(function(n,seg){return n+seg.ratio;},0)<=100.000001;
   var track=safe?'<div class="pd-finance-track" role="img" aria-label="'+E(title+'؛ '+segments.map(function(seg){return financeLabel(seg)+': '+pct(seg.ratio);}).join('، '))+'">'+segments.map(function(seg,i){return '<span class="pd-finance-track-'+(i===0?'fill':'remaining')+' pd-finance-'+E(seg.key)+'" style="width:'+seg.ratio+'%"></span>';}).join('')+'</div>':'<p class="pd-unavailable">'+E(valid?'القيم المصدرية لا تكوّن شريطاً متناسقاً؛ راجع التفصيل أدناه.':'النسبة غير متاحة؛ يلزم توفر قيم متطابقة وموازنة موجبة.')+'</p>';
   var labels='<div class="pd-finance-labels">'+segments.map(function(seg){var sourceLabel=financeLabel(seg),label=seg.key==='committed'?'المخصص (الملتزم به)':seg.key==='nonCommitted'?'غير المخصص (غير الملتزم به)':seg.key==='spent'?'المنفق حسب الفواتير':seg.key==='remaining'?'المتبقي غير المنفق':sourceLabel;return '<div><span class="pd-finance-segment-label"><span class="pd-legend-swatch pd-finance-'+E(seg.key)+'" aria-hidden="true"></span>'+drill(label,seg.value==null?null:seg.id,sourceLabel,'')+'</span><div class="pd-finance-segment-values">'+drill(cash(seg.value,financeDivisor),seg.value==null?null:seg.id,sourceLabel+': '+semantic(seg.value,'money'),'pd-money')+'<span>'+E(financeUnit)+'</span>'+delta(seg.change,sourceLabel,'money','neutral')+drill(pct(seg.ratio),seg.ratio==null?null:panel.cohortId,sourceLabel+' ÷ '+(basis.label||'الموازنة المعتمدة')+': '+semantic(seg.ratio,'percent'),'pd-progress-value')+delta(seg.ratioChange,sourceLabel+'، النسبة','percent','neutral')+'</div></div>';}).join('')+'</div>';
   var notices=[];
   if(flags.overBudget)notices.push('القيمة المصدرية تتجاوز الموازنة في '+num(flags.overBudget)+' مشروع.');
   if(flags.inconsistent)notices.push('قيم المخصص وغير المخصص لا تتطابق مع الموازنة في '+num(flags.inconsistent)+' مشروع.');
   if(flags.negativeInputs)notices.push('قيم مالية سالبة مستبعدة من النسب في '+num(flags.negativeInputs)+' مشروع.');
   var isWork=cls==='pd-finance-work',used=segments[0]||{},usedLabel=financeLabel(used),reading=isWork?'<div class="pd-finance-work-reading">'+drill(cash(used.value,financeDivisor),used.value==null?null:used.id,usedLabel+': '+semantic(used.value,'money'),'pd-money')+'<span>'+E(financeUnit)+'</span>'+delta(used.change,usedLabel,'money','neutral')+drill(pct(used.ratio),used.ratio==null?null:panel.cohortId,usedLabel+' ÷ '+(basis.label||'الموازنة المستخدمة للنسبة')+': '+semantic(used.ratio,'percent'),'pd-progress-value')+delta(used.ratioChange,usedLabel+'، النسبة','percent','neutral')+'</div>':'';
   /* Preserve each chart's monetary denominator without a numeric
    * source-availability annotation beside its solid financial bars. */
   var basisText='<div class="pd-finance-basis"><span>الموازنة المستخدمة للنسب</span><div>'+drill(cash(basis.value,financeDivisor),basis.value==null?null:basis.id,'الموازنة المستخدمة للنسب: '+semantic(basis.value,'money'),'pd-budget-value')+'<span>'+E(financeUnit)+'</span>'+delta(basis.change,'الموازنة المستخدمة للنسب','money','neutral')+'</div></div>';
   var diagnostics=[];
   if(excluded.total)diagnostics.push('<p>'+drill('خارج حساب النسبة: '+num(excluded.total)+' مشروع',excluded.id,'المشاريع المستبعدة من هذه النسبة')+'</p>');
   var exclusions=[];
   if(excluded.missing)exclusions.push('قيم ناقصة: '+num(excluded.missing));
   if(excluded.negative)exclusions.push('قيم سالبة: '+num(excluded.negative));
   if(excluded.nonPositiveBudget)exclusions.push('موازنة صفرية أو سالبة: '+num(excluded.nonPositiveBudget));
   if(exclusions.length)diagnostics.push('<p>'+E(exclusions.join(' · '))+'<small>قد ينطبق أكثر من سبب على المشروع نفسه.</small></p>');
   notices.forEach(function(note){diagnostics.push('<p class="pd-finance-alert">'+E(note)+'</p>');});
   var diagnosticBody=diagnostics.join(''),diagnosticHtml=diagnosticBody?'<details class="pd-finance-details"><summary aria-label="'+E('تفاصيل البيانات والاستثناءات · '+title)+'">تفاصيل البيانات والاستثناءات</summary><div class="pd-finance-detail-body">'+diagnosticBody+'</div></details><div class="pd-finance-details-print"><h4>تفاصيل البيانات والاستثناءات</h4>'+diagnosticBody+'</div>':'';
   return '<div class="pd-finance-block '+(cls||'')+'" data-finance-cohort="'+E(panel.id||'')+'"><div class="pd-finance-heading"><h3>'+E(title)+'</h3>'+reading+'</div>'+basisText+(isWork?track:'')+(isWork?'<div class="pd-finance-work-axis"><bdi dir="ltr">0%</bdi><bdi dir="ltr">100%</bdi></div>':labels+track)+diagnosticHtml+'</div>';
  }
  var panels=m.financePanels||{};
  var finance='<section class="pd-panel pd-finance" data-pd-chart-area="finance" aria-labelledby="pd-finance-title">'+head('الالتزامات وتقدم الإنفاق','','pd-finance-title')+'<div class="pd-finance-overview"><h3>الموازنة المعتمدة للمحفظة</h3><div>'+budgetCell(Object.assign({name:'المحفظة'},o),financeDivisor)+'<span> '+E(financeUnit)+'</span></div></div>'+financePanel(panels.allocation,'الالتزام بالموازنة')+financePanel(panels.invoices,'الإنفاق حسب الفواتير والمتبقي من الموازنة')+financePanel(panels.workCompleted,'قيمة الأعمال المنجزة','pd-finance-work')+'<p class="pd-footnote">النسب من الموازنة المعتمدة ضمن القيم المالية المتطابقة. قيمة الأعمال المنجزة تختلف عن المنفق حسب الفواتير، ولا تمثل نسبة إنجاز المشاريع.</p></section>';

  function managerRatioCell(g,budget){
   var totalMetric=budget?g.totalBudget:null,doneMetric=budget?g.completedBudget:null,totalValue=budget?value(totalMetric):g.total,doneValue=budget?value(doneMetric):g.completed;
   var ratio=budget?g.completedBudgetRatio:g.completionRate,label=g.name+(budget?'، موازنة المشاريع المصنفة منجزة ÷ إجمالي موازنة المحفظة':'، عدد المشاريع المنجزة ÷ إجمالي عدد المشاريع');
   var valid=finite(ratio)&&ratio>=0&&ratio<=100;
   return '<div class="pd-manager-ratio"><div class="pd-manager-ratio-head"><div class="pd-manager-ratio-fraction">'+drill((budget?cash(doneValue):num(doneValue))+' / '+(budget?cash(totalValue):num(totalValue)),totalValue==null?null:budget?totalMetric&&totalMetric.id:g.id,label+': '+semantic(doneValue,budget?'money':'')+' من '+semantic(totalValue,budget?'money':''),'pd-budget-value')+delta(g.changes&&(budget?g.changes.totalBudget:g.changes.total),g.name+(budget?'، الموازنة الإجمالية':'، إجمالي المشاريع'),budget?'money':'count','neutral')+'</div><div class="pd-manager-ratio-percent">'+drill(pct(valid?ratio:null),valid?budget?doneMetric&&doneMetric.id:g.completedId:null,label+': '+semantic(valid?ratio:null,'percent'),'pd-progress-value')+delta(budget?g.changes&&g.changes.completedBudgetRatio:g.changes&&g.changes.completionRate,label,'percent',budget?'neutral':'higher')+'</div></div>'+(valid?'<span class="pd-manager-ratio-track" role="img" aria-label="'+E(label+': '+pct(ratio))+'"><span class="pd-progress-fill" style="width:'+ratio+'%"></span></span>':'<small class="pd-unavailable">غير متاح</small>')+'<small class="pd-manager-residual">'+E(budget?'غير المنجز: ':'غير المنجز: ')+drill(budget?cash(value(g.unfinishedBudget)):num(g.unfinished),budget?value(g.unfinishedBudget)==null?null:g.unfinishedBudget&&g.unfinishedBudget.id:g.unfinished==null?null:g.unfinishedId,g.name+'، غير المنجز','pd-manager-unfinished')+(budget?' درهم':' مشروع')+'</small></div>';
  }
  function managerRows(rows,title,completed){return table(rows,[{text:'الترتيب'},{text:'المدير'},{text:'المشاريع',sub:'عدد المنجز / الإجمالي'},{text:'موازنة المشاريع · درهم',sub:'موازنة المنجز / الإجمالي'}],function(g){return ['<span class="pd-manager-rank"><bdi dir="ltr">'+E(num(g.displayRank||g.rank))+'</bdi></span>',nameCell(g),managerRatioCell(g,false),managerRatioCell(g,true)];},title,'pd-manager-table'+(completed?' pd-manager-completed':''),'',[6,15,30,49]);}
  var follow=m.managerFollowup||{},leaders=follow.leaders||[],completedManagers=follow.completedManagers||[];
  var managerBody=leaders.length?managerRows(leaders,'أعلى ثلاث محافظ غير منجزة لمديري المشاريع',false):'<p class="pd-unavailable">'+E(follow.reason||'لا توجد محافظ غير منجزة لمدير مسجل ضمن النطاق.')+'</p>';
  if(completedManagers.length)managerBody+='<div class="pd-manager-completed-group"><h3>محفظة مكتملة · للمقارنة، خارج ترتيب المتابعة</h3>'+managerRows(completedManagers.map(function(g,i){return Object.assign({},g,{displayRank:leaders.length+i+1});}),'مديرون بمحافظ منجزة بالكامل',true)+'</div>';
  [follow.unassigned,follow.unknownStatus].filter(function(g){return g&&g.total>0;}).forEach(function(g){managerBody+='<p class="pd-footnote">'+nameCell(g)+' · '+count(g.total,g.id,g.name)+' مشروع · خارج ترتيب المحافظ غير المنجزة.</p>';});
  var manager='<section class="pd-panel pd-managers" data-pd-chart-area="managers" aria-labelledby="pd-manager-title">'+head('أولوية متابعة محافظ مديري المشاريع','','pd-manager-title')+managerBody+'<p class="pd-footnote">أعلى 3 حسب حجم المحفظة غير المنجزة · العدد والموازنة<br>'+E(follow.reason||'نصف حصة عدد المشاريع غير المنجزة ونصف حصة موازنتها.')+'<br>نسبة الموازنة حصة موازنة المشاريع المصنفة منجزة، وليست نسبة الإنفاق. نسبة العدد منجز ÷ إجمالي؛ تأكيد توقف التقدم يتطلب تحديثات متتابعة.</p></section>';

  function fullNotes(issue){var it=issue.item||{},t=it.t||{},parts=[['ملاحظات مدير المشروع',t.ownerRemarks],['ملاحظات المالية',t.financeRemarks]].filter(function(p){return p[1]!=null&&String(p[1]).trim()!=='';});return parts.map(function(p){return '<p class="pd-source-note">'+(parts.length>1||p[0]==='ملاحظات المالية'?'<span>'+E(p[0])+'</span>':'')+'<bdi dir="auto">'+E(String(p[1]))+'</bdi></p>';}).join('');}
  function issueReading(issue){
   var it=issue.item||{},t=it.t||{},attention=issue.attention||'unknown',reading=finite(issue.progress)?'<div class="pd-issue-progress">'+E(pct(issue.progress))+'<span class="pd-progress-track" role="img" aria-label="'+E('نسبة الإنجاز المسجلة: '+pct(issue.progress))+'"><span class="pd-progress-fill" style="width:'+issue.progress+'%"></span></span></div>':'';
   return '<span class="pd-issue-status pd-attention-'+E(attention)+'">'+E(issue.displayStatus||it.statusLabel||t.status||'')+'</span>'+reading+(it.dateLabel||t.end?'<small><bdi dir="auto">'+E(it.dateLabel||t.end)+'</bdi></small>':'')+(issue.daysOverdue>0?'<small class="pd-attention-late">'+E('متأخر '+num(issue.daysOverdue)+' يوماً')+'</small>':'');
  }
  var issues=m.issues||[],issuesHtml='<section class="pd-panel pd-issues" data-pd-chart-area="issues" aria-labelledby="pd-issues-title"><header class="pd-section-head"><h2 id="pd-issues-title">المشاريع التي تتطلب المتابعة</h2><span class="pd-issue-total">'+count(issues.length,'issues:all','المشاريع التي تتطلب المتابعة')+delta(m.issuesChange,'المشاريع التي تتطلب المتابعة','count','lower')+'</span></header>'+(issues.length?table(issues,['المشروع','القطاع / الوحدة','مدير المشروع','الحالة / الإنجاز / الموعد','الملاحظات'],function(issue){var it=issue.item||{},t=it.t||{};return [h.link(it.title||'غير مسجل','record',it.key,'pd-issue-project'),E(it.sector||'')+(it.unit?'<small>'+E(it.unit)+'</small>':''),'<bdi dir="auto">'+E(issue.manager||t.pm||'غير مسجل')+'</bdi>',issueReading(issue),fullNotes(issue)];},'المشاريع التي تتطلب المتابعة وملاحظاتها الكاملة','pd-issues-table','',[20,21,12,18,29]):'<p class="pd-unavailable">لا توجد مشاريع متأخرة أو مجمّدة أو ملغاة أو منقولة ضمن هذا النطاق.</p>')+'<p class="pd-footnote pd-followup-definition">المشاريع المتأخرة، ثم المجمّدة، ثم الملغاة، ثم المنقولة فقط. متأخر: تجاوز الموعد ولم ينجز.</p></section>';
  var comparisonNote=m.comparisonAvailable&&options.showComparison!==false?'<p class="pd-comparison-note">'+E(history.points&&history.points.length===2?'المقارنة بين '+history.points[0].date+' و'+history.points[1].date:'المقارنة بين لقطتين مؤكدتين ضمن النطاق')+' · صافي تغير ضمن النطاق، لا يثبت سبب التغير.</p>':'';
  var sections={delivery:delivery,schedule:scheduleHtml,finance:finance,issues:issuesHtml,managers:manager,'priority-counts':priorityCounts,'priority-budget':priorityBudget};
  var selected=[];
  (options.sections||['finance','schedule','delivery','managers','priority-counts','priority-budget','issues']).forEach(function(key){
   (key==='classification'?['priority-counts','priority-budget']:[key]).forEach(function(area){if(sections[area]&&selected.indexOf(area)<0)selected.push(area);});
  });
  return '<div class="portfolio-delivery pd-design-b" lang="ar" dir="rtl">'+comparisonNote+'<div class="pd-reference-grid">'+selected.map(function(key){return sections[key];}).join('')+'</div></div>';
 }
 S.views.portfolioDelivery={render:render};
})(window.Saytara=window.Saytara||{});
