# TEC entity report — revised terminology concept

This package is a separate design study. It does not modify or replace Performance App v133, and it does not amend the approved TEC standard.

Extract the ZIP and open `review.html` for the before / after, information tables and the full proposal. Open `preview/index.html` to see the proposed page at 100% browser zoom. Fonts and the official logo are included locally.

The area filter, summary and status drilldowns, record dialogs and methodology disclosure work. Entity and relationship fields show a fixed illustrative comparison scope. Navigation, the menu's destinations and printing controls show proposed placement; report navigation and export are not implemented in this preview.

Both sides use the same frozen illustrative workbook, source records and cutoff date, 30/09/2026. The selected entity name comes from the fixture's reference dictionary; the records, counts and named coordinators are illustrative and do not assess this entity's operational performance.

The sample has 11 source rows: approved agenda 3, emerging agenda 1, council 6 and special projects 1. Completed 4, open 7, overdue 1 and due within 30 days 2 are separate readings of this scope. They are not categories to sum together.

The current entity model excludes strategic-budget projects. Adding them requires a validated entity relationship and agreed calculation. Generic “required action”, “next commitment” and “accountable owner” fields are not invented. Recorded coordinator / project-manager roles, date types, status, progress and follow-up reasons remain distinct.

`Terminology-Review.md` contains the complete before / after terminology matrix and component sizes. `Entity-Report-Study.md` contains the proposed setup and source rules. `renders/` contains the actual current-app captures, the proposed desktop/mobile captures and the fixed side-by-side comparison. `verification.json` records the focused checks; this is not a full accessibility certification.
