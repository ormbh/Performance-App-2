# TEC branding files — current app assets

Prepared 17 October 2026 from Performance App v175 and Design Principles Revision 39.

## Contents

- `logos/`: the three original PNG files: dark positive, white negative, and red. Original pixels and dimensions are unchanged. Positive is an opaque RGB image; negative and red have alpha transparency. Preserve aspect ratio. The negative logo appears on a dark panel in the preview so its white artwork is visible.
- `fonts/`: the four supplied DIN Arabic / DIN LT Arabic / Dubai Regular / Dubai Bold font files, unchanged.
- `palette/`: current project colors and application status colors, exported as JSON and CSV. Logo artwork is not recolored to match UI tokens.
- `styles/`: standalone color tokens and font-face declarations for these packaged assets. This is not the complete application stylesheet.
- `guidance/`: current TEC desktop design principles and original font provenance notes.
- `references/`: the existing Noto OFL text is retained as a reference, not presented as the license for the DIN/Dubai files. Font provenance/licensing was not independently verified.
- `index.html`: an offline preview of the original logos, colors and font roles. Extract the ZIP before opening it.
- `manifest.json`: file hashes and original asset verification.

These are assets available in the project. Original AI/EPS/SVG logo masters and a separate official corporate brand manual were not supplied. No logos were traced, regenerated, recolored, cropped or upscaled. The pack contains no source workbook, report records or app runtime.
