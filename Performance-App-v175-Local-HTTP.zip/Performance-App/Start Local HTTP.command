#!/bin/bash
# Optional macOS entry point. App files stay unchanged.
set -eu
tec_root="$(cd "$(dirname "$0")" && pwd -P)"
tec_found="$(command -v python3 2>/dev/null || true)"
for tec_python in "$tec_found" /opt/homebrew/bin/python3 /usr/local/bin/python3 /usr/bin/python3; do
  if [ -n "$tec_python" ] && [ -x "$tec_python" ] && "$tec_python" -c 'import sys;sys.exit(0 if sys.version_info >= (3,8) else 1)' >/dev/null 2>&1; then
    exec "$tec_python" "$tec_root/Start-Local-HTTP.py" --open
  fi
done
printf '\nPython 3.8 or newer is required for local HTTP.\nDirect opening of index.html is still available.\n'
printf 'Press Return to close this window.'
read -r tec_reply || true
exit 1
