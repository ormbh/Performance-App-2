Performance App v175 — optional local HTTP package

This package contains the exact unchanged 23-file v175 app, plus this guide and two optional launcher files. The existing Design Principles Revision 39, calculations, layout and PDF fixes are unchanged.

MAC — LOCAL HTTP
1. Extract the whole ZIP into a folder on your Mac.
2. Double-click Start Local HTTP.command. Python 3.8 or newer must already be available. No additional Python packages are needed; the launcher does not install software.
3. The launcher opens Google Chrome at http://127.0.0.1:8765/index.html. If it does not open automatically, copy that address into Chrome.
4. Leave the launcher window open. Select your workbook in the app as usual.
5. To stop, press Control+C in the launcher window, then close it.

The launcher binds only to 127.0.0.1 on this computer. It returns the packaged static assets; it has no workbook upload endpoint and does not save selected workbooks on the server. The app continues to read its selected files in the browser.

Use the same address and port each time. Browser storage for HTTP is separate from file:// storage; the first HTTP launch requires selecting the workbook again. The existing 24-hour saved-workbook expiry still applies. Changing the port or using localhost instead of 127.0.0.1 creates a different browser origin and therefore separate saved data. Do not expect file:// sessions to transfer automatically to HTTP.

If the same copy is already running, launching it again opens its existing server. If another app or another extracted copy is using port 8765, the launcher stops with a clear message rather than silently choosing a new port. Close the other launcher and try again.

DIRECT FILE
Double-click index.html as before. No launcher is required for this mode. Mac direct-file acceptance remains only partially verified; see the existing v175 verification limitations.

MANUAL START
From a terminal in this extracted folder, run:
python3 Start-Local-HTTP.py --open
An explicit alternative port is available with --port 8766. Saved browser data will belong to that different origin.

The Python server and HTTP application flow are verified in the cloud on Linux Chromium. The macOS Finder .command launch and automatic Chrome activation cannot be executed in that environment and are not certified by cloud tests. If macOS refuses to open the launcher, retain the exact message for review; no browser-security setting change is part of this package.
