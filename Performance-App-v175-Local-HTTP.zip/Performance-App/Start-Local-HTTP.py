#!/usr/bin/env python3
"""Serve this unchanged app on loopback only. Python 3.8+, standard library only."""
import argparse
import errno
import hashlib
import json
import mimetypes
from pathlib import Path
import subprocess
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlsplit
from urllib.request import ProxyHandler, build_opener

ROOT = Path(__file__).resolve().parent
SERVER_ID = 'saytara-local-http-v1'
# Distribution assets only: source workbooks and arbitrary neighboring files
# are not served, even when somebody places them inside the app folder.
FILES = frozenset(('README.txt', 'assets/css/app-bundle.css', 'assets/css/print-measure-bundle.css', 'assets/fonts/DIN-Next-Arabic-Regular.otf', 'assets/fonts/DIN-Next-LT-Arabic-Regular.ttf', 'assets/fonts/Dubai-Bold.otf', 'assets/fonts/Dubai-Regular.otf', 'assets/fonts/OFL.txt', 'assets/icons/app-192.png', 'assets/icons/app-512.png', 'assets/icons/apple-touch-icon.png', 'assets/img/agenda-cover.jpg', 'assets/img/agenda-logos.png', 'assets/img/search-background.png', 'assets/img/search-mashrabiya.jpg', 'assets/img/tec-positive.png', 'assets/img/tec-red.png', 'assets/js/app-bundle.js', 'assets/js/lib/offline-pdf-engine.js', 'assets/vendor/offline-pdf-LICENSES.txt', 'assets/vendor/tec-pdf-symbols-LICENSE.txt', 'index.html', 'manifest.webmanifest'))


def asset_path(name):
    target = ROOT
    for part in Path(name).parts:
        target = target / part
        if target.is_symlink():
            return None
    try:
        target.resolve().relative_to(ROOT)
    except (OSError, ValueError, RuntimeError):
        return None
    return target


def identity():
    digest = hashlib.sha256()
    for name in ('index.html', 'assets/js/app-bundle.js'):
        digest.update((ROOT / name).read_bytes())
    return {'server': SERVER_ID, 'appHash': digest.hexdigest(),
            'folderHash': hashlib.sha256(str(ROOT).encode('utf-8')).hexdigest()}


class AppServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def do_GET(self):
        self.serve(False)

    def do_HEAD(self):
        self.serve(True)

    def serve(self, head):
        port = self.server.server_port
        if self.headers.get('Host') not in ('127.0.0.1:' + str(port),
                                            'localhost:' + str(port)):
            self.send_error(403, 'Use the local app address printed by the launcher.')
            return
        try:
            path = unquote(urlsplit(self.path).path, errors='strict')
        except (ValueError, UnicodeError):
            self.send_error(400)
            return
        if path == '/_saytara_local/status':
            content = json.dumps(self.server.identity).encode('utf-8')
            mime = 'application/json; charset=utf-8'
        else:
            name = 'index.html' if path == '/' else path[1:]
            if not path.startswith('/') or name not in FILES:
                self.send_error(404)
                return
            try:
                target = asset_path(name)
                if target is None:
                    self.send_error(404)
                    return
                content = target.read_bytes()
            except (OSError, ValueError, RuntimeError):
                self.send_error(404)
                return
            mime = {'.otf': 'font/otf', '.ttf': 'font/ttf',
                    '.webmanifest': 'application/manifest+json'}.get(target.suffix)
            mime = mime or mimetypes.guess_type(str(target))[0] or 'application/octet-stream'
            if mime.startswith('text/') or mime in ('application/javascript',
                                                      'application/manifest+json'):
                mime += '; charset=utf-8'
        self.send_response(200)
        self.send_header('Content-Type', mime)
        self.send_header('Content-Length', str(len(content)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        if not head:
            try:
                self.wfile.write(content)
            except (BrokenPipeError, ConnectionResetError):
                pass


def open_browser(url):
    try:
        if sys.platform == 'darwin':
            result = subprocess.run(['/usr/bin/open', '-a', 'Google Chrome', url],
                                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if result.returncode == 0:
                return True
        print('Open this address in Chrome: ' + url, flush=True)
    except OSError:
        print('Open this address in Chrome: ' + url, flush=True)
    return False


def matching_server(port, expected):
    if not port:
        return False
    url = 'http://127.0.0.1:' + str(port) + '/_saytara_local/status'
    try:
        # A loopback status probe must never be sent to a configured proxy.
        with build_opener(ProxyHandler({})).open(url, timeout=1) as response:
            return json.loads(response.read(4096).decode('utf-8')) == expected
    except (OSError, ValueError):
        return False


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', type=int, default=8765,
                        help='Local port; default 8765. A different port has separate browser storage.')
    parser.add_argument('--open', action='store_true', help='Open Chrome on macOS.')
    args = parser.parse_args(argv)
    if not 0 <= args.port <= 65535:
        parser.error('Port must be between 0 and 65535.')
    if not all(asset_path(name) is not None and asset_path(name).is_file() for name in FILES):
        print('Extract the complete ZIP and keep the assets folder beside index.html.', file=sys.stderr)
        return 1
    expected = identity()
    try:
        server = AppServer(('127.0.0.1', args.port), Handler)
    except OSError as exc:
        if exc.errno == errno.EADDRINUSE and matching_server(args.port, expected):
            url = 'http://127.0.0.1:' + str(args.port) + '/index.html'
            print('This app is already running.\nURL: ' + url, flush=True)
            if args.open:
                open_browser(url)
            return 0
        print('Cannot start local HTTP on port ' + str(args.port) +
              '. Close the other server or launcher using that port and try again.', file=sys.stderr)
        return 1
    server.identity = expected
    url = 'http://127.0.0.1:' + str(server.server_port) + '/index.html'
    print('Performance App v175 — local HTTP\nURL: ' + url +
          '\nKeep this launcher window open while using the app.' +
          '\nPress Control+C here to stop the server.\n', flush=True)
    if args.open:
        open_browser(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\nLocal HTTP stopped.', flush=True)
    finally:
        server.server_close()
    return 0


if __name__ == '__main__':
    sys.exit(main())
