Performance App v162

1. Extract the complete ZIP.
2. Open index.html in your browser.
3. Select your report workbook.

Keep the assets folder and manifest.webmanifest beside index.html.
The app reads your workbook locally. No workbook is included.

This package contains the app only. Documentation and earlier releases:
https://github.com/ormbh/Performance-App-2

تطبيق تقارير الأداء والتنفيذ
استخرج ملف ZIP كاملاً، ثم افتح index.html واختر ملف التقرير.
احتفظ بمجلد assets وملف manifest.webmanifest بجانب index.html.
