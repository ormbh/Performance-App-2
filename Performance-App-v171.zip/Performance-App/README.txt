Performance App v171 — Desktop / PDF standard

Extract the ZIP and keep index.html, assets and manifest.webmanifest together. No workbook is bundled.

Desktop is the supported design/testing target. Existing responsive code is retained.
PDF only: full content-height PDF for monthly, portfolio, entity, comparison, results and data checks; A4 landscape for agenda, council decisions and special projects. Very long full PDFs continue at the same width when the PDF engine's physical page-height limit is reached. No A4 portrait fallback or PowerPoint export.

Monthly thin status strips are restored. Approved detailed report charts, source eligibility, exact comparison matching and local workbook sessions are preserved. Original workbooks are not modified.

Hosted desktop Chromium and actual native PDF downloads are verified with separate illustrative/synthetic fixtures. Other browsers, direct-file behavior, Excel recalculation and Power Query refresh are not certified. Mobile/tablet and PowerPoint testing are outside scope.
