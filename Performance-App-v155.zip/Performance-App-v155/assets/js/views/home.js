/*
 * Performance reporting · search home (S2) and the shared search box with suggestions.
 */
(function (S) {
  'use strict';

  var U = S.util, SC = S.schema, UI = S.ui;
  var PLACEHOLDER = 'ابحث عن بند أو مشروع أو مسؤول';

  function searchBox(state, size) {
    var q = state.search.q;
    return '' +
      '<div class="sbox sbox-' + size + '" id="sbox" role="search" aria-label="البحث في ملف التقرير">' +
      '  <div class="sfield">' + (size === 'lg' ? U.icon('search', 22, 'sfield-ic') : '<button type="button" class="search-submit tec-search-compact-submit" data-act="sug-all" aria-label="بحث في التقرير">' + U.icon('search', 20) + '</button>') +
      '    <input id="q" type="search" role="combobox" aria-expanded="false" aria-haspopup="listbox" dir="' + (q.trim() ? 'auto' : 'rtl') + '" autocomplete="off" spellcheck="false" value="' + U.esc(q) + '" placeholder="' + PLACEHOLDER + '" aria-label="ابحث بالاسم أو الرقم أو مسؤول المتابعة" aria-controls="sug" aria-autocomplete="list">' +
      '    <button type="button" class="sclear' + (q ? '' : ' is-hidden') + '" data-act="clear-q" aria-label="مسح">' + U.icon('x', 16) + '</button>' +
      '  </div>' +
      '  <div id="sug" class="sug" role="listbox" aria-label="اقتراحات" hidden></div>' +
      '</div>';
  }

  function routeLink(screen, action, label, cls, icon, current, report, state, trustedMarkup) {
    var patch = report && state ? Object.assign({}, state, {report:Object.assign({}, state.report, {kind:report})}) : undefined;
    var href = S.app && S.app.href ? S.app.href(screen, patch) : '#/' + screen;
    return '<a href="' + U.esc(href) + '" data-screen-link="' + screen + '" data-act="' + action + '"' + (report ? ' data-report="' + report + '"' : '') + ' class="' + cls + '"' + (cls === 'tec-search-menu-link' ? ' role="menuitem"' : '') + (current ? ' aria-current="page"' : '') + '>' + (icon ? U.icon(icon, 20) : '') + (trustedMarkup ? label : U.esc(label)) + '</a>';
  }

  /* Task-focused navigation shares the real app actions, without introducing a
     second search model or interfering with the existing facet/report menus. */
  function toolsMenu(state) {
    var current = state.screen === 'home' || state.screen === 'results';
    return '<div class="tec-search-top-actions">' +
      (state.screen === 'results' ? routeLink('home', 'go-home', 'البحث', 'tec-search-top-link', null, true) : '') +
      '<div class="tec-search-tools-wrap">' +
      '<button type="button" class="tec-search-icon-button" data-act="search-tools-toggle" aria-label="صفحات التطبيق" aria-haspopup="menu" aria-controls="tec-search-tools-menu" aria-expanded="false">' + U.icon('grid', 20) + '</button>' +
      '<nav id="tec-search-tools-menu" class="tec-search-tools-menu" role="menu" aria-label="صفحات التطبيق" hidden>' +
      routeLink('home', 'go-home', 'البحث في الأداء', 'tec-search-menu-link', 'search', current) +
      routeLink('dashboard', 'go-dash', 'التقرير الشهري', 'tec-search-menu-link', 'grid') +
      routeLink('projects', 'go-projects', 'محفظة المشاريع', 'tec-search-menu-link', 'rows') +
      routeLink('entities', 'go-entities', 'تقرير الجهات', 'tec-search-menu-link', 'entities') +
      ['agenda','council','hh'].map(function (kind) {
        return routeLink('reports', 'show-report', S.views.reports.title(kind), 'tec-search-menu-link', 'file', false, kind, state);
      }).join('') +
      '<button type="button" class="tec-search-menu-link" role="menuitem" data-act="go-checks">' + U.icon('warn', 20) + 'ملاحظات البيانات</button>' +
      '<button type="button" class="tec-search-menu-link" role="menuitem" data-act="change-file">' + U.icon('upload', 20) + 'رفع ملف التقرير</button>' +
      routeLink('comparison', 'go-comparison', 'المقارنة الشهرية', 'tec-search-menu-link', 'compare') +
      '</nav></div></div>';
  }

  function toggleTools(trigger, focusFirst) {
    var wrap = trigger && trigger.closest('.tec-search-tools-wrap');
    var menu = wrap && wrap.querySelector('.tec-search-tools-menu');
    if (!menu) return false;
    var open = menu.hidden;
    closeTools(false);
    menu.hidden = !open;
    trigger.setAttribute('aria-expanded', String(open));
    if (open) positionHomeTools();
    if (open && focusFirst) {
      var first = menu.querySelector('a, button:not(:disabled)');
      if (first) first.focus();
    }
    return open;
  }

  /* The home menu follows its centered action row and stays inside the visible
     viewport, including when the phone keyboard changes the available height. */
  function positionHomeTools() {
    var menu = document.querySelector('.screen.home .tec-search-tools-menu:not([hidden])');
    if (!menu) return;
    var trigger = menu.parentNode.querySelector('[data-act="search-tools-toggle"]');
    var viewport = window.visualViewport, left = viewport ? viewport.offsetLeft : 0,
      top = viewport ? viewport.offsetTop : 0, width = viewport ? viewport.width : innerWidth,
      height = viewport ? viewport.height : innerHeight, rect = trigger.getBoundingClientRect();
    var menuWidth = Math.min(320, Math.max(1, width - 24));
    menu.style.setProperty('--tec-home-menu-width', menuWidth + 'px');
    menu.style.setProperty('--tec-home-menu-height', Math.max(1, height - 24) + 'px');
    var menuHeight = menu.getBoundingClientRect().height;
    var y = rect.bottom + 8;
    if (y + menuHeight > top + height - 12) y = rect.top - menuHeight - 8;
    menu.style.setProperty('--tec-home-menu-left', Math.max(left + 12, Math.min(rect.right - menuWidth, left + width - menuWidth - 12)) + 'px');
    menu.style.setProperty('--tec-home-menu-top', Math.max(top + 12, Math.min(y, top + height - menuHeight - 12)) + 'px');
  }

  window.addEventListener('resize', positionHomeTools);
  document.addEventListener('scroll', positionHomeTools, true);
  if (window.visualViewport) {
    window.visualViewport.addEventListener('resize', positionHomeTools);
    window.visualViewport.addEventListener('scroll', positionHomeTools);
  }

  function closeTools(returnFocus, target) {
    var closed = false;
    Array.prototype.forEach.call(document.querySelectorAll('.tec-search-tools-wrap'), function (wrap) {
      if (target && wrap.contains(target)) return;
      var menu = wrap.querySelector('.tec-search-tools-menu'), trigger = wrap.querySelector('[data-act="search-tools-toggle"]');
      if (!menu || menu.hidden) return;
      menu.hidden = true;
      if (trigger) { trigger.setAttribute('aria-expanded', 'false'); if (returnFocus) trigger.focus(); }
      closed = true;
    });
    return closed;
  }

  function handleToolsKey(event) {
    var target = event.target, wrap = target.closest && target.closest('.tec-search-tools-wrap');
    if (event.key === 'Escape' && document.querySelector('.tec-search-tools-menu:not([hidden])')) {
      event.preventDefault(); closeTools(true); return true;
    }
    if (!wrap || ['ArrowDown', 'ArrowUp', 'Home', 'End'].indexOf(event.key) < 0) return false;
    var menu = wrap.querySelector('.tec-search-tools-menu'), trigger = wrap.querySelector('[data-act="search-tools-toggle"]');
    if (!menu) return false;
    event.preventDefault();
    if (menu.hidden) toggleTools(trigger, false);
    var items = Array.prototype.slice.call(menu.querySelectorAll('a, button:not(:disabled)')), at = items.indexOf(target);
    var next = event.key === 'Home' ? 0 : event.key === 'End' ? items.length - 1 : event.key === 'ArrowDown' ? (at + 1) % items.length : at < 0 ? items.length - 1 : (at - 1 + items.length) % items.length;
    if (items[next]) items[next].focus();
    return true;
  }

  function searchHeader(state) {
    return '<a class="app-skip-link" href="#app-main" data-act="skip-content">انتقل إلى المحتوى</a>' +
      '<header class="r-head tec-search-header" aria-label="البحث والمحافظ"><div class="r-head-in">' +
      routeLink('home', 'go-home', '<img class="tec-search-result-logo" src="assets/img/tec-red.png" alt="المجلس التنفيذي — The Executive Council">', 'tec-search-logo-link', null, false, null, null, true) +
      searchBox(state, 'md') + toolsMenu(state) + '</div>' +
      '<div class="tabs" id="r-tabs" role="tablist" aria-label="محافظ نتائج البحث"></div></header>';
  }

  /* Suggestions while typing (two characters or a number). */
  function suggestions(state) {
    var q = state.search.q, data = state.data;
    var toks = S.search.tokens(q), joined = toks.join('');
    if (!state.sugOpen || !data || !(joined.length >= 2 || /^\d+$/.test(joined))) return '';
    var sg = S.search.suggest(data, q);
    var html = '';
    if (state.screen === 'home') {
      html += '<button type="button" class="sug-all" data-act="sug-all" role="option">' + U.icon('search', 16) +
        'عرض كل النتائج لـ «<span dir="auto">' + U.esc(q.trim()) + '</span>»<span class="sug-count">النتائج: ' + U.metricText(sg.total) + '</span></button>';
    }
    if (sg.items.length) {
      html += '<div class="sug-h">النتائج</div>' + sg.items.map(function (h) {
        var it = h.it;
        return '<button type="button" class="sug-item" data-act="sug-item" data-key="' + U.esc(it.key) + '" role="option">' +
          '<span class="sug-title" dir="' + it.dir + '">' + S.search.highlight(it.title, sg.toks) + '</span>' +
          '<span class="sug-meta">#' + U.esc(it.ref) + ' · ' + UI.pfName(it.pf) + '</span></button>';
      }).join('');
    }
    if (sg.people.length) {
      html += '<div class="sug-h">الأشخاص</div>' + sg.people.map(function (p) {
        return '<button type="button" class="sug-person" data-act="sug-person" data-name="' + U.esc(p.name) + '" role="option">' +
          '<span dir="auto">' + S.search.highlight(p.name, sg.toks) + '</span><span class="sug-count">المنسق · النتائج: ' + U.metricText(p.n) + '</span></button>';
      }).join('');
    }
    if (sg.pfs.length) {
      html += '<div class="sug-h">المحافظ</div>' + sg.pfs.map(function (pf) {
        return '<button type="button" class="sug-pf" data-act="sug-pf" data-pf="' + pf + '" role="option">' + UI.pfName(pf) + '</button>';
      }).join('');
    }
    if (!sg.items.length && !sg.people.length && !sg.pfs.length) {
      html += '<div class="sug-none">لا توجد اقتراحات. اضغط Enter لعرض النتائج.</div>';
    }
    return html;
  }

  function scopeChips(state) {
    return S.search.TABS.map(function (t) {
      var on = state.search.tab === t;
      return '<button type="button" class="scope-chip' + (on ? ' is-on' : '') + '" data-act="scope" data-tab="' + t + '" aria-pressed="' + on + '">' +
        (t === 'all' ? 'الكل' : UI.pfName(t)) + '</button>';
    }).join('');
  }

  function fileBar(state) {
    var d = state.data, issues = d.issues.filter(function (x) { return x.sev !== 'info'; }).length;
    return '<div class="filebar">' +
      '<button type="button" class="linkbtn" data-act="go-checks">ملاحظات البيانات: ' + U.metricText(issues) + '</button>' +
      '<button type="button" class="linkbtn" data-act="change-file">' + U.icon('upload', 15) + 'تغيير الملف</button></div>';
  }

  function render(state) {
    return '' +
      '<div class="screen home tec-approved-search" data-screen="home">' +
      '<a class="app-skip-link" href="#app-main" data-act="skip-content">انتقل إلى المحتوى</a>' +
      '  <main class="tec-search-home-main"><section class="tec-search-home-content" aria-labelledby="tec-search-home-title">' +
      '    <img class="tec-search-home-logo" src="assets/img/tec-red.png" alt="المجلس التنفيذي — The Executive Council">' +
      '    <div class="tec-search-home-title-frame"><h1 id="tec-search-home-title">البحث في الأداء</h1></div>' +
      searchBox(state, 'lg') +
      '    <div class="tec-search-home-actions">' + toolsMenu(state) + '<button type="button" class="btn btn-primary" data-act="sug-all">بحث في التقرير</button><button type="button" class="btn btn-outline search-browse-all" data-act="browse-all">عرض جميع النتائج</button></div>' +
      '  </section></main>' +
      '</div>';
  }

  S.views.home = { render: render, searchBox: searchBox, suggestions: suggestions, scopeChips: scopeChips, fileBar: fileBar, searchHeader: searchHeader, toolsMenu: toolsMenu, toggleTools: toggleTools, closeTools: closeTools, handleToolsKey: handleToolsKey };
})(window.Saytara = window.Saytara || {});
