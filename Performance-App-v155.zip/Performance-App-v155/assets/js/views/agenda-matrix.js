/* Approved agenda matrix. Source report eligibility, status order and effective periods are unchanged. */
(function (S) {
  'use strict';
  function node(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }
  function num(value, cls) {
    var e = node('bdi', cls, value === 0 ? '–' : String(value));
    if (value === 0) e.setAttribute('aria-label', 'صفر');
    e.dir = 'ltr';
    return e;
  }
  function appearance(name) {
    if (S.ui.statusAppearance) return S.ui.statusAppearance(name);
    var color = S.ui.chartStatusColor(name);
    return { fill: color, ink: S.ui.chartStatusInk ? S.ui.chartStatusInk(name) : '#4F4E4E',
      border: S.ui.chartStatusBorder ? S.ui.chartStatusBorder(name) : color };
  }
  function specification(state) {
    var A = S.agendaReport;
    var selected = S.filterOptions.single(state.report.type);
    var full = selected === null;
    var options = S.views.agendaPage.options(state);
    var model = A.model(state.data, state.dash, state.report.type || '', options);
    var cohorts = full ? [
      { id: 'approved', name: 'الأجندة المعتمدة', items: model.planned },
      { id: 'emerging', name: 'المواضيع المستجدة', items: model.emerging }
    ] : [{
      id: selected === 'مستجد' ? 'emerging' : selected === 'الأجندة السنوية' ? 'approved' : 'other',
      name: selected === 'مستجد' ? 'المواضيع المستجدة' : selected === 'الأجندة السنوية' ? 'الأجندة المعتمدة' : String(selected),
      items: model.items
    }];
    if (full && model.other.length) cohorts.push({ id: 'other', name: 'مواضيع غير مصنفة', items: model.other });
    // Empty categories have no records to compare in the selected report scope.
    cohorts = cohorts.filter(function (cohort) { return cohort.items.length > 0; });
    var active = A.stats(model.items, state.data).map(function (entry) { return entry.name; });
    var sourceOrder = S.order.statuses(state.data, 'agenda');
    var statusNames = sourceOrder.filter(function (name) { return active.indexOf(name) >= 0; })
      .concat(active.filter(function (name) { return sourceOrder.indexOf(name) < 0; }));
    var spec = {
      total: model.total, planned: model.planned.length, emerging: model.emerging.length,
      other: model.other.length, year: model.year, sourcePeriod: model.period, sourceDate: model.date,
      statuses: statusNames.map(function (name) {
        var category = S.rules.catOf(name), style = appearance(name);
        return { name: name, color: style.fill, border: style.border, ink: style.ink,
          textColor: S.ui.statusTextColor ? S.ui.statusTextColor(name) :
            (category === 'delayed' || category === 'done' || category === 'ready' ? style.fill : '#4F4E4E') };
      }),
      // groups() preserves source quarter ordering, latest valid amended dates,
      // existing carryover rules and the explicit undated group.
      displayQuarters: A.groups(state.data, model.items).map(function (group) {
        return { key: group.key, name: group.name };
      }),
      cohorts: [], scale: { min: 0, max: 0, unit: 'عدد المواضيع' },
      sourceRecordKeys: model.items.map(function (item) { return item.key; })
    };
    cohorts.forEach(function (cohort) {
      var counts = Object.create(null);
      A.stats(cohort.items, state.data).forEach(function (entry) { counts[entry.name] = entry.n; });
      var output = {
        id: cohort.id, name: cohort.name, total: cohort.items.length,
        recordKeys: cohort.items.map(function (item) { return item.key; }),
        totals: statusNames.map(function (name) { return { name: name, count: counts[name] || 0 }; }),
        quarters: []
      };
      A.groups(state.data, cohort.items).forEach(function (group) {
        var quarterCounts = Object.create(null);
        A.stats(group.items, state.data).forEach(function (entry) { quarterCounts[entry.name] = entry.n; });
        spec.scale.max = Math.max(spec.scale.max, group.items.length);
        output.quarters.push({
          key: group.key, name: group.name, total: group.items.length,
          recordKeys: group.items.map(function (item) { return item.key; }),
          cells: statusNames.map(function (name) {
            var count = quarterCounts[name] || 0;
            var style = appearance(name);
            return { name: name, count: count, color: style.fill, border: style.border, ink: style.ink };
          })
        });
      });
      spec.cohorts.push(output);
    });
    var largest = spec.scale.max;
    var roughStep = largest / 5;
    var magnitude = Math.pow(10, Math.floor(Math.log10(Math.max(1, roughStep))));
    var step = [1, 2, 5, 10].map(function (n) { return n * magnitude; }).find(function (n) { return n >= roughStep; }) || magnitude * 10;
    spec.scale.step = Math.max(1, step);
    spec.scale.max = largest ? Math.ceil(largest / spec.scale.step) * spec.scale.step : 0;
    spec.scale.basis = 'quarter-total';
    spec.scale.ticks = [];
    for (var tick = 0; tick <= spec.scale.max; tick += spec.scale.step) spec.scale.ticks.push(tick);
    return spec;
  }
  function svgNode(tag, cls, attrs, text) {
    var e = document.createElementNS('http://www.w3.org/2000/svg', tag);
    if (cls) e.setAttribute('class', cls);
    Object.keys(attrs || {}).forEach(function (key) { e.setAttribute(key, String(attrs[key])); });
    if (text != null) e.textContent = text;
    return e;
  }
  function quarterLines(name, limit) {
    var words = String(name).split(/\s+/), lines = [''];
    words.forEach(function (word) {
      var last = lines.length - 1;
      if (lines[last] && (lines[last] + ' ' + word).length > (limit || 14)) lines.push(word);
      else lines[last] += (lines[last] ? ' ' : '') + word;
    });
    return lines;
  }
  function shortQuarter(name) {
    var ordinary = ['الربع الأول', 'الربع الثاني', 'الربع الثالث', 'الربع الرابع'];
    var index = ordinary.indexOf(name);
    if (index >= 0) return 'ربع ' + (index + 1);
    for (var i = 0; i < ordinary.length; i++) {
      if (name.indexOf(ordinary[i] + ' ') === 0) return 'ربع ' + (i + 1) + name.slice(ordinary[i].length);
    }
    return name;
  }
  function detailContent(target, label, values) {
    target.replaceChildren(node('p', 'a-status-context', label));
    var row = node('div', 'a-status-values');
    values.forEach(function (status) {
      var item = node('span', 'a-status-detail');
      item.dataset.status = status.name;
      item.dataset.count = String(status.count);
      item.style.color = status.textColor;
      var value = num(status.count, 'a-detail-number');
      if (!status.count) value.style.color = '#4F4E4E';
      item.append(node('span', '', status.name), value);
      row.append(item);
    });
    target.append(row);
  }
  function chart(spec, cohort, displayQuarters, index) {
    var width = Math.max(650, displayQuarters.length * 118 + 88);
    var maxShortLines = Math.max.apply(null, displayQuarters.map(function (q) { return quarterLines(shortQuarter(q.name), 10).length; }));
    var bottomPad = 72 + Math.max(0, maxShortLines - 2) * 48;
    var height = 480, topPad = 36, bottom = topPad + height;
    var viewHeight = bottom + bottomPad;
    var left = 26, right = width - 70;
    var slot = (right - left) / Math.max(1, displayQuarters.length);
    var barWidth = Math.min(62, slot * .52);
    var drawing = svgNode('svg', 'a-quarter-chart', {
      viewBox: '0 0 ' + width + ' ' + viewHeight, role: 'group',
      'aria-label': cohort.name + '؛ عدد المواضيع حسب الربع',
      'data-scale-max': spec.scale.max, 'data-scale-basis': 'quarter-total',
      'data-plot-height': height, 'data-plot-top': topPad, 'data-bottom-padding': bottomPad,
      'data-count-fit-policy': 'measured-ink-no-segment-inflation', 'data-output-profile': 'screen'
    });
    spec.scale.ticks.forEach(function (tick) {
      var y = bottom - height * tick / spec.scale.max;
      drawing.append(svgNode('line', 'a-chart-grid', { x1: left, x2: right, y1: y, y2: y, 'data-count': tick }));
      drawing.append(svgNode('text', 'a-axis-label', {
        x: right + 28, y: y + 4, 'text-anchor': 'middle', direction: 'ltr', 'data-count': tick
      }, tick === 0 ? '–' : tick));
    });
    var detail = node('div', 'a-quarter-detail');
    detail.id = 'ag-quarter-detail-' + index;
    detail.setAttribute('aria-live', 'polite');
    detail.setAttribute('aria-atomic', 'true');
    var totals = spec.statuses.slice().reverse().map(function (status) {
      var total = cohort.totals.find(function (entry) { return entry.name === status.name; });
      return { name: status.name, count: total ? total.count : 0, color: status.color,
        border: status.border, ink: status.ink, textColor: status.textColor };
    });
    detail.dataset.statusTotals = JSON.stringify(totals);
    detail.dataset.detailMode = 'totals';
    detailContent(detail, 'الإجمالي حسب الحالة', totals);
    displayQuarters.forEach(function (q, qi) {
      var x = right - slot * (qi + .5);
      var top = bottom - height * q.total / spec.scale.max;
      var values = spec.statuses.slice().reverse().map(function (status) {
        var cell = q.cells.find(function (cell) { return cell.name === status.name; });
        return { name: status.name, count: cell ? cell.count : 0, color: status.color,
          border: status.border, ink: status.ink, textColor: status.textColor };
      });
      var description = q.name + ': ' + q.total + ' موضوع؛ ' + values.map(function (s) { return s.name + ' ' + s.count; }).join('، ');
      var group = svgNode('g', 'a-quarter-bar', {
        tabindex: '0', role: 'button', 'aria-label': description,
        'aria-pressed': 'false',
        'aria-controls': detail.id, 'data-quarter': q.key, 'data-quarter-name': q.name,
        'data-count': q.total, 'data-status-counts': JSON.stringify(values),
        'data-resolved-zero-quarter': String(!!q.resolvedZero)
      });
      group.append(svgNode('title', '', {}, description));
      group.append(svgNode('rect', 'a-bar-focus', {
        x: x - slot * .46, y: Math.max(30, top - 36), width: slot * .92,
        height: bottom - Math.max(30, top - 36) + 80 + Math.max(0, quarterLines(shortQuarter(q.name), 10).length - 2) * 48, rx: 6
      }));
      group.append(svgNode('text', 'a-quarter-total', {
        x: x, y: top - 12, 'text-anchor': 'middle', direction: 'ltr', 'data-count': q.total
      }, q.total === 0 ? '–' : q.total));
      var cursor = bottom;
      values.forEach(function (status) {
        if (!status.count) return;
        var segmentHeight = height * status.count / spec.scale.max;
        cursor -= segmentHeight;
        var segment = svgNode('rect', 'a-quarter-segment', {
          x: x - barWidth / 2, y: cursor, width: barWidth, height: segmentHeight,
          fill: status.color, stroke: status.border, 'data-status': status.name, 'data-count': status.count
        });
        segment.append(svgNode('title', '', {}, status.name + ': ' + status.count));
        group.append(segment);
        // Labels never change the numeric segment height. They start hidden until
        // the connected SVG and loaded DIN font can be measured at its real size.
        var label = svgNode('text', 'a-inbar-count', {
          x: x, y: cursor + segmentHeight / 2, 'text-anchor': 'middle', direction: 'ltr',
          'aria-hidden': 'true', 'data-status': status.name, 'data-count': status.count,
          'data-fits': 'false', 'data-min-screen-size': '16', visibility: 'hidden'
        }, status.count);
        label.style.fill = status.ink || appearance(status.name).ink || '#4F4E4E';
        group.append(label);
      });
      ['long', 'short'].forEach(function (mode) {
        var label = svgNode('text', 'a-quarter-label a-quarter-' + mode, { x: x, y: bottom + 31, 'text-anchor': 'middle' });
        quarterLines(mode === 'short' ? shortQuarter(q.name) : q.name, mode === 'short' ? 10 : 14).forEach(function (line, li) {
          label.append(svgNode('tspan', '', { x: x, dy: li ? '1.25em' : 0 }, line));
        });
        group.append(label);
      });
      drawing.append(group);
    });
    var scroll = node('div', 'a-chart-scroll');
    scroll.style.setProperty('--chart-min-width', displayQuarters.length > 4 ? (displayQuarters.length * 64 + 64) + 'px' : '0px');
    scroll.append(node('p', 'a-axis-title', 'عدد المواضيع'), drawing);
    return { drawing: scroll, detail: detail };
  }
  function countTable(spec, c, displayQuarters, ci) {
    var disclosure = node('details', 'a-count-disclosure');
    disclosure.append(node('summary', '', 'تفاصيل الأعداد حسب الربع'));
    var scroller = node('div', 'a-count-table-scroll');
    var table = node('table', 'a-matrix');
    table.setAttribute('aria-label', c.name + ': حالات الإنجاز في الصفوف والأرباع في الأعمدة');
    var cols = node('colgroup');
    cols.append(node('col', 'a-status-col'));
    displayQuarters.forEach(function () { cols.append(node('col', 'a-quarter-col')); });
    cols.append(node('col', 'a-sum-col'));
    table.append(cols);
    var thead = node('thead'), hr = node('tr');
    var sh = node('th', 'a-status-heading', 'الحالة');
    sh.scope = 'col'; hr.append(sh);
    displayQuarters.forEach(function (q, qi) {
      var qh = node('th', 'a-quarter-heading', q.name);
      qh.scope = 'col'; qh.id = 'ag-matrix-quarter-' + ci + '-' + qi; hr.append(qh);
    });
    var sumHead = node('th', '', 'الإجمالي');
    sumHead.scope = 'col'; hr.append(sumHead); thead.append(hr); table.append(thead);
    var tbody = node('tbody');
    spec.statuses.forEach(function (status, si) {
      var row = node('tr'); row.dataset.status = status.name;
      row.style.setProperty('--agenda-count-ink', status.textColor);
      var label = node('th', 'a-status-name', status.name);
      label.scope = 'row'; label.style.color = status.textColor;
      label.id = 'ag-matrix-status-' + ci + '-' + si; row.append(label);
      displayQuarters.forEach(function (q, qi) {
        var cell = q.cells.find(function (x) { return x.name === status.name; });
        var count = cell ? cell.count : 0;
        var td = node('td', 'a-chart-cell');
        td.dataset.status = status.name; td.dataset.quarter = String(q.key); td.dataset.count = String(count);
        td.dataset.resolvedZeroQuarter = String(!!q.resolvedZero);
        td.dataset.sourceRecordCount = String(q.recordKeys.length);
        td.setAttribute('headers', label.id + ' ag-matrix-quarter-' + ci + '-' + qi);
        td.append(num(count, 'a-cell-number')); row.append(td);
      });
      var t = c.totals.find(function (x) { return x.name === status.name; });
      var sum = node('td', 'a-status-total');
      sum.dataset.status = status.name; sum.dataset.count = String(t ? t.count : 0);
      sum.append(num(t ? t.count : 0, 'a-cell-number')); row.append(sum); tbody.append(row);
    });
    table.append(tbody);
    var tfoot = node('tfoot'), fr = node('tr');
    var footLabel = node('th', 'a-status-name', 'الإجمالي'); footLabel.scope = 'row'; fr.append(footLabel);
    displayQuarters.forEach(function (q) {
      var qt = node('td', 'a-quarter-total');
      qt.dataset.quarter = String(q.key); qt.dataset.count = String(q.total);
      qt.dataset.resolvedZeroQuarter = String(!!q.resolvedZero);
      qt.append(num(q.total, 'a-cell-number')); fr.append(qt);
    });
    var finalTotal = node('td', 'a-status-total a-final-total');
    finalTotal.setAttribute('aria-hidden', 'true'); fr.append(finalTotal);
    tfoot.append(fr); table.append(tfoot); scroller.append(table); disclosure.append(scroller);
    return disclosure;
  }
  function element(spec) {
    var quarterColumns = spec.displayQuarters;
    var root = node('section', 'ag-matrix-overview'); root.dir = 'rtl';
    root.setAttribute('aria-label', 'ملخص الأجندة السنوية — الحالات حسب الربع');
    root.dataset.sourceTotal = String(spec.total);
    root.dataset.statusKeys = JSON.stringify(spec.statuses.map(function (status) { return status.name; }));
    root.dataset.cohortCount = String(spec.cohorts.length);
    root.dataset.scaleMin = '0'; root.dataset.scaleMax = String(spec.scale.max);
    root.dataset.scaleBasis = 'quarter-total'; root.dataset.scaleStep = String(spec.scale.step);
    root.dataset.displayQuarterKeys = JSON.stringify(quarterColumns.map(function (q) { return q.key; }));
    root.dataset.presentationQuarterPolicy = 'shared-active-union';
    var lead = node('header', 'a-overview-lead'), total = node('div', 'a-grand-total');
    total.append(num(spec.total, 'a-total-number'), node('span', '', 'الإجمالي'));
    lead.append(node('h2', '', 'الأجندة السنوية'), total); root.append(lead);
    if (!spec.total) {
      root.append(node('p', 'a-empty', 'لا توجد مواضيع ضمن النطاق المحدد.'));
      return root;
    }
    var head = node('div', 'a-chart-head'); head.append(node('h3', '', 'مستويات الإنجاز حسب الربع')); root.append(head);
    var panels = node('div', 'a-chart-panels');
    panels.style.setProperty('--cohorts', String(spec.cohorts.length));
    spec.cohorts.forEach(function (c, ci) {
      var displayQuarters = quarterColumns.map(function (q) {
        return c.quarters.find(function (x) { return x.key === q.key; }) ||
          { key: q.key, name: q.name, total: 0, recordKeys: [], cells: [], resolvedZero: true };
      });
      var panel = node('figure', 'a-chart-panel');
      panel.dataset.cohort = c.id; panel.dataset.total = String(c.total);
      panel.dataset.denominator = String(c.total); panel.style.setProperty('--quarters', String(displayQuarters.length));
      panel.dataset.resolvedZeroQuarters = JSON.stringify(displayQuarters.filter(function (q) { return q.resolvedZero; }).map(function (q) { return q.key; }));
      panel.setAttribute('aria-labelledby', 'ag-matrix-cohort-' + c.id);
      var caption = node('figcaption', 'a-panel-title'), categoryTotal = node('div', 'a-category-total');
      var heading = node('h4', '', c.name); heading.id = 'ag-matrix-cohort-' + c.id;
      categoryTotal.append(num(c.total, 'a-panel-total'), node('span', '', 'الإجمالي'));
      caption.append(heading, categoryTotal); panel.append(caption);
      var result = chart(spec, c, displayQuarters, ci);
      panel.dataset.statusTotals = result.detail.dataset.statusTotals;
      panel.append(result.drawing, result.detail, countTable(spec, c, displayQuarters, ci));
      panels.append(panel);
    });
    root.append(panels); return root;
  }
  function chartNodes(root) {
    root = root || document;
    var charts = Array.from(root.querySelectorAll('.a-quarter-chart'));
    if (root.matches && root.matches('.a-quarter-chart')) charts.unshift(root);
    return charts;
  }
  function fitCounts(root) {
    var charts = chartNodes(root).filter(function (svg) { return svg.isConnected; });
    var groups = new Map(), sharedTop = new Map();
    charts.forEach(function (svg) {
      var overview = svg.closest('.ag-matrix-overview') || svg;
      if (!groups.has(overview)) groups.set(overview, []);
      groups.get(overview).push(svg);
    });
    // Paired charts need one physical count scale as well as one numeric axis.
    // Measure all total labels first and reserve their maximum headroom in every
    // chart in the same overview. No segment is enlarged to make a label fit.
    groups.forEach(function (members) {
      var neededTop = 0;
      members.forEach(function (svg) {
        var plotHeight = Number(svg.dataset.plotHeight), scaleMax = Number(svg.dataset.scaleMax);
        neededTop = Math.max(neededTop, svg.dataset.outputProfile === 'print' ? 20 : 36);
        svg.querySelectorAll('.a-quarter-total').forEach(function (total) {
          var box = total.getBBox(), baseline = Number(total.getAttribute('y'));
          neededTop = Math.max(neededTop, 2 + 12 - (box.y - baseline) -
            plotHeight * (1 - Number(total.dataset.count) / scaleMax));
        });
      });
      members.forEach(function (svg) { sharedTop.set(svg, neededTop); });
    });
    charts.forEach(function (svg) {
      var view = svg.ownerDocument.defaultView || window;
      var currentTop = Number(svg.dataset.plotTop), plotHeight = Number(svg.dataset.plotHeight);
      var neededTop = sharedTop.get(svg);
      var shift = neededTop - currentTop;
      if (Math.abs(shift) > .01) {
        svg.querySelectorAll('[y]').forEach(function (item) {
          item.setAttribute('y', Number(item.getAttribute('y')) + shift);
        });
        svg.querySelectorAll('.a-chart-grid').forEach(function (line) {
          line.setAttribute('y1', Number(line.getAttribute('y1')) + shift);
          line.setAttribute('y2', Number(line.getAttribute('y2')) + shift);
        });
        svg.dataset.plotTop = String(neededTop);
        svg.setAttribute('viewBox', '0 0 ' + svg.viewBox.baseVal.width + ' ' +
          (neededTop + plotHeight + Number(svg.dataset.bottomPadding)));
      }
      var matrix = svg.getScreenCTM();
      var scale = matrix ? Math.sqrt(matrix.a * matrix.a + matrix.b * matrix.b) :
        svg.getBoundingClientRect().width / svg.viewBox.baseVal.width;
      if (!(scale > 0) || !svg.isConnected) return;
      var context = svg.ownerDocument.createElement('canvas').getContext('2d');
      if (!context) return;
      svg.querySelectorAll('.a-quarter-segment').forEach(function (segment) {
        var label = segment.nextElementSibling;
        if (!label || !label.classList.contains('a-inbar-count')) return;
        var style = view.getComputedStyle(label);
        // Keep type readable in CSS pixels instead of shrinking text to force a
        // small source segment to contain it. 16px is 12pt in a print document.
        var fontSize = Math.max(svg.dataset.outputProfile === 'print' ? 22 : 18, 16 / scale);
        label.style.fontSize = fontSize + 'px';
        context.font = '400 ' + fontSize + 'px ' + style.fontFamily;
        var ink = context.measureText(label.textContent);
        var ascent = ink.actualBoundingBoxAscent, descent = ink.actualBoundingBoxDescent;
        var inkHeight = ascent + descent;
        var room = Number(segment.getAttribute('height'));
        var width = Number(segment.getAttribute('width'));
        var fits = Number.isFinite(inkHeight) && inkHeight > 0 &&
          room >= inkHeight + 4 / scale && width >= ink.width + 8 / scale;
        label.setAttribute('y', Number(segment.getAttribute('y')) + room / 2 + (ascent - descent) / 2);
        label.setAttribute('dominant-baseline', 'auto');
        label.setAttribute('visibility', fits ? 'visible' : 'hidden');
        label.dataset.fits = String(fits);
        label.dataset.inkHeight = String(inkHeight);
        label.dataset.inkWidth = String(ink.width);
        label.dataset.renderedFontSize = String(fontSize * scale);
        label.dataset.fitRoom = String(room);
      });
    });
  }
  function setPrintLayout(root, print) {
    chartNodes(root).forEach(function (svg) {
      var height = print ? 236 : 480, topPad = print ? 20 : 36;
      var bottom = topPad + height, max = Number(svg.dataset.scaleMax);
      svg.dataset.outputProfile = print ? 'print' : 'screen';
      svg.dataset.plotHeight = String(height); svg.dataset.plotTop = String(topPad);
      svg.setAttribute('viewBox', '0 0 ' + svg.viewBox.baseVal.width + ' ' +
        (bottom + Number(svg.dataset.bottomPadding)));
      svg.querySelectorAll('.a-chart-grid').forEach(function (line) {
        var y = bottom - height * Number(line.dataset.count) / max;
        line.setAttribute('y1', y); line.setAttribute('y2', y);
      });
      svg.querySelectorAll('.a-axis-label').forEach(function (label) {
        label.setAttribute('y', bottom - height * Number(label.dataset.count) / max + 4);
      });
      svg.querySelectorAll('.a-quarter-bar').forEach(function (group) {
        var top = bottom - height * Number(group.dataset.count) / max;
        group.querySelector('.a-quarter-total').setAttribute('y', top - 12);
        var focus = group.querySelector('.a-bar-focus'), focusTop = Math.max(0, top - 36);
        // The print clone deliberately removes keyboard-only focus rectangles.
        if (focus) {
          focus.setAttribute('y', focusTop);
          focus.setAttribute('height', bottom - focusTop + Number(svg.dataset.bottomPadding));
        }
        group.querySelectorAll('.a-quarter-label').forEach(function (label) { label.setAttribute('y', bottom + 31); });
        var cursor = bottom;
        group.querySelectorAll('.a-quarter-segment').forEach(function (segment) {
          var segmentHeight = height * Number(segment.dataset.count) / max;
          cursor -= segmentHeight;
          segment.setAttribute('y', cursor); segment.setAttribute('height', segmentHeight);
        });
      });
    });
    fitCounts(root);
  }
  var fitFrame = 0;
  function scheduleFit() {
    if (fitFrame) return;
    fitFrame = window.requestAnimationFrame(function () { fitFrame = 0; fitCounts(); });
  }
  function resetPanel(panel) {
    var detail = panel.querySelector('.a-quarter-detail');
    if (!detail || detail.dataset.detailMode === 'totals') return;
    var totals;
    try { totals = JSON.parse(panel.dataset.statusTotals || detail.dataset.statusTotals); } catch (ignore) { return; }
    panel.querySelectorAll('.a-quarter-bar').forEach(function (button) { button.setAttribute('aria-pressed', 'false'); });
    delete panel.dataset.selectedQuarter;
    detail.dataset.detailMode = 'totals';
    delete detail.dataset.quarter;
    detailContent(detail, 'الإجمالي حسب الحالة', totals);
  }
  function resetDetails(root) {
    root = root || document;
    var panels = Array.from(root.querySelectorAll('.a-chart-panel'));
    if (root.matches && root.matches('.a-chart-panel')) panels.unshift(root);
    panels.forEach(resetPanel);
  }
  function chooseQuarter(control) {
    if (!control) return;
    var panel = control.closest('.a-chart-panel');
    if (!panel) return;
    var selected = control.getAttribute('aria-pressed') === 'true';
    // Only an explicitly activated quarter has detail values; other panels stay on totals.
    var root = panel.closest('.ag-matrix-overview');
    resetDetails(root);
    if (selected) return;
    var detail = panel.querySelector('.a-quarter-detail'), values;
    try { values = JSON.parse(control.dataset.statusCounts); } catch (ignore) { return; }
    control.setAttribute('aria-pressed', 'true');
    panel.dataset.selectedQuarter = control.dataset.quarter;
    detail.dataset.detailMode = 'quarter';
    detail.dataset.quarter = control.dataset.quarter;
    detailContent(detail, control.dataset.quarterName, values);
  }
  function quarterTarget(event) {
    return event.target && event.target.closest ? event.target.closest('.ag-matrix-overview .a-quarter-bar') : null;
  }
  // The report renders through outerHTML and is replaced after filters change.
  // Delegation keeps pointer and keyboard details available after every render.
  if (!S.agendaMatrix || !S.agendaMatrix.eventsInstalled) {
    window.addEventListener('resize', scheduleFit);
    window.addEventListener('beforeprint', function () { resetDetails(); setPrintLayout(document, true); });
    window.addEventListener('afterprint', function () { setPrintLayout(document, false); });
    if (document.fonts && document.fonts.ready) {
      document.fonts.ready.then(scheduleFit);
      if (document.fonts.addEventListener) document.fonts.addEventListener('loadingdone', scheduleFit);
    }
    // Report markup is replaced through outerHTML after filters change. Observe
    // child additions only, so fitting SVG attributes cannot trigger a loop.
    if (typeof MutationObserver === 'function') {
      new MutationObserver(function (records) {
        if (records.some(function (record) {
          return Array.from(record.addedNodes).some(function (added) {
            return added.nodeType === 1 && ((added.matches && added.matches('.a-quarter-chart')) ||
              (added.querySelector && added.querySelector('.a-quarter-chart')));
          });
        })) scheduleFit();
      }).observe(document.documentElement, { childList: true, subtree: true });
    }
    document.addEventListener('click', function (event) {
      var button = quarterTarget(event);
      if (button) chooseQuarter(button);
      else resetDetails();
    });
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') { resetDetails(); return; }
      var button = quarterTarget(event);
      if (!button) return;
      if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); chooseQuarter(button); return; }
      var movement = { ArrowLeft: 1, ArrowRight: -1, Home: 0, End: 0 };
      if (!Object.prototype.hasOwnProperty.call(movement, event.key)) return;
      event.preventDefault();
      var buttons = Array.from(button.closest('.a-chart-panel').querySelectorAll('.a-quarter-bar'));
      var index = buttons.indexOf(button);
      var next = event.key === 'Home' ? 0 : event.key === 'End' ? buttons.length - 1 :
        Math.max(0, Math.min(buttons.length - 1, index + movement[event.key]));
      buttons[next].focus();
    });
  }
  S.agendaMatrix = {
    spec: specification, element: element, resetDetails: resetDetails, fitCounts: fitCounts,
    setPrintLayout: setPrintLayout, eventsInstalled: true,
    render: function (state) { return element(specification(state)).outerHTML; }
  };
})(window.Saytara = window.Saytara || {});
