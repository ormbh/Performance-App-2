/* Offline native PDF export. Browser layout owns wrapping and geometry;
 * the local font engine writes selectable text and vector shapes. No workbook
 * data is recomputed here, and no report is sent to an external service. */
(function (S) {
  'use strict';
  var PX_PT = 72 / 96, MM_PT = 72 / 25.4, enginePromise;
  function loadEngine() {
    if (S.pdfEngine) return Promise.resolve(S.pdfEngine);
    if (!enginePromise) enginePromise = new Promise(function (resolve, reject) {
      var script = document.createElement('script');
      script.src = new URL('assets/js/lib/offline-pdf-engine.js?v=139', document.baseURI).href;
      script.onload = function () { if (S.pdfEngine) resolve(S.pdfEngine); else { enginePromise=null; reject(new Error('PDF engine unavailable')); } };
      script.onerror = function () { script.remove(); enginePromise=null; reject(new Error('تعذر تحميل مكونات PDF المحلية. استخرج ملف التطبيق كاملاً ثم حاول مجدداً.')); };
      document.head.appendChild(script);
    });
    return enginePromise;
  }
  function opaque(color) { return color && color !== 'transparent' && !/rgba\([^)]*,\s*0\s*\)/.test(color) && color !== 'none'; }
  function color(doc, css, stroke) {
    var m = css && css.match(/rgba?\(([^)]+)\)/), c = css, a=1;
    if(m){var parts=m[1].split(',').map(Number);c=parts.slice(0,3);if(parts.length>3)a=parts[3];}
    if(stroke){doc.strokeColor(c);doc.strokeOpacity(a);}else {doc.fillColor(c);doc.fillOpacity(a);}
  }
  // HH uses the same native full-bleed cover contract as the agenda. The
  // chart specification is already frozen by the screen; only composition
  // changes here, without deriving another set of project counts.
  function prepareHH(artifact, state) {
    if (!(state.screen === 'reports' && state.report && state.report.kind === 'hh')) return false;
    var root=artifact.root, doc=artifact.document, overview=root.querySelector('.hh-chart-overview');
    if(!overview)return false;
    function el(tag,cls){var n=doc.createElement(tag);n.className=cls;return n;}
    var container=el('div','ag-pdf-document hh-report hh-pdf-document'),cover=el('section','ag-pdf-cover'),display=S.reportDisplay.get(state),esc=S.util.esc;
    var entity=S.util.hasSelection(state.dash.entity)?S.util.selectionText(state.dash.entity,undefined,'d:entity'):'';
    cover.innerHTML='<img class="ag-pdf-cover-photo" src="assets/img/agenda-cover.jpg" alt=""><div class="ag-pdf-cover-wash" aria-hidden="true"></div><img class="ag-pdf-cover-logos" src="assets/img/agenda-logos.png" alt="حكومة دبي والمجلس التنفيذي"><div class="ag-pdf-cover-title"><h1>'+esc(display.title)+'</h1>'+(entity?'<p>'+esc(entity)+'</p>':'')+'<p>'+esc(display.period)+'</p></div>';
    container.appendChild(cover);
    var first=el('section','hh-pdf-first-block');first.appendChild(overview.cloneNode(true));container.appendChild(first);
    var rest=el('section','hh-pdf-rest'),main=root.querySelector('.rpt-main').cloneNode(true);
    Array.from(main.querySelectorAll('.hh-chart-overview,#hh-cover,.rpt-intro,.rpt-controls,.rpt-body-source-note,.report-display-controls,.report-editorial-controls,#hh-shortcuts')).forEach(function(n){n.remove();});
    rest.appendChild(main);container.appendChild(rest);root.replaceChildren(container);artifact.hh={};artifact.report=container;
    var style=doc.createElement('style');style.textContent='.hh-pdf-first-block{margin:0!important;padding:0!important;break-inside:avoid!important}.hh-pdf-rest>.rpt-main{margin:0!important;padding:0!important;width:100%!important;max-width:none!important}.hh-pdf-rest #hh-summary{break-before:auto!important}.hh-pdf-rest .hh-summary-dashboard:empty{display:none!important}.hh-pdf-first-block .hh-chart-overview{margin:0!important}';doc.head.appendChild(style);
    return true;
  }
  function collectHH(artifact,bounds){if(!artifact.hh)return null;return {cover:bounds(artifact.root.querySelector('.ag-pdf-cover')),first:bounds(artifact.root.querySelector('.hh-pdf-first-block')),rest:bounds(artifact.root.querySelector('.hh-pdf-rest'))};}
  function hhPages(data,geometry){
    var h=data.hh,capacity=182*96/25.4,plans=[{regions:[{source:h.cover,x:0,y:0}],fullBleed:true,noFooter:true}];
    if(h.first.h>capacity+.5){
      // Unusual source scopes can add sectors or long definitions. Keep their
      // measured native rows and text, continuing without clipping or dropping.
      plans=plans.concat(pagePlan(Object.assign({},data,{hh:null,height:h.first.y+h.first.h}),Object.assign({},geometry,{sourceStart:h.first.y,capacityPx:capacity})));
    }else plans.push({regions:[{source:h.first,x:h.first.x,y:0}]});
    if(h.rest.h>.5){var remaining=Object.assign({},data,{hh:null,height:h.rest.y+h.rest.h});var restPlan=pagePlan(remaining,Object.assign({},geometry,{sourceStart:h.rest.y,capacityPx:capacity}));plans=plans.concat(restPlan);}
    plans.forEach(function(p,i){if(!p.noFooter){p.footerPage=i;p.footerTotal=plans.length-1;}});return plans;
  }
  function fitHHCounts(artifact){
    if(!artifact.hh)return;
    var win=artifact.window,canvas=artifact.document.createElement('canvas'),ctx=canvas.getContext('2d');
    Array.from(artifact.root.querySelectorAll('.hh-cohort-segment bdi')).forEach(function(label){
      var segment=label.closest('.hh-cohort-segment'),style=win.getComputedStyle(label),box=win.getComputedStyle(segment);
      ctx.font=style.fontStyle+' '+style.fontWeight+' '+style.fontSize+' '+style.fontFamily;
      var metrics=ctx.measureText(label.textContent.trim()),inner=segment.clientWidth-(parseFloat(box.paddingLeft)||0)-(parseFloat(box.paddingRight)||0);
      var inkHeight=(metrics.actualBoundingBoxAscent||0)+(metrics.actualBoundingBoxDescent||0),fits=metrics.width+4<=inner&&inkHeight+4<=segment.clientHeight;
      // This is a visibility decision only. Counts never stretch their source
      // bars or reduce the approved physical text size to squeeze into a mark.
      label.style.visibility=fits?'visible':'hidden';label.dataset.pdfCountFit=String(fits);label.dataset.pdfCountWidth=String(metrics.width);label.dataset.pdfCountRoom=String(inner);
    });
  }
  S.hhPrint={prepare:prepareHH,fit:fitHHCounts};
  function collect(artifact) {
    var root=artifact.root, win=root.ownerDocument.defaultView, origin=root.getBoundingClientRect();
    var ops=[], lines=[], avoids=[], breaks=[], tables=[];
    var canvas=root.ownerDocument.createElement('canvas'), ctx=canvas.getContext('2d');
    var segmenter=typeof Intl.Segmenter==='function'?new Intl.Segmenter('ar',{granularity:'grapheme'}):null;
    function bounds(el){var r=el.getBoundingClientRect();return {x:r.left-origin.left,y:r.top-origin.top,w:r.width,h:r.height};}
    function text(node, style) {
      if(!node.textContent.trim())return;
      var raw=node.textContent, range=root.ownerDocument.createRange(), chunks=[];
      var svgParent=node.parentElement.namespaceURI==='http://www.w3.org/2000/svg',matrix=svgParent&&node.parentElement.getScreenCTM(),fontScale=matrix?Math.hypot(matrix.c,matrix.d):1;
      if(segmenter)Array.from(segmenter.segment(raw)).forEach(function(s){chunks.push({index:s.index,text:s.segment});});
      else {var pos=0;Array.from(raw).forEach(function(s){chunks.push({index:pos,text:s});pos+=s.length;});}
      var groups=[];
      chunks.forEach(function(ch){
        range.setStart(node,ch.index);range.setEnd(node,ch.index+ch.text.length);
        var rects=Array.from(range.getClientRects()).filter(function(r){return r.width>.01&&r.height>.01;});
        if(!rects.length)return;
        var r=rects[0],key=Math.round(r.top*4),g=groups.find(function(x){return x.key===key;});
        if(!g){g={key:key,text:'',left:r.left,right:r.right,top:r.top,bottom:r.bottom};groups.push(g);}
        g.text+=ch.text;g.left=Math.min(g.left,r.left);g.right=Math.max(g.right,r.right);g.bottom=Math.max(g.bottom,r.bottom);
      });
      ctx.font=style.fontStyle+' '+style.fontWeight+' '+style.fontSize+' '+style.fontFamily;
      groups.forEach(function(g){
        var str=g.text.replace(/[\t\r\n\f]/g,' ');
        if(!/pre/.test(style.whiteSpace))str=str.replace(/ +/g,' ');
        if(!str.trim())return;
        var tm=ctx.measureText(str),ascent=tm.fontBoundingBoxAscent;
        if(!Number.isFinite(ascent))ascent=parseFloat(style.fontSize)*.8;
        var exactBaseline=null;
        if(svgParent&&matrix&&node.parentElement.getStartPositionOfChar){try{var pt=node.parentElement.getStartPositionOfChar(0);exactBaseline=matrix.b*pt.x+matrix.d*pt.y+matrix.f-origin.top;}catch(ignore){}}
        var op={type:'text',text:str,x:g.left-origin.left,y:g.top-origin.top,w:g.right-g.left,h:g.bottom-g.top,
          headerText:!!node.parentElement.closest('.mp-header,.tec-print-first-header,.ag-pdf-group-title'),
          baseline:exactBaseline===null?g.top-origin.top+ascent*fontScale:exactBaseline,size:parseFloat(style.fontSize)*fontScale,font:style.fontFamily,bold:Number(style.fontWeight)>=600,
          direction:style.direction,color:svgParent?style.fill:style.color,letterSpacing:parseFloat(style.letterSpacing)||0};
        lines.push(op);ops.push(op);
      });
      range.detach();
    }
    function svg(el, style) {
      var tag=el.tagName.toLowerCase(),matrix=el.getScreenCTM&&el.getScreenCTM();
      if(!matrix)return false;
      if(tag==='text'||tag==='tspan')return false;
      var allowed=['rect','circle','ellipse','path','line','polygon','polyline'];
      if(allowed.indexOf(tag)<0)return false;
      var attrs={};Array.from(el.attributes).forEach(function(a){attrs[a.name]=a.value;});
      ops.push({type:'svg',tag:tag,attrs:attrs,matrix:[matrix.a,matrix.b,matrix.c,matrix.d,matrix.e-origin.left,matrix.f-origin.top],
        x:bounds(el).x,y:bounds(el).y,w:bounds(el).w,h:bounds(el).h,fill:style.fill,stroke:style.stroke,strokeWidth:parseFloat(style.strokeWidth),opacity:parseFloat(style.opacity)});
      return true;
    }
    function visit(el){
      var st=win.getComputedStyle(el),r=bounds(el);
      if(st.display==='none'||st.visibility==='hidden'||Number(st.opacity)===0)return;
      if(el.tagName.toLowerCase()==='defs'||el.tagName.toLowerCase()==='title'||el.tagName.toLowerCase()==='desc')return;
      // display:contents has no own rectangle, but its source text and child
      // boxes remain visible. Printable report links use it intentionally.
      if(!el.getClientRects().length){
        if(st.display!=='contents')return;
        Array.from(el.childNodes).forEach(function(n){if(n.nodeType===1)visit(n);else if(n.nodeType===3)text(n,st);});
        return;
      }
      if(st.breakBefore==='page'||st.breakBefore==='always'||st.pageBreakBefore==='always')breaks.push(r.y);
      if(st.breakAfter==='page'||st.breakAfter==='always'||st.pageBreakAfter==='always')breaks.push(r.y+r.h);
      if((/avoid/.test(st.breakInside)||/avoid/.test(st.pageBreakInside)||el.tagName==='TR'||el.matches('.mp-metrics,.mp-card-head,.mp-requester h4,.mp-kpi-metric,.mp-money-main'))&&r.h>0)avoids.push({top:r.y,bottom:r.y+r.h,x:r.x,w:r.w,row:el.tagName==='TR'});
      if(el.tagName==='TABLE'&&el.tHead){
        var hr=bounds(el.tHead),first=el.tBodies[0]&&Array.from(el.tBodies[0].rows).find(function(row){return row.getClientRects().length;}),fr=first&&bounds(first);
        tables.push({top:r.y,bottom:r.y+r.h,head:hr});
        if(fr){var top=hr.y;
          // A title can be a sibling of the table or of its scroll wrapper.
          // Keep the nearby visible heading chain with the first source row.
          Array.from(root.querySelectorAll('h2,h3,h4,[role="heading"]')).forEach(function(title){
            if(!title.getClientRects().length||!(title.compareDocumentPosition(el)&4))return;
            var tr=bounds(title),overlap=Math.min(tr.x+tr.w,hr.x+hr.w)-Math.max(tr.x,hr.x);
            if(tr.y<=hr.y&&hr.y-tr.y<160&&overlap>Math.min(tr.w,hr.w)*.5)top=Math.min(top,tr.y);
          });
          avoids.push({top:top,bottom:fr.y+fr.h,x:hr.x,w:hr.w,row:true});}
      }
      if(el.namespaceURI==='http://www.w3.org/2000/svg'&&svg(el,st))return;
      if(el.namespaceURI!=='http://www.w3.org/2000/svg'){
        if(el.matches('.hh-progress-ring')){var before=win.getComputedStyle(el,'::before'),palette=st.backgroundImage.match(/rgba?\([^)]+\)/g)||[];ops.push({type:'ring',x:r.x,y:r.y,w:r.w,h:r.h,value:Math.max(0,Math.min(100,parseFloat(st.getPropertyValue('--progress'))||0)),color:st.getPropertyValue('--progress-color').trim()||'#115E67',track:palette[palette.length-1]||'#E7E0D3',inner:before.backgroundColor,inset:parseFloat(before.left)||6});}
        else if(opaque(st.backgroundColor)&&r.w>0&&r.h>0)ops.push({type:'box',x:r.x,y:r.y,w:r.w,h:r.h,radius:parseFloat(st.borderTopLeftRadius)||0,fill:st.backgroundColor});
        var sides=['Top','Right','Bottom','Left'],uniform=sides.every(function(side){return st['border'+side+'Width']===st.borderTopWidth&&st['border'+side+'Color']===st.borderTopColor&&st['border'+side+'Style']===st.borderTopStyle;});
        if(uniform&&parseFloat(st.borderTopWidth)>0&&st.borderTopStyle!=='none'&&opaque(st.borderTopColor))ops.push({type:'outline',x:r.x,y:r.y,w:r.w,h:r.h,radius:parseFloat(st.borderTopLeftRadius)||0,width:parseFloat(st.borderTopWidth),color:st.borderTopColor});
        if(!uniform)sides.forEach(function(side){var width=parseFloat(st['border'+side+'Width']);if(width>0&&st['border'+side+'Style']!=='none'&&opaque(st['border'+side+'Color']))ops.push({type:'border',x:r.x,y:r.y,w:r.w,h:r.h,side:side,width:width,color:st['border'+side+'Color']});});
      }
      if(el.tagName==='IMG'){
        var embedded=S.pdfImages&&S.pdfImages[el.getAttribute('src')];
        if(!embedded&&S.pdfImages)Object.keys(S.pdfImages).some(function(key){if(el.src.endsWith('/'+key)){embedded=S.pdfImages[key];return true;}return false;});
        if(embedded){ops.push({type:'image',x:r.x,y:r.y,w:r.w,h:r.h,data:embedded});return;}
        var c=root.ownerDocument.createElement('canvas');c.width=el.naturalWidth;c.height=el.naturalHeight;
        if(c.width&&c.height){c.getContext('2d').drawImage(el,0,0);ops.push({type:'image',x:r.x,y:r.y,w:r.w,h:r.h,data:c.toDataURL('image/png')});}
        return;
      }
      var clip=/(hidden|clip)/.test(st.overflowX+' '+st.overflowY)&&r.w>0&&r.h>0;
      if(clip)ops.push({type:'clip-start',x:r.x,y:r.y,w:r.w,h:r.h,radius:parseFloat(st.borderTopLeftRadius)||0});
      var closedDetails=el.tagName==='DETAILS'&&!el.open;
      Array.from(el.childNodes).forEach(function(n){
        // Chromium can expose Range rectangles inside collapsed disclosures;
        // those descendants do not belong to the visible export.
        if(closedDetails&&!(n.nodeType===1&&n.tagName==='SUMMARY'))return;
        if(n.nodeType===1)visit(n);else if(n.nodeType===3)text(n,st);
      });
      if(clip)ops.push({type:'clip-end'});
    }
    visit(root);
    var monthly=null,report=root.querySelector('.mp-report');
    if(report){var columns=Array.from(report.querySelectorAll('.mp-portfolios>div')).map(function(col){return Array.from(col.children).map(function(el){var r=bounds(el);return {x:r.x,y:r.y,w:r.w,h:r.h};});});
      var header=report.querySelector('.mp-header'),follow=report.querySelector('.mp-followups,.mp-empty-followups');
      monthly={header:header&&bounds(header),columns:columns,follow:follow&&bounds(follow)};}
    // The last visible font rectangle can overhang its element by a fraction
    // of a pixel. Include it so pagination neither drops that line nor creates
    // a trailing sheet containing only the footer.
    var textBottom=lines.reduce(function(bottom,line){return Math.max(bottom,line.y+line.h);},0);
    return {ops:ops,lines:lines,avoids:avoids,breaks:breaks,tables:tables,monthly:monthly,
      agenda:S.agendaPrint ? S.agendaPrint.collect(artifact,bounds) : null,
      hh:collectHH(artifact,bounds),
      height:Math.max(origin.height,root.scrollHeight,Math.ceil(textBottom)),width:origin.width};
  }
  function pagePlan(data, geometry){
    if(geometry.layout==='continuous')return [{start:0,end:data.height,head:null}];
    if(data.agenda&&S.agendaPrint)return S.agendaPrint.pagePlan(data);
    if(data.hh)return hhPages(data,geometry);
    if(data.monthly&&data.monthly.columns.length)return monthlyPages(data,geometry);
    var pageH=(geometry.direction==='landscape'?210:297)-20;
    var capacity=geometry.capacityPx||pageH*96/25.4,plans=[],start=geometry.sourceStart||0;
    while(start<data.height-.5){
      var table=data.tables.find(function(t){return start>=t.head.y+t.head.h-.5&&start<t.bottom-.5;});
      var head=table?table.head:null,reserve=head?head.h:0,limit=Math.min(data.height,start+capacity-reserve);
      var forced=data.breaks.filter(function(y){return y>start+capacity*.2&&y<limit;}).sort(function(a,b){return a-b;})[0];
      if(forced!==undefined)limit=forced;
      var end=limit,cutting=data.avoids.filter(function(a){return a.top<end-.5&&a.bottom>end+.5&&a.bottom-a.top<capacity-reserve;});
      // Avoid splitting a fitting row/card. Re-evaluate when two adjacent
      // columns overlap, while retaining a useful amount of content per page.
      for(var n=0;n<30&&cutting.length;n++){
        var eligible=cutting.filter(function(a){return a.top>start+capacity*.25;});
        if(!eligible.length)break;
        var candidate=Math.min.apply(null,eligible.map(function(a){return a.top;}));
        end=candidate;cutting=data.avoids.filter(function(a){return a.top<end-.5&&a.bottom>end+.5&&a.bottom-a.top<capacity-reserve;});
      }
      // A genuinely oversized row/card may continue, but never cut a text line.
      var crossing=data.lines.filter(function(l){return l.y<end-.1&&l.y+l.h>end+.1;});
      if(crossing.length){var lineTop=Math.min.apply(null,crossing.map(function(l){return l.y;}));if(lineTop>start+1)end=lineTop;}
      if(end<=start+1)end=limit;
      plans.push({start:start,end:end,head:head});start=end;
      if(plans.length>2000)throw new Error('التقرير أطول من الحد المتاح لتصدير PDF.');
    }
    return plans.length?plans:[{start:0,end:0,head:null}];
  }

  function monthlyPages(data,geometry){
    var cap=((geometry.direction==='landscape'?210:297)-20)*96/25.4,pages=[],m=data.monthly;
    function page(i){while(pages.length<=i)pages.push({regions:[]});return pages[i];}
    function region(r,at,y){page(at).regions.push({source:r,x:r.x,y:y});}
    function portions(r,at,cursor){
      var start=r.y,end=r.y+r.h;
      while(start<end-.2){
        var table=data.tables.find(function(t){return start>=t.head.y+t.head.h-.5&&start<t.bottom-.5&&t.head.x<r.x+r.w&&t.head.x+t.head.w>r.x;});
        if(cursor>cap-2){at++;cursor=0;}
        if(table&&start>r.y+.5){region(table.head,at,cursor);cursor+=table.head.h;}
        var available=cap-cursor,cut=Math.min(end,start+available);
        var crossing=data.avoids.filter(function(a){return a.top<cut-.2&&a.bottom>cut+.2&&a.bottom-a.top<cap&&a.x<r.x+r.w&&a.x+a.w>r.x&&a.top>start+1;});
        if(crossing.length)cut=Math.min.apply(null,crossing.map(function(a){return a.top;}));
        var text=data.lines.filter(function(l){return l.x<r.x+r.w&&l.x+l.w>r.x&&l.y<cut-.2&&l.y+l.h>cut+.2;});
        if(text.length)cut=Math.min.apply(null,text.map(function(l){return l.y;}));
        if(cut<=start+.5){at++;cursor=0;continue;}
        region({x:r.x,y:start,w:r.w,h:cut-start},at,cursor);cursor+=cut-start;start=cut;
        if(start<end-.2){at++;cursor=0;}
      }
      return {at:at,cursor:cursor};
    }
    if(m.header)region(m.header,0,m.header.y);
    var endings=m.columns.map(function(nodes){
      var at=0,cursor=nodes.length?nodes[0].y:0,previous=null;
      nodes.forEach(function(r){
        var gap=previous?Math.max(0,r.y-previous.y-previous.h):0;
        if(r.h<=cap){if(cursor+gap+r.h>cap+.1){at++;cursor=0;gap=0;}cursor+=gap;region(r,at,cursor);cursor+=r.h;}
        else {if(cursor>0){at++;cursor=0;}var result=portions(r,at,cursor);at=result.at;cursor=result.cursor;}
        previous=r;
      });return {at:at,cursor:cursor};
    });
    if(m.follow){
      var at=Math.max.apply(null,endings.map(function(x){return x.at;})),cursor=Math.max.apply(null,endings.filter(function(x){return x.at===at;}).map(function(x){return x.cursor;}));
      var sourceBottom=Math.max.apply(null,m.columns.map(function(nodes){var last=nodes[nodes.length-1];return last.y+last.h;}));
      var gap=Math.max(0,m.follow.y-sourceBottom);
      if(m.follow.h<=cap){if(cursor+gap+m.follow.h>cap){at++;cursor=0;gap=0;}region(m.follow,at,cursor+gap);}
      else {cursor+=gap;if(cursor>cap-40){at++;cursor=0;}portions(m.follow,at,cursor);}
    }
    return pages;
  }
  function textFits(op,start,end){
    // Font Range rectangles may extend beyond mastheads and agenda group
    // headings even when their baseline and visible glyphs are inside. Assign
    // heading text by baseline; retain strict line bounds for report rows.
    return op.headerText ? op.baseline>=start-.2&&op.baseline<=end+.2 : op.y>=start-.2&&op.y+op.h<=end+.2;
  }
  function paintRegion(doc,engine,data,placement,xInset,yInset){
    var r=placement.source,x=xInset+placement.x*PX_PT,y=yInset+placement.y*PX_PT;
    doc.save();doc.rect(x-.4,y-.4,r.w*PX_PT+.8,r.h*PX_PT+.8).clip();doc.translate(x-r.x*PX_PT,y-r.y*PX_PT);
    data.ops.forEach(function(op){
      if(op.type==='clip-start'||op.type==='clip-end')paint(doc,engine,op);
      else if(op.x<r.x+r.w+.1&&op.x+op.w>r.x-.1&&op.y<r.y+r.h+.1&&op.y+op.h>r.y-.1){
        if(op.type!=='text'||textFits(op,r.y,r.y+r.h))paint(doc,engine,op);
      }
    });doc.restore();
  }

  function shape(doc,op){
    var a=op.attrs,m=op.matrix;
    doc.save();doc.transform(m[0]*PX_PT,m[1]*PX_PT,m[2]*PX_PT,m[3]*PX_PT,m[4]*PX_PT,m[5]*PX_PT);
    var num=function(k,d){var v=parseFloat(a[k]);return Number.isFinite(v)?v:(d||0);};
    if(op.tag==='rect')doc.roundedRect(num('x'),num('y'),num('width'),num('height'),Math.min(num('rx'),num('width')/2,num('height')/2));
    else if(op.tag==='circle')doc.circle(num('cx'),num('cy'),num('r'));
    else if(op.tag==='ellipse')doc.ellipse(num('cx'),num('cy'),num('rx'),num('ry'));
    else if(op.tag==='path')doc.path(a.d||'');
    else if(op.tag==='line')doc.moveTo(num('x1'),num('y1')).lineTo(num('x2'),num('y2'));
    else{var pts=(a.points||'').trim().split(/[\s,]+/).map(Number);for(var i=0;i+1<pts.length;i+=2){if(i)doc.lineTo(pts[i],pts[i+1]);else doc.moveTo(pts[i],pts[i+1]);}if(op.tag==='polygon')doc.closePath();}
    var fill=opaque(op.fill)&&op.tag!=='line',stroke=opaque(op.stroke)&&op.strokeWidth>0;
    if(fill)color(doc,op.fill);if(stroke){color(doc,op.stroke,true);doc.lineWidth(op.strokeWidth);}
    if(fill&&stroke)doc.fillAndStroke();else if(fill)doc.fill();else if(stroke)doc.stroke();
    doc.restore();
  }
  function paint(doc,engine,op){
    var x=op.x*PX_PT,y=op.y*PX_PT,w=op.w*PX_PT,h=op.h*PX_PT;
    if(op.type==='text'){
      engine.drawText(doc,op.text,{x:x,yBaseline:op.baseline*PX_PT,widthPt:w,sizePt:op.size*PX_PT,font:op.font,bold:op.bold,direction:op.direction,color:op.color,letterSpacing:op.letterSpacing*PX_PT});
    }else if(op.type==='ring'){
      var radius=Math.min(w,h)/2,cx=x+w/2,cy=y+h/2;
      color(doc,op.track);doc.circle(cx,cy,radius).fill();
      if(op.value>0){color(doc,op.color);if(op.value>=100)doc.circle(cx,cy,radius).fill();else {var angle=op.value/100*Math.PI*2,ex=cx+Math.sin(angle)*radius,ey=cy-Math.cos(angle)*radius;doc.path('M'+cx+' '+cy+' L'+cx+' '+(cy-radius)+' A'+radius+' '+radius+' 0 '+(op.value>50?1:0)+' 1 '+ex+' '+ey+' Z').fill();}}
      color(doc,op.inner);doc.circle(cx,cy,Math.max(0,radius-op.inset*PX_PT)).fill();
    }else if(op.type==='box'){
      color(doc,op.fill);doc.roundedRect(x,y,w,h,Math.min(op.radius*PX_PT,w/2,h/2)).fill();
    }else if(op.type==='outline'){
      color(doc,op.color,true);doc.lineWidth(op.width*PX_PT);doc.roundedRect(x,y,w,h,Math.min(op.radius*PX_PT,w/2,h/2)).stroke();
    }else if(op.type==='border'){
      color(doc,op.color,true);doc.lineWidth(op.width*PX_PT);
      if(op.side==='Top')doc.moveTo(x,y).lineTo(x+w,y);
      if(op.side==='Bottom')doc.moveTo(x,y+h).lineTo(x+w,y+h);
      if(op.side==='Left')doc.moveTo(x,y).lineTo(x,y+h);
      if(op.side==='Right')doc.moveTo(x+w,y).lineTo(x+w,y+h);
      doc.stroke();
    }else if(op.type==='image'){
      // Images must not inherit opacity from the preceding background wash.
      doc.save().opacity(1);
      doc.image(op.data,x,y,{width:w,height:h});
      doc.restore();
    }
    else if(op.type==='svg')shape(doc,op);
    else if(op.type==='clip-start'){doc.save();doc.roundedRect(x,y,w,h,Math.min(op.radius*PX_PT,w/2,h/2)).clip();}
    else if(op.type==='clip-end')doc.restore();
  }
  function paintSlice(doc,engine,data,start,end,x,y,repeat){
    doc.save();doc.rect(x,y,data.width*PX_PT,(end-start)*PX_PT).clip();doc.translate(x,y-start*PX_PT);
    data.ops.forEach(function(op){
      if(op.type==='clip-start'||op.type==='clip-end')paint(doc,engine,op);
      else if((op.type==='border'||op.type==='outline'||op.type==='box'||op.type==='svg'||op.type==='ring')&&op.y<end&&op.y+op.h>=start)paint(doc,engine,op);
      else if(op.type==='text'&&textFits(op,start,end))paint(doc,engine,op);
      else if(op.type==='image'&&op.y<end&&op.y+op.h>start)paint(doc,engine,op);
    });doc.restore();
  }
  // Official English names supplied by the user, 13 October 2026.
  // Filename presentation only: do not rewrite Arabic source scopes or report labels.
  var filenameScopeNames={
    sector:[
      ["الأمانة العامة للمجلس التنفيذي","الأمانة العامة للمجلس التنفيذي","General Secretariat of the Executive Council"],
      ["الحوكمة","قطاع الحوكمة","Governance Sector"],
      ["التنمية المستدامة","قطاع التنمية المستدامة","Sustainable Development Sector"],
      ["الاقتصاد والتنمية الاجتماعية","قطاع الاقتصاد والتنمية الاجتماعية","Socioeconomic Sector"],
      ["التميز والخدمات الحكومية","قطاع التميز والخدمات الحكومية","Excellence and Government Services Sector"],
      ["الاتصال الحكومي وشؤون الأمانة العامة","قطاع الاتصال الحكومي وشؤون الأمانة العامة","Government Communication & General Secretariat Affairs Sector"]
    ],
    unit:[
      ["مكتب الأمين العام","إدارة مكتب الأمين العام","Secretary General Department"],
      ["الشراكات والعلاقات الدولية","قسم الشراكات والعلاقات الدولية","Partnerships and International Relations Section"],
      ["مكتب التدقيق الداخلي","مكتب التدقيق الداخلي","Internal Audit Office"],
      ["مكتب خطة دبي","مكتب خطة دبي","Dubai Plan Office"],
      ["الأبحاث والرصد","إدارة الأبحاث والرصد","Research and Sensing Department"],
      ["الحوكمة","إدارة الحوكمة","Governance Department"],
      ["التشريعات الحكومية","إدارة التشريعات الحكومية","Government Legislations Department"],
      ["التنفيذ والأداء","إدارة التنفيذ والأداء","Performance & Effectiveness Department"],
      ["السياسات والاستراتيجيات الصحية والعدل","إدارة السياسات والاستراتيجيات الصحية والعدل","Health and Justice Policies and Strategies Department"],
      ["السياسات والاستراتيجيات البيئية والبنية التحتية","إدارة السياسات والاستراتيجيات البيئية والبنية التحتية","Environment and Infrastructure Policies and Strategies Department"],
      ["السياسات والإستراتيجيات الاجتماعية","إدارة السياسات والإستراتيجيات الاجتماعية","Social Policies and Strategies Department"],
      ["السياسات والإستراتيجيات الاقتصادية","إدارة السياسات والإستراتيجيات الاقتصادية","Economic Policies and Strategies Department"],
      ["التقييم والدراسات","إدارة التقييم والدراسات","Assessment and Studies Department"],
      ["التميز والخدمات الحكومية","إدارة التميز والخدمات الحكومية","Excellence and Government Services Department"],
      ["الاتصال الحكومي","إدارة الاتصال الحكومي","Government Communication Department"],
      ["الاتصال الداخلي","قسم الاتصال الداخلي","Internal Communication Section"],
      ["الخدمات المؤسسية","إدارة الخدمات المؤسسية","Corporate Services Department"],
      ["تميز الموارد البشرية","قسم تميز الموارد البشرية","People Excellence Section"],
      ["المشتريات والشؤون الإدارية","قسم المشتريات والشؤون الإدارية","Procurement and Administration Section"],
      ["تقنية المعلومات","قسم تقنية المعلومات","Information Technology Section"],
      ["المالية والحسابات","قسم المالية والحسابات","Finance & Accounts Section"],
      ["المراسلات والأرشفة","قسم المراسلات والأرشفة","Correspondence and Archiving Section"],
      ["تنفيذ ومتابعة المشاريع الميدانية","قسم تنفيذ ومتابعة المشاريع الميدانية","Operational Project Delivery and Follow-up Section"]
    ]
  };
  function filenameSlug(value){
    return value.replace(/&/g,' and ').replace(/[^A-Za-z0-9]+/g,'_').replace(/^_+|_+$/g,'');
  }
  function filenameScope(field,value){
    var label=S.filterOptions.canonical(value,'d:'+field);
    var row=filenameScopeNames[field].find(function(r){return label===r[0]||label===r[1]||label.toLowerCase()===r[2].toLowerCase();});
    // Unlisted Arabic scopes retain an explicit selected-scope marker until mapped.
    var english=row?row[2]:(/^[\x20-\x7E]+$/.test(label)&&/[A-Za-z]/.test(label)?label:'Selected_'+(field==='unit'?'Unit':'Sector'));
    // User-approved short filenames omit trailing Department/Section only.
    return filenameSlug(english).replace(/(?:^|_)(?:Department|Section)$/i,'')||('Selected_'+(field==='unit'?'Unit':'Sector'));
  }
  function downloadName(state,title){
    if(state.screen!=='dashboard')return title.replace(/[\\/:*?"<>|]/g,'-')+'.pdf';
    var U=S.util,F=S.filterOptions,base='TEC_Monthly';
    if(state.data&&U.validDateSerial(state.data.today)){
      var date=U.ymd(state.data.today),months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      base+='_'+months[date.m-1]+'_'+String(date.y).slice(-2);
    }
    var scope='',filters=state.dash||{};
    ['unit','sector'].some(function(field){
      if(!U.hasSelection(filters[field]))return false;
      var options=(state.multiOptions||{})['d:'+field];
      if(F.compactText(filters[field],options,'الكل','d:'+field)==='الكل')return false;
      var first=F.selectionGroups(filters[field],options,'d:'+field)[0];
      scope=filenameScope(field,first.v);
      return true;
    });
    // ASCII filenames need no bidi controls; retain the date, type suffix and extension.
    var limit=240-base.length-1-4;
    if(scope.length>limit){
      var tail=/_Sector$/.test(scope)?'_Sector':'';
      scope=scope.slice(0,limit-tail.length).replace(/_+$/,'')+tail;
    }
    return base+(scope?'_'+scope:'')+'.pdf';
  }
  async function exportPDF(state){
    var sourceTitle=document.title,fileName=downloadName(state,sourceTitle);
    var prepared=S.printPagination.preparedDocument(state),loading=loadEngine();
    var pair;
    try{pair=await Promise.all([loading,prepared]);}catch(error){prepared.then(function(a){if(a&&a.cleanup)a.cleanup();},function(){});throw error;}
    var engine=pair[0],artifact=pair[1];
    if(!artifact)throw new Error('تعذر تجهيز التقرير للتصدير.');
    try{
      var data=collect(artifact),g=Object.assign({},artifact.geometry,{layout:artifact.layout,direction:artifact.direction});
      // Honor the page-height ceiling even when the user chooses a long PDF.
      if(g.layout==='continuous'&&g.heightMM>5080){
        if(artifact.cleanup)artifact.cleanup();
        artifact=await S.printPagination.preparedDocument(state,{layout:'a4'});
        data=collect(artifact);g=Object.assign({},artifact.geometry,{layout:artifact.layout,direction:artifact.direction});
      }
      var plans=pagePlan(data,g),continuous=g.layout==='continuous';
      var width=(continuous?297:g.direction==='landscape'?297:210)*MM_PT;
      var height=(continuous?Math.max(80,Math.ceil(data.height*25.4/96)+27):g.direction==='landscape'?210:297)*MM_PT;
      var inset=(continuous?8:10)*MM_PT;
      if(engine.ready)await engine.ready();
      var doc=await engine.create({size:[width,height],title:sourceTitle,author:'الأمانة العامة للمجلس التنفيذي لإمارة دبي'});
      for(var i=0;i<plans.length;i++){
        if(i)doc.addPage({size:[width,height],margin:0});
        doc.save();doc.rect(0,0,width,height).fill(continuous?'#EFEBE7':'#FCFBFB');doc.restore();
        var p=plans[i];
        var pageInset=p.fullBleed?0:inset;
        if(p.regions)p.regions.forEach(function(r){paintRegion(doc,engine,data,r,pageInset,pageInset);});
        else {var reserve=p.head?p.head.h*PX_PT:0;
          if(p.head)paintSlice(doc,engine,data,p.head.y,p.head.y+p.head.h,inset,inset);
          paintSlice(doc,engine,data,p.start,p.end,inset,inset+reserve);}
        if(!p.noFooter){
          var baseline=height-(continuous?11:data.agenda||data.hh?10:5)*MM_PT;
          var footerPage=p.footerPage==null?i+1:p.footerPage,footerTotal=p.footerTotal==null?plans.length:p.footerTotal;
          engine.drawText(doc,'صفحة '+footerPage+' من '+footerTotal,{x:inset,yBaseline:baseline,sizePt:10.5,font:'TEC Dubai',direction:'rtl',color:'#4F4E4E'});
          var copyright=S.ui.copyrightText();
          engine.drawText(doc,copyright,{x:width-inset,yBaseline:baseline,sizePt:10.5,font:'TEC Dubai',direction:'rtl',align:'right',color:'#4F4E4E'});
        }
        // Let the browser update the visible loading state for long report packs.
        if(i%5===4)await new Promise(function(resolve){setTimeout(resolve,0);});
      }
      var bytes=await engine.finish(doc),blob=new Blob([bytes],{type:'application/pdf'});
      return {blob:blob,name:fileName,pages:plans.length,layout:g.layout,
        widthMM:width/MM_PT,heightMM:height/MM_PT,nativeTextLines:data.lines.length};
    }finally{if(artifact.cleanup)artifact.cleanup();}
  }
  S.offlinePdf={export:exportPDF,collect:collect,pagePlan:pagePlan,downloadName:downloadName};
})(window.Saytara=window.Saytara||{});
