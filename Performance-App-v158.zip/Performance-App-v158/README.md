# Performance App v158

Agenda and special-project reports now use the same TEC design roles throughout: page header, direct scope filters, compact report settings, navigation, chart panels, status figures, detailed legends, section headings, tables and mobile record cards. Their distinct source content, approved chart orientations and calculations remain unchanged.

Agenda PDF no longer adds separate count-matrix pages. Charts, full definitions and the original topic tables remain. The special-project main list has six columns, without **مدير المشروع**; manager information remains in the project detail cards and source records. The same table appearance applies to native PDF and editable PowerPoint exports.

Both reports retain full-bleed covers in PDF, with centered title, selected entity and period. Copyright and numbering begin after the cover. The previously approved monthly legislation card and numeric progress display are retained.

Extract the complete folder and open **index.html**. All application assets remain local. Select your report workbook; no workbook is bundled. Use **DESIGN-PRINCIPLES-v158.md**, Revision 25, and **VERIFICATION-v158.md** for the current design contract and checks. Earlier verification files describe their original releases.
