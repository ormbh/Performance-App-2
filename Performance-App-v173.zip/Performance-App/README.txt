Performance App v173 — Desktop consistency / Design Principles Revision 37

Extract the entire ZIP and open index.html in desktop Chrome or Edge. Keep index.html, assets and manifest.webmanifest together. No workbook, illustrative records, audit folders or tests are bundled.

Four main project filters: sector, organizational unit, concerned entity and project manager. Entity report adds domain as its fifth main filter. Actual project-manager source values drive PM filtering; coordinators are not substituted. Scope is retained in drill routes, reset and PDF. Contents are reserved for agenda, council decisions and special projects. Approved summaries and chart-specific legends remain; generic overview headings are omitted.

Workspace logos use a stable 192px top/right position, including results. Search landing and landscape covers keep their separate approved compositions. Section links stay within the current route; unavailable local destinations do not reset the page. Screen report/list links stay on screen. Genuine internal PDF links remain functional.

Existing calculations, chart designs, typography, source notes and source identities are retained. Monthly strips remain thin with no added in-bar numerals. Named-project finance and monthly all-row finance retain their documented different scopes. Source workbooks are not edited.

PDF only: full content-height export for other pages; A4 landscape for agenda, council decisions and special projects. No PowerPoint export. Desktop only; no mobile/tablet certification.

Validation notes: tests use the supplied dummy workbook, not operational figures. The reported broad monthly PDF text shift was not reproduced in the tested browser print/native PDF geometry; do not treat it as a confirmed alignment fix. Physical paper margins and approved print font roles differ from desktop pixels. Real previous-month movements and Excel/Power Query execution are outside this release's certification. See the separately supplied principles and verification notes.
