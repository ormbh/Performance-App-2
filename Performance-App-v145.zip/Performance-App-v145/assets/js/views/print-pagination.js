/* Native TEC print preparation. CSS paged media owns page count and flow.
 * Measurement clones the complete view without filtering or reordering records. */
(function (S) {
  'use strict';
  var U = S.util;
  var MM_PER_PX = 25.4 / 96, CONTINUOUS_WIDTH_MM = 297, CONTINUOUS_MARGIN_MM = 8;
  var CONTINUOUS_FOOTER_RESERVE_MM = 8;
  var CONTINUOUS_INITIAL_HEIGHT_MM = 80, CONTINUOUS_MAX_HEIGHT_MM = 5080;
  var printSession = null, readyArtifact = null, pendingArtifact = null, warmState = null, generation = 0;
  var READINESS_TIMEOUT_MS = 15000;
  var TITLES = { dashboard:'التقرير الشهري للأداء والتنفيذ', projects:'مستجدات محفظة المشاريع', results:'نتائج البحث في الأداء', home:'البحث في الأداء', entities:'تقرير الجهات', comparison:'المقارنة الشهرية', agenda:'الأجندة السنوية', council:'تقرير قرارات المجالس', checks:'ملاحظات البيانات', detail:'تفاصيل البند', upload:'رفع ملف التقرير' };
  function title(state) {
    if (state.screen === 'reports' && S.reportDisplay) return S.reportDisplay.get(state).title;
    var root = document.querySelector('#app .project-masthead h1, #app main h1');
    return TITLES[state.screen] || (root ? root.textContent.trim() : 'تقرير الأداء');
  }
  function headerScope(state) {
    var scope, prefix;
    if (['dashboard','reports','agenda','council'].includes(state.screen)) { scope=state.dash; prefix='d'; }
    else if (state.screen==='projects') { scope=state.projects; prefix='p'; }
    else if (state.screen==='comparison') { scope=(state.comparison||{}).scope; prefix='c'; }
    else if (state.screen==='results') { scope=(state.search||{}).f; prefix='f'; }
    // Other views have different scope models. Never reuse a stale dashboard
    // selection for a page whose records do not use those organizational filters.
    if (!prefix) return '';
    scope=scope||{};
    var drill=prefix==='f'&&state.search&&state.search.drill&&state.search.drill.scope;
    function selectedText(values,id,all) {
      if(!S.filterOptions)return U.selectionText(values,all,id);
      var formatter=['dashboard','results'].includes(state.screen)?S.filterOptions.compactText:S.filterOptions.text;
      return formatter(values,(state.multiOptions||{})[id],all,id);
    }
    return '<div class="tec-print-scope" dir="rtl">' +
      [['sector','القطاع','جميع القطاعات'],['unit','الوحدة التنظيمية','جميع الوحدات التنظيمية']].map(function(field) {
        var id=prefix+':'+field[0], values=scope[field[0]], caption=selectedText(values,id,field[2]);
        if (drill&&U.hasSelection(drill[field[0]])) {
          var inherited=U.selectionText(drill[field[0]],field[2],'d:'+field[0]);
          // Search facets further restrict a monthly drill; they never replace
          // it. Show both constraints when their displayed selections differ.
          caption=!U.hasSelection(values)||caption===inherited ? inherited : 'نطاق التقرير: '+inherited+'؛ تصفية البحث: '+caption;
        }
        var content=U.esc(caption);
        // A separate Latin text run preserves +N in the native PDF shaper too.
        if(['dashboard','results'].includes(state.screen))content=content.replace(/\u2066(\+\d+)\u2069/g,'<bdi dir="ltr">$1</bdi>');
        return '<span class="tec-print-scope-field">' + field[1] + ': <bdi dir="auto">' +
          content + '</bdi></span>';
      }).join('<span class="tec-print-scope-separator" aria-hidden="true"> · </span>') + '</div>';
  }
  function headerContent(state) {
    return '<img class="mp-tec-logo" src="assets/img/tec-red.png" alt="المجلس التنفيذي — The Executive Council"><div class="mp-title tec-print-title"><h1>' +
      U.esc(title(state)) + ' - لتاريخ <bdi dir="ltr">' + U.esc(U.fmtDate(state.data.today)) + '</bdi></h1>' + headerScope(state) + '</div>';
  }
  function orientation(state) {
    // A project report shares the reports route, but keeps the portrait rule.
    var landscape = state && (state.screen === 'agenda' || state.screen === 'council' ||
      state.screen === 'reports' && state.report && ['agenda', 'council', 'hh'].includes(state.report.kind));
    return landscape ? 'landscape' : 'portrait';
  }
  function legal() {
    return S.ui && S.ui.copyrightText ? S.ui.copyrightText() : 'الأمانة العامة للمجلس التنفيذي لإمارة دبي · حقوق النشر © ' + new Date().getFullYear() + ' · جميع الحقوق محفوظة';
  }
  function groupPanels() {
    document.querySelectorAll('#app .pd-reference-grid').forEach(function(grid) {
      if (grid.classList.contains('tec-print-grouped')) return;
      var panels = Array.from(grid.children);
      grid.classList.add('tec-print-grouped');
      for (var i = 0; i < panels.length;) {
        if (panels[i].classList.contains('pd-issues')) { i++; continue; }
        var pair = document.createElement('div'); pair.className = 'tec-print-panel-pair';
        grid.insertBefore(pair, panels[i]); pair.appendChild(panels[i++]);
        if (i < panels.length && !panels[i].classList.contains('pd-issues')) pair.appendChild(panels[i++]);
      }
    });
  }
  function printMediaActive() {
    return !window.matchMedia || window.matchMedia('print').matches;
  }
  function pageSize(session, heightMM) {
    var rule = session.continuous && !session.fallback
      ? '@page tec-report { size:' + CONTINUOUS_WIDTH_MM + 'mm ' + heightMM + 'mm; margin:' + CONTINUOUS_MARGIN_MM + 'mm ' + CONTINUOUS_MARGIN_MM + 'mm ' + (CONTINUOUS_MARGIN_MM + CONTINUOUS_FOOTER_RESERVE_MM) + 'mm; background:#EFEBE7; @bottom-left { vertical-align:top; padding-top:1mm; } @bottom-right { vertical-align:top; padding-top:1mm; } }'
      : '@page tec-report { size:A4 ' + session.direction + '; margin:10mm; }';
    // A stable width and content-based height avoid page-size feedback or scaling.
    rule += '\n@media print { .tec-print-measure-frame { display:none!important; } }';
    if (session.css.textContent !== rule) session.css.textContent = rule;
  }
  function continuousRequested(state) {
    return !!(state && state.data && state.screen === 'dashboard' && S.monthlyTools && S.monthlyTools.layout(state) === 'continuous');
  }
  function snapshot(state, options) {
    var root = document.getElementById('app'), monthly = document.getElementById('monthly-print-root');
    if (!root || !state || !state.data) return null;
    var continuous = continuousRequested(state) && !(options && options.layout === 'a4'), build = document.querySelector('meta[name="performance-build"]');
    if (continuous && (!monthly || !monthly.querySelector('.mp-report'))) return null;
    return { root:root, continuous:continuous, direction:continuous ? 'portrait' : orientation(state),
      key:(build ? build.content : 'local') + '\n' + legal() + '\n' + document.body.className + '\n' +
        (continuous ? monthly.outerHTML : root.outerHTML), version:build ? build.content : 'local' };
  }
  function sameSnapshot(a, b) {
    return !!(a && b && a.key === b.key && a.continuous === b.continuous && a.direction === b.direction);
  }
  function pageStyle() {
    var css = document.getElementById('tec-print-page-size');
    if (!css) { css = document.createElement('style'); css.id = 'tec-print-page-size'; document.head.appendChild(css); }
    return css;
  }
  function prepared(state, options) {
    var current = snapshot(state,options);
    return readyArtifact && !readyArtifact.disposed && readyArtifact.iframe.isConnected &&
      sameSnapshot(current, readyArtifact.snapshot) ? readyArtifact : null;
  }
  function dispose(artifact) {
    if (!artifact || artifact.disposed) return;
    artifact.disposed = true;
    if (artifact.iframe) artifact.iframe.remove();
    if (readyArtifact === artifact) {
      readyArtifact = null;
      if (!printSession) { var css = document.getElementById('tec-print-page-size'); if (css) css.remove(); }
    }
  }
  function invalidate() {
    generation++;
    if (readyArtifact) dispose(readyArtifact);
    if (pendingArtifact) dispose(pendingArtifact.artifact);
    pendingArtifact = null;
    if (!printSession) { var css = document.getElementById('tec-print-page-size'); if (css) css.remove(); }
  }
  function publishWarm(artifact, state) {
    if (printSession || !artifact || !artifact.continuous || artifact.overHeightLimit || !sameSnapshot(snapshot(state), artifact.snapshot)) return;
    // Publish only measured geometry before Chromium takes its native page-format
    // snapshot. Body remains in ordinary screen mode until beforeprint.
    pageSize({css:pageStyle(), continuous:true, fallback:false}, artifact.heightMM);
  }
  function frames() {
    return new Promise(function(resolve) { requestAnimationFrame(function() { requestAnimationFrame(resolve); }); });
  }
  function imageReadiness(root) {
    return Promise.all(Array.from(root.querySelectorAll('img')).map(function(img) {
      img.loading = 'eager';
      var loaded = img.complete ? Promise.resolve() : new Promise(function(resolve) {
        img.addEventListener('load', resolve, {once:true}); img.addEventListener('error', resolve, {once:true});
      });
      return loaded.then(function() { return img.decode ? img.decode().catch(function() {}) : undefined; });
    }));
  }
  async function measureDocument(state, current) {
    var iframe = document.createElement('iframe');
    iframe.className = 'tec-print-measure-frame'; iframe.title = 'تجهيز التقرير'; iframe.setAttribute('aria-hidden','true'); iframe.tabIndex = -1;
    var widthMM = current.continuous ? CONTINUOUS_WIDTH_MM : current.direction === 'landscape' ? 297 : 210;
    var contentWidthMM = widthMM - (current.continuous ? CONTINUOUS_MARGIN_MM * 2 : 20);
    iframe.style.cssText = 'position:fixed;left:-100000px;top:0;width:' + widthMM + 'mm;height:1000px;border:0;pointer-events:none;opacity:0;';
    document.body.appendChild(iframe);
    var doc = iframe.contentDocument, win = iframe.contentWindow;
    doc.open(); doc.write('<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"></head><body></body></html>'); doc.close();
    var base = doc.createElement('base'); base.href = document.baseURI; doc.head.appendChild(base);
    var link = doc.createElement('link'); link.rel = 'stylesheet';
    var cssReady = new Promise(function(resolve,reject) {
      link.addEventListener('load',resolve,{once:true}); link.addEventListener('error',function(){reject(new Error('Print measurement stylesheet did not load'));},{once:true});
    });
    link.href = new URL('assets/css/print-measure-bundle.css?v=' + encodeURIComponent(current.version), document.baseURI).href;
    doc.head.appendChild(link);
    doc.body.className = document.body.className;
    doc.body.setAttribute('data-screen',state.screen);
    doc.body.setAttribute('data-tec-print',current.continuous ? 'continuous' : 'a4');
    doc.body.setAttribute('data-tec-print-orientation',current.direction);
    if (state.screen === 'dashboard') doc.body.setAttribute('data-monthly-layout',current.continuous ? 'continuous' : 'a4');
    doc.documentElement.style.setProperty('--tec-print-legal',JSON.stringify(legal()));
    // Scrollbars must not narrow the print viewport. Pagination is measured from
    // content geometry, independently of this offscreen frame's height.
    doc.documentElement.style.setProperty('overflow','hidden','important');
    var root = current.root.cloneNode(true); doc.body.appendChild(root);
    var artifact = { iframe:iframe, frame:iframe, document:doc, window:win, root:root,
      report:root.querySelector('.mp-report') || root, snapshot:current,
      continuous:current.continuous, layout:current.continuous ? 'continuous' : 'a4', direction:current.direction,
      widthMM:widthMM, contentWidthMM:contentWidthMM, heightMM:null, contentHeightPx:null, disposed:false };
    artifact.cleanup = function() { dispose(artifact); };
    if (current.continuous && pendingArtifact && sameSnapshot(pendingArtifact.snapshot,current)) pendingArtifact.artifact = artifact;
    var timer;
    try {
      await Promise.race([(async function() {
        await cssReady;
        // First activate print-only layout; only then wait for its font faces.
        root.getBoundingClientRect();
        if (doc.fonts && doc.fonts.ready) await doc.fonts.ready;
        await imageReadiness(root);
        root.getBoundingClientRect();
        if (doc.fonts && doc.fonts.ready) await doc.fonts.ready;
        await frames();
      })(), new Promise(function(resolve,reject) { timer = setTimeout(function(){reject(new Error('Print preparation timed out'));},READINESS_TIMEOUT_MS); })]);
      if (artifact.disposed) throw new Error('Print preparation superseded');
      var rect = root.getBoundingClientRect(), contentHeight = Math.max(rect.height,root.scrollHeight);
      if (!rect.width || !contentHeight || !Number.isFinite(contentHeight)) throw new Error('Print report has no measurable geometry');
      if (current.continuous && Math.abs(rect.width - contentWidthMM / MM_PER_PX) > 2) throw new Error('Print measurement width differs from page content');
      artifact.contentHeightPx = contentHeight;
      artifact.heightMM = current.continuous ? Math.max(CONTINUOUS_INITIAL_HEIGHT_MM,
        Math.ceil(contentHeight * MM_PER_PX) + CONTINUOUS_MARGIN_MM * 2 + CONTINUOUS_FOOTER_RESERVE_MM + 3) : current.direction === 'landscape' ? 210 : 297;
      artifact.overHeightLimit = current.continuous && artifact.heightMM > CONTINUOUS_MAX_HEIGHT_MM;
      artifact.geometry = { widthMM:widthMM,contentWidthMM:contentWidthMM,heightMM:artifact.heightMM,contentHeightPx:contentHeight };
      return artifact;
    } catch (error) { dispose(artifact); throw error; }
    finally { clearTimeout(timer); }
  }
  function preflight(state, options) {
    var current = snapshot(state,options), cached = prepared(state,options);
    if (!current) return Promise.resolve(null);
    if (cached) { publishWarm(cached,state); return Promise.resolve(cached); }
    if (!current.continuous) return measureDocument(state,current);
    if (pendingArtifact && sameSnapshot(current,pendingArtifact.snapshot)) return pendingArtifact.promise;
    invalidate();
    var ticket = generation, pending = {snapshot:current,artifact:null,promise:null}; pendingArtifact = pending;
    pending.promise = measureDocument(state,current).then(function(artifact) {
      if (ticket !== generation || !sameSnapshot(snapshot(state),current)) { dispose(artifact); return null; }
      readyArtifact = artifact; publishWarm(artifact,state); return artifact;
    }).finally(function(){if(pendingArtifact===pending)pendingArtifact=null;});
    return pending.promise;
  }
  function warm(state) {
    warmState = state;
    if (!continuousRequested(state)) { invalidate(); return Promise.resolve(null); }
    return preflight(state).catch(function() { return null; });
  }
  function preparedDocument(state, options) {
    // The consumer may read computed styles and serialize this full prepared
    // document. Call cleanup only after serialization; source DOM is untouched.
    // A height-limit fallback may request {layout:'a4'} without changing the
    // saved monthly layout or source scope/date.
    return preflight(state,options);
  }
  function continuousFallback(session, artifact) {
    session.fallback = true;
    document.body.setAttribute('data-tec-print', 'a4');
    document.body.setAttribute('data-monthly-layout', 'a4');
    pageSize(session);
    var tooLong = artifact && artifact.overHeightLimit;
    window.dispatchEvent(new CustomEvent('tec-print-layout-fallback', { detail: {
      layout:'a4', reason:tooLong ? 'page-height-limit' : 'preflight-unavailable',
      heightMM:artifact && artifact.heightMM, maxHeightMM:CONTINUOUS_MAX_HEIGHT_MM,
      message:tooLong ? 'يتجاوز التقرير حد طول الصفحة المتصلة؛ تم استخدام صفحات A4 عمودية للحفاظ على جميع البنود والملاحظات.' :
        'لم يكتمل تجهيز الصفحة المتصلة؛ تم استخدام صفحات A4 عمودية للحفاظ على جميع البنود والملاحظات.'
    } }));
  }
  function measureContinuous() {
    var session = printSession;
    if (!session || !session.continuous || session.fallback) return;
    // Native beforeprint is synchronous: late fonts cannot change page size.
    // Both toolbar and native printing reuse the already measured document.
    pageSize(session,session.heightMM);
  }
  function measurePrint(session) {
    if (session !== printSession || !document.body.hasAttribute('data-tec-print')) return;
    if (session.continuous && !session.fallback) measureContinuous();
    else measureRows(session.direction);
  }
  function measureRows(direction) {
    // Hidden paper DOM has no useful geometry before print media is active.
    // Measure synchronously on actual media entry, not just before window.print.
    if (!printMediaActive()) return;
    if (document.body.getAttribute('data-tec-print') === 'continuous') { measureContinuous(); return; }
    direction = direction === 'landscape' || direction === 'portrait' ? direction :
      document.body.getAttribute('data-tec-print-orientation') || 'portrait';
    var max = (direction === 'landscape' ? 190 : 277) * 96 / 25.4;
    document.querySelectorAll('#app tbody tr').forEach(function (row) {
      var rect = row.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      var table = row.closest('table'), head = table && table.tHead;
      var available = Math.max(0, max - (head ? head.getBoundingClientRect().height : 0));
      row.classList.toggle('tec-print-tall-row', rect.height > available);
    });
    document.querySelectorAll('#app .mp-card, #app .pd-panel, #app .entity-print-summary, #app .cmp-kpi, #app .cmp-section, #app .cmp-record, #app .rpt-chart-panel').forEach(function (card) {
      var rect = card.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      card.classList.toggle('tec-print-tall-card', rect.height > max);
    });
  }
  function prepare(state) {
    var root = document.getElementById('app');
    if (!root || !state || !state.data) return;
    var continuous = continuousRequested(state), direction = continuous ? 'portrait' : orientation(state), css = pageStyle();
    if (!printSession || printSession.root !== root || printSession.css !== css || printSession.continuous !== continuous) {
      var artifact = continuous ? prepared(state) : null;
      printSession = { root:root, css:css, continuous:continuous, direction:direction, fallback:false,
        monthlyLayout:document.body.getAttribute('data-monthly-layout'), heightMM:artifact && artifact.heightMM };
      if (continuous && (!artifact || artifact.overHeightLimit)) continuousFallback(printSession,artifact);
    }
    var session = printSession; session.direction = direction;
    pageSize(session,session.heightMM);
    document.documentElement.style.setProperty('--tec-print-legal', JSON.stringify(legal()));
    document.body.setAttribute('data-tec-print', continuous && !session.fallback ? 'continuous' : 'a4');
    document.body.setAttribute('data-tec-print-orientation', direction);
    if (session.fallback) document.body.setAttribute('data-monthly-layout', 'a4');
    if (state.screen !== 'dashboard') {
      var heading = document.getElementById('tec-print-first-header');
      if (!heading) { heading = document.createElement('header'); heading.id = 'tec-print-first-header'; heading.className = 'tec-print-first-header'; heading.setAttribute('dir','rtl'); root.insertBefore(heading,root.firstChild); }
      heading.innerHTML = headerContent(state);
    }
    groupPanels();
    measurePrint(session);
    requestAnimationFrame(function () { measurePrint(session); });
  }
  function clear() {
    var session = printSession; printSession = null;
    if (session && session.fallback) {
      if (session.monthlyLayout === null) document.body.removeAttribute('data-monthly-layout');
      else document.body.setAttribute('data-monthly-layout', session.monthlyLayout);
    }
    document.body.removeAttribute('data-tec-print');
    document.body.removeAttribute('data-tec-print-orientation');
    var heading = document.getElementById('tec-print-first-header'); if (heading) heading.remove();
    var css = document.getElementById('tec-print-page-size'); if (css) css.remove();
    document.documentElement.style.removeProperty('--tec-print-legal');
    document.querySelectorAll('.tec-print-panel-pair').forEach(function(pair){pair.replaceWith.apply(pair,Array.from(pair.children));});
    document.querySelectorAll('.tec-print-grouped').forEach(function(grid){grid.classList.remove('tec-print-grouped');});
    document.querySelectorAll('.tec-print-tall-row').forEach(function(row){row.classList.remove('tec-print-tall-row');});
    document.querySelectorAll('.tec-print-tall-card').forEach(function(card){card.classList.remove('tec-print-tall-card');});
    if (warmState) publishWarm(prepared(warmState),warmState);
  }
  if (window.matchMedia) {
    var printMedia = window.matchMedia('print');
    var mediaChanged = function (event) {
      if (event.matches && printSession) measurePrint(printSession);
    };
    if (printMedia.addEventListener) printMedia.addEventListener('change', mediaChanged);
    else if (printMedia.addListener) printMedia.addListener(mediaChanged);
  }
  if (document.fonts && document.fonts.addEventListener) {
    document.fonts.addEventListener('loadingdone', function () { if (printSession) measurePrint(printSession); });
  }
  if (document.addEventListener) {
    var imageReady = function (event) {
      var session = printSession;
      if (session && session.continuous && !session.fallback && event.target &&
          event.target.tagName === 'IMG' && session.root.contains(event.target)) measurePrint(session);
    };
    // Also catch images completing after media entry or a pending-font recheck.
    document.addEventListener('load', imageReady, true);
    document.addEventListener('error', imageReady, true);
  }
  S.printPagination = { prepare:prepare, clear:clear, preflight:preflight, warm:warm, prepared:prepared, preparedDocument:preparedDocument, invalidate:invalidate, measureRows:measureRows, measureContinuous:measureContinuous, orientation:orientation, headerContent:headerContent };
})(window.Saytara = window.Saytara || {});
