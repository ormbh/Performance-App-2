# Performance App v157

The monthly legislation card now shows one **منجز** figure combining the existing SLC completion categories, alongside **قيد العمل**. Where the source supports that relationship, **منها متأخر** appears beneath in progress; late items are not counted again in the total.

The Green/Linen completion bar and **نسبة المنجز** caption use the full filtered legislation total. Counts, drilldowns and available changes follow the selected workbook and scope. Existing source categories remain available in underlying data and detailed comparisons. The same composition appears in native continuous and A4 PDF output.

Extract the complete folder and open **index.html**. All application assets remain local. Select your report workbook; no workbook is bundled. The illustration's example numbers are not hardcoded.

The current design contract is **DESIGN-PRINCIPLES-v157.md**, Revision 24. See **VERIFICATION-v157.md** for the checks performed and their limits. Earlier verification files describe their original releases.
