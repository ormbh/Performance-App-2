# Performance App v152

The search landing page places the menu beside **بحث في التقرير**. The menu, search action and **عرض جميع النتائج** form one centered RTL row beneath the search field, with aligned vertical centers. The menu remains within the visible viewport on desktop and phone.

Extract the complete folder and open **index.html**. See **VERIFICATION-v152.md**. This update retains the v151 agenda layout and existing app charts; the revised vertical-quarter illustration remains a separate review concept.

# Historical Performance App v151

Agenda tables reserve space for **موعد الإنجاز** on one line. Approved and emerging section titles use consistent heading and metadata styles. The cover title, entity and reporting period are centered horizontally and vertically. Empty approved table sections and their jump links are omitted.

The existing chart bars are retained, as requested. A separate vertical-quarter illustration is a review concept only and is not applied to this app.

Extract the complete folder and open **index.html**. See **VERIFICATION-v151.md** and **AGENDA-DESIGN-v151.md**; earlier release notes below are historical.

# Historical Performance App v150

Agenda charts hide any category with no records in the selected scope. A single remaining category uses the full chart width on screen and in PDF. When all categories are empty, the report shows its existing empty-state message. Zeros within populated categories remain dashes, and source counts/filter rules are unchanged.

This includes the v149 full-page cover, numbering/copyright from physical page 2, emerging-topic title/count/entity column, and removal of the chart scale note. Extract the entire folder and open **index.html**. See **VERIFICATION-v150.md**; earlier release notes below are historical.

# Historical Performance App v149

The agenda PDF cover image fills the complete A4 landscape page, with no cover footer. Copyright and page numbering start on the second physical page as **صفحة 1**; the cover is excluded from the displayed page total. Content-page margins and the combined chart/definitions page are retained.

Emerging-topic tables include **الجهة المعنية**, plus the heading **المواضيع المستجدة** and its topic count. The chart scale note **عدد المواضيع 0–…** is removed from screen and PDF. Source values and filter rules are unchanged.

Extract the entire folder and open **index.html**. See **VERIFICATION-v149.md** and **AGENDA-DESIGN-v149.md** for this update. Earlier release notes are historical.

# Historical Performance App v148

The agenda PDF restores its dedicated cover. Both charts and **تعريفات مستويات الإنجاز** share page 2, with colored squares beside the definitions and no duplicate upper legend. Positive completed/late chart numbers use their status colors; zero dashes remain neutral. Detail tables show their cohort, quarter and topic count above them.

The search landing-page menu is on the right. The shared app menu uses the newly requested sequence. Extract the complete folder and open **index.html**. See **VERIFICATION-v148.md** and **AGENDA-DESIGN-v148.md** for the current change; earlier release notes below are historical.

# Historical Performance App v147

**تعريفات مستويات الإنجاز** now appears directly beneath the agenda chart, before the topic tables, on screen and in the PDF reading order. The existing definitions, chart, legend and source data are retained. The strategy pair now reads **المؤشرات المعتمدة / المؤشرات المقاسة**, with the approved count on the right and measured count on the left. Coverage calculations are unchanged.

Extract the complete folder and open **index.html**. See **VERIFICATION-v147.md** for this focused update. Previous release notes below are historical.

# Historical Performance App v146

## Approved agenda report

The agenda report uses the approved status-row / quarter-column matrix. Zeros display as **–**; only **متأخر** and **منجز** status labels use Red/Green. A shared legend remains. Percentages and repeated bottom-left grand totals are removed. Empty statuses/quarters hide across the filtered report; intersections remain aligned with dashes.

The report title, selected entity (when applicable), and reporting month range appear in the first-page PDF header only. Both charts stay together on A4 landscape. Topic/entity columns are wider and the source-notes appendix is removed from the agenda page and PDF. Record notes and the existing PowerPoint report pipeline remain separate from this page/PDF change.

Extract the complete folder and open **index.html** with its **assets** folder beside it. Native PDF download uses the bundled offline engine. No source workbook is included. See **VERIFICATION-v146.md** for executed checks and limits; **AGENDA-DESIGN-v146.md** records the approved agenda-specific rules.

# Historical Performance App v145

## Current release — search results and search prompt

The shared search prompt is **ابحث عن بند أو مشروع أو مسؤول**. Search results use the approved compact toolbar, clearer matching-text highlight, four-column default desktop table and readable phone rows. The existing full record details, optional columns, filters, sorting, pagination and offline PDF/CSV downloads remain available.

Search scope summaries now follow the dashboard: first selected name **+N**, or **الكل** when all/unrestricted. Exact source tokens, records, query matching and default status/date ordering remain unchanged.

The search landing page retains the approved logo/title/field arrangement. The consolidated **Revision 20** standard is included in **DESIGN-STANDARD.md**. Current verification and practical limits are in **VERIFICATION-v145.md**. Earlier release notes below retain their historical scope.

## Historical Performance App v144

### Approved monthly completion layout — v144

v144 applies two separate, equal agenda-category boxes and adjacent **نسبة المنجز** percentage captions below the agenda, council-decision, legislation and special-project bars. Budgeted projects now have their own solid green/Linen completion bar and caption beneath status figures, before quarters. The caption stays beside its percentage in both the dashboard and continuous/A4 PDFs.

Percentages use the current scope and each card's full denominator; legislation completion includes both completed SLC categories. Source totals, financial bars, strategy metrics, report filters, PDF filenames and earlier note-removal rules retain their behavior. Invalid or unavailable percentages are omitted rather than presented as zero.

The consolidated **Revision 19** standard is included in **DESIGN-STANDARD.md**. Current checks and practical limits are recorded in **VERIFICATION-v144.md**. Previous release notes below describe the history of the app.



v143 downloads monthly PDFs with short English filenames: **TEC_Monthly_Sep_26.pdf**, **TEC_Monthly_Sep_26_Dubai_Plan_Office.pdf**, or **TEC_Monthly_Sep_26_Governance_Sector.pdf**. The date follows the report date. Use the first selected unit name, otherwise the first selected sector, and omit **+N**. See **VERIFICATION-v143.md** for focused checks and limits.

The supplied official English names are mapped locally. Filenames omit a terminal **Department** or **Section** while retaining **Office**, **Sector**, and **General Secretariat of the Executive Council** without an added Sector suffix. Full official mapping names and Arabic workbook fields/report captions remain intact. The filename uses ASCII letters, digits and underscores, converts **&** to **and**, and requires no hidden direction controls. An unlisted Arabic scope uses **Selected_Unit** or **Selected_Sector** until its approved translation is added. The complete approved mapping and filename forms are in **DESIGN-STANDARD.md**.

Monthly continuous and A4 PDFs omit the special-project **جهة الطلب غير مسجلة … مشمولة في الإجمالي** note and the explanation that the prior month's saved project statuses do not cover its total. Both notes remain on screen. Source counts, comparison eligibility and unavailable-change handling retain their existing rules; other source/comparison warnings remain in output. Empty note containers are omitted. Optional native monthly printing uses the same exported composition.

Retained monthly filter display:

- Partial selection: first selected name, then **+N** additional choices. One choice shows only its name.
- All choices selected or an unrestricted filter: **الكل**, without a count.
- Removing the first choice promotes the next remaining choice; selection order is preserved.
- PDF filename: **TEC_Monthly_Mmm_yy[_scope].pdf**, using the report date and a partial unit selection before a partial sector selection. Multiple selections use only the first name; all-selected/unrestricted scope is omitted. With no partial scope, use **TEC_Monthly_Sep_26.pdf**. Retain filename cleanup and the 240-character limit; shorten an unusually long scope while retaining the date and genuine .pdf extension.

The dropdown still exposes the complete checked choices. The selected data, totals, source matching and output profiles retain their definitions. See **VERIFICATION-v141.md** for the historical filter-display checks and **VERIFICATION-v143.md** for historical filename checks and limits.

Retained v140 / Revision 15 refinements:

- Below the strategic-budget project quarters, show only **مشاريع 2027: N** when the filtered count of projects with a valid 2027 finish year is positive. Otherwise omit the line and its spacing. Preserve the separate quarter reference-year label and quarter figures.
- Keep the approved budget total first, then **المنفق حسب الفواتير**, its amount/change and solid Teal bar, followed by **المخصص / غير المخصص** and the solid Taupe allocation bar.
- Remove the visible dynamic spending-percentage caption, such as **الإنفاق 31.8% من الموازنة المعتمدة**, while preserving the calculation, approved-budget denominator and accessible bar label.
- Apply completion colors to the **SLC منجز بعد موعد** change arrow and number: positive Green #01831E, negative Red #C00000, zero changes hidden, with the existing unavailable-comparison handling retained. The completed main figure stays Green; date cohorts, timing formulas and isolated SLC caption order retain their rules.

Source calculations and financial values retain their definitions. See **VERIFICATION-v140.md** for the historical v140 focused checks and practical limits.

Extract the complete ZIP, then open `index.html` with its `assets` folder beside it.
All scripts, images and approved fonts are bundled locally. Select your report
workbook on the upload page. Workbook processing stays on your device.

## Offline PDF download

The report action is now **تنزيل PDF**. It downloads a real PDF directly on your
computer, without opening a browser print dialog or using an internet service.
The local PDF engine, font bytes, text shaping and official logo are bundled in
the complete app ZIP. Extract the whole folder before opening `index.html`.

Monthly output defaults to one continuous 297mm-wide page with the approved
281mm content width, Linen canvas, 8mm top/side insets and 16mm footer reserve.
Monthly A4 portrait remains available in **إعدادات PDF**. Agenda, council and HH
reports use A4 landscape; other reports use A4 portrait. No A3 format is offered.
First-page headers show the official logo, report title with the actual cutoff date,
and a sector/organisational-unit scope line. The entity filter stays out of the
header while continuing to filter the report. Footers contain copyright and page numbers.
The exporter uses the current source, scope and complete report records; it
writes native text and vector charts, with approved logos kept as image assets.

Original TEC font files, metrics, colors and source models stay unchanged.
The PDF engine includes shaping for the supplied Arabic fonts and a licensed,
symbol-only fallback for characters missing from those faces. See
`assets/vendor/offline-pdf-VERSIONS.json`, `assets/vendor/offline-pdf-LICENSES.txt`
and `FONT-ASSETS.md` for provenance. This is a local browser app; the PDF
exporter is independent of browser printer settings.

The native browser keyboard/menu print path remains available for users who
need it; its preparation now waits for complete fonts/layout and never prints
an unmeasured 80mm temporary page. There is no Print button in the app.

Final v139 direct-download checks pass; results and practical
limits are recorded in **VERIFICATION-v139.md**. Revision 14 restores the
exported sector/unit scope line and removes the strategy card's **مؤشرات الأداء**
tag. Earlier v138 offline-download checks remain historical evidence in
**VERIFICATION-v138.md**; they do not establish a v139 pass.

## Approved TEC design

This release implements the approved design in the app, including the monthly
and projects dashboards, their browser reports, search, search results and upload.
The consolidated **Revision 19** standard includes the preceding Revision 18 filename rules. Revision 18 uses TEC_Monthly, the report month/year and an optional official English scope name, omitting terminal Department/Section and additional-selection counts from filenames. It also removes the two specified notes from monthly PDF output while preserving their screen diagnostics and source rules. It retains Revision 16’s compact dashboard/header summaries and Revision 15’s conditional 2027 annotation, spending above allocation, removal of the visible spending-percentage caption and completion colors for the SLC completed-after-deadline change. It retains Revision 14's removal of the strategy **مؤشرات الأداء** tag and the export's first-page sector/unit scope line beneath the actual-date report title. A valid nonzero strategy total-count difference remains as a neutral, unlabeled header change. Revision 13's direct **تنزيل PDF** workflow and Revision 12's full-page Linen monthly surface, reading insets, footer reserve and card/table spacing remain approved. Selectable A4 output remains available. Historical v143 results and practical limits belong in **VERIFICATION-v143.md**; **VERIFICATION-v142.md**, **VERIFICATION-v141.md**, **VERIFICATION-v140.md** and earlier files retain their historical release scopes.
The latest approved Google-like search layout supplements that standard.

- DIN Next Arabic Regular headings: page 38px (search home 36px), portfolio 30px and card 28px.
  DIN Next LT Arabic Regular figures: 34–40px; special-project subgroup totals and status figures remain 28px. Subgroup names are 18px Dubai Regular. Dubai Regular supporting text;
  table names, notes and status text 16px, table headings Dubai Bold 18px, explanations 14px,
  agenda category labels (الأجندة المعتمدة / المواضيع المستجدة) 18px,
  monthly dashboard short value/status labels and strategy metric names 16px, change arrows 15px and metadata 14px. Table names/notes and essential explanations use Ink #4F4E4E; neutral differences and secondary metadata use Taupe #756B5F.
- Names remain neutral and regular. Approved status badges are informational,
  with separate accessible drilldown controls. Completed work is green, including
  legislation completed after its deadline; unfinished late work is red.
- Shared report headers retain the official logo, a 38px title and only the
  cutoff date below it. Primary navigation uses Search plus the current-page link with a
  current-page underline; other destinations and utilities remain in the app menu.
  Search home uses the menu only; search results use one current Search link.
  The home title is moved 4px upward from v132, preserving the logo, field and action positions. All three report destinations appear as direct links in both the search and shared page menus. PDF actions sit together, followed by separate sector/unit/entity filters.
  Project type, priority, quarter, status and manager filters use an additional
  disclosure. Closing it preserves selections. Clearing scope preserves the file,
  report date, historical comparison and saved display/output preferences.
- Shared controls use readable labels, 44px minimum action targets, approved normal,
  hover, pressed and disabled states, and visible keyboard focus. Menus dismiss
  outside or on Escape; keyboard menu navigation and mobile filter focus are retained.
- Generic explanatory subtitles beneath titles are removed. Actual table notes,
  field/value labels, required dates, source caveats and meaningful definitions remain, except the approved removal of passive financial numeric-availability annotations.
  Screen footers show only the copyright line.
- Monthly content uses the available width at 100% browser zoom. Executive
  portfolios remain on the right, projects on the left and strategy below
  legislation. Short labels remain above their figures, including on mobile; the main total label stays below its total. Valid historical metric changes remain below their values; the strategy total-count difference is the approved unlabeled header exception. Empty status
  and priority groups stay hidden; zero counts use a dash while meaningful
  source progress of 0% is retained.
- Financial bars use solid fills, including partial numeric coverage: allocation remains Taupe, spending Teal and the unused track Linen. The strategic-budget card keeps the budget total first, the invoice-spending amount/change and Teal bar next, and the allocated/unallocated row and Taupe bar below. The visible dynamic **الإنفاق … من الموازنة المعتمدة** caption, hatching and passive numeric-availability notes are removed on screen and in both PDF formats. Actual notes, diagnostic drilldowns, metric definitions, financial ratios, missing-value exclusions and the spending bar's accessible label remain.
- Strategic-budget quarters show **مشاريع 2027: N** only when the filtered valid-2027 project count is positive; zero omits the annotation and its spacing. The separate quarter reference-year label stays visible under its existing rules. The removed full finish-year summary does not change the source classification or quarter calculations.
- Projects keep the approved paired sections and chart scales. Priority charts
  fit their visible content without internal vertical scrollbars. The follow-up
  table includes late, frozen, cancelled and transferred projects in that order.
- Search has a centered TEC logo, a pill-shaped search field and two primary
  tasks. Results use the approved six-column table with native details, filters,
  sorting, column customization, pagination, CSV and PDF download of all matches.
  On mobile, the readable table scrolls inside its own labelled region.
- Upload uses the approved panel, drop zone and button hierarchy while retaining
  native selection, drag/drop, local processing, busy-state guards and error
  recovery. Invalid replacement files do not discard the current workbook.
- The strategy card omits the **مؤشرات الأداء** tag as well as the repeated coverage/unmeasured-count, result-count and target-count notes on screen and in both output formats. Keep a valid nonzero total-count difference as a neutral, unlabeled header change (15px Dubai Regular Taupe on screen; 11pt in output). Primary values, the measured/registered denominator, measurement bar and valid metric changes remain; figures/changes align when side by side.
- SLC stays first at the physical left of each mixed-language caption, followed by isolated Arabic. On phones, legislation metrics reflow into two columns without shrinking 16px labels.
- Legislation timing labels read **SLC منجز ضمن موعد** and **SLC منجز بعد موعد**. The repeated SLC comparison paragraph is removed; timing formulas and source notes are retained. The completed-after-deadline change arrow and number use the existing completion treatment: positive Green #01831E, negative Red #C00000, unchanged/unavailable hidden. Its main figure stays Green on screen and in continuous/A4 PDF.
- Monthly digital output defaults to **PDF متصل — صفحة واحدة**: a custom 297mm-wide PDF with 281mm content width, an 8mm reading inset and additional bottom footer reserve. Its actual page margins are 8mm top/left/right and 16mm bottom; height is measured from the complete report. Linen #EFEBE7 fills the whole page, including its insets, with Paper #FCFBFB cards and their approved Sand borders. Projects remain left, executive portfolios right and full-width followups below; the white outer frame is removed.
- The continuous page reserves an extra 8mm at the bottom for its footer. Direct PDF download uses an 11mm footer-baseline inset within this reserve; optional native printing retains top-aligned footer boxes with 1mm top padding. Copyright glyphs must remain at least 8mm from the physical bottom edge. Page-height measurement allows the complete measured content plus 27mm: 8mm top + 16mm bottom + 3mm rounding/clearance. Approved text sizes and source values remain unchanged.
- Continuous digital spacing uses 6mm card/followup padding, an 8mm column gap, 6mm stacked-card gap, 4mm below card headings, 3mm above metric rows/bars and 3.5mm table-cell padding. Portfolio headings use 6mm inline padding to align with card content and 3mm bottom padding. The followup section sits 8mm below the report summary, with 3mm below its heading and 3mm above / 4mm below its status-summary row. The document uses one header/footer and retains approved fonts without zoom or font shrink.
- Monthly **A4 عمودي — للطباعة** remains selectable for physical paper. All paper modes remain A4 only: agenda, council and HH use landscape; projects (including the project report), entities, comparison, search and other views use portrait. A4 margins remain 10mm. Monthly A4 retains its paired portfolios/full-width followups and 4mm column gap; other portrait views retain their own flow. Fitting cards stay together; oversized content continues readably. A3 remains unavailable.
- If a continuous monthly page would exceed 5080mm, the current export uses A4 portrait pages and shows an explanatory toast. All records, notes, values and scope are preserved; the saved format preference is unchanged. This is an unusually long-report fallback, not a truncation or text-shrink option.
- The compliance audit corrects primary/filter interaction states, disabled fills, export loading indication, native chart status colors and number fonts, HH figure fonts/surfaces and ring fit, task-page print cleanup, wrapped checks badges and comparison/table pagination.
- PDF reports use their own readable print scale. Monthly continuous output grows its measured page height; A4 output uses content-driven pagination.
  Table body, names, notes and in-table statuses are 12pt (16 CSS px); column headings
  remain 13.5pt Dubai Bold. Screen table/status text remains 16px.
  The first page has the official logo, one 24pt DIN Next Arabic Regular title including the actual
  report date, and a restored sector/organisational-unit scope line in 10.5pt Dubai Regular Ink.
  Use the active selections, or the existing all-sector/all-unit labels when unrestricted.
  The ordinary continuous monthly PDF has one masthead and footer.
  In paginated A4 output, later pages have no report masthead; table column headings repeat.
  Each output footer has only copyright and the renderer-generated page X of Y.
  The entity filter and its selected value are omitted from print headers;
  the selected scope still filters the report and actual row entity names remain.

## Data and workflows

Source records, matching keys, calculation models, chart eligibility, ranking,
filters and historical comparison rules retain their definitions. A presentation
change does not create a status, replace missing data with zero or invent an arrow.
Search includes all matching source records; the follow-up tables retain their
separate eligibility rules. Missing/unknown statuses remain distinct.

The app reads cached Excel formula results; it does not refresh Excel formulas
or Power Query. Existing note/history storage is retained; the monthly output-format preference is stored separately. To use the
new version, keep the old folder until you have checked your notes/settings in
this browser. Browser file-origin storage may vary when the folder moves.

On the monthly page, open **إعدادات PDF** and use **تنسيق التقرير** to choose:

- **PDF متصل — صفحة واحدة** for the continuous digital document. It is the default when no current format preference is saved; its height follows the complete report.
- **A4 عمودي — للطباعة** for a PDF sized for physical paper. This selection is retained as your monthly format preference; its page count grows with the content.

Then select **تنزيل PDF** to download the selected format directly. No browser print dialog or Background graphics setting is needed for this action. All other report pages use **تنزيل PDF** with their approved A4 orientation. Projects retain their comfortable/compact spacing options and A4 portrait mode in **إعدادات PDF**.

Direct download writes only the approved app header/footer, including actual page counters. It is independent of browser printer settings. To print on paper, open the downloaded A4 PDF in your preferred viewer. Optional native browser printing remains available through the browser's own controls; disable its headers/footers to avoid extra URL/date lines. That separate path depends on browser CSS page-margin support; historical native-print checks used Chromium 151. The continuous monthly format is a digital custom-size page, not an A3 choice. Approved text sizes and selected source scope remain the same in digital and paper output; A4 page count is not forced to match an earlier preview.

## Verification and maintenance

**Revision 15 / Performance App v140** retains the approved typography, surfaces, controls, status palette, source rules and offline PDF workflow, with the conditional 2027 annotation, budget order, spending-caption removal and SLC completion-change refinements described above. Those historical v140 outcomes and practical limits remain in **VERIFICATION-v140.md**; historical v141 filter-summary outcomes belong in **VERIFICATION-v141.md**. Historical **Revision 18 / Performance App v143** filename and targeted PDF-note changes and focused outcomes belong in **VERIFICATION-v143.md**. Revision 17 filename outcomes in **VERIFICATION-v142.md** are historical.

Historical **Revision 14 / Performance App v139** introduced the targeted strategy-tag and exported-header changes. Final v139 direct-download checks pass; outcomes and practical limits are recorded in **VERIFICATION-v139.md**. Historical **Revision 13 / Performance App v138** direct-download and corrected optional native-print evidence remains in **VERIFICATION-v138.md**. **Revision 12 / Performance App v137** browser/source-regression, settled continuous PDF, selected A4, height-limit fallback and upload checks remain in **VERIFICATION-v137.md**; those settled-output tests missed the first native print-preview timing defect. **Revision 11 / Performance App v136** and **VERIFICATION-v136.md** remain historical continuous-format references; **VERIFICATION-v135.md** and earlier files retain their own release scope. No historical pass establishes a v144 result.

Screen/PDF verification uses an explicitly illustrative test workbook; that workbook and its test records are not bundled. The operational workbook visible in the user's screenshots was not supplied. Historical numerical regression uses the frozen illustrative fixture. Historical v143 filename and targeted PDF-note outcomes belong in **VERIFICATION-v143.md**; these presentation changes do not constitute a fresh audit of all calculations. Native Windows file opening and physical printing remain outside these browser checks. Prior extracted-app checks used local HTTP because the managed browser policy blocks direct file navigation.

Readable source modules are included. Rebuild with
`python tools/build-bundles.py`; check them with
`python tools/build-bundles.py --check`. `release-manifest.json` records the SHA-256
of every release file except itself. **FONT-ASSETS.md** identifies bundled fonts.

The exported organizational scope line is limited to views with sector/unit filtering. Entity and data-check views retain their own scope models and do not inherit dashboard selections. Search drill scope and search facets both remain in effect.
