/* Offline native PDF export. Browser layout owns wrapping and geometry;
 * the local font engine writes selectable text and vector shapes. No workbook
 * data is recomputed here, and no report is sent to an external service. */
(function (S) {
  'use strict';
  var PX_PT = 72 / 96, MM_PT = 72 / 25.4, enginePromise;
  function loadEngine() {
    if (S.pdfEngine) return Promise.resolve(S.pdfEngine);
    if (!enginePromise) enginePromise = new Promise(function (resolve, reject) {
      var script = document.createElement('script');
      script.src = new URL('assets/js/lib/offline-pdf-engine.js?v=138', document.baseURI).href;
      script.onload = function () { if (S.pdfEngine) resolve(S.pdfEngine); else { enginePromise=null; reject(new Error('PDF engine unavailable')); } };
      script.onerror = function () { script.remove(); enginePromise=null; reject(new Error('تعذر تحميل مكونات PDF المحلية. استخرج ملف التطبيق كاملاً ثم حاول مجدداً.')); };
      document.head.appendChild(script);
    });
    return enginePromise;
  }
  function opaque(color) { return color && color !== 'transparent' && !/rgba\([^)]*,\s*0\s*\)/.test(color) && color !== 'none'; }
  function color(doc, css, stroke) {
    var m = css && css.match(/rgba?\(([^)]+)\)/), c = css, a=1;
    if(m){var parts=m[1].split(',').map(Number);c=parts.slice(0,3);if(parts.length>3)a=parts[3];}
    if(stroke){doc.strokeColor(c);doc.strokeOpacity(a);}else {doc.fillColor(c);doc.fillOpacity(a);}
  }
  function collect(artifact) {
    var root=artifact.root, win=root.ownerDocument.defaultView, origin=root.getBoundingClientRect();
    var ops=[], lines=[], avoids=[], breaks=[], tables=[];
    var canvas=root.ownerDocument.createElement('canvas'), ctx=canvas.getContext('2d');
    var segmenter=typeof Intl.Segmenter==='function'?new Intl.Segmenter('ar',{granularity:'grapheme'}):null;
    function bounds(el){var r=el.getBoundingClientRect();return {x:r.left-origin.left,y:r.top-origin.top,w:r.width,h:r.height};}
    function text(node, style) {
      if(!node.textContent.trim())return;
      var raw=node.textContent, range=root.ownerDocument.createRange(), chunks=[];
      var svgParent=node.parentElement.namespaceURI==='http://www.w3.org/2000/svg',matrix=svgParent&&node.parentElement.getScreenCTM(),fontScale=matrix?Math.hypot(matrix.c,matrix.d):1;
      if(segmenter)Array.from(segmenter.segment(raw)).forEach(function(s){chunks.push({index:s.index,text:s.segment});});
      else {var pos=0;Array.from(raw).forEach(function(s){chunks.push({index:pos,text:s});pos+=s.length;});}
      var groups=[];
      chunks.forEach(function(ch){
        range.setStart(node,ch.index);range.setEnd(node,ch.index+ch.text.length);
        var rects=Array.from(range.getClientRects()).filter(function(r){return r.width>.01&&r.height>.01;});
        if(!rects.length)return;
        var r=rects[0],key=Math.round(r.top*4),g=groups.find(function(x){return x.key===key;});
        if(!g){g={key:key,text:'',left:r.left,right:r.right,top:r.top,bottom:r.bottom};groups.push(g);}
        g.text+=ch.text;g.left=Math.min(g.left,r.left);g.right=Math.max(g.right,r.right);g.bottom=Math.max(g.bottom,r.bottom);
      });
      ctx.font=style.fontStyle+' '+style.fontWeight+' '+style.fontSize+' '+style.fontFamily;
      groups.forEach(function(g){
        var str=g.text.replace(/[\t\r\n\f]/g,' ');
        if(!/pre/.test(style.whiteSpace))str=str.replace(/ +/g,' ');
        if(!str.trim())return;
        var tm=ctx.measureText(str),ascent=tm.fontBoundingBoxAscent;
        if(!Number.isFinite(ascent))ascent=parseFloat(style.fontSize)*.8;
        var exactBaseline=null;
        if(svgParent&&matrix&&node.parentElement.getStartPositionOfChar){try{var pt=node.parentElement.getStartPositionOfChar(0);exactBaseline=matrix.b*pt.x+matrix.d*pt.y+matrix.f-origin.top;}catch(ignore){}}
        var op={type:'text',text:str,x:g.left-origin.left,y:g.top-origin.top,w:g.right-g.left,h:g.bottom-g.top,
          baseline:exactBaseline===null?g.top-origin.top+ascent*fontScale:exactBaseline,size:parseFloat(style.fontSize)*fontScale,font:style.fontFamily,bold:Number(style.fontWeight)>=600,
          direction:style.direction,color:svgParent?style.fill:style.color,letterSpacing:parseFloat(style.letterSpacing)||0};
        lines.push(op);ops.push(op);
      });
      range.detach();
    }
    function svg(el, style) {
      var tag=el.tagName.toLowerCase(),matrix=el.getScreenCTM&&el.getScreenCTM();
      if(!matrix)return false;
      if(tag==='text'||tag==='tspan')return false;
      var allowed=['rect','circle','ellipse','path','line','polygon','polyline'];
      if(allowed.indexOf(tag)<0)return false;
      var attrs={};Array.from(el.attributes).forEach(function(a){attrs[a.name]=a.value;});
      ops.push({type:'svg',tag:tag,attrs:attrs,matrix:[matrix.a,matrix.b,matrix.c,matrix.d,matrix.e-origin.left,matrix.f-origin.top],
        x:bounds(el).x,y:bounds(el).y,w:bounds(el).w,h:bounds(el).h,fill:style.fill,stroke:style.stroke,strokeWidth:parseFloat(style.strokeWidth),opacity:parseFloat(style.opacity)});
      return true;
    }
    function visit(el){
      var st=win.getComputedStyle(el),r=bounds(el);
      if(st.display==='none'||st.visibility==='hidden'||Number(st.opacity)===0)return;
      if(el.tagName.toLowerCase()==='defs'||el.tagName.toLowerCase()==='title'||el.tagName.toLowerCase()==='desc')return;
      // display:contents has no own rectangle, but its source text and child
      // boxes remain visible. Printable report links use it intentionally.
      if(!el.getClientRects().length){
        if(st.display!=='contents')return;
        Array.from(el.childNodes).forEach(function(n){if(n.nodeType===1)visit(n);else if(n.nodeType===3)text(n,st);});
        return;
      }
      if(st.breakBefore==='page'||st.breakBefore==='always'||st.pageBreakBefore==='always')breaks.push(r.y);
      if(st.breakAfter==='page'||st.breakAfter==='always'||st.pageBreakAfter==='always')breaks.push(r.y+r.h);
      if((/avoid/.test(st.breakInside)||/avoid/.test(st.pageBreakInside)||el.tagName==='TR'||el.matches('.mp-metrics,.mp-card-head,.mp-requester h4,.mp-kpi-metric,.mp-money-main'))&&r.h>0)avoids.push({top:r.y,bottom:r.y+r.h,x:r.x,w:r.w,row:el.tagName==='TR'});
      if(el.tagName==='TABLE'&&el.tHead){
        var hr=bounds(el.tHead),first=el.tBodies[0]&&Array.from(el.tBodies[0].rows).find(function(row){return row.getClientRects().length;}),fr=first&&bounds(first);
        tables.push({top:r.y,bottom:r.y+r.h,head:hr});
        if(fr){var top=hr.y;
          // A title can be a sibling of the table or of its scroll wrapper.
          // Keep the nearby visible heading chain with the first source row.
          Array.from(root.querySelectorAll('h2,h3,h4,[role="heading"]')).forEach(function(title){
            if(!title.getClientRects().length||!(title.compareDocumentPosition(el)&4))return;
            var tr=bounds(title),overlap=Math.min(tr.x+tr.w,hr.x+hr.w)-Math.max(tr.x,hr.x);
            if(tr.y<=hr.y&&hr.y-tr.y<160&&overlap>Math.min(tr.w,hr.w)*.5)top=Math.min(top,tr.y);
          });
          avoids.push({top:top,bottom:fr.y+fr.h,x:hr.x,w:hr.w,row:true});}
      }
      if(el.namespaceURI==='http://www.w3.org/2000/svg'&&svg(el,st))return;
      if(el.namespaceURI!=='http://www.w3.org/2000/svg'){
        if(el.matches('.hh-progress-ring')){var before=win.getComputedStyle(el,'::before'),palette=st.backgroundImage.match(/rgba?\([^)]+\)/g)||[];ops.push({type:'ring',x:r.x,y:r.y,w:r.w,h:r.h,value:Math.max(0,Math.min(100,parseFloat(st.getPropertyValue('--progress'))||0)),color:st.getPropertyValue('--progress-color').trim()||'#115E67',track:palette[palette.length-1]||'#E7E0D3',inner:before.backgroundColor,inset:parseFloat(before.left)||6});}
        else if(opaque(st.backgroundColor)&&r.w>0&&r.h>0)ops.push({type:'box',x:r.x,y:r.y,w:r.w,h:r.h,radius:parseFloat(st.borderTopLeftRadius)||0,fill:st.backgroundColor});
        var sides=['Top','Right','Bottom','Left'],uniform=sides.every(function(side){return st['border'+side+'Width']===st.borderTopWidth&&st['border'+side+'Color']===st.borderTopColor&&st['border'+side+'Style']===st.borderTopStyle;});
        if(uniform&&parseFloat(st.borderTopWidth)>0&&st.borderTopStyle!=='none'&&opaque(st.borderTopColor))ops.push({type:'outline',x:r.x,y:r.y,w:r.w,h:r.h,radius:parseFloat(st.borderTopLeftRadius)||0,width:parseFloat(st.borderTopWidth),color:st.borderTopColor});
        if(!uniform)sides.forEach(function(side){var width=parseFloat(st['border'+side+'Width']);if(width>0&&st['border'+side+'Style']!=='none'&&opaque(st['border'+side+'Color']))ops.push({type:'border',x:r.x,y:r.y,w:r.w,h:r.h,side:side,width:width,color:st['border'+side+'Color']});});
      }
      if(el.tagName==='IMG'){
        var embedded=S.pdfImages&&S.pdfImages[el.getAttribute('src')];
        if(!embedded&&S.pdfImages)Object.keys(S.pdfImages).some(function(key){if(el.src.endsWith('/'+key)){embedded=S.pdfImages[key];return true;}return false;});
        if(embedded){ops.push({type:'image',x:r.x,y:r.y,w:r.w,h:r.h,data:embedded});return;}
        var c=root.ownerDocument.createElement('canvas');c.width=el.naturalWidth;c.height=el.naturalHeight;
        if(c.width&&c.height){c.getContext('2d').drawImage(el,0,0);ops.push({type:'image',x:r.x,y:r.y,w:r.w,h:r.h,data:c.toDataURL('image/png')});}
        return;
      }
      var clip=/(hidden|clip)/.test(st.overflowX+' '+st.overflowY)&&r.w>0&&r.h>0;
      if(clip)ops.push({type:'clip-start',x:r.x,y:r.y,w:r.w,h:r.h,radius:parseFloat(st.borderTopLeftRadius)||0});
      var closedDetails=el.tagName==='DETAILS'&&!el.open;
      Array.from(el.childNodes).forEach(function(n){
        // Chromium can expose Range rectangles inside collapsed disclosures;
        // those descendants do not belong to the visible export.
        if(closedDetails&&!(n.nodeType===1&&n.tagName==='SUMMARY'))return;
        if(n.nodeType===1)visit(n);else if(n.nodeType===3)text(n,st);
      });
      if(clip)ops.push({type:'clip-end'});
    }
    visit(root);
    var monthly=null,report=root.querySelector('.mp-report');
    if(report){var columns=Array.from(report.querySelectorAll('.mp-portfolios>div')).map(function(col){return Array.from(col.children).map(function(el){var r=bounds(el);return {x:r.x,y:r.y,w:r.w,h:r.h};});});
      var header=report.querySelector('.mp-header'),follow=report.querySelector('.mp-followups,.mp-empty-followups');
      monthly={header:header&&bounds(header),columns:columns,follow:follow&&bounds(follow)};}
    return {ops:ops,lines:lines,avoids:avoids,breaks:breaks,tables:tables,monthly:monthly,height:Math.max(origin.height,root.scrollHeight),width:origin.width};
  }
  function pagePlan(data, geometry){
    if(geometry.layout==='continuous')return [{start:0,end:data.height,head:null}];
    if(data.monthly&&data.monthly.columns.length)return monthlyPages(data,geometry);
    var pageH=(geometry.direction==='landscape'?210:297)-20;
    var capacity=pageH*96/25.4,plans=[],start=0;
    while(start<data.height-.5){
      var table=data.tables.find(function(t){return start>=t.head.y+t.head.h-.5&&start<t.bottom-.5;});
      var head=table?table.head:null,reserve=head?head.h:0,limit=Math.min(data.height,start+capacity-reserve);
      var forced=data.breaks.filter(function(y){return y>start+capacity*.2&&y<limit;}).sort(function(a,b){return a-b;})[0];
      if(forced!==undefined)limit=forced;
      var end=limit,cutting=data.avoids.filter(function(a){return a.top<end-.5&&a.bottom>end+.5&&a.bottom-a.top<capacity-reserve;});
      // Avoid splitting a fitting row/card. Re-evaluate when two adjacent
      // columns overlap, while retaining a useful amount of content per page.
      for(var n=0;n<30&&cutting.length;n++){
        var eligible=cutting.filter(function(a){return a.top>start+capacity*.25;});
        if(!eligible.length)break;
        var candidate=Math.min.apply(null,eligible.map(function(a){return a.top;}));
        end=candidate;cutting=data.avoids.filter(function(a){return a.top<end-.5&&a.bottom>end+.5&&a.bottom-a.top<capacity-reserve;});
      }
      // A genuinely oversized row/card may continue, but never cut a text line.
      var crossing=data.lines.filter(function(l){return l.y<end-.1&&l.y+l.h>end+.1;});
      if(crossing.length){var lineTop=Math.min.apply(null,crossing.map(function(l){return l.y;}));if(lineTop>start+1)end=lineTop;}
      if(end<=start+1)end=limit;
      plans.push({start:start,end:end,head:head});start=end;
      if(plans.length>2000)throw new Error('التقرير أطول من الحد المتاح لتصدير PDF.');
    }
    return plans.length?plans:[{start:0,end:0,head:null}];
  }

  function monthlyPages(data,geometry){
    var cap=((geometry.direction==='landscape'?210:297)-20)*96/25.4,pages=[],m=data.monthly;
    function page(i){while(pages.length<=i)pages.push({regions:[]});return pages[i];}
    function region(r,at,y){page(at).regions.push({source:r,x:r.x,y:y});}
    function portions(r,at,cursor){
      var start=r.y,end=r.y+r.h;
      while(start<end-.2){
        var table=data.tables.find(function(t){return start>=t.head.y+t.head.h-.5&&start<t.bottom-.5&&t.head.x<r.x+r.w&&t.head.x+t.head.w>r.x;});
        if(cursor>cap-2){at++;cursor=0;}
        if(table&&start>r.y+.5){region(table.head,at,cursor);cursor+=table.head.h;}
        var available=cap-cursor,cut=Math.min(end,start+available);
        var crossing=data.avoids.filter(function(a){return a.top<cut-.2&&a.bottom>cut+.2&&a.bottom-a.top<cap&&a.x<r.x+r.w&&a.x+a.w>r.x&&a.top>start+1;});
        if(crossing.length)cut=Math.min.apply(null,crossing.map(function(a){return a.top;}));
        var text=data.lines.filter(function(l){return l.x<r.x+r.w&&l.x+l.w>r.x&&l.y<cut-.2&&l.y+l.h>cut+.2;});
        if(text.length)cut=Math.min.apply(null,text.map(function(l){return l.y;}));
        if(cut<=start+.5){at++;cursor=0;continue;}
        region({x:r.x,y:start,w:r.w,h:cut-start},at,cursor);cursor+=cut-start;start=cut;
        if(start<end-.2){at++;cursor=0;}
      }
      return {at:at,cursor:cursor};
    }
    if(m.header)region(m.header,0,m.header.y);
    var endings=m.columns.map(function(nodes){
      var at=0,cursor=nodes.length?nodes[0].y:0,previous=null;
      nodes.forEach(function(r){
        var gap=previous?Math.max(0,r.y-previous.y-previous.h):0;
        if(r.h<=cap){if(cursor+gap+r.h>cap+.1){at++;cursor=0;gap=0;}cursor+=gap;region(r,at,cursor);cursor+=r.h;}
        else {if(cursor>0){at++;cursor=0;}var result=portions(r,at,cursor);at=result.at;cursor=result.cursor;}
        previous=r;
      });return {at:at,cursor:cursor};
    });
    if(m.follow){
      var at=Math.max.apply(null,endings.map(function(x){return x.at;})),cursor=Math.max.apply(null,endings.filter(function(x){return x.at===at;}).map(function(x){return x.cursor;}));
      var sourceBottom=Math.max.apply(null,m.columns.map(function(nodes){var last=nodes[nodes.length-1];return last.y+last.h;}));
      var gap=Math.max(0,m.follow.y-sourceBottom);
      if(m.follow.h<=cap){if(cursor+gap+m.follow.h>cap){at++;cursor=0;gap=0;}region(m.follow,at,cursor+gap);}
      else {cursor+=gap;if(cursor>cap-40){at++;cursor=0;}portions(m.follow,at,cursor);}
    }
    return pages;
  }
  function paintRegion(doc,engine,data,placement,xInset,yInset){
    var r=placement.source,x=xInset+placement.x*PX_PT,y=yInset+placement.y*PX_PT;
    doc.save();doc.rect(x-.4,y-.4,r.w*PX_PT+.8,r.h*PX_PT+.8).clip();doc.translate(x-r.x*PX_PT,y-r.y*PX_PT);
    data.ops.forEach(function(op){
      if(op.type==='clip-start'||op.type==='clip-end')paint(doc,engine,op);
      else if(op.x<r.x+r.w+.1&&op.x+op.w>r.x-.1&&op.y<r.y+r.h+.1&&op.y+op.h>r.y-.1){
        if(op.type!=='text'||op.y>=r.y-.2&&op.y+op.h<=r.y+r.h+.2)paint(doc,engine,op);
      }
    });doc.restore();
  }

  function shape(doc,op){
    var a=op.attrs,m=op.matrix;
    doc.save();doc.transform(m[0]*PX_PT,m[1]*PX_PT,m[2]*PX_PT,m[3]*PX_PT,m[4]*PX_PT,m[5]*PX_PT);
    var num=function(k,d){var v=parseFloat(a[k]);return Number.isFinite(v)?v:(d||0);};
    if(op.tag==='rect')doc.roundedRect(num('x'),num('y'),num('width'),num('height'),Math.min(num('rx'),num('width')/2,num('height')/2));
    else if(op.tag==='circle')doc.circle(num('cx'),num('cy'),num('r'));
    else if(op.tag==='ellipse')doc.ellipse(num('cx'),num('cy'),num('rx'),num('ry'));
    else if(op.tag==='path')doc.path(a.d||'');
    else if(op.tag==='line')doc.moveTo(num('x1'),num('y1')).lineTo(num('x2'),num('y2'));
    else{var pts=(a.points||'').trim().split(/[\s,]+/).map(Number);for(var i=0;i+1<pts.length;i+=2){if(i)doc.lineTo(pts[i],pts[i+1]);else doc.moveTo(pts[i],pts[i+1]);}if(op.tag==='polygon')doc.closePath();}
    var fill=opaque(op.fill)&&op.tag!=='line',stroke=opaque(op.stroke)&&op.strokeWidth>0;
    if(fill)color(doc,op.fill);if(stroke){color(doc,op.stroke,true);doc.lineWidth(op.strokeWidth);}
    if(fill&&stroke)doc.fillAndStroke();else if(fill)doc.fill();else if(stroke)doc.stroke();
    doc.restore();
  }
  function paint(doc,engine,op){
    var x=op.x*PX_PT,y=op.y*PX_PT,w=op.w*PX_PT,h=op.h*PX_PT;
    if(op.type==='text'){
      engine.drawText(doc,op.text,{x:x,yBaseline:op.baseline*PX_PT,widthPt:w,sizePt:op.size*PX_PT,font:op.font,bold:op.bold,direction:op.direction,color:op.color,letterSpacing:op.letterSpacing*PX_PT});
    }else if(op.type==='ring'){
      var radius=Math.min(w,h)/2,cx=x+w/2,cy=y+h/2;
      color(doc,op.track);doc.circle(cx,cy,radius).fill();
      if(op.value>0){color(doc,op.color);if(op.value>=100)doc.circle(cx,cy,radius).fill();else {var angle=op.value/100*Math.PI*2,ex=cx+Math.sin(angle)*radius,ey=cy-Math.cos(angle)*radius;doc.path('M'+cx+' '+cy+' L'+cx+' '+(cy-radius)+' A'+radius+' '+radius+' 0 '+(op.value>50?1:0)+' 1 '+ex+' '+ey+' Z').fill();}}
      color(doc,op.inner);doc.circle(cx,cy,Math.max(0,radius-op.inset*PX_PT)).fill();
    }else if(op.type==='box'){
      color(doc,op.fill);doc.roundedRect(x,y,w,h,Math.min(op.radius*PX_PT,w/2,h/2)).fill();
    }else if(op.type==='outline'){
      color(doc,op.color,true);doc.lineWidth(op.width*PX_PT);doc.roundedRect(x,y,w,h,Math.min(op.radius*PX_PT,w/2,h/2)).stroke();
    }else if(op.type==='border'){
      color(doc,op.color,true);doc.lineWidth(op.width*PX_PT);
      if(op.side==='Top')doc.moveTo(x,y).lineTo(x+w,y);
      if(op.side==='Bottom')doc.moveTo(x,y+h).lineTo(x+w,y+h);
      if(op.side==='Left')doc.moveTo(x,y).lineTo(x,y+h);
      if(op.side==='Right')doc.moveTo(x+w,y).lineTo(x+w,y+h);
      doc.stroke();
    }else if(op.type==='image')doc.image(op.data,x,y,{width:w,height:h});
    else if(op.type==='svg')shape(doc,op);
    else if(op.type==='clip-start'){doc.save();doc.roundedRect(x,y,w,h,Math.min(op.radius*PX_PT,w/2,h/2)).clip();}
    else if(op.type==='clip-end')doc.restore();
  }
  function paintSlice(doc,engine,data,start,end,x,y,repeat){
    doc.save();doc.rect(x,y,data.width*PX_PT,(end-start)*PX_PT).clip();doc.translate(x,y-start*PX_PT);
    data.ops.forEach(function(op){
      if(op.type==='clip-start'||op.type==='clip-end')paint(doc,engine,op);
      else if((op.type==='border'||op.type==='outline'||op.type==='box'||op.type==='svg'||op.type==='ring')&&op.y<end&&op.y+op.h>=start)paint(doc,engine,op);
      else if(op.type==='text'&&op.y>=start-.2&&op.y+op.h<=end+.2)paint(doc,engine,op);
      else if(op.type==='image'&&op.y<end&&op.y+op.h>start)paint(doc,engine,op);
    });doc.restore();
  }
  async function exportPDF(state){
    var sourceTitle=document.title;
    var prepared=S.printPagination.preparedDocument(state),loading=loadEngine();
    var pair;
    try{pair=await Promise.all([loading,prepared]);}catch(error){prepared.then(function(a){if(a&&a.cleanup)a.cleanup();},function(){});throw error;}
    var engine=pair[0],artifact=pair[1];
    if(!artifact)throw new Error('تعذر تجهيز التقرير للتصدير.');
    try{
      var data=collect(artifact),g=Object.assign({},artifact.geometry,{layout:artifact.layout,direction:artifact.direction});
      // Honor the page-height ceiling even when the user chooses a long PDF.
      if(g.layout==='continuous'&&g.heightMM>5080){
        if(artifact.cleanup)artifact.cleanup();
        artifact=await S.printPagination.preparedDocument(state,{layout:'a4'});
        data=collect(artifact);g=Object.assign({},artifact.geometry,{layout:artifact.layout,direction:artifact.direction});
      }
      var plans=pagePlan(data,g),continuous=g.layout==='continuous';
      var width=(continuous?297:g.direction==='landscape'?297:210)*MM_PT;
      var height=(continuous?Math.max(80,Math.ceil(data.height*25.4/96)+27):g.direction==='landscape'?210:297)*MM_PT;
      var inset=(continuous?8:10)*MM_PT;
      if(engine.ready)await engine.ready();
      var doc=await engine.create({size:[width,height],title:sourceTitle,author:'الأمانة العامة للمجلس التنفيذي لإمارة دبي'});
      for(var i=0;i<plans.length;i++){
        if(i)doc.addPage({size:[width,height],margin:0});
        doc.save();doc.rect(0,0,width,height).fill(continuous?'#EFEBE7':'#FCFBFB');doc.restore();
        var p=plans[i];
        if(p.regions)p.regions.forEach(function(r){paintRegion(doc,engine,data,r,inset,inset);});
        else {var reserve=p.head?p.head.h*PX_PT:0;
          if(p.head)paintSlice(doc,engine,data,p.head.y,p.head.y+p.head.h,inset,inset);
          paintSlice(doc,engine,data,p.start,p.end,inset,inset+reserve);}
        var baseline=height-(continuous?11:5)*MM_PT;
        engine.drawText(doc,'صفحة '+(i+1)+' من '+plans.length,{x:inset,yBaseline:baseline,sizePt:10.5,font:'TEC Dubai',direction:'rtl',color:'#4F4E4E'});
        var copyright=S.ui.copyrightText();
        engine.drawText(doc,copyright,{x:width-inset,yBaseline:baseline,sizePt:10.5,font:'TEC Dubai',direction:'rtl',align:'right',color:'#4F4E4E'});
        // Let the browser update the visible loading state for long report packs.
        if(i%5===4)await new Promise(function(resolve){setTimeout(resolve,0);});
      }
      var bytes=await engine.finish(doc),blob=new Blob([bytes],{type:'application/pdf'});
      return {blob:blob,name:sourceTitle.replace(/[\\/:*?"<>|]/g,'-')+'.pdf',pages:plans.length,layout:g.layout,
        widthMM:width/MM_PT,heightMM:height/MM_PT,nativeTextLines:data.lines.length};
    }finally{if(artifact.cleanup)artifact.cleanup();}
  }
  S.offlinePdf={export:exportPDF,collect:collect,pagePlan:pagePlan};
})(window.Saytara=window.Saytara||{});
