/* Approved agenda matrix. Source report eligibility, status order and effective periods are unchanged. */
(function (S) {
  'use strict';
  function node(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }
  function num(value, cls) {
    var e = node('bdi', cls, value === 0 ? '–' : String(value));
    if (value === 0) e.setAttribute('aria-label', 'صفر');
    e.dir = 'ltr';
    return e;
  }
  function specification(state) {
    var A = S.agendaReport;
    var selected = S.filterOptions.single(state.report.type);
    var full = selected === null;
    var options = S.views.agendaPage.options(state);
    var model = A.model(state.data, state.dash, state.report.type || '', options);
    var cohorts = full ? [
      { id: 'approved', name: 'الأجندة المعتمدة', items: model.planned },
      { id: 'emerging', name: 'المواضيع المستجدة', items: model.emerging }
    ] : [{
      id: selected === 'مستجد' ? 'emerging' : selected === 'الأجندة السنوية' ? 'approved' : 'other',
      name: selected === 'مستجد' ? 'المواضيع المستجدة' : selected === 'الأجندة السنوية' ? 'الأجندة المعتمدة' : String(selected),
      items: model.items
    }];
    if (full && model.other.length) cohorts.push({ id: 'other', name: 'مواضيع غير مصنفة', items: model.other });
    var active = A.stats(model.items, state.data).map(function (entry) { return entry.name; });
    var sourceOrder = S.order.statuses(state.data, 'agenda');
    var statusNames = sourceOrder.filter(function (name) { return active.indexOf(name) >= 0; })
      .concat(active.filter(function (name) { return sourceOrder.indexOf(name) < 0; }));
    var spec = {
      total: model.total, planned: model.planned.length, emerging: model.emerging.length,
      other: model.other.length, year: model.year, sourcePeriod: model.period, sourceDate: model.date,
      statuses: statusNames.map(function (name) {
        var category = S.rules.catOf(name);
        return { name: name, color: S.ui.chartStatusColor(name),
          textColor: category === 'delayed' ? '#C00000' : category === 'done' ? '#01831E' : '#4F4E4E' };
      }),
      // groups() preserves source quarter ordering, latest valid amended dates,
      // existing carryover rules and the explicit undated group.
      displayQuarters: A.groups(state.data, model.items).map(function (group) {
        return { key: group.key, name: group.name };
      }),
      cohorts: [], scale: { min: 0, max: 0, unit: 'عدد المواضيع' },
      sourceRecordKeys: model.items.map(function (item) { return item.key; })
    };
    cohorts.forEach(function (cohort) {
      var counts = Object.create(null);
      A.stats(cohort.items, state.data).forEach(function (entry) { counts[entry.name] = entry.n; });
      var output = {
        id: cohort.id, name: cohort.name, total: cohort.items.length,
        recordKeys: cohort.items.map(function (item) { return item.key; }),
        totals: statusNames.map(function (name) { return { name: name, count: counts[name] || 0 }; }),
        quarters: []
      };
      A.groups(state.data, cohort.items).forEach(function (group) {
        var quarterCounts = Object.create(null);
        A.stats(group.items, state.data).forEach(function (entry) { quarterCounts[entry.name] = entry.n; });
        output.quarters.push({
          key: group.key, name: group.name, total: group.items.length,
          recordKeys: group.items.map(function (item) { return item.key; }),
          cells: statusNames.map(function (name) {
            var count = quarterCounts[name] || 0;
            spec.scale.max = Math.max(spec.scale.max, count);
            return { name: name, count: count, color: S.ui.chartStatusColor(name) };
          })
        });
      });
      spec.cohorts.push(output);
    });
    return spec;
  }
  function element(spec) {
    var quarterColumns = spec.displayQuarters;
    var root = node('section', 'ag-matrix-overview');
    root.dir = 'rtl';
    root.setAttribute('aria-label', 'ملخص الأجندة السنوية — الحالات حسب الربع');
    root.dataset.sourceTotal = String(spec.total);
    root.dataset.statusKeys = JSON.stringify(spec.statuses.map(function (status) { return status.name; }));
    root.dataset.cohortCount = String(spec.cohorts.length);
    root.dataset.scaleMin = '0';
    root.dataset.scaleMax = String(spec.scale.max);
    root.dataset.displayQuarterKeys = JSON.stringify(quarterColumns.map(function (q) { return q.key; }));
    root.dataset.presentationQuarterPolicy = 'shared-active-union';
    var lead = node('header', 'a-overview-lead');
    var total = node('div', 'a-grand-total');
    total.append(num(spec.total, 'a-total-number'), node('span', '', 'الإجمالي'));
    lead.append(node('h2', '', 'الأجندة السنوية'), total);
    root.append(lead);
    var head = node('div', 'a-chart-head');
    var scale = node('span', 'a-scale');
    scale.append(node('span', '', 'عدد المواضيع '), num('0–' + spec.scale.max));
    head.append(node('h3', '', 'مستويات الإنجاز حسب الربع'), scale);
    if (spec.total) root.append(head);
    var categories = node('div', 'a-category-boxes');
    categories.style.setProperty('--cohorts', String(spec.cohorts.length));
    spec.cohorts.forEach(function (c) {
      var box = node('div', 'a-category');
      box.id = 'ag-matrix-cohort-' + c.id;
      box.append(node('span', '', c.name), num(c.total, 'a-category-value'));
      categories.append(box);
    });
    root.append(categories);
    if (!spec.total) {
      root.append(node('p', 'a-empty', 'لا توجد مواضيع ضمن النطاق المحدد.'));
      return root;
    }
    var panels = node('div', 'a-chart-panels');
    panels.style.setProperty('--cohorts', String(spec.cohorts.length));
    spec.cohorts.forEach(function (c, ci) {
      var displayQuarters = quarterColumns.map(function (q) {
        var sourceQuarter = c.quarters.find(function (x) { return x.key === q.key; });
        return sourceQuarter || { key: q.key, name: q.name, total: 0, recordKeys: [], cells: [], resolvedZero: true };
      });
      var panel = node('figure', 'a-chart-panel');
      panel.dataset.cohort = c.id;
      panel.dataset.total = String(c.total);
      panel.dataset.denominator = String(c.total);
      panel.style.setProperty('--quarters', String(displayQuarters.length));
      panel.dataset.resolvedZeroQuarters = JSON.stringify(displayQuarters.filter(function (q) { return q.resolvedZero; }).map(function (q) { return q.key; }));
      panel.setAttribute('aria-labelledby', 'ag-matrix-cohort-' + c.id);
      var caption = node('figcaption', 'a-panel-title');
      caption.append(node('h4', '', c.name), num(c.total, 'a-panel-total'));
      panel.append(caption);
      var table = node('table', 'a-matrix');
      table.setAttribute('aria-label', c.name + ': حالات الإنجاز في الصفوف والأرباع في الأعمدة');
      var cols = node('colgroup');
      cols.append(node('col', 'a-status-col'));
      displayQuarters.forEach(function () { cols.append(node('col', 'a-quarter-col')); });
      cols.append(node('col', 'a-sum-col'));
      table.append(cols);
      var thead = node('thead'), hr = node('tr');
      var sh = node('th', 'a-status-heading', 'الحالة');
      sh.scope = 'col';
      hr.append(sh);
      displayQuarters.forEach(function (q, qi) {
        var qh = node('th', 'a-quarter-heading', q.name);
        qh.scope = 'col';
        qh.id = 'ag-matrix-quarter-' + ci + '-' + qi;
        hr.append(qh);
      });
      var sumHead = node('th', '', 'الإجمالي');
      sumHead.scope = 'col';
      hr.append(sumHead);
      thead.append(hr);
      table.append(thead);
      var tbody = node('tbody');
      spec.statuses.forEach(function (status, si) {
        var row = node('tr');
        row.dataset.status = status.name;
        row.style.setProperty('--agenda-count-ink', status.textColor === '#C00000' || status.textColor === '#01831E' ? status.textColor : '#333333');
        var label = node('th', 'a-status-name', status.name);
        label.scope = 'row';
        label.style.color = status.textColor;
        label.style.setProperty('--agenda-status-ink', status.textColor);
        label.id = 'ag-matrix-status-' + ci + '-' + si;
        row.append(label);
        displayQuarters.forEach(function (q, qi) {
          var cell = q.cells.find(function (x) { return x.name === status.name; });
          var count = cell ? cell.count : 0;
          var td = node('td', 'a-chart-cell');
          td.dataset.status = status.name;
          td.dataset.quarter = String(q.key);
          td.dataset.count = String(count);
          td.dataset.resolvedZeroQuarter = String(!!q.resolvedZero);
          td.dataset.sourceRecordCount = String(q.recordKeys.length);
          td.setAttribute('headers', label.id + ' ag-matrix-quarter-' + ci + '-' + qi);
          td.append(node('span', 'a-mobile-quarter', q.name), num(count, 'a-cell-number'));
          var track = node('span', 'a-cell-track');
          var bar = node('span', 'a-cell-bar');
          track.setAttribute('aria-hidden', 'true');
          bar.style.width = (spec.scale.max ? count / spec.scale.max * 100 : 0) + '%';
          bar.style.backgroundColor = cell ? cell.color : status.color;
          track.append(bar);
          td.append(track);
          row.append(td);
        });
        var t = c.totals.find(function (x) { return x.name === status.name; });
        var sum = node('td', 'a-status-total');
        sum.dataset.status = status.name;
        sum.dataset.count = String(t ? t.count : 0);
        sum.append(node('span', 'a-mobile-total-label', 'الإجمالي'), num(t ? t.count : 0, 'a-cell-number'));
        row.append(sum);
        tbody.append(row);
      });
      table.append(tbody);
      var tfoot = node('tfoot'), fr = node('tr');
      var footLabel = node('th', 'a-status-name', 'الإجمالي');
      footLabel.scope = 'row';
      fr.append(footLabel);
      displayQuarters.forEach(function (q) {
        var qt = node('td', 'a-quarter-total');
        qt.dataset.quarter = String(q.key);
        qt.dataset.count = String(q.total);
        qt.dataset.resolvedZeroQuarter = String(!!q.resolvedZero);
        qt.append(node('span', 'a-mobile-quarter', q.name), num(q.total, 'a-cell-number'));
        fr.append(qt);
      });
      var finalTotal = node('td', 'a-status-total a-final-total');
      finalTotal.setAttribute('aria-hidden', 'true');
      fr.append(finalTotal);
      tfoot.append(fr);
      table.append(tfoot);
      panel.append(table);
      panels.append(panel);
    });
    root.append(panels);
    return root;
  }
  S.agendaMatrix = {
    spec: specification,
    element: element,
    render: function (state) { return element(specification(state)).outerHTML; }
  };
})(window.Saytara = window.Saytara || {});
