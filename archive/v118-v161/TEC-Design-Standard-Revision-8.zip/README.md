# TEC design standard — Revision 8

Approved 12 October 2026: A4 landscape for agenda, council and HH; A4 portrait for all other print/PDF views; no A3.

The paper amendment is recorded in this specification and is pending app implementation. Performance App v133 is unchanged.
