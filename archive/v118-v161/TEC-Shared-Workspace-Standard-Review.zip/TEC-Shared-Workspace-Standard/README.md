# TEC shared workspace standard — review pack

Extract the entire folder and open `index.html`. The before/after images, standards, prototype and print specimen use bundled fonts and logo. The `proposal.html` controls are an isolated demonstration, not a new app release.

Read `tables.html` for all specifications and save `TEC-Apple-Design-Standard-Revision-3-Complete-Review.md` for the complete proposal plus approved baseline.

Print specimen: three A4-landscape component pages using frozen illustrative records, not the full operational report.
