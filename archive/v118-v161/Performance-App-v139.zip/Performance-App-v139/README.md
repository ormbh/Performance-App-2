# Performance App v139

Extract the complete ZIP, then open `index.html` with its `assets` folder beside it.
All scripts, images and approved fonts are bundled locally. Select your report
workbook on the upload page. Workbook processing stays on your device.

## Offline PDF download

The report action is now **تنزيل PDF**. It downloads a real PDF directly on your
computer, without opening a browser print dialog or using an internet service.
The local PDF engine, font bytes, text shaping and official logo are bundled in
the complete app ZIP. Extract the whole folder before opening `index.html`.

Monthly output defaults to one continuous 297mm-wide page with the approved
281mm content width, Linen canvas, 8mm top/side insets and 16mm footer reserve.
Monthly A4 portrait remains available in **إعدادات PDF**. Agenda, council and HH
reports use A4 landscape; other reports use A4 portrait. No A3 format is offered.
First-page headers show the official logo, report title with the actual cutoff date,
and a sector/organisational-unit scope line. The entity filter stays out of the
header while continuing to filter the report. Footers contain copyright and page numbers.
The exporter uses the current source, scope and complete report records; it
writes native text and vector charts, with approved logos kept as image assets.

Original TEC font files, metrics, colors and source models stay unchanged.
The PDF engine includes shaping for the supplied Arabic fonts and a licensed,
symbol-only fallback for characters missing from those faces. See
`assets/vendor/offline-pdf-VERSIONS.json`, `assets/vendor/offline-pdf-LICENSES.txt`
and `FONT-ASSETS.md` for provenance. This is a local browser app; the PDF
exporter is independent of browser printer settings.

The native browser keyboard/menu print path remains available for users who
need it; its preparation now waits for complete fonts/layout and never prints
an unmeasured 80mm temporary page. There is no Print button in the app.

Final v139 direct-download checks pass; results and practical
limits are recorded in **VERIFICATION-v139.md**. Revision 14 restores the
exported sector/unit scope line and removes the strategy card's **مؤشرات الأداء**
tag. Earlier v138 offline-download checks remain historical evidence in
**VERIFICATION-v138.md**; they do not establish a v139 pass.

## Approved TEC design

This release implements the approved design in the app, including the monthly
and projects dashboards, their browser reports, search, search results and upload.
The consolidated **Revision 14** standard is included as **DESIGN-STANDARD.md**. Its targeted changes remove the strategy **مؤشرات الأداء** tag and restore the export's first-page sector/unit scope line beneath the actual-date report title. A valid nonzero strategy total-count difference remains as a neutral, unlabeled header change. Revision 13's direct **تنزيل PDF** workflow and Revision 12's full-page Linen monthly surface, reading insets, footer reserve and card/table spacing remain approved. Selectable A4 output remains available. Final v139 direct-download results and practical limits are recorded in **VERIFICATION-v139.md**.
The latest approved Google-like search layout supplements that standard.

- DIN Next Arabic Regular headings: page 38px (search home 36px), portfolio 30px and card 28px.
  DIN Next LT Arabic Regular figures: 34–40px; special-project subgroup totals and status figures remain 28px. Subgroup names are 18px Dubai Regular. Dubai Regular supporting text;
  table names, notes and status text 16px, table headings Dubai Bold 18px, explanations 14px,
  agenda category labels (الأجندة المعتمدة / المواضيع المستجدة) 18px,
  monthly dashboard short value/status labels and strategy metric names 16px, change arrows 15px and metadata 14px. Table names/notes and essential explanations use Ink #4F4E4E; neutral differences and secondary metadata use Taupe #756B5F.
- Names remain neutral and regular. Approved status badges are informational,
  with separate accessible drilldown controls. Completed work is green, including
  legislation completed after its deadline; unfinished late work is red.
- Shared report headers retain the official logo, a 38px title and only the
  cutoff date below it. Primary navigation uses Search plus the current-page link with a
  current-page underline; other destinations and utilities remain in the app menu.
  Search home uses the menu only; search results use one current Search link.
  The home title is moved 4px upward from v132, preserving the logo, field and action positions. All three report destinations appear as direct links in both the search and shared page menus. PDF actions sit together, followed by separate sector/unit/entity filters.
  Project type, priority, quarter, status and manager filters use an additional
  disclosure. Closing it preserves selections. Clearing scope preserves the file,
  report date, historical comparison and saved display/output preferences.
- Shared controls use readable labels, 44px minimum action targets, approved normal,
  hover, pressed and disabled states, and visible keyboard focus. Menus dismiss
  outside or on Escape; keyboard menu navigation and mobile filter focus are retained.
- Generic explanatory subtitles beneath titles are removed. Actual table notes,
  field/value labels, required dates, source caveats and meaningful definitions remain, except the approved removal of passive financial numeric-availability annotations.
  Screen footers show only the copyright line.
- Monthly content uses the available width at 100% browser zoom. Executive
  portfolios remain on the right, projects on the left and strategy below
  legislation. Short labels remain above their figures, including on mobile; the main total label stays below its total. Valid historical metric changes remain below their values; the strategy total-count difference is the approved unlabeled header exception. Empty status
  and priority groups stay hidden; zero counts use a dash while meaningful
  source progress of 0% is retained.
- Financial bars use solid fills, including partial numeric coverage: allocation remains Taupe, spending Teal and the unused track Linen. Hatching and passive numeric-availability notes are removed on screen and in print. Actual notes, diagnostic drilldowns, metric definitions, financial ratios and missing-value exclusions remain.
- Projects keep the approved paired sections and chart scales. Priority charts
  fit their visible content without internal vertical scrollbars. The follow-up
  table includes late, frozen, cancelled and transferred projects in that order.
- Search has a centered TEC logo, a pill-shaped search field and two primary
  tasks. Results use the approved six-column table with native details, filters,
  sorting, column customization, pagination, CSV and PDF download of all matches.
  On mobile, the readable table scrolls inside its own labelled region.
- Upload uses the approved panel, drop zone and button hierarchy while retaining
  native selection, drag/drop, local processing, busy-state guards and error
  recovery. Invalid replacement files do not discard the current workbook.
- The strategy card omits the **مؤشرات الأداء** tag as well as the repeated coverage/unmeasured-count, result-count and target-count notes on screen and in both output formats. Keep a valid nonzero total-count difference as a neutral, unlabeled header change (15px Dubai Regular Taupe on screen; 11pt in output). Primary values, the measured/registered denominator, measurement bar and valid metric changes remain; figures/changes align when side by side.
- SLC stays first at the physical left of each mixed-language caption, followed by isolated Arabic. On phones, legislation metrics reflow into two columns without shrinking 16px labels.
- Legislation timing labels read **SLC منجز ضمن موعد** and **SLC منجز بعد موعد**. The repeated SLC comparison paragraph is removed; timing formulas and source notes are retained.
- Monthly digital output defaults to **PDF متصل — صفحة واحدة**: a custom 297mm-wide PDF with 281mm content width, an 8mm reading inset and additional bottom footer reserve. Its actual page margins are 8mm top/left/right and 16mm bottom; height is measured from the complete report. Linen #EFEBE7 fills the whole page, including its insets, with Paper #FCFBFB cards and their approved Sand borders. Projects remain left, executive portfolios right and full-width followups below; the white outer frame is removed.
- The continuous page reserves an extra 8mm at the bottom for its footer. Direct PDF download uses an 11mm footer-baseline inset within this reserve; optional native printing retains top-aligned footer boxes with 1mm top padding. Copyright glyphs must remain at least 8mm from the physical bottom edge. Page-height measurement allows the complete measured content plus 27mm: 8mm top + 16mm bottom + 3mm rounding/clearance. Approved text sizes and source values remain unchanged.
- Continuous digital spacing uses 6mm card/followup padding, an 8mm column gap, 6mm stacked-card gap, 4mm below card headings, 3mm above metric rows/bars and 3.5mm table-cell padding. Portfolio headings use 6mm inline padding to align with card content and 3mm bottom padding. The followup section sits 8mm below the report summary, with 3mm below its heading and 3mm above / 4mm below its status-summary row. The document uses one header/footer and retains approved fonts without zoom or font shrink.
- Monthly **A4 عمودي — للطباعة** remains selectable for physical paper. All paper modes remain A4 only: agenda, council and HH use landscape; projects (including the project report), entities, comparison, search and other views use portrait. A4 margins remain 10mm. Monthly A4 retains its paired portfolios/full-width followups and 4mm column gap; other portrait views retain their own flow. Fitting cards stay together; oversized content continues readably. A3 remains unavailable.
- If a continuous monthly page would exceed 5080mm, the current export uses A4 portrait pages and shows an explanatory toast. All records, notes, values and scope are preserved; the saved format preference is unchanged. This is an unusually long-report fallback, not a truncation or text-shrink option.
- The compliance audit corrects primary/filter interaction states, disabled fills, export loading indication, native chart status colors and number fonts, HH figure fonts/surfaces and ring fit, task-page print cleanup, wrapped checks badges and comparison/table pagination.
- PDF reports use their own readable print scale. Monthly continuous output grows its measured page height; A4 output uses content-driven pagination.
  Table body, names, notes and in-table statuses are 12pt (16 CSS px); column headings
  remain 13.5pt Dubai Bold. Screen table/status text remains 16px.
  The first page has the official logo, one 24pt DIN Next Arabic Regular title including the actual
  report date, and a restored sector/organisational-unit scope line in 10.5pt Dubai Regular Ink.
  Use the active selections, or the existing all-sector/all-unit labels when unrestricted.
  The ordinary continuous monthly PDF has one masthead and footer.
  In paginated A4 output, later pages have no report masthead; table column headings repeat.
  Each output footer has only copyright and the renderer-generated page X of Y.
  The entity filter and its selected value are omitted from print headers;
  the selected scope still filters the report and actual row entity names remain.

## Data and workflows

Source records, matching keys, calculation models, chart eligibility, ranking,
filters and historical comparison rules retain their definitions. A presentation
change does not create a status, replace missing data with zero or invent an arrow.
Search includes all matching source records; the follow-up tables retain their
separate eligibility rules. Missing/unknown statuses remain distinct.

The app reads cached Excel formula results; it does not refresh Excel formulas
or Power Query. Existing note/history storage is retained; the monthly output-format preference is stored separately. To use the
new version, keep the old folder until you have checked your notes/settings in
this browser. Browser file-origin storage may vary when the folder moves.

On the monthly page, open **إعدادات PDF** and use **تنسيق التقرير** to choose:

- **PDF متصل — صفحة واحدة** for the continuous digital document. It is the default when no current format preference is saved; its height follows the complete report.
- **A4 عمودي — للطباعة** for a PDF sized for physical paper. This selection is retained as your monthly format preference; its page count grows with the content.

Then select **تنزيل PDF** to download the selected format directly. No browser print dialog or Background graphics setting is needed for this action. All other report pages use **تنزيل PDF** with their approved A4 orientation. Projects retain their comfortable/compact spacing options and A4 portrait mode in **إعدادات PDF**.

Direct download writes only the approved app header/footer, including actual page counters. It is independent of browser printer settings. To print on paper, open the downloaded A4 PDF in your preferred viewer. Optional native browser printing remains available through the browser's own controls; disable its headers/footers to avoid extra URL/date lines. That separate path depends on browser CSS page-margin support; historical native-print checks used Chromium 151. The continuous monthly format is a digital custom-size page, not an A3 choice. Approved text sizes and selected source scope remain the same in digital and paper output; A4 page count is not forced to match an earlier preview.

## Verification and maintenance

**Revision 14 / Performance App v139** retains the approved typography, surfaces, controls, status palette, source rules and offline PDF workflow, with the targeted strategy-tag and exported-header changes described above. Final v139 direct-download checks pass; outcomes and practical limits are recorded in **VERIFICATION-v139.md**. Historical **Revision 13 / Performance App v138** direct-download and corrected optional native-print evidence remains in **VERIFICATION-v138.md**. **Revision 12 / Performance App v137** browser/source-regression, settled continuous PDF, selected A4, height-limit fallback and upload checks remain in **VERIFICATION-v137.md**; those settled-output tests missed the first native print-preview timing defect. **Revision 11 / Performance App v136** and **VERIFICATION-v136.md** remain historical continuous-format references; **VERIFICATION-v135.md** and earlier files retain their own release scope. No historical pass establishes a v139 result.

Screen/PDF verification uses an explicitly illustrative test workbook; that workbook and its test records are not bundled. The operational workbook visible in the user's screenshots was not supplied. Numerical regression uses the frozen illustrative fixture; final v139 outcomes are recorded in **VERIFICATION-v139.md**. Native Windows file opening and physical printing remain outside these browser checks. Prior extracted-app checks used local HTTP because the managed browser policy blocks direct file navigation.

Readable source modules are included. Rebuild with
`python tools/build-bundles.py`; check them with
`python tools/build-bundles.py --check`. `release-manifest.json` records the SHA-256
of every release file except itself. **FONT-ASSETS.md** identifies bundled fonts.

The exported organizational scope line is limited to views with sector/unit filtering. Entity and data-check views retain their own scope models and do not inherit dashboard selections. Search drill scope and search facets both remain in effect.
