/* Projects workspace: named source records, shared filters and traceable drilldowns.
   This deliberately reuses the report's scoped rows and numeric-cell rules. */
(function(S){
 'use strict';
 var U=S.util,R=S.rules,O=S.order,P=S.projectsReport;
 var KEYS=['sector','unit','entity','projectType','priority','quarter','projectStatus','pm'];
 var TYPE={Strategic:'استراتيجي',Operational:'تشغيلي'},PRIORITY={H:'عالية',M:'متوسطة',L:'منخفضة'};
 var Q=['Q1','Q2','Q3','Q4','other'],QL={Q1:'الربع الأول',Q2:'الربع الثاني',Q3:'الربع الثالث',Q4:'الربع الرابع',other:'خارج سنة التقرير / غير مؤرخ'};
 var FIELDS=[['approved','الموازنة الأصلية'],['revised','الموازنة المعتمدة'],['committed','المخصص'],['nonCommitted','غير المخصص'],['workDone','قيمة الأعمال المنجزة'],['spent','المنفق حسب الفواتير']];
 var LABELS={sector:'القطاع',unit:'الوحدة التنظيمية',entity:'الجهة المعنية',projectType:'نوع المشروع',priority:'الأولوية',quarter:'ربع الانتهاء',projectStatus:'الحالة',pm:'مدير المشروع'};
 function esc(v){return U.esc(v==null?'':String(v));}
 function n(v){return v===0?'–':U.metricText(v);}
 function display(v,dec,suffix){return v===0?(suffix==='%'?'0%':'–'):U.displayNumber(v,dec,suffix);}
 function val(v){return v==null||String(v).trim()===''?'غير مسجل':String(v);}
 function status(it){return it.statusLabel||it.t.status||'غير مسجل';}
 function owner(it){return it.coord||it.t.pm||'';}
 function defaults(){return {tab:'delivery',view:'dashboard',focus:'all',value:'',sector:'',unit:'',entity:'',entityMode:'concerned',projectType:'',priority:'',quarter:'',projectStatus:'',pm:''};}
 function adapter(state){return Object.assign({},state,{dash:state.projects,report:Object.assign({},state.report,state.projects,{kind:'projects'})});}
 function reportState(state){var p=Object.assign(defaults(),state.dash);['projectType','priority','quarter','projectStatus','pm'].forEach(function(k){p[k]=state.report[k]||'';});return Object.assign({},state,{projects:p});}
 function get(it,key){return key==='sector'?it.sector||'':key==='unit'?it.unit||'':key==='projectType'?it.t.ptype||'':key==='priority'?it.t.priority||'':key==='quarter'?P.quarter(it):key==='projectStatus'?status(it):key==='pm'?it.t.pm||'':key==='owner'?owner(it):'';}
 function label(key,v){var labels=key==='projectType'?TYPE:key==='priority'?PRIORITY:key==='quarter'?QL:{};return Object.prototype.hasOwnProperty.call(labels,v)?labels[v]:val(v);}
 function group(state,items,key){return [...new Set(items.map(function(it){return get(it,key);}))].map(function(k){var rows=items.filter(function(it){return get(it,key)===k;});return {key:k,name:label(key,k),n:rows.length,done:rows.filter(R.MET.secDone.test).length};}).sort(function(a,b){return key==='quarter'?Q.indexOf(a.key)-Q.indexOf(b.key):key==='projectStatus'?O.status(state.data,a.key,b.key,'secretariat'):O.compare(state.data,{sector:'Sectors',unit:'Departments',projectType:'ProjectType',priority:'ProjectPriority'}[key]||'Departments',a.key,b.key);});}
 function model(state){var m=P.model(adapter(state));m.finance=FIELDS.map(function(f){return {key:f[0],name:f[1],...P.amount(m.items,f[0])};});
  var pairs=m.items.filter(function(it){return P.money(it.c.revised)!=null&&P.money(it.c.spent)!=null;});
  m.remaining={key:'remaining',name:'المتبقي من الموازنة بعد المنفق',value:pairs.length?pairs.reduce(function(sum,it){return sum+P.money(it.c.revised)-P.money(it.c.spent);},0):null,known:pairs.length,total:m.items.length};
  m.noOwner=m.items.filter(function(it){return !String(owner(it)).trim();});
  m.namesCount=new Set(m.items.map(function(it){return String(it.title).trim();})).size;
  m.groups={};['sector','unit','projectType','priority','quarter','projectStatus','pm','owner'].forEach(function(k){m.groups[k]=group(state,m.items,k);});m.pmo=S.projectsPMO.model(state,m);m.delivery=S.portfolioDelivery.model(state,m);return m;
 }
 function known(it,key){return key==='remaining'?S.portfolioDelivery.money(it,'revised')!=null&&S.portfolioDelivery.money(it,'spent')!=null:S.portfolioDelivery.money(it,key)!=null;}
 function deliveryHelpers(){return {esc:esc,n:n,val:val,status:status,owner:owner,label:label,link:link,attrs:attrs,head:head,badge:badge,moneyText:moneyText,coverage:coverage};}
 function renderDelivery(state,m){var h=deliveryHelpers();h.resetAction=state.screen==='reports'?'reset-report-filters':'projects-reset';return S.views.portfolioDelivery.render(state,m||model(state).delivery,h);}
 function sourceNotice(state){var p=state.projects,noticeState=Object.assign({},state,{dash:p,data:Object.assign({},state.data,{items:state.data.items.filter(function(it){return it.pf==='secretariat'&&P.matches(it,p);})})});return '<div class="app-screen-only">'+S.views.dashboard.sourceTitleNotice(noticeState,false)+'</div><div class="pw-source-print-only">'+S.views.dashboard.sourceTitleNotice(noticeState,true)+'</div>';}
 function emptyState(state,m){
  var p=state.projects||defaults(),active=KEYS.some(function(k){return U.hasSelection(p[k]);}),reset=state.screen==='reports'?'reset-report-filters':'projects-reset';
  var source=state.data.items.filter(function(it){return it.pf==='secretariat';}),named=source.filter(R.MET.secTotal.test),untitled=source.filter(function(it){return !R.MET.secTotal.test(it)&&R.inScope(it,p)&&P.matches(it,p);});
  var filtered=active&&named.length>0,kind=filtered?'filtered':untitled.length?'source-titles':'source-empty';
  var title=filtered?'لا توجد مشاريع تطابق عوامل التصفية':untitled.length?'لا توجد مشاريع مسماة قابلة للحساب':'لا توجد مشاريع مسجلة في هذا النطاق';
  var note=filtered?'جرّب توسيع النطاق أو إعادة ضبط عوامل التصفية.':untitled.length?'يحتوي النطاق على '+n(untitled.length)+' صفاً بلا اسم مشروع. تستبعدها معادلات القالب من الإجمالي؛ راجع أسماء المشاريع في المصدر.':'راجع بيانات المشاريع في الملف أو اختر ملف بيانات آخر.';
  return '<section class="pw-empty pw-source-empty" data-project-empty="'+kind+'"><h2>'+title+'</h2><p class="pw-empty-count">عدد المشاريع القابلة للحساب: <strong aria-label="صفر">–</strong></p><p>'+note+'</p><div class="pw-empty-actions">'+(filtered?'<button type="button" class="dbtn" data-act="'+reset+'">إعادة ضبط عوامل التصفية</button>':'<button type="button" class="dbtn" data-act="go-checks">مراجعة بيانات المصدر</button><button type="button" class="btn" data-act="change-file">اختيار ملف آخر</button>')+'</div></section>';
 }
 function summary(state,m){
  if(!m.items.length)return '';
  var d=m.delivery,g=d.overall,b=g.budget,progress=g.progress;
  var cards=[{label:'إجمالي المشاريع',value:n(g.total),id:g.id,note:'المشاريع المسماة ضمن النطاق'},
   {label:'منجز بحسب الحالة',value:g.completed==null?'غير متاح':n(g.completed),id:g.completedId,note:'وفق الحالة المسجلة في المصدر'},
   {label:'يتطلب المتابعة',value:n(d.issues.length),id:'issues:all',note:'المشاريع المشمولة في جدول المتابعة'},
   {label:'الموازنة المعتمدة',value:b.available?display(b.value/1000000,2):'غير متاح',id:b.id,note:'مليون درهم'},
   {label:'متوسط الإنجاز المسجل',value:progress.available?(progress.value===0?'0%':display(progress.value,1,'%')):'غير متاح',id:progress.id,note:coverage(progress)+' · دون وزن بالموازنة'}];
  return '<section class="pw-portfolio-summary" aria-label="ملخص محفظة المشاريع ضمن عوامل التصفية الحالية">'+cards.map(function(c){return '<button type="button" class="pw-summary-card"'+attrs('delivery',c.id)+' aria-label="'+esc(c.label+': '+c.value+' · '+c.note+' · يعرض المشاريع المطابقة')+'"><span>'+esc(c.label)+'</span><strong><bdi>'+esc(c.value)+'</bdi></strong><small>'+esc(c.note)+'</small></button>';}).join('')+'</section>';
 }
 function updateScrollHints(){
  if(typeof document==='undefined'||!document.querySelectorAll)return;
  document.querySelectorAll('.portfolio-delivery .pd-table-region').forEach(function(region){var overflow=region.scrollWidth>region.clientWidth+1,hint=region.nextElementSibling;region.setAttribute('data-pd-overflow',String(overflow));if(hint&&hint.classList.contains('pd-scroll-hint'))hint.hidden=!overflow;});
 }
 if(window.addEventListener)window.addEventListener('resize',updateScrollHints);
 if(typeof document!=='undefined'&&document.fonts&&document.fonts.ready)document.fonts.ready.then(updateScrollHints);
 function masthead(state,m,display){
  var cutoff=U.validDateSerial(state.data.today)?'حتى تاريخ '+U.fmtDate(state.data.today):'تاريخ البيانات غير متاح',selectedScope=scope(state),p=state.projects;
  var rows=p.view==='records'?focusRows(m,p).length:m.items.length,caption=selectedScope==='جميع المشاريع'?'جميع القطاعات · جميع الوحدات التنظيمية':selectedScope;
  // Hide the entity field in print without changing the state used to select
  // report records. All other scope labels and the actual entity table data stay.
  var printState=Object.assign({},state,{projects:Object.assign({},p,{entity:''})}),printScope=scope(printState),printCaption=printScope==='جميع المشاريع'?'جميع القطاعات · جميع الوحدات التنظيمية':printScope;
  var tail=' · عدد المشاريع: '+n(rows)+(p.view==='records'?' · '+esc(focusLabel(p,m)):'');
  return '<div class="project-masthead"><h1 id="projects-heading" tabindex="-1"'+(display?' data-report-title':'')+'>'+esc(display?display.title:'مستجدات محفظة المشاريع')+'</h1><p class="project-masthead-period"'+(display?' data-report-period-label':'')+'>'+esc(display?display.period:cutoff)+'</p>'+(display?'<p class="project-masthead-cutoff" data-project-cutoff'+(display.period===cutoff?' hidden':'')+'>التاريخ المرجعي للحسابات: '+esc(U.validDateSerial(state.data.today)?U.fmtDate(state.data.today):'غير متاح')+'</p>':'')+'</div>';
 }
 function focusRows(m,p){if(p.focus==='delivery')return S.portfolioDelivery.select(m.delivery,p.value);if(p.focus==='record')return m.items.filter(function(it){return it.key===p.value;});if(p.focus==='done')return m.done;if(p.focus==='active')return m.active;if(p.focus==='notes')return m.notes;if(p.focus==='high')return m.high;if(p.focus==='noOwner')return m.noOwner;if(p.focus==='pmo')return S.projectsPMO.select(m.pmo,p.value);if(p.focus==='known'||p.focus==='missing')return FIELDS.some(function(f){return f[0]===p.value;})||p.value==='remaining'?m.items.filter(function(it){return known(it,p.value)===(p.focus==='known');}):[];if(p.focus==='group'){var pair;try{pair=JSON.parse(p.value);}catch(e){return [];}return Array.isArray(pair)&&m.groups[pair[0]]?m.items.filter(function(it){return get(it,pair[0])===pair[1];}):[];}return m.items;}
 function focusLabel(p,m){if(p.focus==='delivery'&&p.value==='issues:all')return 'المشاريع التي تتطلب المتابعة';if(p.focus==='delivery')return m?S.portfolioDelivery.label(m.delivery,p.value):'تفصيل محفظة المشاريع';if(p.focus==='pmo')return S.projectsPMO.label(p.value);if(p.focus==='group'){try{var pair=JSON.parse(p.value);return (LABELS[pair[0]]||'مدير المشروع')+': '+label(pair[0],pair[1]);}catch(e){return 'نطاق غير صالح';}}if(p.focus==='known'||p.focus==='missing'){var f=FIELDS.find(function(f){return f[0]===p.value;});return (p.focus==='missing'?'القيم غير المسجلة: ':'القيم المتاحة: ')+(f?f[1]:p.value==='remaining'?'المتبقي من الموازنة':'حقل غير صالح');}var labels={all:'قائمة المشاريع',done:'منجز حسب الحالة',active:'قيد العمل',notes:'مشاريع بملاحظات مصدرية',high:'أولوية عالية',noOwner:'مدير المشروع غير مسجل',record:'تفاصيل المشروع'};return Object.prototype.hasOwnProperty.call(labels,p.focus)?labels[p.focus]:'قائمة المشاريع';}
 function attrs(focus,value){return ' data-act="projects-drill" data-focus="'+esc(focus||'all')+'" data-value="'+esc(value||'')+'"';}
 function link(text,focus,value,cls){return '<button type="button" class="pw-link '+(cls||'')+'"'+attrs(focus,value)+' aria-label="'+esc(text+(focus&&focus!=='all'&&focus!=='record'?' · '+focusLabel({focus:focus,value:value||''}):''))+' · يعرض المشاريع المطابقة">'+esc(text)+'</button>';}
 function scope(state){return P.scope(adapter(state));}
 function filters(state,m){
  var p=state.projects,all=state.data.items.filter(function(it){return it.pf==='secretariat'&&R.MET.secTotal.test(it);});
  var active=KEYS.filter(function(k){return U.hasSelection(p[k]);}).length;
  var controls=KEYS.map(function(k){var rows=k==='unit'?all.filter(function(it){return S.filterOptions.selected(it.sector,p.sector,'sector');}):all,opts=k==='entity'?[{v:'الأمانة العامة للمجلس التنفيذي',label:'الأمانة العامة للمجلس التنفيذي'}]:group(state,rows,k).filter(function(g){return k!=='sector'||S.filterOptions.key(g.key,'sector')!==S.filterOptions.key('الأمانة العامة للمجلس التنفيذي','sector');}).map(function(g){return {v:g.key,label:g.name,n:g.n};});return S.ui.multiSelect(state,'p:'+k,LABELS[k],p[k],opts);}).join('');
  var summary=KEYS.filter(function(k){return U.hasSelection(p[k]);}).map(function(k){var values=S.filterOptions.selectionGroups(p[k],(state.multiOptions||{})['p:'+k],'p:'+k);return LABELS[k]+': '+values.slice(0,2).map(function(o){return o.label;}).join('، ')+(values.length>2?' +'+(values.length-2):'');}).join(' · ')||'جميع المشاريع';
  return S.ui.filterPanel(state,{id:'projects',resetAction:'projects-reset',title:'عوامل التصفية',body:controls,summary:summary,activeCount:active})+'<p class="visually-hidden" role="status" aria-live="polite" aria-atomic="true">عدد المشاريع: '+n(m.items.length)+' من أصل '+n(all.length)+' · '+esc(scope(state))+'</p>';
 }

 function head(name,note,action){return '<div class="pw-panel-head"><h2>'+esc(name)+'</h2>'+(note?'<span class="pw-results-count">'+esc(note)+'</span>':'')+(action||'')+'</div>';}
 function badge(it){return S.ui.statusChip(it);}
 function moneyText(f){return display(f.value,2);}
 function coverage(f){return 'عدد المشاريع: '+n(f.known)+' من أصل '+n(f.total)+(f.known<f.total?' · تغطية جزئية':'');}
 function issueTable(rows,m){
  var issues=new Map((m.delivery.issues||[]).map(function(issue){return [issue.item.key,issue];}));
  var headings=['المشروع','القطاع / الوحدة','مدير المشروع','الحالة / الإنجاز / الموعد','الملاحظات'];
  return '<div class="portfolio-delivery"><div class="pd-table-region" tabindex="0" role="region" data-pd-table-kind="pd-issues-table" aria-label="المشاريع التي تتطلب المتابعة وملاحظاتها الكاملة"><table role="table" class="pd-table pd-issues-table pw-issues-table"><caption class="visually-hidden">المشاريع التي تتطلب المتابعة وملاحظاتها الكاملة</caption><thead role="rowgroup"><tr role="row">'+headings.map(function(h){return '<th role="columnheader" scope="col">'+esc(h)+'</th>';}).join('')+'</tr></thead><tbody role="rowgroup">'+rows.map(function(it){
   var issue=issues.get(it.key)||{},noteParts=[['ملاحظات مدير المشروع',it.t.ownerRemarks],['ملاحظات المالية',it.t.financeRemarks]].filter(function(p){return p[1]!=null&&String(p[1]).trim()!=='';}),notes=noteParts.map(function(p){return '<p class="pd-source-note">'+(noteParts.length>1||p[0]==='ملاحظات المالية'?'<span>'+esc(p[0])+'</span>':'')+'<bdi dir="auto">'+esc(p[1])+'</bdi></p>';}).join('');
   var cells=[link(it.title,'record',it.key,'pd-issue-project')+'<small>المشروع <bdi>'+esc(val(it.ref||it.seq))+'</bdi></small>',esc(U.tableCellText(it.sector))+'<small>'+esc(U.tableCellText(it.unit))+'</small>','<bdi dir="auto">'+esc(U.tableCellText(owner(it)))+'</bdi>','<span class="pd-issue-status pd-attention-'+esc(issue.attention||'unknown')+'">'+esc(issue.displayStatus||status(it))+'</span>'+(issue.progress!=null?'<div class="pd-issue-progress">'+esc(display(issue.progress,1,'%'))+'<span class="pd-progress-track"><span class="pd-progress-fill" style="width:'+issue.progress+'%"></span></span></div>':'')+'<small><bdi dir="auto">'+esc(U.tableCellText(it.dateLabel||it.t.end))+'</bdi></small>'+(issue.daysOverdue>0?'<small>'+esc('متأخر '+n(issue.daysOverdue)+' يوماً')+'</small>':''),notes];
   return '<tr role="row" data-record="'+esc(it.key)+'" data-project-key="'+esc(it.key)+'">'+cells.map(function(value,i){return '<'+(i===0?'th role="rowheader" scope="row"':'td role="cell"')+' data-label="'+esc(headings[i])+'">'+value+'</'+(i===0?'th':'td')+'>';}).join('')+'</tr>';
  }).join('')+'</tbody></table></div><p class="pd-scroll-hint" hidden>اسحب الجدول أفقياً لعرض جميع الأعمدة.</p></div>';
 }
 function recordTable(state,m){
  var p=state.projects,rows=focusRows(m,p),showIssues=p.focus==='delivery'&&p.value==='issues:all';
  var table=rows.length?(showIssues?issueTable(rows,m):'<div class="pw-table-scroll" tabindex="0" role="region" aria-label="قائمة المشاريع"><table class="pw-record-table"><caption class="visually-hidden">'+esc(focusLabel(p,m))+'</caption><thead><tr>'+['المشروع','القطاع / الوحدة','النوع / الأولوية','الحالة / الإنجاز','مدير المشروع','موعد الانتهاء'].map(function(h){return '<th scope="col">'+esc(h)+'</th>';}).join('')+'</tr></thead><tbody>'+rows.map(function(it){return '<tr data-record="'+esc(it.key)+'"><th scope="row">'+link(it.title,'record',it.key,'pd-issue-project')+'<small>المشروع <bdi>'+esc(val(it.ref||it.seq))+'</bdi></small></th><td>'+esc(U.tableCellText(it.sector))+'<small>'+esc(U.tableCellText(it.unit))+'</small></td><td>'+esc(U.tableCellText(label('projectType',it.t.ptype)))+'<small>'+esc(U.tableCellText(label('priority',it.t.priority)))+'</small></td><td>'+badge(it)+'<small>'+esc(it.progress==null?'':display(it.progress,1,'%'))+'</small></td><td><bdi dir="auto">'+esc(U.tableCellText(owner(it)))+'</bdi></td><td><bdi dir="auto">'+esc(U.tableCellText(it.dateLabel||it.t.end))+'</bdi></td></tr>';}).join('')+'</tbody></table></div>'):'<div class="pw-empty"><h3>لا توجد مشاريع لهذا التفصيل</h3></div>';
  var details=rows.length&&(p.focus==='record'||p.focus==='notes'||p.focus==='known'||p.focus==='missing')?'<div class="pw-record-details">'+rows.map(function(it){return '<article><h3><bdi dir="auto">'+esc(it.title)+'</bdi> <small>· '+esc(val(it.ref||it.seq))+'</small></h3>'+(p.focus==='record'&&it.t.desc?'<p dir="auto">'+esc(it.t.desc)+'</p>':'')+(String(it.t.ownerRemarks||'').trim()?'<p class="pw-source-note"><span>ملاحظات مدير المشروع</span><bdi dir="auto">'+esc(it.t.ownerRemarks)+'</bdi></p>':'')+(String(it.t.financeRemarks||'').trim()?'<p class="pw-source-note"><span>ملاحظات المالية</span><bdi dir="auto">'+esc(it.t.financeRemarks)+'</bdi></p>':'')+(p.focus!=='notes'?'<dl class="pw-record-finance">'+FIELDS.map(function(f){var v=S.portfolioDelivery.money(it,f[0]);return '<div><dt>'+esc(f[1])+'</dt><dd><bdi>'+esc(v==null?'غير مسجل':display(v,2))+'</bdi></dd></div>';}).join('')+'</dl>':'')+'</article>';}).join('')+'</div>':'';
  return '<section class="pw-panel pw-records" id="projects-records" tabindex="-1">'+head(focusLabel(p,m),'عدد المشاريع: '+n(rows.length)+' من أصل '+n(m.items.length),'<button type="button" class="dbtn" data-act="projects-overview">'+(p.returnScreen==='reports'?'العودة إلى تقرير المشاريع':'العودة إلى المشاريع')+'</button>')+table+details+'</section>';
 }
 function method(state,m){
  var duplicate=m.namesCount<m.items.length?'<p>عدد المشاريع: '+n(m.items.length)+'؛ الأسماء المختلفة: '+n(m.namesCount)+'. لا تُدمج المشاريع بالاسم.</p>':'';
  var schedule=m.pmo.schedule.known?'<p>الزمن المنقضي = المدة من البداية إلى تاريخ البيانات ÷ مدة المشروع، بين 0% و100%. المقارنة تستخدم تواريخ كاملة للبداية والانتهاء ونسبة إنجاز صالحة؛ الشهر وحده لا يحدد مدة بالأيام.</p>':'';
  var excluded=m.excludedFinancial?'<p class="pw-caveat">بنود مالية بلا اسم مشروع مستبعدة: '+n(m.excludedFinancial)+'. مبالغها ضمن النطاق التنظيمي قبل عوامل تصفية المشروع: '+m.excludedAmounts.filter(function(f){return f.known;}).map(function(f){return esc(f.name)+': '+esc(display(f.value,2));}).join(' · ')+' درهم.</p>':'';
  return '<details class="pw-method"><summary>تعريف المؤشرات</summary><p>يُحسب كل مشروع مسمى مرة واحدة؛ وقد ينطبق أكثر من مؤشر متابعة على المشروع نفسه.</p>'+duplicate+'<p>متأخر: مشروع مفتوح بعد نهاية شهر الانتهاء. الشهر دون سنة يتبع سنة مرجع بيانات الملف؛ والتاريخ الكامل يحتفظ بسنته. الإنجاز بحسب الحالة المسجلة.</p><p>المبالغ تجمع القيم المتاحة لكل حقل. المقارنات المالية تستخدم المشاريع ذات القيمتين؛ نسب الموازنة تتطلب موازنة موجبة وقيمة مقارنة غير سالبة.</p>'+schedule+excluded+'</details>';
 }

 function render(state){
  if(!state.data)return '<div class="screen projects-workspace">'+S.ui.appHeader(state,'projects')+'<main class="pw-main"><div class="pw-empty"><h1>مستجدات محفظة المشاريع</h1><p>ارفع ملف البيانات لعرض المشاريع.</p><button type="button" class="dbtn" data-act="change-file">رفع الملف</button></div></main></div>';
  var p=state.projects||defaults(),m=model(state);
  var pageTools='<button type="button" class="btn app-utility" data-act="projects-report">تقرير المشاريع</button>'+S.projectPrint.utilityButton(state)+'<button type="button" class="btn app-utility pw-print" data-act="download-pdf" aria-label="تنزيل العرض الحالي بصيغة PDF حسب عوامل التصفية الحالية"'+((state.reporting||state.pdfDownloading)?' disabled':'')+(state.pdfDownloading?' aria-busy="true"':'')+'>'+(state.pdfDownloading?'<span class="tec-command-spinner" role="status" aria-label="جارٍ إعداد PDF…"></span>':U.icon('download',20))+' تنزيل PDF</button>';
  // Reuse the approved completeness notice on the same project scope, retaining
  // unnamed source rows for review without changing the named-project metric.
  var content=p.view==='records'?recordTable(state,m):!m.items.length?emptyState(state,m):renderDelivery(state,m.delivery);
  return '<div class="screen projects-workspace projects-pmo" data-screen="projects">'+S.ui.appHeader(state,'projects',{masthead:masthead(state,m),actions:pageTools})+'<main class="pw-main">'+filters(state,m)+sourceNotice(state)+'<div id="projects-panel">'+content+'</div>'+method(state,m)+'</main></div>';
 }

 S.projects={defaults:defaults,keys:KEYS,model:model,adapter:adapter,reportState:reportState,renderDelivery:renderDelivery,sourceNotice:sourceNotice,emptyState:emptyState,summary:summary,updateScrollHints:updateScrollHints,masthead:masthead,focusRows:focusRows,focusLabel:focusLabel,scope:scope};S.views.projects={render:render};
})(window.Saytara=window.Saytara||{});
