/* Project-only print preferences. No workbook, filter or calculation changes. */
(function(S){
 'use strict';
 var U=S.util,KEY='saytara.project-print.v1';
 function active(state){return !!(state&&state.data&&(state.screen==='projects'||state.screen==='reports'&&state.report&&state.report.kind==='projects'));}
 function clean(value){value=value||{};return {layout:'a4',density:value.density==='compact'?'compact':'comfortable'};}
 function defaults(){var saved={};try{saved=JSON.parse(U.store.get('sessionStorage',KEY)||'{}');if(saved.layout!=='a4')U.store.set('sessionStorage',KEY,JSON.stringify(clean(saved)));}catch(ignore){}return Object.assign(clean(saved),{settingsOpen:false});}
 function get(state){if(state&&state.projectPrint)state.projectPrint.layout='a4';return clean(state&&state.projectPrint);}
 function save(state){var value=get(state);try{U.store.set('sessionStorage',KEY,JSON.stringify(value));}catch(ignore){}return value;}
 function set(state,key,value){if(!['layout','density'].includes(key))return get(state);state.projectPrint=Object.assign({settingsOpen:false},state.projectPrint||{},get(state));state.projectPrint[key]=key==='layout'?'a4':(value==='compact'?'compact':'comfortable');return save(state);}
 function reset(state){state.projectPrint=Object.assign({},state.projectPrint||{},{layout:'a4',density:'comfortable'});return save(state);}
 function attrs(state){var value=get(state);return ' data-project-print-layout="'+value.layout+'" data-project-print-density="'+value.density+'"';}
 function summary(state){var value=get(state);return 'A4 عمودي · '+(value.density==='compact'?'تباعد مضغوط':'تباعد مريح');}
 function utilityButton(state){return '<button type="button" class="btn app-utility project-print-settings-trigger" data-act="project-print-settings" aria-haspopup="dialog" aria-controls="project-print-settings" aria-expanded="'+!!(state&&state.projectPrint&&state.projectPrint.settingsOpen)+'">'+U.icon('down',20)+' إعدادات PDF</button>';}
 function dialog(state){
  if(!active(state))return '';
  var value=get(state),disabled=(state.reporting||state.pdfDownloading)?' disabled':'';
  return '<dialog id="project-print-settings" class="project-print-dialog" lang="ar" dir="rtl" aria-labelledby="project-print-settings-title"><div class="project-print-dialog-head"><h2 id="project-print-settings-title">إعدادات PDF</h2><button type="button" class="project-print-dialog-close icon-btn" data-act="project-print-close" aria-label="إغلاق إعدادات PDF">'+U.icon('x',20)+'</button></div><div class="project-print-fields"><label for="project-print-layout">تنسيق التقرير<input id="project-print-layout" name="project-print-layout" type="text" value="A4 عمودي" readonly aria-readonly="true"></label><label for="project-print-density">تباعد المحتوى<select id="project-print-density" name="project-print-density" data-project-print-field="density"'+disabled+'><option value="comfortable"'+(value.density==='comfortable'?' selected':'')+'>مريح</option><option value="compact"'+(value.density==='compact'?' selected':'')+'>مضغوط</option></select></label></div><p id="project-print-settings-summary" class="project-print-summary" role="status" aria-live="polite">'+U.esc(summary(state))+'</p><div class="project-print-dialog-actions"><button type="button" class="btn" data-act="project-print-reset"'+disabled+'>استعادة الافتراضي</button><button type="button" class="btn btn-primary" data-act="project-print-save">حفظ الإعدادات</button></div></dialog>';
 }
 function apply(state){
  if(typeof document==='undefined'||!document.querySelectorAll)return get(state);
  var value=get(state),isActive=active(state);
  document.querySelectorAll('.screen.projects-pmo').forEach(function(screen){if(isActive){screen.setAttribute('data-project-print-layout',value.layout);screen.setAttribute('data-project-print-density',value.density);}else{screen.removeAttribute('data-project-print-layout');screen.removeAttribute('data-project-print-density');}});
  return value;
 }
 function refreshDialog(state){
  if(typeof document==='undefined')return;
  var value=get(state),layout=document.getElementById('project-print-layout'),density=document.getElementById('project-print-density'),status=document.getElementById('project-print-settings-summary');
  if(layout)layout.value='A4 عمودي';if(density)density.value=value.density;if(status)status.textContent=summary(state);
 }
 S.projectPrint={active:active,defaults:defaults,get:get,set:set,reset:reset,attrs:attrs,summary:summary,utilityButton:utilityButton,dialog:dialog,apply:apply,refreshDialog:refreshDialog};
})(window.Saytara=window.Saytara||{});
