#!/usr/bin/env python3
"""Build the self-contained, network-free browser PDF core from pinned packages.
Build-time npm downloads use HTTPS and lockfile integrity. Runtime never fetches
fonts, WASM or libraries, including when index.html is opened through file://.
"""
from pathlib import Path
import argparse,base64,hashlib,json,re,shutil,subprocess,tempfile,unicodedata
from fontTools.ttLib import TTFont
from fontTools import subset
from fontTools.feaLib.builder import addOpenTypeFeaturesFromString

APP=Path(__file__).resolve().parents[1]
VENDOR=APP/'assets/vendor';OUTPUT=APP/'assets/js/lib/offline-pdf-engine.js'
VERSIONS={'pdfkit':'0.20.2','fontkit':'2.0.4','bidi-js':'1.1.0','harfbuzzjs':'1.6.3','esbuild':'0.28.2'}
FACES={'din':'DIN-Next-Arabic-Regular.otf','dinLT':'DIN-Next-LT-Arabic-Regular.ttf','dubai':'Dubai-Regular.otf','dubaiBold':'Dubai-Bold.otf'}
SYMBOLS='↑↓→←↔↕○◔◑◕●'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(args,**kw):subprocess.run(args,check=True,**kw)

def din_shaping_source(source,target):
    """Supply missing joining lookups to HB_TINY, using only the source cmap.
    This transient face selects glyph IDs; the PDF embeds untouched original
    font bytes. Glyph order, outlines, advances and font metrics are invariant.
    """
    font=TTFont(source,recalcTimestamp=False);cmap=font.getBestCmap()
    if 'GSUB'in font:raise RuntimeError('The pinned legacy DIN face unexpectedly contains GSUB.')
    mappings={key:{}for key in ['isol','init','medi','fina']}
    tags={'isolated':'isol','initial':'init','medial':'medi','final':'fina'}
    for point,glyph in cmap.items():
        parts=unicodedata.decomposition(chr(point)).split()
        if len(parts)==2 and parts[0].strip('<>')in tags:
            base=int(parts[1],16)
            if base in cmap and 0x0600<=base<=0x08ff:mappings[tags[parts[0].strip('<>')]][cmap[base]]=glyph
    features='languagesystem DFLT dflt;\nlanguagesystem arab dflt;\n'
    for tag,pairs in mappings.items():
        features+='feature '+tag+' {\n'+''.join('sub '+a+' by '+b+';\n'for a,b in pairs.items()if a!=b)+'} '+tag+';\n'
    features+='feature rlig { lookupflag IgnoreMarks;\n'
    for point in range(0xfef5,0xfefd):
        if point not in cmap:continue
        parts=unicodedata.decomposition(chr(point)).split();tag=tags[parts[0].strip('<>')]
        first,last=[int(value,16)for value in parts[1:]]
        first=mappings['init'if tag=='isol'else'medi'].get(cmap[first],cmap[first]);last=mappings['fina'].get(cmap[last],cmap[last])
        features+='sub '+first+' '+last+' by '+cmap[point]+';\n'
    features+='} rlig;\n'
    original_order=font.getGlyphOrder();addOpenTypeFeaturesFromString(font,features)
    if font.getGlyphOrder()!=original_order:raise RuntimeError('Shaping supplement changed DIN glyph IDs.')
    font.save(target)
    return features

def symbol_subset():
    basename='tec-pdf-symbols';target=VENDOR/(basename+'.ttf')
    source=Path('/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf')
    notice=Path('/usr/share/doc/fonts-liberation/copyright')
    characters=SYMBOLS
    family='TEC PDF Symbol Fallback'
    postscript='TECPDFSymbolFallback-Regular'
    if not target.exists():
        if not source.exists()or not notice.exists():raise RuntimeError('The supplied symbol subset or the local OFL LiberationSerif source is required.')
        font=TTFont(source,recalcTimestamp=False);opts=subset.Options();opts.name_IDs=['*'];opts.name_languages=['*'];opts.name_legacy=True
        cmap=font.getBestCmap()
        missing=[hex(ord(char))for char in characters if ord(char)not in cmap]
        if missing:raise RuntimeError('The licensed symbol source lacks required characters: '+', '.join(missing))
        worker=subset.Subsetter(options=opts);worker.populate(unicodes=[ord(x)for x in characters]);worker.subset(font)
        # The original OFL reserves Liberation. Give this modified symbol subset its own name.
        replacement={1:family,2:'Regular',3:family.replace(' ','-')+'-1',4:family+' Regular',6:postscript,16:family,17:'Regular'}
        for item in font['name'].names:
            if item.nameID in replacement:item.string=replacement[item.nameID].encode(item.getEncoding(),errors='replace')
        font.save(target)
        (VENDOR/(basename+'-LICENSE.txt')).write_text(notice.read_text())
        (VENDOR/(basename+'-PROVENANCE.json')).write_text(json.dumps({'source':str(source),'sourceSha256':sha(source),
          'subsetSha256':sha(target),'characters':characters,'license':'SIL-OFL-1.1','derivativeName':family,
          'role':'Only missing arrows and Harvey progress symbols; original DIN/Dubai headings and body fonts remain unchanged.'},indent=2)+'\n')
    missing=[hex(ord(char))for char in characters if ord(char)not in TTFont(target).getBestCmap()]
    if missing:raise RuntimeError('The retained PDF symbol subset is stale or incomplete: '+', '.join(missing))
    return target

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--deps',type=Path,help='Existing exact-version npm package directory for a local rebuild')
    args=parser.parse_args();VENDOR.mkdir(parents=True,exist_ok=True);OUTPUT.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='tec-offline-pdf-')as temp:
        work=Path(temp);deps=args.deps
        lock=VENDOR/'offline-pdf-package-lock.json'
        if deps is None:
            deps=work/'deps';deps.mkdir();(deps/'package.json').write_text(json.dumps({'private':True,'dependencies':VERSIONS}))
            if lock.exists():
                shutil.copyfile(lock,deps/'package-lock.json');run(['npm','ci','--ignore-scripts','--no-audit','--no-fund','--registry=https://registry.npmjs.org'],cwd=deps)
            else:
                run(['npm','install','--ignore-scripts','--no-audit','--no-fund','--registry=https://registry.npmjs.org'],cwd=deps)
                shutil.copyfile(deps/'package-lock.json',lock)
        modules=deps/'node_modules'
        for name,expected in VERSIONS.items():
            actual=json.loads((modules/name/'package.json').read_text())['version']
            if actual!=expected:raise RuntimeError(f'{name}: expected{expected}, found{actual}')
        if not lock.exists()and(deps/'package-lock.json').exists():shutil.copyfile(deps/'package-lock.json',lock)
        symbols=symbol_subset();font_sources={key:APP/'assets/fonts'/name for key,name in FACES.items()};font_sources['symbols']=symbols
        data={key:{'base64':base64.b64encode(p.read_bytes()).decode()}for key,p in font_sources.items()}
        shaping_face=work/'din-shaping-only.otf';features=din_shaping_source(font_sources['din'],shaping_face)
        data['din']['shapingBase64']=base64.b64encode(shaping_face.read_bytes()).decode()
        (VENDOR/'offline-pdf-din-shaping.fea').write_text(features)
        wasm=modules/'harfbuzzjs/dist/harfbuzz.wasm'
        (work/'data.mjs').write_text('export const wasmBase64='+json.dumps(base64.b64encode(wasm.read_bytes()).decode())+';\nexport const fontData='+json.dumps(data)+';\n')
        hb_source=(modules/'harfbuzzjs/dist/index.mjs').read_text()
        hb_source=hb_source.replace('init(await createHarfBuzz());','export async function initializeOffline(wasmBinary) { if (Module) return; init(await createHarfBuzz({wasmBinary})); }')
        if 'initializeOffline'not in hb_source:raise RuntimeError('HarfBuzz initializer patch did not match the pinned source.')
        (work/'hb-offline.mjs').write_text(hb_source)
        glue=(modules/'harfbuzzjs/dist/harfbuzz.js').read_text().replace('import.meta.url',"(typeof document !== 'undefined' ? document.baseURI : 'file:///')")
        (work/'harfbuzz.js').write_text(glue)
        runtime=(VENDOR/'offline-pdf-runtime.mjs').read_text()
        runtime=runtime.replace('__PDFKIT_STANDALONE__',str(modules/'pdfkit/js/pdfkit.standalone.js'))
        runtime=runtime.replace('__HARFBUZZ_OFFLINE_MODULE__',str(work/'hb-offline.mjs'))
        runtime=runtime.replace('__BIDI_MODULE__',str(modules/'bidi-js/dist/bidi.mjs'))
        entry=work/'engine.mjs';entry.write_text(runtime)
        run([str(modules/'esbuild/bin/esbuild'),str(entry),'--bundle','--platform=browser','--format=iife','--target=chrome100',
          '--minify','--external:module','--legal-comments=none','--outfile='+str(OUTPUT)])
        copyright_text=[]
        for name in ['pdfkit','bidi-js','harfbuzzjs']:
            folder=modules/name;found=next((p for p in [folder/'LICENSE',folder/'LICENSE.txt']if p.exists()),None)
            if found:copyright_text.append(name+' '+VERSIONS[name]+'\n'+found.read_text())
        # The pinned fontkit npm tarball declares MIT but does not ship a LICENSE.
        # Preserve its declared author/license metadata and the standard MIT terms.
        fontkit_metadata=json.loads((modules/'fontkit/package.json').read_text())
        mit_terms=(modules/'pdfkit/LICENSE').read_text().split('Permission is hereby granted',1)[1]
        copyright_text.append('fontkit2.0.4\nDeclared package license: '+fontkit_metadata['license']+'\nAuthor metadata: '+str(fontkit_metadata.get('author',''))+'\nStandard MIT terms:\nPermission is hereby granted'+mit_terms)
        packages=json.loads((deps/'package-lock.json').read_text()).get('packages',{})
        for package_path,metadata in packages.items():
            if not package_path.startswith('node_modules/'):continue
            folder=deps/package_path
            if folder.name in ['pdfkit','bidi-js','harfbuzzjs','fontkit']:continue
            for filename in ['LICENSE','LICENSE.txt','LICENSE.md','license','license.txt','COPYING']:
                notice=folder/filename
                if notice.exists():
                    copyright_text.append(package_path+' '+metadata.get('version','')+'\n'+notice.read_text(errors='replace'));break
        copyright_text.append('PDF symbol fallback\n'+(VENDOR/'tec-pdf-symbols-LICENSE.txt').read_text())
        (VENDOR/'offline-pdf-LICENSES.txt').write_text('\n\n'.join(copyright_text)+'\n')
        provenance={'versions':VERSIONS,'runtime':'Self-contained browser IIFE; embedded WASM and font bytes; no network/file fetch at runtime.',
          'fontSources':{},'harfbuzzWasmSha256':sha(wasm),'bundleSha256':sha(OUTPUT),'bundleBytes':OUTPUT.stat().st_size,
          'harfbuzzPatch':'Initialize with embedded wasmBinary instead of top-level network loading; import.meta URL replaced for bundled browser execution.'}
        provenance['legacyDinShaping']='Transient joining-only GSUB supplement generated from the original font Unicode presentation-form cmap; original font bytes/outlines/metrics embedded unchanged.'
        provenance['legacyDinShapingFaceSha256']=sha(shaping_face)
        provenance['unicodeDataVersion']=unicodedata.unidata_version
        for key,p in font_sources.items():
            font=TTFont(p);provenance['fontSources'][key]={'file':str(p.relative_to(APP)),'sha256':sha(p),'bytes':p.stat().st_size,'fsType':font['OS/2'].fsType}
        (VENDOR/'offline-pdf-VERSIONS.json').write_text(json.dumps(provenance,indent=2)+'\n')
        print(json.dumps({'output':str(OUTPUT),'bytes':OUTPUT.stat().st_size,'sha256':sha(OUTPUT)}))
if __name__=='__main__':main()
