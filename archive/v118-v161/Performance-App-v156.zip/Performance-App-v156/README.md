# Performance App v156

Recorded progress now appears as a numeric percentage, without Harvey balls or circular progress indicators. The change applies to report tables, project cards, entity details and report exports. Zero remains a dash; missing progress remains blank; raw values, status and calculations are preserved.

The HH PDF keeps its paired charts and detailed definitions, report contents, project list and detail cards. The duplicate combined overview card that followed the charts has been removed from the PDF.

Extract the complete folder and open **index.html**. All application assets remain local. Select your report workbook in the app; no workbook is bundled.

The current design contract is **DESIGN-PRINCIPLES-v156.md**, Revision 23. See **VERIFICATION-v156.md** for the checks performed and their limits. Earlier verification documents describe their original releases.

The proposed monthly legislation card is a separate illustration for review; the live monthly calculation and SLC display have not changed in v156.
