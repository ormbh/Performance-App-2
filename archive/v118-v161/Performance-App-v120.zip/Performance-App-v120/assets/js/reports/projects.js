/* Projects report: the same scoped portfolio layout as the projects dashboard. */
(function(S){
 'use strict';
 var U=S.util,R=S.rules,O=S.order,QUARTERS=['Q1','Q2','Q3','Q4','other'];
 var QLABEL={Q1:'الربع الأول',Q2:'الربع الثاني',Q3:'الربع الثالث',Q4:'الربع الرابع',other:'خارج سنة التقرير / غير مؤرخ'};
 var TYPE={Strategic:'استراتيجي',Operational:'تشغيلي'},PRIORITY={H:'عالية',M:'متوسطة',L:'منخفضة'};
 var FIELDS=[['revised','الموازنة المعتمدة'],['committed','المخصص'],['nonCommitted','غير المخصص'],['workDone','قيمة الأعمال المنجزة'],['spent','المنفق الفعلي حسب الفواتير']];
 function e(v){return U.esc(v==null?'':String(v));}
 function n(v){return U.metricText(v);}
 function val(v){return v==null||String(v).trim()===''?'غير مسجل':String(v);}
 function status(it){return it.statusLabel||it.t.status||'غير مسجل';}
 function quarter(it){return QUARTERS.includes(it.calc.quarter)?it.calc.quarter:'other';}
 function money(cell){if(!cell||!['n','s'].includes(cell.t))return null;var v=cell.t==='n'?cell.v:String(cell.v).replace(/[,\s ]/g,'');return v!==''&&Number.isFinite(Number(v))?Number(v):null;}
 function amount(items,key){var values=items.map(function(it){return money(it.c[key]);}).filter(function(v){return v!=null;});return {value:values.length?values.reduce(function(a,b){return a+b;},0):null,known:values.length,total:items.length};}
 function matches(it,f){f=f||{};return U.selected(it.t.ptype||'',f.projectType)&&U.selected(it.t.priority||'',f.priority)&&U.selected(quarter(it),f.quarter)&&U.selected(status(it),f.projectStatus)&&U.selected(it.t.pm||'',f.pm);}
 function model(state){var base=state.data.items.filter(function(it){return it.pf==='secretariat'&&R.MET.secTotal.test(it)&&R.inScope(it,state.dash);}),f=state.report;
  var items=base.filter(function(it){return matches(it,f);}).sort(function(a,b){return S.views.reports.projectCompare(state.data,a,b);});
  var names=O.statuses(state.data,'secretariat').slice();items.forEach(function(it){if(!names.includes(status(it)))names.push(status(it));});
  var done=items.filter(function(it){return R.MET.secDone.test(it);});
  var untitled=state.data.items.filter(function(it){return it.pf==='secretariat'&&!R.MET.secTotal.test(it)&&R.inScope(it,state.dash)&&matches(it,f)&&FIELDS.some(function(f){return money(it.c[f[0]])!=null;});});
  return {excludedFinancial:untitled.length,excludedAmounts:FIELDS.map(function(f){return {name:f[1],...amount(untitled,f[0])};}),base:base,items:items,done:done,names:names,late:items.filter(function(it){return R.MET.secLate.test(it);}),active:items.filter(function(it){return R.MET.secActive.test(it);}),high:items.filter(function(it){return it.t.priority==='H';}),notes:items.filter(function(it){return String(it.t.ownerRemarks||'').trim()||String(it.t.financeRemarks||'').trim();}),finance:FIELDS.map(function(f){return {key:f[0],name:f[1],...amount(items,f[0])};})};
 }
 function filters(state,m){var controls='',fields=[['projectType','نوع المشروع',function(it){return it.t.ptype||'';},function(v){return TYPE[v]||val(v);}],['priority','الأولوية',function(it){return it.t.priority||'';},function(v){return PRIORITY[v]||val(v);}],['quarter','ربع الانتهاء',quarter,function(v){return QLABEL[v];}],['projectStatus','الحالة',status,val],['pm','مدير المشروع',function(it){return it.t.pm||'';},val]];
  fields.forEach(function(f){var vs=[...new Set(m.base.map(f[2]))];if(f[0]==='quarter')vs.sort(function(a,b){return QUARTERS.indexOf(a)-QUARTERS.indexOf(b);});if(f[0]==='priority')vs.sort(function(a,b){return O.compare(state.data,'ProjectPriority',a,b);});if(f[0]==='projectType')vs.sort(function(a,b){return O.compare(state.data,'ProjectType',a,b);});if(f[0]==='projectStatus')vs.sort(function(a,b){return O.status(state.data,a,b,'secretariat');});controls+=S.ui.multiSelect(state,'r:'+f[0],f[1],state.report[f[0]],vs.map(function(v){return {v:v,label:f[3](v)};}));});return S.ui.reportFilterControls(state,R.dashboard(state.data,state.dash),controls);
 }
 function scope(state){return [['القطاع',state.dash.sector,null,'d:sector'],['الوحدة التنظيمية',state.dash.unit,null,'d:unit'],['الجهة المعنية',state.dash.entity,null,'d:entity'],['نوع المشروع',state.report.projectType,TYPE,'r:projectType'],['الأولوية',state.report.priority,PRIORITY,'r:priority'],['ربع الانتهاء',state.report.quarter,QLABEL,'r:quarter'],['الحالة',state.report.projectStatus,null,'r:projectStatus'],['مدير المشروع',state.report.pm,null,'r:pm']].filter(function(x){return U.hasSelection(x[1]);}).map(function(x){return x[0]+': '+S.filterOptions.selectionGroups(x[1],(state.multiOptions||{})[x[3]],x[3]).map(function(o){var v=S.filterOptions.display(o.v);return x[2]?x[2][v]||val(o.label):val(o.label);}).join('، ');}).join(' · ')||'جميع المشاريع';}
 function excludedFinance(m){return m.excludedFinancial?'<aside class="pr-excluded"><strong>بنود مالية بلا اسم مشروع مستبعدة من إجماليات هذا التقرير: '+n(m.excludedFinancial)+'.</strong><p>'+m.excludedAmounts.filter(function(f){return f.known;}).map(function(f){return e(f.name)+': '+e(U.displayNumber(f.value,2));}).join(' · ')+' درهم إماراتي</p></aside>':'';}
 function method(){return '<p class="pr-note pd-report-method">تُحسب المشاريع المسماة ضمن عوامل التصفية مرة واحدة. المنجز بحسب الحالة المسجلة، والإنجاز متوسط النسب المسجلة. المفقود ليس صفراً. جدول المتابعة يقتصر على المشاريع التي تتطلب متابعة؛ الملاحظات نصوص مصدرية كاملة.</p>';}
 function render(state){
  if(!state.data)return '<div class="screen reports projects-report" data-screen="reports">'+S.ui.appHeader(state,'reports')+'<main class="rpt-main"><div class="pw-empty"><h1>مستجدات محفظة المشاريع</h1><p>ارفع ملف البيانات لعرض المشاريع.</p><button type="button" class="dbtn" data-act="change-file">رفع الملف</button></div></main></div>';
  var projectState=S.projects.reportState(state),m=S.projects.model(projectState),display=S.reportDisplay.get(state);
  return '<div class="screen reports projects-report projects-pmo" data-screen="reports">'+S.ui.appHeader(state,'reports')+'<main class="rpt-main"><section class="rpt-intro app-page-heading"><div><h1 data-report-title>'+e(display.title)+'</h1><p class="rpt-scope">'+e(scope(state))+'</p></div><div class="rpt-source"><span data-report-period-label>'+e(display.period)+'</span><small>التاريخ المرجعي للحسابات: '+e(U.fmtDate(state.data.today))+'</small></div></section><div class="rpt-controls">'+filters(state,m)+'</div>'+S.reportDisplay.controls(state)+S.reportEditorial.editor(state)+'<p class="pr-result-count" role="status" aria-live="polite">عدد المشاريع: '+n(m.items.length)+' من أصل '+n(m.base.length)+' ضمن النطاق التنظيمي · '+e(scope(state))+'</p>'+S.projects.sourceNotice(projectState)+excludedFinance(m)+S.reportEditorial.output(state)+'<div id="projects-panel">'+S.projects.renderDelivery(projectState,m.delivery,{report:true})+'</div>'+method()+'</main></div>';
 }
 S.projectsReport={model:model,render:render,money:money,amount:amount,quarter:quarter,scope:scope,matches:matches};
})(window.Saytara=window.Saytara||{});
