# Performance App v159

Data observations now focus on actionable source issues. Sector and department values and their relationship are validated against the approved organisation registry, including its bounded legacy aliases. Every populated schema-controlled field is checked against its applicable list of values, including recorded completion percentages.

Active projects at zero completion, repeated titles alone, blank leadership flags, valid future completion dates and partial historical status blocks no longer inflate the observation count. Blank leadership flags retain TEC membership. Missing decision follow-up requirements are flagged only when follow-up data is present. Negative unallocated amounts are finance review items, not confirmed data errors.

Confirmed identity problems, date/year conflicts, completed-status/percentage inconsistencies, missing targets and ambiguous zero measurement remain reviewable. Source values, totals, filters, report geometry and historical comparison eligibility are preserved.

Extract the complete folder and open **index.html**. Select your workbook; no workbook is bundled. See **DATA-CHECKS-POLICY-v159.md** and **VERIFICATION-v159.md** for the revised rules and evidence. The visual standard remains TEC Revision 25 in **DESIGN-PRINCIPLES-v158.md**. Earlier verification files describe their original releases.
