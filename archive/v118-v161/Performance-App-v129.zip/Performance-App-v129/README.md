# Performance App v129

Extract the complete ZIP, then open `index.html` with its `assets` folder beside it.
All scripts, images and approved fonts are bundled locally. Select your report
workbook on the upload page. Workbook processing stays on your device.

## Approved TEC design

This release implements the approved design in the app, including the monthly
and projects dashboards, their browser reports, search, search results and upload.
The supplied revision 2 formatting standard is included as **DESIGN-STANDARD.md**.
The latest approved Google-like search layout supplements that standard.

- DIN Next Arabic Regular headings: page 38px, portfolio 30px and card 28px.
  DIN Next LT Arabic Regular figures: 34–40px. Dubai Regular supporting text;
  table names and notes 16px, table headings Dubai Bold 18px, explanations 14px,
  change arrows 15px and metadata 14px.
- Names remain neutral and regular. Approved status badges are informational,
  with separate accessible drilldown controls. Completed work is green, including
  legislation completed after its deadline; unfinished late work is red.
- Shared controls use readable labels, 44px minimum targets, approved normal,
  hover, pressed and disabled states, and visible keyboard focus.
- Monthly content uses the available width at 100% browser zoom. Executive
  portfolios remain on the right, projects on the left and strategy below
  legislation. Valid historical changes remain below their values. Empty status
  and priority groups stay hidden; zero counts use a dash while meaningful
  source progress of 0% is retained.
- Projects keep the approved paired sections and chart scales. Priority charts
  fit their visible content without internal vertical scrollbars. The follow-up
  table includes late, frozen, cancelled and transferred projects in that order.
- Search has a centered TEC logo, a pill-shaped search field and two primary
  tasks. Results use the approved six-column table with native details, filters,
  sorting, column customization, pagination, CSV and print of all matches.
  On mobile, the readable table scrolls inside its own labelled region.
- Upload uses the approved panel, drop zone and button hierarchy while retaining
  native selection, drag/drop, local processing, busy-state guards and error
  recovery. Invalid replacement files do not discard the current workbook.
- Browser reports have their own readable print scale, repeated table headers
  and content-driven pagination. The entity filter and its selected value are
  omitted from the print header; the selected scope still filters the report.

## Data and workflows

Source records, matching keys, calculation models, chart eligibility, ranking,
filters and historical comparison rules retain their definitions. A presentation
change does not create a status, replace missing data with zero or invent an arrow.
Search includes all matching source records; the follow-up tables retain their
separate eligibility rules. Missing/unknown statuses remain distinct.

The app reads cached Excel formula results; it does not refresh Excel formulas
or Power Query. Existing note and settings storage keys are retained. To use the
new version, keep the old folder until you have checked your notes/settings in
this browser. Browser file-origin storage may vary when the folder moves.

Select **نسخة التقرير** for monthly browser printing and use its adjacent settings
control for A4/A3. Projects retain their A4/A3 and comfortable/compact print options.
PDF pages accommodate the content at the approved text sizes; page count is not
forced to match an earlier compact preview.

## Verification and maintenance

See **VERIFICATION-v129.md** for browser, source-regression, upload and PDF checks
and their practical limits. Verification files from earlier versions are historical.
The screenshots/PDF previews supplied with the release use an explicitly
illustrative test workbook; that workbook and test records are not bundled.

The operational workbook visible in the user's screenshots was not supplied for
this release. Numerical regression was checked against the illustrative fixture,
not an unseen production workbook. Native Windows file opening and physical
printing were not tested in this managed Linux browser environment.

Readable source modules are included. Rebuild with
`python tools/build-bundles.py`; check them with
`python tools/build-bundles.py --check`. `release-manifest.json` records the SHA-256
of every release file except itself. **FONT-ASSETS.md** identifies bundled fonts.
