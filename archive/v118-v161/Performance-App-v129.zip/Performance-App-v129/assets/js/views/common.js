/*
 * Performance reporting · shared view pieces
 * Status chips, timing badges, progress bars and the tooltip registry.
 */
(function (S) {
  'use strict';

  var U = S.util, SC = S.schema;

  var HEALTH = {
    delayed: { ar: 'متأخر', icon: 'clock-alert' },
    doneOnTime: { ar: 'ضمن الموعد بحسب المؤشر', icon: 'check' },
    doneLate: { ar: 'تجاوز الموعد', icon: 'check-clock' },
    clear: { ar: 'بدون تأخير', icon: 'check-circle' }
  };

  // Generated UI wording only; workbook labels, values and identifiers stay literal.
  function recordWord(pf, form) {
    var words = S.terms.words(pf);
    return words[form || 'definite'] || words.definite;
  }

  // Type belongs to generated field labels, never to the source title value.
  function contentLabel(itemOrPf) {
    var pf = typeof itemOrPf === 'string' ? itemOrPf : itemOrPf && itemOrPf.pf;
    return SC.PF[pf] ? recordWord(pf, 'definite') : 'العنوان';
  }
  function contentHeader(items, fallbackPortfolios) {
    var rows = Array.isArray(items) ? items : [];
    var types = rows.length ? rows : U.selection(fallbackPortfolios);
    var labels = Array.from(new Set(types.map(contentLabel)));
    return labels.length === 1 ? labels[0] : 'العنوان';
  }

  function statusChip(it, size) {
    if (!it.statusLabel) return '';
    var cat = it.statusCat;
    // The approved stylesheet owns the category treatment; source labels stay literal.
    return '<span class="st st-' + cat + (size ? ' st-' + size : '') + '">' +
      '<span dir="auto">' + U.esc(it.statusLabel) + '</span></span>';
  }

  function healthChip(key, n, size) {
    var h = HEALTH[key];
    if (!h) return '';
    return '<span class="hl hl-' + key + (size ? ' hl-' + size : '') + '">' + U.icon(h.icon, size === 'lg' ? 15 : 14) + h.ar +
      (n != null && n !== '' ? ' <span class="num">' + U.esc(n) + '</span>' : '') + '</span>';
  }

  /* Status plus timing; a status that already says "متأخر" is not repeated. */
  function chips(it, size) {
    var dup = it.statusCat === 'delayed' && it.health === 'delayed';
    return statusChip(it, size) + (it.health && !dup ? healthChip(it.health, null, size) : '');
  }

  /* Progress cell: % complete for projects and decisions, result vs target for KPIs. */
  function progressReading(value) {
    var text=U.displayNumber(value,1,'%');
    return U.esc(text);
  }
  function progress(it, big) {
    if (it.pf === 'kpi') {
      var r = it.calc.resultRecorded, t = it.calc.targetRecorded;
      if (r == null) return '<span class="prog-none">' + (it.c.result ? 'نتيجة غير رقمية' : 'غير مسجل') + '</span>';
      var rp = Math.round(r * 100), tp = t != null ? Math.round(t * 100) : null;
      var fill = tp == null ? 'var(--info)' : rp >= tp ? 'var(--ok)' : 'var(--warn)';
      return '<div class="prog' + (big ? ' prog-lg' : '') + '"><div class="prog-label">' + progressReading(r*100) + (tp != null ? ' · المستهدف ' + progressReading(t*100) : '') + '</div>' +
        '<div class="prog-bar"><span style="width:' + Math.max(0, Math.min(100, rp)) + '%;background:' + fill + '"></span>' +
        (tp != null ? '<i class="prog-mark" style="inset-inline-start:' + Math.max(0, Math.min(100, tp)) + '%" title="المستهدف"></i>' : '') + '</div></div>';
    }
    if (it.progress == null) {
      var has = it.pf === 'special' || it.pf === 'secretariat' || it.pf === 'council';
      return '<span class="prog-none">' + (has ? 'غير مسجلة' : '—') + '</span>';
    }
    var p = Math.round(it.progress);
    var col = it.statusCat === 'done' ? 'var(--status-completed)' : it.health === 'delayed' || it.statusCat === 'delayed' ? 'var(--status-late)' : 'var(--info)';
    return '<div class="prog' + (big ? ' prog-lg' : '') + '"><div class="prog-label">' + progressReading(it.progress) + '</div>' +
      '<div class="prog-bar"><span style="width:' + Math.max(0, Math.min(100, p)) + '%;background:' + col + '"></span></div></div>';
  }

  function pfName(pf) { return SC.PF[pf] ? SC.PF[pf].ar : pf; }

  function drillCue() { return ''; }

  /* File names mix Arabic, digits and ".xlsx"; keep the extension in its own
     left-to-right run so "سبتمبر 2026.xlsx" does not show as "xlsx.2026". */
  function fileName(name) {
    var n = String(name || ''), dot = n.lastIndexOf('.');
    if (U.dirOf(n) === 'ltr' || dot <= 0) return '<bdi dir="' + U.dirOf(n) + '">' + U.esc(n) + '</bdi>';
    return '<bdi dir="rtl">' + U.esc(n.slice(0, dot)) + '</bdi><bdi dir="ltr">' + U.esc(n.slice(dot)) + '</bdi>';
  }

  /* Source identity and calculation context remain available at the footer. */
  function searchSource(state) { return ''; }
  // Legal release year is separate from the selected reporting/calculation year.
  function copyrightText() { return 'الأمانة العامة للمجلس التنفيذي لإمارة دبي حقوق النشر © 2026 · جميع الحقوق محفوظة'; }
  function sourceFooter(state) {
    var data=state.data,context='';
    if(data){
      var date=data.referenceDateReady&&U.validDateSerial(data.today)?U.fmtDate(data.today):'لم يُحدَّد';
      var reference=U.validDateSerial(data.sourceValidationDate)?data.sourceValidationDate:data.savedReportDate;
      context='<span class="source-footer-file"><span class="source-footer-label">ملف البيانات</span><strong>'+fileName(data.file&&data.file.name||'ملف غير مسمى')+'</strong></span><span class="source-footer-date"><span class="source-footer-label">تاريخ الحساب</span><bdi dir="ltr">'+U.esc(date)+'</bdi></span>'+(U.validDateSerial(reference)&&reference!==data.today?'<span class="source-footer-reference"><span class="source-footer-label">مرجع الملف</span><bdi dir="ltr">'+U.esc(U.fmtDate(reference))+'</bdi></span>':'');
    }
    return '<footer class="app-source-footer" aria-label="مصدر البيانات وحقوق النشر"><style>:root{--app-footer-context:'+JSON.stringify(copyrightText())+';}</style><div class="app-source-footer-in">'+context+'<p class="app-footer-copyright">'+U.esc(copyrightText())+'</p></div></footer>';
  }

  /* The approved monthly reference has its own report masthead and a compact
     workspace switch. These pieces reuse the live routes and source context;
     they never substitute the illustrative workbook used in the reference. */
  function monthlyReferenceHeader(state, summary) {
    var data = state.data, busy = !!state.reporting;
    var date = data && U.validDateSerial(data.today) ? U.fmtDate(data.today) : 'لم يُحدَّد';
    var reference = data && U.validDateSerial(data.sourceValidationDate) ? data.sourceValidationDate : data && data.savedReportDate;
    var issues = data ? (data.issues || []).filter(function (x) { return x.sev !== 'info'; }).length : 0;
    function link(screen, action, label, icon, cls) {
      var href = S.app && S.app.href ? S.app.href(screen) : '#/' + screen;
      return '<a href="' + U.esc(href) + '" data-screen-link="' + screen + '" data-act="' + action + '" class="' + (cls || 'wb-reference-tool') + '">' + (icon ? U.icon(icon, 17) : '') + '<span>' + U.esc(label) + '</span></a>';
    }
    var reports = S.views.reports && S.views.reports.menu ? '<div class="wb-reference-report-menu">' + S.views.reports.menu(state) + '</div>' : '';
    var tools = link('home', 'go-home', 'البحث', 'search') +
      link('entities', 'go-entities', 'تقرير الجهات', 'entities') +
      link('comparison', 'go-comparison', 'المقارنة الشهرية', 'compare') + reports +
      '<button type="button" class="wb-reference-tool" data-act="go-checks">' + U.icon('warn', 17) + '<span>ملاحظات البيانات</span><bdi class="badge">' + U.fmtN(issues) + '</bdi></button>' +
      '<button type="button" class="wb-reference-tool" data-act="change-file"' + (busy ? ' disabled' : '') + '>' + U.icon('upload', 17) + '<span>تغيير الملف</span></button>' +
      (data ? '<p class="wb-reference-source"><span>ملف البيانات</span><strong>' + fileName(data.file && data.file.name || 'ملف غير مسمى') + '</strong><span>تاريخ الحساب <bdi dir="ltr">' + U.esc(date) + '</bdi></span>' + (U.validDateSerial(reference) && reference !== data.today ? '<span>مرجع الملف <bdi dir="ltr">' + U.esc(U.fmtDate(reference)) + '</bdi></span>' : '') + '</p>' : '');
    return '<a class="app-skip-link" href="#app-main" data-act="skip-content">انتقل إلى المحتوى</a>' +
      '<header class="app-header wb-reference-header' + (state.navOpen ? ' is-nav-open' : '') + '">' +
        '<div class="wb-reference-page-header"><div class="wb-reference-title"><h1>التقرير الشهري للأداء والتنفيذ</h1><p class="wb-reference-context">حتى تاريخ <bdi dir="ltr">' + U.esc(date) + '</bdi> <span aria-hidden="true" class="wb-reference-sep">·</span> <span>' + U.esc(summary || 'جميع القطاعات والوحدات والجهات') + '</span></p></div>' +
          '<a href="#/dashboard" data-screen-link="dashboard" data-act="go-dash" class="wb-reference-brand" aria-label="التقرير الشهري"><img class="tec-logo" src="assets/img/tec-red.png" alt="المجلس التنفيذي — The Executive Council"></a></div>' +
        '<div class="wb-reference-workspace"><nav class="wb-reference-tabs" aria-label="لوحات المتابعة"><a href="#/dashboard" data-screen-link="dashboard" data-act="go-dash" class="wb-reference-tab is-selected" aria-current="page">اللوحة الشهرية</a>' + link('projects', 'go-projects', 'محفظة المشاريع', '', 'wb-reference-tab') + '</nav>' +
          '<div class="wb-reference-tools"><button type="button" class="wb-reference-tools-trigger" data-act="toggle-nav" aria-expanded="' + !!state.navOpen + '" aria-controls="monthly-reference-tools"><i aria-hidden="true"></i><span>البيانات الحالية</span>' + U.icon('rows', 18) + '<span class="visually-hidden">وأدوات الصفحة</span></button><div id="monthly-reference-tools" class="wb-reference-tools-panel" role="group" aria-label="البيانات وأدوات الصفحة">' + tools + '</div></div></div>' +
      '</header>';
  }

  /* The open reference row wraps the existing multi-select markup. Selection,
     stored aliases, option search and filter unions stay with the original UI. */
  function monthlyReferenceFilters(state, controlsHtml, summary, activeCount) {
    var active = Math.max(0, Number(activeCount) || 0), busy = !!state.reporting;
    var controls = controlsHtml || '';
    [['sector', 'القطاع', 'جميع القطاعات'], ['unit', 'الوحدة التنظيمية', 'جميع الوحدات'], ['entity', 'الجهة المعنية', 'جميع الجهات']].forEach(function (field) {
      if (state.dash && U.hasSelection(state.dash[field[0]])) return;
      var trigger = new RegExp('(<div class="menu-wrap multi-wrap" data-multi-wrap="d:' + field[0] + '"><button\\b[^>]*>)([\\s\\S]*?)(</button>)');
      controls = controls.replace(trigger, function (all, start, body, end) {
        return start.replace('aria-label="' + U.esc(field[1] + ': الكل') + '"', 'aria-label="' + U.esc(field[1] + ': ' + field[2]) + '"') + body.replace('<b dir="auto">الكل</b>', '<b dir="auto">' + U.esc(field[2]) + '</b>') + end;
      });
    });
    return '<section class="wb-reference-filter-row" aria-label="نطاق التقرير الشهري"><div class="wb-reference-filter-controls">' + controls + '</div>' +
      '<div class="wb-reference-scope" role="status" aria-live="polite" aria-atomic="true"><i aria-hidden="true"></i><span' + (active ? ' title="' + U.esc(summary || '') + '"' : '') + '>' + (active ? 'نطاق التقرير المحدد' : 'نطاق التقرير الكامل') + '</span>' +
        (active ? '<button type="button" class="wb-reference-reset" data-act="reset-dashboard-filters"' + (busy ? ' disabled' : '') + '>مسح التصفية <bdi aria-label="' + U.esc('عدد عوامل التصفية النشطة: ' + U.fmtN(active)) + '">' + U.fmtN(active) + '</bdi></button>' : '') + '</div>' +
      '<div class="monthly-print-control wb-reference-print-control"><button type="button" class="wb-reference-print" data-act="print"' + (busy ? ' disabled' : '') + '>' + U.icon('print', 18) + '<span>نسخة التقرير</span></button><button type="button" class="wb-reference-print-settings" data-act="monthly-settings" aria-label="إعدادات التقرير والطباعة" title="إعدادات التقرير والطباعة" aria-haspopup="dialog" aria-controls="monthly-report-settings" aria-expanded="' + !!(state.monthly && state.monthly.settingsOpen) + '"' + (busy ? ' disabled' : '') + '>' + U.icon('down', 16) + '</button></div>' +
    '</section>';
  }


  /* Shared navigation keeps the same routes/actions across every working screen.
     Primary destinations stay distinct from file, validation and export utilities. */
  function appHeader(state, current, options) {
    options = options || {};
    var hasData = !!state.data, busy = !!state.reporting;
    var nav = '', utilities = '';
    function destination(key, action, text, icon) {
      var screen = key === 'search' ? 'home' : key;
      var href = S.app && S.app.href ? S.app.href(screen) : '#/' + screen;
      return '<a href="' + U.esc(href) + '" data-screen-link="' + screen + '" class="app-nav-item' + (current === key ? ' is-current' : '') + '" data-act="' + action + '"' + (current === key ? ' aria-current="page"' : '') + '>' + (icon ? U.icon(icon, 17) : '') + text + '</a>';
    }
    if (hasData) {
      nav = destination('search', 'go-home', 'البحث', 'search') +
        destination('dashboard', 'go-dash', 'التقرير الشهري', 'grid') +
        destination('projects', 'go-projects', 'محفظة المشاريع', 'rows') +
        destination('entities', 'go-entities', 'تقرير الجهات', 'entities') +
        destination('comparison', 'go-comparison', 'المقارنة الشهرية', 'compare');
      if (S.views.reports && S.views.reports.menu) nav += '<div class="app-report-nav' + (current === 'reports' ? ' is-current' : '') + '">' + S.views.reports.menu(state) + '</div>';
    }
    if (hasData) {
      var n = (state.data.issues||[]).filter(function (x) { return x.sev !== 'info'; }).length;
      utilities += '<button type="button" class="btn app-utility" data-act="go-checks">' + U.icon('warn', 17) + 'ملاحظات البيانات <span class="badge">' + n + '</span></button>' +
        '<button type="button" class="btn app-utility" data-act="change-file">' + U.icon('upload', 17) + 'تغيير الملف</button>';
    }
    if (current === 'reports') {
      var kind = state.report.kind;
      if (kind === 'hh' || kind === 'agenda' || kind === 'council') utilities += '<button type="button" class="btn app-utility" data-act="' + (kind === 'hh' ? 'hh-report' : kind === 'council' ? 'council-report' : 'agenda-report') + '"' + (busy ? ' disabled' : '') + '>' + U.icon('download', 17) + (busy ? 'جارٍ إعداد PowerPoint…' : 'تنزيل PowerPoint') + '</button>';
      utilities += '<button type="button" class="btn app-utility" data-act="print">' + U.icon('print', 17) + 'طباعة / حفظ PDF</button>';
    }
    if (current === 'comparison') utilities += '<button type="button" class="btn app-utility" data-act="reset-comparison">' + U.icon('refresh', 17) + 'مسح المقارنة</button>';
    if (options.masthead && options.actions) utilities += options.actions;
    var brandScreen = hasData ? 'dashboard' : 'upload';
    return '<a class="app-skip-link" href="#app-main" data-act="skip-content">انتقل إلى المحتوى</a><header class="wb-topbar app-header'+(options.masthead?' app-project-header':'')+(state.navOpen?' is-nav-open':'')+'"><div class="wb-topbar-in app-header-in"><a href="#/'+brandScreen+'" class="wb-brand" data-screen-link="'+brandScreen+'" data-act="' + (hasData ? 'go-dash' : 'change-file') + '" aria-label="'+(hasData?'التقرير الشهري':'رفع الملف')+'"><img class="tec-logo" src="assets/img/tec-red.png" alt="المجلس التنفيذي — The Executive Council"></a>'+(options.masthead||'')+(hasData?'<button type="button" class="btn app-menu-toggle" aria-label="أدوات الصفحة" data-act="toggle-nav" aria-controls="app-page-tools" aria-expanded="'+!!state.navOpen+'">'+U.icon('rows',20)+'<span>أدوات الصفحة</span></button>':'')+'<div id="app-navigation" class="app-navigation">'+(nav?'<nav class="app-nav" aria-label="التنقل الرئيسي">' + nav + '</nav>':'') + (utilities ? '<div id="app-page-tools" class="app-utilities" role="group" aria-label="أدوات الصفحة">' + utilities + '</div>' : '') + '</div></div></header>';
  }

  // All report kinds use the same scope controls and reset action. Extra
  // controls are supplied by the owning report; dashboard markup is unchanged.
  function reportFilterControls(state, dashboard, extra) {
    return state.report.kind==='council' ? S.views.dashboard.filterBar(state,dashboard,true,extra) : S.views.dashboard.filterBar(state,dashboard,true)+(extra||'');
  }
  // Both binary leadership values mean an unconstrained report, including
  // records whose source flag is blank. Keep explicit single/blank values.
  function reportLeadSelection(value) {
    var selected=U.selection(value),keys=selected.map(S.filterOptions.key);
    return keys.includes(S.filterOptions.key('نعم'))&&keys.includes(S.filterOptions.key('لا'))?'':U.selectionState(selected);
  }
  // One disclosure pattern across views. Opening is a presentation preference;
  // it never changes selections, result counts, routing, or export scope.
  function filterPanel(state, options) {
    var id=String(options.id||'scope').replace(/[^a-z0-9-]/gi,'-');
    var open=!!(state.filterPanels&&state.filterPanels[id]);
    var heading='filters-'+id+'-title', controls='filters-'+id+'-controls';
    var active=Math.max(0,Number(options.activeCount)||0);
    return '<section class="ui-filter-panel'+(open?' is-open':'')+'" data-filter-panel="'+id+'" aria-labelledby="'+heading+'">'+
      '<div class="ui-filter-header"><div class="ui-filter-title"><h2 id="'+heading+'" class="visually-hidden">'+U.esc(options.title||'عوامل التصفية')+'</h2><span class="ui-scope-label">النطاق</span><p class="ui-filter-summary" role="status" aria-live="polite" aria-atomic="true"><bdi dir="auto">'+U.esc(options.summary||'الكل')+'</bdi></p></div>'+
      '<div class="ui-filter-actions">'+(active&&options.resetAction?'<button type="button" class="dbtn ui-filter-reset" data-act="'+U.esc(options.resetAction)+'"'+(state.reporting?' disabled':'')+'>'+U.esc(options.resetLabel||'مسح التصفية')+'</button>':'')+'<button type="button" class="dbtn ui-filter-toggle" data-act="toggle-filters" data-filter-panel="'+id+'" aria-expanded="'+open+'" aria-controls="'+controls+'"><span class="ui-filter-toggle-label">'+(open?'إغلاق التصفية':'تصفية')+'</span>'+(active?'<span class="ui-filter-count" aria-label="'+U.esc('عدد عوامل التصفية النشطة: '+active)+'">'+U.fmtN(active)+'</span>':'')+U.icon(open?'up':'down',18)+'</button></div></div>'+
      '<div class="ui-filter-body" id="'+controls+'"'+(open?'':' hidden')+'>'+(options.body||'')+'</div></section>';
  }
  function multiSelect(state,id,label,value,values) {
    var F=S.filterOptions,sel=U.selection(id==='r:lead'?reportLeadSelection(value):value),opts=F.group(F.sourceAliases(state,id,F.organizationOptions(state,id,values)),sel,id),groups=F.selectionGroups(sel,opts,id),open=state.menu===id;
    state.multiOptions=state.multiOptions||{};state.multiOptions[id]=opts;
    var ident='multi-'+id.replace(/[^a-z0-9-]/gi,'-'),text=groups.length===1?groups[0].label:groups.length?'القيم المحددة: '+groups.length:'الكل';
    var query=state.multiSearch&&state.multiSearch[id]||'',needle=U.norm(F.display(query)),matching=opts.filter(function(o){return F.matches(o,query);}).length;
    return '<div class="menu-wrap multi-wrap" data-multi-wrap="'+U.esc(id)+'"><button type="button" class="dbtn multi-trigger'+(groups.length?' is-active':'')+'" data-act="menu" data-menu="'+U.esc(id)+'" aria-expanded="'+open+'"'+(open?' aria-controls="'+ident+'"':'')+' aria-label="'+U.esc(label+': '+(groups.length?F.text(sel,opts,null,id):'الكل'))+'"'+(state.reporting?' disabled':'')+'><span class="muted">'+U.esc(label)+'</span><b dir="auto">'+U.esc(text)+'</b>'+U.icon('down',16)+'</button>'+(open?'<div id="'+ident+'" class="menu menu-check multi-menu" role="group" aria-label="'+U.esc(label)+'"><div class="multi-menu-heading"><strong>'+U.esc(label)+'</strong><button type="button" class="multi-close" data-act="close-multi" data-multi="'+U.esc(id)+'" aria-label="إغلاق خيارات '+U.esc(label)+'">'+U.icon('x',18)+'</button></div><label class="multi-search-label"><span class="visually-hidden">البحث في خيارات '+U.esc(label)+'</span><input type="search" data-multi-search="'+U.esc(id)+'" value="'+U.esc(query)+'" placeholder="البحث في الخيارات" aria-controls="'+ident+'-options"></label><div class="multi-actions"><button type="button" data-act="multi-all" data-multi="'+U.esc(id)+'">تحديد الكل</button><button type="button" data-act="multi-clear" data-multi="'+U.esc(id)+'">مسح التحديد</button><span class="multi-selected-count">'+(groups.length?U.fmtN(groups.length)+' محدد':'الكل')+'</span></div><div class="multi-options" id="'+ident+'-options">'+opts.map(function(o){return '<label class="opt'+(o.stale?' is-stale':'')+'"'+(!F.matches(o,query)?' hidden':'')+'><input type="checkbox" data-change="multi" data-multi="'+U.esc(id)+'" data-v="'+U.esc(o.v)+'"'+(o.selected&&!o.partial?' checked':'')+(o.partial?' data-multi-partial="true" aria-checked="mixed"':'')+'><span class="opt-l" dir="auto">'+U.esc(o.label)+(o.partial?'<small class="multi-partial-note"> · تحديد جزئي محفوظ</small>':'')+'</span>'+(o.n==null?'':'<span class="opt-n">'+U.metricText(o.n)+'</span>')+'</label>';}).join('')+'</div><p class="multi-empty" role="status"'+(matching?' hidden':'')+'>'+(opts.length?'لا توجد خيارات مطابقة للبحث':'لا توجد قيم ضمن النطاق الحالي')+'</p></div>':'')+'</div>';
  }

  /* Tooltips: views register {title, def, now, base} and mark the element with data-tip. */
  var tips = {};
  var tipSeq = 0;
  function tip(t) { var id = 't' + (++tipSeq); tips[id] = t; return ' data-tip="' + id + '"'; }
  function resetTips() { tips = {}; tipSeq = 0; S.ui.tips = tips; }

  S.views = S.views || {};
  S.ui = {
    recordWord:recordWord, contentLabel:contentLabel, contentHeader:contentHeader, drillCue:drillCue, filterPanel:filterPanel, reportFilterControls:reportFilterControls, reportLeadSelection:reportLeadSelection, multiSelect:multiSelect, statusChip: statusChip, healthChip: healthChip, chips: chips, progress: progress,
    pfName: pfName, fileName: fileName, searchSource:searchSource, sourceFooter:sourceFooter, copyrightText:copyrightText, appHeader: appHeader, monthlyReferenceHeader:monthlyReferenceHeader, monthlyReferenceFilters:monthlyReferenceFilters, HEALTH: HEALTH, tip: tip, resetTips: resetTips, tips: tips
  };
})(window.Saytara = window.Saytara || {});
