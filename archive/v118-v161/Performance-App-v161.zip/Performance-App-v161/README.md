# Performance App v161

Agenda and special-project reports now share one report structure: contents, charts and compact full definitions, records, applicable detailed updates, then notes and recommendations. **المستجدات التفصيلية** remains exclusive to special projects.

Both reports use consistent cover titles, entity/date placement, table-column order, continuous record numbering, links, typography and empty states. PDF contents uses actual page numbers and internal links. Page numbering and copyright begin after the cover. Smaller legends give the charts more room.

Extract the complete folder and open **index.html**. Select your workbook; no workbook is bundled.

- [Full recommendations and approach](REPORT-CONSISTENCY-v161.md)
- [Current design principles — Revision 26](DESIGN-PRINCIPLES-v161.md)
- [Verification and limitations](VERIFICATION-v161.md)
- [Data-check policy](DATA-CHECKS-POLICY-v160.md)

Source records, metric definitions, filters and the approved v159/v160 data checks are preserved. Earlier verification files describe their original releases.
