/* Native TEC print preparation. CSS paged media owns page count and flow.
 * Do not clone/filter/reorder data here: each view's full export DOM is retained. */
(function (S) {
  'use strict';
  var U = S.util;
  var MM_PER_PX = 25.4 / 96, CONTINUOUS_WIDTH_MM = 297, CONTINUOUS_MARGIN_MM = 8;
  var CONTINUOUS_FOOTER_RESERVE_MM = 8;
  var CONTINUOUS_INITIAL_HEIGHT_MM = 80, CONTINUOUS_MAX_HEIGHT_MM = 5080;
  var printSession = null;
  var TITLES = { dashboard:'التقرير الشهري للأداء والتنفيذ', projects:'مستجدات محفظة المشاريع', results:'نتائج البحث في الأداء', home:'البحث في الأداء', entities:'تقرير الجهات', comparison:'المقارنة الشهرية', agenda:'الأجندة السنوية', council:'تقرير قرارات المجالس', checks:'ملاحظات البيانات', detail:'تفاصيل البند', upload:'رفع ملف التقرير' };
  function title(state) {
    if (state.screen === 'reports' && S.reportDisplay) return S.reportDisplay.fileTitle(S.reportDisplay.get(state).fileTitle);
    var root = document.querySelector('#app .project-masthead h1, #app main h1');
    return TITLES[state.screen] || (root ? root.textContent.trim() : 'تقرير الأداء');
  }
  function orientation(state) {
    // A project report shares the reports route, but keeps the portrait rule.
    var landscape = state && (state.screen === 'agenda' || state.screen === 'council' ||
      state.screen === 'reports' && state.report && ['agenda', 'council', 'hh'].includes(state.report.kind));
    return landscape ? 'landscape' : 'portrait';
  }
  function legal() {
    return S.ui && S.ui.copyrightText ? S.ui.copyrightText() : 'الأمانة العامة للمجلس التنفيذي لإمارة دبي · حقوق النشر © ' + new Date().getFullYear() + ' · جميع الحقوق محفوظة';
  }
  function groupPanels() {
    document.querySelectorAll('#app .pd-reference-grid').forEach(function(grid) {
      if (grid.classList.contains('tec-print-grouped')) return;
      var panels = Array.from(grid.children);
      grid.classList.add('tec-print-grouped');
      for (var i = 0; i < panels.length;) {
        if (panels[i].classList.contains('pd-issues')) { i++; continue; }
        var pair = document.createElement('div'); pair.className = 'tec-print-panel-pair';
        grid.insertBefore(pair, panels[i]); pair.appendChild(panels[i++]);
        if (i < panels.length && !panels[i].classList.contains('pd-issues')) pair.appendChild(panels[i++]);
      }
    });
  }
  function printMediaActive() {
    return !window.matchMedia || window.matchMedia('print').matches;
  }
  function pageSize(session, heightMM) {
    var rule = session.continuous && !session.fallback
      ? '@page tec-report { size:' + CONTINUOUS_WIDTH_MM + 'mm ' + heightMM + 'mm; margin:' + CONTINUOUS_MARGIN_MM + 'mm ' + CONTINUOUS_MARGIN_MM + 'mm ' + (CONTINUOUS_MARGIN_MM + CONTINUOUS_FOOTER_RESERVE_MM) + 'mm; background:#EFEBE7; @bottom-left { vertical-align:top; padding-top:1mm; } @bottom-right { vertical-align:top; padding-top:1mm; } }'
      : '@page tec-report { size:A4 ' + session.direction + '; margin:10mm; }';
    // A stable width and content-based height avoid page-size feedback or scaling.
    if (session.css.textContent !== rule) session.css.textContent = rule;
  }
  function continuousFallback(session, heightMM) {
    if (session !== printSession || session.fallback) return;
    session.fallback = true;
    document.body.setAttribute('data-tec-print', 'a4');
    document.body.setAttribute('data-monthly-layout', 'a4');
    pageSize(session);
    // This is a print-session fallback; the saved preference and report data stay intact.
    window.dispatchEvent(new CustomEvent('tec-print-layout-fallback', { detail: {
      layout:'a4', reason:'page-height-limit', heightMM:heightMM, maxHeightMM:CONTINUOUS_MAX_HEIGHT_MM,
      message:'يتجاوز التقرير حد طول الصفحة المتصلة؛ تم استخدام صفحات A4 عمودية للحفاظ على جميع البنود والملاحظات.'
    } }));
    measureRows('portrait');
  }
  function measureContinuous() {
    var session = printSession;
    if (!session || !session.continuous || session.fallback || !printMediaActive() ||
        document.body.getAttribute('data-tec-print') !== 'continuous') return;
    // Flush print styles before checking fonts: activating paper-only text can request a font.
    var rect = session.root.getBoundingClientRect();
    if (document.fonts && document.fonts.status !== 'loaded') return;
    if (!rect.width || !rect.height) return;
    // Measure the complete export DOM, never the viewport/body height or current paper size.
    var contentHeight = Math.max(rect.height, session.root.scrollHeight);
    var heightMM = Math.max(CONTINUOUS_INITIAL_HEIGHT_MM,
      Math.ceil(contentHeight * MM_PER_PX) + CONTINUOUS_MARGIN_MM * 2 + CONTINUOUS_FOOTER_RESERVE_MM + 3);
    if (!Number.isFinite(heightMM)) return;
    if (heightMM > CONTINUOUS_MAX_HEIGHT_MM) { continuousFallback(session, heightMM); return; }
    session.heightMM = heightMM;
    pageSize(session, heightMM);
  }
  function queueContinuousReadiness(session) {
    if (session.readinessPending || session.fallback || !session.continuous) return;
    session.readinessPending = true;
    var fonts = document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve();
    fonts.then(function () {
      if (session !== printSession || !printMediaActive() || session.fallback) return [];
      return Promise.all(Array.from(session.root.querySelectorAll('img')).map(function (img) {
        var rect = img.getBoundingClientRect();
        if (!rect.width || !rect.height || img.complete || !img.decode) return Promise.resolve();
        return img.decode().catch(function () {});
      }));
    }).then(function () {
      session.readinessPending = false;
      if (session === printSession) measureContinuous();
    }, function () { session.readinessPending = false; });
  }
  function measurePrint(session) {
    if (session !== printSession || !document.body.hasAttribute('data-tec-print')) return;
    if (session.continuous && !session.fallback) {
      measureContinuous();
      queueContinuousReadiness(session);
    } else measureRows(session.direction);
  }
  function measureRows(direction) {
    // Hidden paper DOM has no useful geometry before print media is active.
    // Measure synchronously on actual media entry, not just before window.print.
    if (!printMediaActive()) return;
    if (document.body.getAttribute('data-tec-print') === 'continuous') { measureContinuous(); return; }
    direction = direction === 'landscape' || direction === 'portrait' ? direction :
      document.body.getAttribute('data-tec-print-orientation') || 'portrait';
    var max = (direction === 'landscape' ? 190 : 277) * 96 / 25.4;
    document.querySelectorAll('#app tbody tr').forEach(function (row) {
      var rect = row.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      var table = row.closest('table'), head = table && table.tHead;
      var available = Math.max(0, max - (head ? head.getBoundingClientRect().height : 0));
      row.classList.toggle('tec-print-tall-row', rect.height > available);
    });
    document.querySelectorAll('#app .mp-card, #app .pd-panel, #app .entity-print-summary, #app .cmp-kpi, #app .cmp-section, #app .cmp-record, #app .rpt-chart-panel').forEach(function (card) {
      var rect = card.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      card.classList.toggle('tec-print-tall-card', rect.height > max);
    });
  }
  function prepare(state) {
    var root = document.getElementById('app');
    if (!root || !state || !state.data) return;
    var continuous = state.screen === 'dashboard' && S.monthlyTools && S.monthlyTools.layout(state) === 'continuous';
    var direction = continuous ? 'portrait' : orientation(state), css = document.getElementById('tec-print-page-size');
    if (!css) { css = document.createElement('style'); css.id = 'tec-print-page-size'; document.head.appendChild(css); }
    // Toolbar preparation and the native beforeprint event can run for the same session.
    // Keep a safe fallback sticky until afterprint, rather than retrying an oversized page.
    if (!printSession || printSession.root !== root || printSession.css !== css || printSession.continuous !== !!continuous) {
      printSession = { root:root, css:css, continuous:!!continuous, direction:direction, fallback:false,
        monthlyLayout:document.body.getAttribute('data-monthly-layout'), heightMM:null, readinessPending:false };
    }
    var session = printSession;
    session.direction = direction;
    pageSize(session, session.heightMM || CONTINUOUS_INITIAL_HEIGHT_MM);
    document.documentElement.style.setProperty('--tec-print-legal', JSON.stringify(legal()));
    document.body.setAttribute('data-tec-print', continuous && !session.fallback ? 'continuous' : 'a4');
    document.body.setAttribute('data-tec-print-orientation', direction);
    if (session.fallback) document.body.setAttribute('data-monthly-layout', 'a4');
    if (state.screen !== 'dashboard') {
      var heading = document.getElementById('tec-print-first-header');
      if (!heading) { heading = document.createElement('header'); heading.id = 'tec-print-first-header'; heading.className = 'tec-print-first-header'; heading.setAttribute('dir','rtl'); root.insertBefore(heading,root.firstChild); }
      heading.innerHTML = '<img src="assets/img/tec-red.png" alt="المجلس التنفيذي — The Executive Council"><h1>' + U.esc(title(state)) + ' - لتاريخ <bdi dir="ltr">' + U.esc(U.fmtDate(state.data.today)) + '</bdi></h1>';
    }
    groupPanels();
    measurePrint(session);
    requestAnimationFrame(function () { measurePrint(session); });
  }
  function clear() {
    var session = printSession; printSession = null;
    if (session && session.fallback) {
      if (session.monthlyLayout === null) document.body.removeAttribute('data-monthly-layout');
      else document.body.setAttribute('data-monthly-layout', session.monthlyLayout);
    }
    document.body.removeAttribute('data-tec-print');
    document.body.removeAttribute('data-tec-print-orientation');
    var heading = document.getElementById('tec-print-first-header'); if (heading) heading.remove();
    var css = document.getElementById('tec-print-page-size'); if (css) css.remove();
    document.documentElement.style.removeProperty('--tec-print-legal');
    document.querySelectorAll('.tec-print-panel-pair').forEach(function(pair){pair.replaceWith.apply(pair,Array.from(pair.children));});
    document.querySelectorAll('.tec-print-grouped').forEach(function(grid){grid.classList.remove('tec-print-grouped');});
    document.querySelectorAll('.tec-print-tall-row').forEach(function(row){row.classList.remove('tec-print-tall-row');});
    document.querySelectorAll('.tec-print-tall-card').forEach(function(card){card.classList.remove('tec-print-tall-card');});
  }
  if (window.matchMedia) {
    var printMedia = window.matchMedia('print');
    var mediaChanged = function (event) {
      if (event.matches && printSession) measurePrint(printSession);
    };
    if (printMedia.addEventListener) printMedia.addEventListener('change', mediaChanged);
    else if (printMedia.addListener) printMedia.addListener(mediaChanged);
  }
  if (document.fonts && document.fonts.addEventListener) {
    document.fonts.addEventListener('loadingdone', function () { if (printSession) measurePrint(printSession); });
  }
  if (document.addEventListener) {
    var imageReady = function (event) {
      var session = printSession;
      if (session && session.continuous && !session.fallback && event.target &&
          event.target.tagName === 'IMG' && session.root.contains(event.target)) measurePrint(session);
    };
    // Also catch images completing after media entry or a pending-font recheck.
    document.addEventListener('load', imageReady, true);
    document.addEventListener('error', imageReady, true);
  }
  S.printPagination = { prepare:prepare, clear:clear, measureRows:measureRows, measureContinuous:measureContinuous, orientation:orientation };
})(window.Saytara = window.Saytara || {});
