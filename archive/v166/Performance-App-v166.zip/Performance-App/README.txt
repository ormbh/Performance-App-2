Performance App v166

Extract the complete folder and open index.html. Keep assets and manifest.webmanifest beside it, then select your report workbook. No workbook is included.

Council decisions without an issuing body appear in a full-width box below the named council charts, preserving totals, status bars and the common count scale. Screen and native exports share this structure. The monthly report uses the approved layouts, corrected leadership/TEC classification, counted status bars, shared color legend and scope-preserving report links. Screen and native PDF retain the same figures and status meanings. The clean package includes the app, required fonts/assets and license notices only.

Design principles and verification notes are published separately in the repository docs folder. Readable development source is retained separately in archive/development.
