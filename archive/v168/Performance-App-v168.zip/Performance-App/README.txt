Performance App v168

Extract the complete folder and open index.html. Keep assets and manifest.webmanifest beside it, then select your report workbook. No workbook is included.

The entity report uses matching screen/PDF content, recorded-status charts, scoped tables and readable Arabic. The approved portfolio and other report rules are retained. Native PDF retains A4 portrait and matching source content. Financial values use a common strict numeric reader. The clean package contains runtime files and licenses only.

Design principles, verification notes and illustrative examples are published separately.
