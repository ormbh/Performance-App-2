Performance App v167

Extract the complete folder and open index.html. Keep assets and manifest.webmanifest beside it, then select your report workbook. No workbook is included.

The project portfolio uses the approved full-page layout, shared status colors and legend, count-scaled deadline bars, consistent tables and scoped report links. Native PDF retains A4 portrait and matching source content. Financial values use a common strict numeric reader. The clean package contains runtime files and licenses only.

Design principles, verification notes and illustrative examples are published separately.
