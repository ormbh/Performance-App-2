Performance App v163

Extract the complete folder and open index.html. Keep assets and manifest.webmanifest beside it, then select your report workbook. No workbook is included.

The council decisions report uses issuing-body status charts and the approved six-column table. Decision number, issuing body and meeting date appear above the full latest decision; empty reference fields are omitted. The clean package includes the app, required fonts/assets and license notices only.

Design principles and verification notes are published separately in the repository docs folder. Readable development source is retained separately in archive/development.
