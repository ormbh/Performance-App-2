# Current design standard — Revision 30 / v166

Read DESIGN-PRINCIPLES-v166.md. The approved monthly illustrations and audit corrections are implemented. Retain all prior council/agenda/special-project contracts and PDF glyph compatibility. VERIFICATION-v166.md records actual checks and limits.
