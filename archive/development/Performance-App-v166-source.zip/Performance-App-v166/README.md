# Performance App v166 development source

Approved monthly illustrations and audit corrections: exact special-project cohorts/statuses, valid historical comparisons, counted bars, compact legend, scoped report links and matching native PDFs.

Build with `python3 tools/build-bundles.py`; verify freshness with `--check`. See DESIGN-PRINCIPLES-v166.md and VERIFICATION-v166.md. Clean end-user runtime is published separately as Performance-App-v166.zip. Original fonts and PDF engine remain unchanged.
