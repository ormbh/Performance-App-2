/* Council decisions: source-defined follow-up eligibility and year/quarter groups.
 * Every scoped source decision stays in the main report or its exclusion annex. */
(function (S) {
  'use strict';
  var U = S.util, R = S.rules, O = S.order;
  var COLORS = {'متأخر':'C00000','جاهز للعرض':'115E67','قيد المراجعة':'D9E1E2','قيد التطوير':'D9E1E2','منجز':'01831E','بدون حالة':'FCFBFB'};

  function sourceYear(it) {
    var cell = it.c && it.c.year, text = it.t && it.t.year;
    if (cell && cell.t === 'n' && Number.isInteger(cell.v) && cell.v >= 1900 && cell.v <= 9999) return cell.v;
    if (cell && cell.t === 's' && /^\d{4}$/.test(String(text || '').trim())) {
      var year = Number(text);
      if (year >= 1900 && year <= 9999) return year;
    }
    return null;
  }
  function period(it) {
    var cell = it.c && it.c.meetingDate, year = sourceYear(it);
    if (cell && cell.t === 'n' && U.validDateSerial(cell.v)) {
      var date = U.ymd(cell.v), quarter = Math.ceil(date.m/3);
      return {key:'quarter-'+date.y+'-'+quarter,name:U.quarterLabel(date.y+' Q'+quarter),
        year:date.y,quarter:quarter,month:date.m,day:date.d,basis:'meetingDate',sourceYear:year,mismatch:year != null && year !== date.y};
    }
    if (year != null) return {key:'year-'+year,name:'سنة الاجتماع '+year+' · الربع غير محدد',year:year,quarter:null,month:null,day:null,basis:'year',sourceYear:year,mismatch:false};
    return {key:'undated',name:'تاريخ اجتماع غير محدد',year:null,quarter:null,month:null,day:null,basis:'undated',sourceYear:null,mismatch:false};
  }
  function status(it, data) {
    var cell = it.c && it.c.status;
    if (!cell || cell.t === 'e') return 'بدون حالة';
    var raw = U.xlTrim(cell.t === 's' ? cell.v : String(cell.v),true);
    if (!raw) return 'بدون حالة';
    var known = O.statuses(data,'council').find(function(value){return U.xlTrim(value,true).toLowerCase()===raw.toLowerCase();});
    return known || raw;
  }
  function compare(data, a, b) {
    var ap = period(a), bp = period(b);
    return (ap.year == null ? 1e6 : ap.year)-(bp.year == null ? 1e6 : bp.year) ||
      (ap.month == null ? 13 : ap.month)-(bp.month == null ? 13 : bp.month) ||
      (ap.day == null ? 32 : ap.day)-(bp.day == null ? 32 : bp.day) ||
      O.status(data,status(a,data),status(b,data),'council') ||
      O.compare(data,'Issuers',a.t.issuer || '',b.t.issuer || '') ||
      O.compare(data,'Departments',a.unit || '',b.unit || '') ||
      O.compare(data,'Entities',a.entity || '',b.entity || '') ||
      String(a.t.no || '').localeCompare(String(b.t.no || ''),'ar',{numeric:true}) || a.seq-b.seq;
  }
  function groups(data, items) {
    var map = new Map();
    items.forEach(function(it){
      var p = period(it);
      if (!map.has(p.key)) map.set(p.key,{key:p.key,name:p.name,year:p.year,quarter:p.quarter,basis:p.basis,items:[]});
      map.get(p.key).items.push(it);
    });
    return Array.from(map.values()).sort(function(a,b){return (a.year == null ? 1e6 : a.year)-(b.year == null ? 1e6 : b.year) || (a.quarter == null ? 5 : a.quarter)-(b.quarter == null ? 5 : b.quarter);})
      .map(function(g){g.items.sort(function(a,b){return compare(data,a,b);});return g;});
  }
  function distribution(data, items, name, read) {
    var map = new Map();
    items.forEach(function(it){var label=read(it),key=U.key(label);if(!map.has(key))map.set(key,{name:label || 'غير مسجل',value:label || '',n:0});map.get(key).n++;});
    return Array.from(map.values()).sort(function(a,b){return name==='status'?O.status(data,a.value,b.value,'council'):O.compare(data,name,a.value,b.value);});
  }
  function stats(data, items) { return distribution(data,items,'status',function(it){var label=status(it,data);return label==='بدون حالة'?'':label;}).map(function(x){if(!x.value)x.name='بدون حالة';return x;}); }
  // A presentation specification over the already eligible scope. Issuer and
  // status values are never inferred from another field or merged into TEC.
  function issuerCharts(data, items, statusAvailable) {
    var issuers=new Map(), preferred=['المجلس التنفيذي','مجلس الشؤون الاستراتيجية'];
    var definitions={
      'متأخر':'قرار متأخر وفق مستوى الإنجاز المسجل في المصدر.',
      'جاهز للعرض':'قرار جاهز للعرض وفق مستوى الإنجاز المسجل في المصدر.',
      'قيد المراجعة':'قرار قيد المراجعة؛ يُحتسب ضمن القرارات قيد العمل.',
      'قيد التطوير':'قرار قيد التطوير؛ يُحتسب ضمن القرارات قيد العمل.',
      'منجز':'قرار مكتمل وفق مستوى الإنجاز المسجل في المصدر.',
      'بدون حالة':'لم يسجل مستوى إنجاز للقرار؛ يبقى مشمولاً في الإجمالي.'
    };
    function appearance(name){return {fill:S.ui.chartStatusColor(name),ink:S.ui.chartStatusInk(name),border:S.ui.chartStatusBorder(name),textColor:S.ui.statusTextColor(name)};}
    function issuerRank(value){var index=preferred.findIndex(function(name){return U.key(name)===U.key(value);});return index<0?(value?2:3):index;}
    items.forEach(function(it){var value=U.xlTrim(String(it.t.issuer || ''),true),key=U.key(value);if(!issuers.has(key))issuers.set(key,{key:key || 'missing-issuer',issuer:value,title:value || 'قرارات دون جهة إصدار محددة',items:[]});issuers.get(key).items.push(it);});
    var panels=Array.from(issuers.values()).sort(function(a,b){return issuerRank(a.issuer)-issuerRank(b.issuer) || O.compare(data,'Issuers',a.issuer,b.issuer);}).map(function(panel){
      return {key:panel.key,issuer:panel.issuer,title:panel.title,total:panel.items.length,recordKeys:panel.items.map(function(it){return it.key;}),statuses:statusAvailable?stats(data,panel.items).filter(function(row){return row.n>0;}).map(function(row){return Object.assign({name:row.name,count:row.n,recordKeys:panel.items.filter(function(it){return U.key(status(it,data))===U.key(row.name);}).map(function(it){return it.key;})},appearance(row.name));}):[]};
    });
    var largest=Math.max.apply(null,[0].concat(panels.flatMap(function(panel){return panel.statuses.map(function(row){return row.count;});})));
    var rough=Math.max(1,largest/4),power=Math.pow(10,Math.floor(Math.log10(rough))),step=[1,2,5,10].map(function(n){return n*power;}).find(function(n){return n>=rough;});
    step=Math.max(1,step);var max=Math.max(1,Math.ceil(largest/step)*step),ticks=[];for(var n=0;n<=max;n+=step)ticks.push(n);
    var names=statusAvailable?stats(data,items).map(function(row){return row.name;}):[];
    return {total:items.length,recordKeys:items.map(function(it){return it.key;}),max:max,step:step,ticks:ticks,statusAvailable:statusAvailable,panels:panels,definitions:names.map(function(name){return Object.assign({name:name,text:definitions[name] || 'وفق مستوى الإنجاز المسجل في المصدر؛ تبقى هذه القرارات مشمولة في الإجمالي.'},appearance(name));})};
  }
  function followupValue(it) {
    var cell=it.c && it.c.followup;
    return cell && cell.v!=null?String(cell.v):String(it.t && it.t.followup || '');
  }
  function fieldAvailable(data,field) {
    var metadata=data.meta && data.meta.council;
    return !!(metadata && metadata.found && !(metadata.missing || []).includes(S.schema.PF.council.fields[field].h));
  }
  function scopeRows(data,scope) {
    var source=data.byPf && data.byPf.council || (data.items || []).filter(function(it){return it.pf==='council';});
    var titleAvailable=fieldAvailable(data,'title');
    return source.filter(function(it){return (!titleAvailable || R.present(it,'title')) && R.inScope(it,scope);});
  }
  function followupList(data,rows,includeLov) {
    var order=O.list(data,'FollowUp'),rank=new Map(),values=new Map();
    order.forEach(function(value,index){rank.set(value,index);if(includeLov)values.set(value,{v:value,label:value,n:0});});
    rows.forEach(function(it){var value=followupValue(it);if(!values.has(value))values.set(value,{v:value,label:value.trim()?value:'غير مسجل',n:0});values.get(value).n++;});
    return Array.from(values.values()).sort(function(a,b){
      if(a.v===b.v)return 0;if(a.v==='')return 1;if(b.v==='')return -1;
      var ai=rank.has(a.v)?rank.get(a.v):1e6,bi=rank.has(b.v)?rank.get(b.v):1e6;
      return ai-bi || a.v.localeCompare(b.v,'ar',{numeric:true});
    });
  }
  function followupOptions(data,scope) {
    scope=Object.assign({entityMode:'concerned'},scope || {});
    return fieldAvailable(data,'followup')?followupList(data,scopeRows(data,scope),true):[];
  }
  function replyDate(it) { return it.t.replyDate || 'غير مسجل'; }
  function noteFields(it) { return ['latest','notes','plan','entities','letterRef','letterDate','hasReport'].filter(function(field){return String(it.t[field] || '').trim();}); }
  function model(data, scope, options) {
    scope = Object.assign({entityMode:'concerned'},scope || {}); options = options || {};
    var metadata=data.meta && data.meta.council, available=!!(metadata && metadata.found);
    var titleAvailable=available && !(metadata.missing || []).includes(S.schema.PF.council.fields.title.h);
    var eligibilityAvailable=R.metricAvailable(data,'councilTotal',scope),statusAvailable=R.metricAvailable(data,'councilDone',scope);
    var followupAvailable=fieldAvailable(data,'followup'),followupSelection=U.selection(options.followup),base=scopeRows(data,scope);
    var all = base.filter(function(it){return !followupAvailable || !followupSelection.length || followupSelection.includes(followupValue(it));}).slice().sort(function(a,b){return compare(data,a,b);});
    var items=eligibilityAvailable?all.filter(function(it){return R.test('councilTotal',it);}):[],excluded=eligibilityAvailable?all.filter(function(it){return !R.test('councilTotal',it);}):[],undetermined=eligibilityAvailable?[]:all;
    var count=function(metric){return R.metricAvailable(data,metric,scope)?items.filter(function(it){return R.test(metric,it);}).length:null;};
    var blank=function(rows){return rows.filter(function(it){return !U.key(it.unit);}).length;};
    var missingDate=items.filter(function(it){var c=it.c.meetingDate;return !c || c.t!=='n' || !U.validDateSerial(c.v);});
    var out={all:all,items:items,eligible:items,excluded:excluded,undetermined:undetermined,allTotal:all.length,total:eligibilityAvailable?items.length:null,excludedTotal:eligibilityAvailable?excluded.length:null,
      done:count('councilDone'),progress:count('councilProgress'),late:count('councilLate'),unknownStatus:count('councilNoStatus'),
      statuses:statusAvailable?stats(data,items):[],groups:groups(data,items),excludedGroups:groups(data,excluded),undeterminedGroups:groups(data,undetermined),
      followup:followupAvailable?followupList(data,all,false).map(function(value){return {name:value.label,value:value.v,n:value.n};}):[],
      followupSelection:followupSelection,followupOptions:followupAvailable?followupList(data,base,true):[],followupAvailable:followupAvailable,
      issuers:distribution(data,items,'Issuers',function(it){return it.t.issuer || '';}),
      blankUnitCount:blank(all),eligibleBlankUnitCount:blank(items),excludedBlankUnitCount:blank(excluded),
      missingDateCount:missingDate.length,undated:items.filter(function(it){return period(it).basis==='undated';}),
      dateMismatchCount:all.filter(function(it){return period(it).mismatch;}).length,
      notes:all.filter(function(it){return noteFields(it).length;}),
      available:available,titleAvailable:titleAvailable,eligibilityAvailable:eligibilityAvailable,statusAvailable:statusAvailable,missingColumns:metadata && metadata.missing || [],
      year:data.year,date:U.fmtDate(data.today),period:(S.reportDisplay?S.reportDisplay.clean(options.reportPeriodText,100):options.reportPeriodText) || 'حتى تاريخ '+U.fmtDate(data.today),
      source:data.file && data.file.name || '',scope:{sector:scope.sector || '',unit:scope.unit || '',entity:scope.entity || '',entityMode:'concerned'}};
    out.issuerCharts=issuerCharts(data,items,statusAvailable);
    out.reconciled=statusAvailable?out.done+out.progress+out.late+out.unknownStatus===out.total:null;
    return out;
  }
  function summaryText(m) {
    if (!m.available) return 'جدول قرارات المجالس غير متاح في الملف.';
    if (!m.allTotal) return 'لا توجد قرارات ضمن النطاق المحدد.';
    if (!m.eligibilityAvailable) return 'القرارات المسجلة '+U.metricText(m.allTotal)+'؛ تصنيف متطلبات المتابعة غير متاح بسبب نقص أعمدة المصدر.';
    if (!m.statusAvailable) return 'تتطلب المتابعة '+U.metricText(m.total)+' من أصل '+U.metricText(m.allTotal)+' قراراً؛ مستويات الإنجاز غير متاحة بسبب نقص أعمدة المصدر.';
    return 'تتطلب المتابعة '+U.metricText(m.total)+' من أصل '+U.metricText(m.allTotal)+' قراراً؛ المنجز '+U.metricText(m.done)+
      (m.total?' ('+U.displayNumber(m.done/m.total*100,1,'%')+')':'')+'، وقيد العمل '+U.metricText(m.progress)+'، والمتأخر '+U.metricText(m.late)+'.';
  }
  S.councilReport={model:model,period:period,sourceYear:sourceYear,status:status,compare:compare,groups:groups,stats:stats,issuerCharts:issuerCharts,
    replyDate:replyDate,noteFields:noteFields,followupValue:followupValue,followupOptions:followupOptions,summaryText:summaryText,colors:COLORS};
})(window.Saytara=window.Saytara || {});
