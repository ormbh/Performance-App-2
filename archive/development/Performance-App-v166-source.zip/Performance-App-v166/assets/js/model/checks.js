/*
 * Performance reporting · data checks
 * Flags actionable source issues: invalid controlled values, sector/unit
 * mismatches, unresolved identities and inconsistencies requiring review.
 * Severity: error (structure) · warn (affects the report) · info (worth a look).
 */
(function (S) {
  'use strict';

  var U = S.util, SC = S.schema, R = S.rules;

  function run(data) {
    var out = data.notes.slice();
    var lovs = data.lovs;
    // User-approved organization registry; bounded aliases preserve source tokens.
    function orgKey(field, value) {
      return S.organizationReference ? S.organizationReference.key(field, value) : U.key(value);
    }
    var orgSets = {}, orgParents = new Map();
    var organizationRows = S.organizationReference ? S.organizationReference.rows : lovs.lists.Departments || [];
    [['sector', S.organizationReference ? S.organizationReference.sectors : lovs.lists.Sectors || []],
     ['unit', organizationRows.map(function(row) { return row.value; })]].forEach(function(pair) {
      orgSets[pair[0]] = new Set(pair[1].map(function(value) { return orgKey(pair[0], value); }));
    });
    var parents = new Map();
    organizationRows.forEach(function(row) {
      var unit = orgKey('unit', row.value), sector = orgKey('sector', row.parent);
      if (!unit || !sector) return;
      if (!parents.has(unit)) parents.set(unit, new Map());
      parents.get(unit).set(sector, row.parent);
    });
    parents.forEach(function(values, unit) {
      if (values.size === 1) orgParents.set(unit, Array.from(values.values())[0]);
    });
    function acceptedValue(field, descriptor, cell, value) {
      if (orgSets[field]) return orgSets[field].has(orgKey(field, value));
      var set = lovs.sets[descriptor.lov];
      if (!set || !set.size) return true; // Missing lists are diagnosed by the loader.
      if (descriptor.lov !== 'CompletionPercent') return set.has(U.key(value));
      var numeric = cell.t === 'n' ? cell.v : null;
      if (numeric == null && cell.t === 's') {
        var parsed = numericText(cell.v);
        if (parsed) numeric = parsed.value;
      }
      if (!Number.isFinite(numeric)) return false;
      return (lovs.lists.CompletionPercent || []).some(function(item) {
        var raw = typeof item === 'object' ? item.value : item;
        var parsed = typeof raw === 'number' ? null : numericText(raw);
        var expected = typeof raw === 'number' ? raw : parsed ? parsed.value : NaN;
        return Number.isFinite(expected) && Math.abs(numeric - expected) < 1e-9;
      });
    }

    // Recognition only: never replace or coerce the original source cell.
    function numericText(value) {
      var text = String(value).trim().replace(/^'/, '').replace(/[٠-٩۰-۹]/g, function(digit) {
        var code = digit.charCodeAt(0); return String(code >= 0x6f0 ? code - 0x6f0 : code - 0x660);
      }).replace(/−/g, '-').replace(/٬/g, ',').replace(/٫/g, '.').replace(/٪/g, '%');
      if (/^\(.*\)$/.test(text)) text = '-' + text.slice(1, -1).trim();
      if (!/^[+-]?(?:(?:\d{1,3}(?:[,\s\u00a0]\d{3})+|\d+)(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?\s*%?$/i.test(text)) return null;
      return { value:Number(text.replace(/[,\s\u00a0%]/g, '')) / (/%$/.test(text) ? 100 : 1) };
    }
    function dateRange(cell) {
      if (!cell || cell.t !== 'n' || !U.validDateSerial(cell.v)) return null;
      var day = Math.floor(cell.v);
      if (cell.fmt && cell.fmt.monthYear) {
        var parts = U.ymd(day);
        return { first:U.serial(parts.y, parts.m, 1), last:U.serial(parts.y, parts.m + 1, 1) - 1 };
      }
      return { first:day, last:day };
    }
    function monthRange(month, year) {
      var index = U.monthIndexAr(month), token = String(year == null ? '' : year).trim();
      if (!index || !/^\d{4}$/.test(token)) return null;
      var number = Number(token);
      if (number < 1900 || number > 9999) return null;
      return { first:U.serial(number, index, 1), last:U.serial(number, index + 1, 1) - 1 };
    }

    function push(sev, it, field, problem, value, fix) {
      out.push({
        sev: sev, sheet: it ? it.sheet : '', row: it ? String(it.row) : '', field: field,
        problem: problem, value: value == null ? '' : String(value), fix: fix || '',
        key: it ? it.key : null, pf: it ? it.pf : null
      });
    }

    data.items.forEach(function (it) {
      var spec = SC.PF[it.pf], f = spec.fields, t = it.t, c = it.c;

      if (!it.hasTitle) push('warn', it, f.title.h, 'صف فيه بيانات بدون عنوان', '', 'راجع العنوان مع مسؤول البيانات مع الحفاظ على محتوى الصف');


      Object.keys(f).forEach(function (fk) {
        var fd = f[fk];
        if (c[fk] && c[fk].t === 's' && ['num', 'pct', 'progress', 'year'].indexOf(fd.type) >= 0 && numericText(c[fk].v)) {
          push('warn', it, fd.h, 'قيمة رقمية محفوظة كنص في حقل رقمي', c[fk].v,
            'حوّل الخلية إلى قيمة رقمية فعلية مع الحفاظ على القيمة ووحدة القياس؛ تغيير التنسيق وحده لا يكفي');
        }
        if (!fd.lov || !c[fk] || !it.k[fk]) return;
        // Numeric progress outside its range gets the specific diagnostic below.
        if (fd.lov === 'CompletionPercent' && c[fk].t === 'n' && (c[fk].v < 0 || c[fk].v > 1)) return;
        if (!acceptedValue(fk, fd, c[fk], t[fk])) push('warn', it, fd.h,
          'القيمة خارج قائمة القيم المعتمدة', t[fk], 'اختر قيمة معتمدة من قائمة ' + fd.h);

      });

      if (it.hasTitle && (it.pf === 'secretariat' || it.pf === 'special')) {
        var startRange = it.pf === 'special' ? monthRange(t.startMonth, t.startYear) : dateRange(c.start);
        var endRange = it.pf === 'special' ? monthRange(t.endMonth, t.endYear) : dateRange(c.end);
        if (startRange && endRange && endRange.last < startRange.first) {
          push('warn', it, it.pf === 'special' ? f.endMonth.h : f.end.h, 'تاريخ انتهاء المشروع يسبق تاريخ البدء',
            it.pf === 'special' ? [t.startMonth, t.startYear].join(' ') + ' → ' + [t.endMonth, t.endYear].join(' ') : t.start + ' → ' + t.end,
            'راجع تاريخي البدء والانتهاء مع مسؤول البيانات؛ لم تُعدّل التواريخ أو قيم المصدر');
        }
      }

      if (it.k.unit && it.k.sector && orgParents.has(orgKey('unit', t.unit))) {
        var owner = orgParents.get(orgKey('unit', t.unit));
        if (orgKey('sector', owner) !== orgKey('sector', t.sector)) push('warn', it, f.unit.h, 'القطاع لا يطابق القطاع المعتمد للوحدة التنظيمية: ' + owner, t.sector + ' · ' + t.unit, 'راجع القطاع والوحدة وفق قائمة التنظيم المعتمدة؛ لم تُعدّل قيم المصدر');
      }

      if (c.progress && c.progress.t === 'n' && (c.progress.v < 0 || c.progress.v > 1)) {
        push('warn', it, f.progress.h, 'نسبة الإنجاز خارج المدى 0% إلى 100%', t.progress, 'اختر نسبة من القائمة');
      }

      if (it.pf === 'council' && it.hasTitle && !it.k.followup &&
          (it.k.status || c.progress && c.progress.t === 'n' && c.progress.v > 0 || c.letterDate || c.replyDate)) {
        push('warn', it, f.followup.h, 'متطلبات المتابعة فارغة مع وجود بيانات متابعة للقرار', '',
          'راجع ما إذا كان القرار يتطلب متابعة وحدد القيمة المعتمدة؛ لم يُغيّر نطاق التقرير');
      }
      if (it.pf === 'council' && it.hasTitle && c.year && c.year.t === 'n' && c.meetingDate && c.meetingDate.t === 'n' && U.validDateSerial(c.meetingDate.v)) {
        var meetingYear = U.ymd(c.meetingDate.v).y;
        if (c.year.v !== meetingYear) push('warn', it, f.year.h,
          'سنة الاجتماع لا تطابق سنة تاريخ الاجتماع؛ حُفظت القيمتان كما وردتا في المصدر',
          t.year + ' · ' + t.meetingDate, 'راجع السنة والتاريخ مع مسؤول البيانات؛ لم تُعدّل هوية القرار أو قيم المصدر');
      }

      if (it.pf === 'legislation' && it.hasTitle) {
        if (!it.c.kpi) push('warn', it, f.kpi.h, 'مؤشرات الأداء فارغة، فلا يظهر التشريع في حالات البطاقة', '', 'أدخل «قيد الإجراء» أو «في الموعد»');
        else if (it.x.kpi !== 'قيد الإجراء' && it.x.kpi !== 'في الموعد') {
          var near = it.k.kpi === U.key('قيد الإجراء') || it.k.kpi === U.key('في الموعد');
          push('warn', it, f.kpi.h, near ? 'في القيمة مسافات زائدة، فلا يُحتسب التشريع في حالات البطاقة، كما في ملف Excel' : 'قيمة غير متوقعة، فلا يظهر التشريع في حالات البطاقة', near ? String(it.c.kpi.v) : t.kpi, 'استخدم «قيد الإجراء» أو «في الموعد»');
        }
        if (!c.actual && !c.ext && !c.slc) push('info', it, f.slc.h, 'لا يوجد تاريخ SLC ولا تمديد، فلا يمكن حساب التأخر', '', 'أدخل تاريخ الإنجاز وفق SLC');
        [['slc', c.slc], ['ext', c.ext], ['actual', c.actual], ['deptDate', c.deptDate]].forEach(function (p) {
          if (p[1] && p[1].t === 's') push('warn', it, f[p[0]].h, 'التاريخ مكتوب نصاً، فلا تحتسبه معادلات التأخر', t[p[0]], 'أدخل التاريخ بصيغة تاريخ');
        });
      }

      if (it.pf === 'secretariat' && it.hasTitle) {
        if (c.nonCommitted && c.nonCommitted.t === 'n' && c.nonCommitted.v < 0) push('info', it, f.nonCommitted.h, 'مراجعة مالية: قيمة غير المخصص سالبة؛ قد تكون تسوية أو تجاوزاً للمخصص', t.nonCommitted, 'راجع القيمة مع المالية دون تغيير نطاق التقرير');
        if (!c.end) push('warn', it, f.end.h, 'تاريخ الانتهاء فارغ، فلا يدخل المشروع في الأرباع ولا يُحسب تأخره', '', 'أدخل تاريخ الانتهاء');
        else if (c.end.t === 's' && !it.calc.quarter) push('warn', it, f.end.h, 'تاريخ الانتهاء نص غير مقروء', t.end, 'أدخل التاريخ بصيغة تاريخ');
        if (it.k.status === 'completed' && c.progress && c.progress.t === 'n' && c.progress.v < 1) push('warn', it, f.progress.h, 'الحالة «Completed» ونسبة الإنجاز أقل من 100%', t.progress, 'راجع الحالة ونسبة الإنجاز مع مسؤول البيانات');
      }

      if ((it.pf === 'special' || it.pf === 'council') && it.hasTitle && it.k.status === U.key('منجز') && c.progress && c.progress.t === 'n' && c.progress.v < 1) {
        push('warn', it, f.progress.h, 'مستوى الإنجاز «منجز» ونسبة الإنجاز أقل من 100%', t.progress, 'راجع الحالة ونسبة الإنجاز مع مسؤول البيانات');
      }

      if (it.pf === 'kpi' && it.hasTitle && it.calc.measurementIssue) {
        var measurementProblems = {
          unknownState: 'حالة القياس غير معتمدة أو أعمدتها متعارضة؛ استُبعدت النتيجة من إحصاءات القياس',
          missingMeasuredResult: 'حالة القياس «مقاس» دون نتيجة رقمية صالحة؛ النتيجة غير متاحة ولم تُحوَّل إلى صفر',
          excludedStateWithResult: 'حالة القياس تستبعد المؤشر مع وجود نتيجة غير صفرية؛ حُفظت النتيجة واستُبعدت من إحصاءات القياس'
        };
        push('warn', it, f.measurementState.h, measurementProblems[it.calc.measurementIssue], t.measurementState,
          'راجع حالة القياس والنتيجة مع مسؤول البيانات؛ القيم المعتمدة: مقاس / غير مقاس / لا ينطبق أو Measured / Unmeasured / Not applicable');
      }

      if (it.pf === 'kpi' && it.hasTitle && it.calc.result != null && it.calc.target == null) {
        push('info', it, f.target.h, 'للمؤشر نتيجة وليس له مستهدف', '', 'أدخل المستهدف للعام');
      }
    });

    var d = R.dashboard(data, {}), n = d.n;
    function recon(pf, field, total, sum, fix) {
      var untitled = data.byPf[pf].some(function(it) { return !it.hasTitle; });
      push('warn', null, field, untitled ? 'مجموع الحالات لا يطابق الإجمالي؛ توجد سجلات بدون عنوان، وتختلف شروط احتساب الحالات عن الإجمالي في القالب' : 'مجموع الحالات لا يطابق إجمالي ' + SC.PF[pf].ar, U.fmtN(sum) + ' مقابل ' + U.fmtN(total), untitled ? 'راجع العناوين والحالات وشروط الاحتساب؛ لم تُغيَّر الأرقام أو بيانات المصدر' : fix);
      out[out.length - 1].sheet = data.meta[pf].sheet;
    }
    if (d.missing.agenda) recon('agenda', 'مستوى الإنجاز', n.agendaTotal, n.agendaProgress + n.agendaReady + n.agendaDone + n.agendaLate, 'أكمل مستوى الإنجاز لكل موضوع');
    if (d.missing.council) recon('council', 'مستوى الإنجاز', n.councilTotal, n.councilProgress + n.councilDone + n.councilLate, 'أكمل مستوى الإنجاز للقرارات التي تتطلب متابعة');
    if (d.missing.legislation) recon('legislation', 'مؤشرات الأداء', n.legTotal, n.legProgress + n.legOnTime + n.legOverrun, 'أكمل مؤشرات الأداء لكل تشريع');
    // Dates in another year are valid source values, not missing-data defects.
    var quarterSum = n.secQ1 + n.secQ2 + n.secQ3 + n.secQ4 + n.secNoQuarter;
    if (quarterSum !== n.secTotal) {
      push('warn', null, 'ربع الانتهاء', 'توزيع الأرباع لا يطابق الإجمالي؛ القالب يحتسب الأرباع حسب التاريخ والإجمالي حسب وجود عنوان المشروع', U.fmtN(quarterSum) + ' مقابل ' + U.fmtN(n.secTotal), 'راجع عناوين المشاريع وتواريخ الانتهاء؛ لم تُغيَّر شروط القالب');
      out[out.length - 1].sheet = data.meta.secretariat.sheet;
    }

    var order = { error: 0, warn: 1, info: 2 };
    return out.sort(function (a, b) {
      return order[a.sev] - order[b.sev] || String(a.sheet).localeCompare(String(b.sheet), 'ar') || (parseInt(a.row, 10) || 0) - (parseInt(b.row, 10) || 0);
    });
  }

  S.checks = { run: run };
})(window.Saytara = window.Saytara || {});
