/* Agenda PDF composition. Reuse the rendered source records and chart cells;
 * paginate measured native elements without changing report scope or counts. */
(function (S) {
  'use strict';
  var PX_MM = 96 / 25.4, CONTENT_MM = 182;
  function applies(state) {
    return !!(state && (state.screen === 'agenda' || state.screen === 'reports' && state.report && state.report.kind === 'agenda'));
  }
  function element(doc, tag, name, text) {
    var el = doc.createElement(tag); if (name) el.className = name;
    if (text != null) el.textContent = text; return el;
  }
  function header(state) {
    var display = S.reportDisplay.get(state), entity = S.views.agendaPage.entityText(state), e = S.util.esc;
    return '<img class="ag-pdf-cover-photo" src="assets/img/agenda-cover.jpg" alt=""><div class="ag-pdf-cover-wash" aria-hidden="true"></div>' +
      '<img class="ag-pdf-cover-logos" src="assets/img/agenda-logos.png" alt="حكومة دبي والمجلس التنفيذي">' +
      '<div class="ag-pdf-cover-title"><h1>' + e(display.title) + '</h1>' +
      (entity ? '<p class="ag-pdf-entity">' + e(entity) + '</p>' : '') +
      '<p class="ag-pdf-period">' + e(display.period) + '</p></div>';
  }
  function prepare(artifact, state) {
    if (!applies(state)) return false;
    var root = artifact.root, doc = artifact.document, overview = root.querySelector('.ag-matrix-overview');
    var groups = Array.from(root.querySelectorAll('.ag-table-section')).filter(function (section) { return section.querySelector('.ag-table'); });
    var definitions = root.querySelector('.ag-definitions');
    var editorial = Array.from(root.querySelectorAll('#report-editorial .ag-editorial-section,#agenda-editorial .ag-editorial-section'));
    var contents = S.pdfReportContents.create(artifact);
    var documentRoot = element(doc, 'div', 'ag-pdf-document'); documentRoot.dir = 'rtl';
    var cover = element(doc, 'section', 'ag-pdf-cover'); cover.innerHTML = header(state);
    documentRoot.appendChild(cover);
    if (contents && overview) documentRoot.appendChild(contents);
    var first = element(doc, 'section', 'ag-pdf-first-block');
    first.id = 'report-dashboard';
    if (overview) {
    var chart = overview.cloneNode(true);
    // A PDF carries every quarter at once. Reset the detached chart to its
    // category totals even when the screen currently shows a clicked quarter.
    // Keep those totals below each plot; only interactive affordances disappear.
    S.agendaMatrix.resetDetails(chart);
    Array.from(chart.querySelectorAll('.a-count-disclosure,.a-bar-focus')).forEach(function (el) { el.remove(); });
    Array.from(chart.querySelectorAll('.a-quarter-detail')).forEach(function (el) {
      el.removeAttribute('aria-live'); el.removeAttribute('aria-atomic');
    });
    Array.from(chart.querySelectorAll('.a-quarter-bar')).forEach(function (el) {
      el.removeAttribute('role'); el.removeAttribute('tabindex'); el.removeAttribute('aria-pressed');
    });
    first.appendChild(chart);
    if (definitions) { var copy = definitions.cloneNode(true); copy.classList.add('ag-pdf-intro'); first.appendChild(copy); }
    } else {
      first.appendChild(element(doc, 'p', 'rpt-empty', 'لا توجد بيانات ضمن النطاق المحدد'));
    }
    documentRoot.appendChild(first);
    // Interactive count details stay on screen. The printed report proceeds
    // from its chart/definitions page directly to the original topic tables.
    var expectedKeys = [], assignedCohorts = {};
    groups.forEach(function (source) {
      var group = element(doc, 'section', 'ag-pdf-table-group'), heading = source.querySelector(':scope > .rpt-section-heading');
      var cohort = source.closest('#report-table,#agenda-emerging,#agenda-other');
      if (cohort && !assignedCohorts[cohort.id]) { group.id = cohort.id; assignedCohorts[cohort.id] = true; }
      var cohortHeading = cohort && cohort.querySelector(':scope > .rpt-section-heading');
      if (heading) {
        var titles = element(doc, 'header', 'ag-pdf-group-title');
        if (cohortHeading) { var cohortTitle=cohortHeading.cloneNode(true);cohortTitle.querySelector('h2').classList.add('ag-pdf-cohort-title');titles.appendChild(cohortTitle); }
        var quarterTitle=heading.cloneNode(true);quarterTitle.querySelector('h2').classList.add(cohortHeading?'ag-pdf-quarter-title':'ag-pdf-cohort-title');titles.appendChild(quarterTitle);
        group.appendChild(titles);
      }
      var table = source.querySelector('.ag-table').cloneNode(true);
      table.classList.add('ag-pdf-table');
      Array.from(table.querySelectorAll('tbody tr')).forEach(function (row) { expectedKeys.push(row.dataset.record); });
      group.appendChild(table); documentRoot.appendChild(group);
    });
    if (editorial.length) {
      var tail = element(doc, 'aside', 'ag-pdf-tail rpt-editorial'); tail.id = 'report-editorial';
      editorial.forEach(function (section) { tail.appendChild(section.cloneNode(true)); });
      documentRoot.appendChild(tail);
    }
    root.replaceChildren(documentRoot);
    artifact.agenda = { expectedKeys:expectedKeys, contentHeightMM:CONTENT_MM };
    artifact.report = documentRoot;
    return true;
  }
  function collect(artifact, bounds) {
    if (!artifact.agenda) return null;
    var root = artifact.root, tables = Array.from(root.querySelectorAll('.ag-pdf-table-group')).map(function (group) {
      var table = group.querySelector('table'), heading = group.querySelector('.ag-pdf-group-title');
      return { rect:bounds(group), heading:heading && bounds(heading), head:table.tHead && bounds(table.tHead),
        rows:Array.from(table.tBodies[0].rows).map(function (row) { return { rect:bounds(row), key:row.dataset.record }; }) };
    });
    var contents = root.querySelector('.tec-pdf-contents');
    return { cover:bounds(root.querySelector('.ag-pdf-cover')), contents:contents && bounds(contents), first:bounds(root.querySelector('.ag-pdf-first-block')), tables:tables,
      tails:Array.from(root.querySelectorAll('.ag-pdf-tail')).map(bounds),
      expectedKeys:artifact.agenda.expectedKeys, contentHeightMM:artifact.agenda.contentHeightMM };
  }
  function fit(artifact) {
    if (!artifact.agenda) return;
    var first = artifact.root.querySelector('.ag-pdf-first-block'), capacity = CONTENT_MM * PX_MM;
    if (S.agendaMatrix.setPrintLayout) S.agendaMatrix.setPrintLayout(first, true);
    var cover = artifact.root.querySelector('.ag-pdf-cover'), title = cover.querySelector('.ag-pdf-cover-title');
    function coverOverflows(inset) {
      var textBounds = title.getBoundingClientRect(), coverBounds = cover.getBoundingClientRect(), safe = inset * PX_MM;
      return textBounds.top < coverBounds.top + safe || textBounds.bottom > coverBounds.bottom - safe ||
        textBounds.left < coverBounds.left + safe || textBounds.right > coverBounds.right - safe;
    }
    if (coverOverflows(8)) cover.dataset.agendaSpacing = 'compact';
    if (coverOverflows(4)) throw new Error('يتجاوز نص الغلاف المساحة المتاحة؛ يرجى تقليل طول عنوان التقرير أو الفترة المعروضة.');
    // Keep both chart panels and their definitions on one page. Preserve the
    // approved type sizes; reclaim only whitespace when extra statuses exist.
    if (first.getBoundingClientRect().height > capacity + .5) first.dataset.agendaSpacing = 'compact';
    if (first.getBoundingClientRect().height > capacity + .5) first.dataset.agendaSpacing = 'compact-plus';
    // A third category and extra statuses can wrap the totals to another row.
    // Reclaim a little plot whitespace only for that denser result; all labels
    // retain their physical PDF font sizes in fitQuarterCharts below.
    if (first.getBoundingClientRect().height > capacity + .5) first.dataset.agendaPlot = 'compact';
    fitQuarterCharts(first);
    if (S.agendaMatrix.fitCounts) S.agendaMatrix.fitCounts(first);
  }
  function fitQuarterCharts(first) {
    Array.from(first.querySelectorAll('svg.a-quarter-chart')).forEach(function (svg) {
      var box = svg.getBoundingClientRect(), view = svg.viewBox.baseVal;
      if (!box.width || !box.height || !view.width || !view.height) return;
      // Give the plot its actual panel width without stretching its letters.
      // One, two and three cohorts therefore retain the same physical type
      // sizes. Only the horizontal spacing/bar widths follow the panel width.
      var width = box.width / box.height * view.height, factor = width / view.width;
      Array.from(svg.querySelectorAll('[x],[x1],[x2],[width]')).forEach(function (el) {
        ['x','x1','x2','width'].forEach(function (attribute) {
          if (!el.hasAttribute(attribute)) return;
          var value = Number(el.getAttribute(attribute));
          if (Number.isFinite(value)) el.setAttribute(attribute, String(value * factor));
        });
      });
      svg.setAttribute('viewBox', '0 0 ' + width + ' ' + view.height);
      var matrix = svg.getScreenCTM(), scale = matrix && Math.hypot(matrix.c, matrix.d);
      if (!scale) return;
      [['.a-axis-title,.a-axis-label,.a-quarter-label',9],['.a-quarter-total',16]].forEach(function (role) {
        Array.from(svg.querySelectorAll(role[0])).forEach(function (label) {
          label.style.setProperty('font-size', String(role[1] * 96 / 72 / scale) + 'px', 'important');
        });
      });
      svg.dataset.pdfTypeScale = String(scale);
    });
  }
  function pagePlan(data) {
    var agenda = data.agenda, capacity = agenda.contentHeightMM * PX_MM, gap = 5 * PX_MM;
    var plans = [{regions:[], agenda:true, fullBleed:true, noFooter:true}], page = plans[0], cursor = 0, keys = [];
    function next() { page = {regions:[], agenda:true}; plans.push(page); cursor = 0; }
    function place(rect) { page.regions.push({source:rect,x:rect.x,y:cursor}); cursor += rect.h; }
    function room(height) { if (cursor && cursor + height > capacity + .2) next(); }
    function blocks(rects) {
      rects.forEach(function (rect) {
        room((cursor ? gap : 0) + Math.min(rect.h, capacity));
        if (cursor) cursor += gap;
        if (rect.h > capacity) slice(rect, null); else place(rect);
      });
    }
    function slice(rect, keepHeader) {
      var from = rect.y, end = rect.y + rect.h;
      while (from < end - .1) {
        var available = capacity - cursor, cut = Math.min(end, from + available);
        var crossing = data.lines.filter(function (line) { return line.x < rect.x + rect.w && line.x + line.w > rect.x && line.y < cut - .1 && line.y + line.h > cut + .1; });
        if (crossing.length) cut = Math.min.apply(null, crossing.map(function (line) { return line.y; }));
        if (cut <= from + .5) { next(); if (keepHeader) place(keepHeader); continue; }
        place({x:rect.x,y:from,w:rect.w,h:cut-from}); from = cut;
        if (from < end - .1) { next(); if (keepHeader) place(keepHeader); }
      }
    }
    if (agenda.cover.h > 210 * PX_MM + .5 || agenda.cover.w > 297 * PX_MM + .5) throw new Error('يتجاوز غلاف الأجندة مساحة الصفحة؛ يرجى مراجعة طول عنوان التقرير أو الفترة المعروضة.');
    if (agenda.first.h > capacity + .5) throw new Error('يتجاوز مخطط الأجندة وتعريفاته مساحة الصفحة؛ يرجى مراجعة مستويات الإنجاز في المصدر.');
    page.regions.push({source:agenda.cover,x:0,y:0});
    if (agenda.contents) { next(); blocks([agenda.contents]); }
    next(); place(agenda.first);
    // Cover has no footer; contents is content page one and charts plus
    // definitions are the next atomic page. Record tables follow them.
    if (agenda.tables.some(function (group) { return group.rows.length; })) next();
    agenda.tables.forEach(function (group) {
      if (!group.rows.length) return;
      var head = group.head, firstRow = group.rows[0].rect;
      var start = group.heading ? group.heading.y : head.y;
      var lead = {x:group.rect.x,y:start,w:group.rect.w,h:firstRow.y-start};
      var firstNeed = lead.h + Math.min(firstRow.h, capacity - lead.h);
      room((cursor ? gap : 0) + firstNeed);
      if (cursor) cursor += gap;
      place(lead);
      group.rows.forEach(function (row) {
        if (cursor + row.rect.h > capacity + .2 && row.rect.h <= capacity - (head ? head.h : 0)) { next(); if (head) place(head); }
        if (cursor + row.rect.h > capacity + .2) slice(row.rect, head); else place(row.rect);
        keys.push(row.key);
      });
    });
    blocks(agenda.tails);
    if (JSON.stringify(keys) !== JSON.stringify(agenda.expectedKeys)) throw new Error('تعذّر التحقق من اكتمال صفوف الأجندة في PDF.');
    if (plans.some(function (p) { return p.regions.some(function (r) { return r.y + r.source.h > (p.fullBleed ? 210 * PX_MM : capacity) + .5; }); })) throw new Error('تعذّر ضبط هوامش تقرير الأجندة.');
    plans.forEach(function (p, i) { if (!p.noFooter) { p.footerPage = i; p.footerTotal = plans.length - 1; } });
    return plans;
  }
  S.agendaPrint = {applies:applies, header:header, prepare:prepare, fit:fit, collect:collect, pagePlan:pagePlan};
})(window.Saytara = window.Saytara || {});
