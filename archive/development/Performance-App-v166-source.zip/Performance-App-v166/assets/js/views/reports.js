/* Continuous report pages. One source record = one complete detail card. */
(function(S){
 'use strict';
 var U=S.util,O=S.order,R=S.rules;
 var QUARTERS=['الربع الأول','الربع الثاني','الربع الثالث','الربع الرابع'];
 var TITLES={agenda:'تقرير الأجندة السنوية',hh:'تقرير المشاريع الخاصة',council:'تقرير قرارات المجالس',projects:'تقرير المشاريع'};
 function e(v){return U.esc(v==null?'':String(v));}
 function text(v){return U.presentationText(v);}
 function colour(name){return S.ui.chartStatusColor(name);}
 function hhChartInk(name){return S.ui.chartStatusInk(name);}
 function count(n){return U.metricText(n);}
 function status(it){return it.statusLabel||it.t.status||'غير مسجل';}
 function done(it){return U.key(status(it))===U.key('منجز');}
 function sorted(data,items){return items.slice().sort(function(a,b){return O.items(data,a,b);});}
 function namesFor(data,pf,items){var names=O.statuses(data,pf).slice();if(!names.includes('حالات أخرى')&&items.some(function(it){return !names.includes(status(it));}))names.push('حالات أخرى');return names;}
 function stats(items,names){return names.map(function(name){return {name:name,n:items.filter(function(it){return name==='حالات أخرى'?!names.includes(status(it))||status(it)===name:status(it)===name;}).length};}).filter(function(x){return x.n>0;});}
 // Shared navigation is generated from the sections that are actually rendered.
 function reportLink(id,label,cls){return '<a'+(cls?' class="'+cls+'"':'')+' href="#'+e(id)+'" data-act="report-jump" data-target="'+e(id)+'">'+e(label)+'</a>';}
 function reportReturn(contents){return '<div class="rpt-section-return">'+reportLink(contents,'العودة إلى محتويات التقرير','rpt-return-link')+'</div>';}
 function contentsEntry(x,i){return '<a href="#'+e(x.id)+'" data-act="report-jump" data-target="'+e(x.id)+'"'+(x.id==='report-editorial'?' data-editorial-entry':'')+'><b>'+String(i+1).padStart(2,'0')+'</b><span>'+e(x.label)+'</span>'+(typeof x.count==='number'?'<small>'+e(x.countLabel||'عدد المشاريع')+': '+count(x.count)+'</small>':'')+'</a>';}
 function reportContents(id,entries,cls){return '<nav id="'+e(id)+'" class="rpt-contents tec-report-contents '+(cls||'')+'" aria-label="محتويات التقرير"><h2>محتويات التقرير</h2>'+entries.map(contentsEntry).join('')+'</nav>';}
 // Editorial text can change while a textarea owns focus. Refresh only its
 // navigation entry; never replace the editor or the rest of the page.
 function updateEditorialNavigation(populated){var nav=document.getElementById('report-contents');if(!nav)return;var current=nav.querySelector('[data-editorial-entry]');if(!populated&&current)current.remove();if(populated&&!current)nav.insertAdjacentHTML('beforeend',contentsEntry({id:'report-editorial',label:'ملاحظات وتوصيات'},nav.querySelectorAll('a[data-act="report-jump"]').length));}
 function reportJumps(id,entries){return '<nav id="'+e(id)+'" class="rpt-jumps" aria-label="أقسام التقرير">'+entries.map(function(x){return reportLink(x.id,x.label);}).join('')+'</nav>';}
 S.reportNavigation={link:reportLink,returnLink:reportReturn,contents:reportContents,jumps:reportJumps,updateEditorial:updateEditorialNavigation};
 function empty(message){return '<p class="rpt-empty">'+e(message||'لا توجد بيانات ضمن النطاق المحدد')+'</p>';}
 function pct(n,total){return total?U.displayNumber(n/total*100,1,'%'):'غير متاح';}
 function badge(it){var label=U.presentationText(status(it));return S.ui.statusChip(Object.assign({},it,{statusLabel:label,statusCat:it.statusCat||R.catOf(label)}));}
 function progress(it){return it.progress==null?'':U.displayNumber(it.progress,1,'%');}
 function start(it){return it.pf==='special'?[it.t.startMonth,it.t.startYear].filter(Boolean).join(' '):U.monthLabel(it.t.start);}
 function end(it){return it.pf==='special'?[it.t.endMonth,it.t.endYear].filter(Boolean).join(' '):it.pf==='agenda'?S.agendaReport.originalDeadline(it):U.monthLabel(it.t.end);}
 function scope(state){return [U.selectionText(state.dash.sector,undefined,'d:sector'),U.selectionText(state.dash.unit,undefined,'d:unit'),U.hasSelection(state.dash.entity)?'الجهة المعنية: '+U.selectionText(state.dash.entity):''].filter(Boolean).join(' · ');}
 function field(label,v,cls){return '<div class="rpt-field '+(cls||'')+'"><h3>'+e(label)+'</h3><p>'+e(text(v))+'</p></div>';}
 function metrics(values){return '<dl class="rpt-metrics">'+values.map(function(v){return '<div'+(v[2]?' class="'+v[2]+'"':'')+'><dt>'+e(v[0])+'</dt><dd>'+e(v[1])+'</dd></div>';}).join('')+'</dl>';}
 function heading(title,note){return '<div class="rpt-section-heading"><h2>'+e(title)+'</h2>'+(note?'<span class="rpt-heading-count">'+e(note)+'</span>':'')+'</div>';}
 // Filter before constructing any bar, slot, label or key. An all-zero series is an empty state.
 function barChart(values,title,note,accent){
  values=values.filter(function(x){return x.n>0;});var max=Math.max(1,...values.map(function(x){return x.n;}));
  return '<figure class="rpt-chart-panel"><figcaption><h2>'+e(title)+'</h2></figcaption>'+(values.length?'<div class="rpt-bars">'+values.map(function(x){return '<div class="rpt-bar-row" data-label="'+e(x.name)+'" data-value="'+x.n+'" style="color:'+S.ui.statusTextColor(x.name)+'"><span class="rpt-bar-label">'+e(x.name)+'</span><div class="rpt-bar-track"><span class="rpt-bar" style="width:'+x.n/max*100+'%;background:'+(accent||colour(x.name))+(accent?'':';border:1px solid '+S.ui.chartStatusBorder(x.name))+'" role="img" aria-label="'+e(x.name+': '+x.n)+'"></span></div><strong>'+count(x.n)+'</strong></div>';}).join('')+'</div>':empty('لا توجد بيانات لعرض الرسم'))+'</figure>';
 }
 function itemQuarter(it,year){return it.pf==='secretariat'?(/^Q[1-4]$/.test(it.calc.quarter)?Number(it.calc.quarter.slice(1)):0):S.agendaReport.quarter(it,year);}
 function quarterChart(state,items,names){
  var groups=QUARTERS.map(function(name,i){return {name:name,items:items.filter(function(it){return itemQuarter(it,state.data.year)===i+1;})};}).sort(function(a,b){return O.compare(state.data,'Quarters',a.name,b.name);});
  groups.push({name:'خارج سنة التقرير / غير مؤرخ',items:items.filter(function(it){return itemQuarter(it,state.data.year)===0;})});
  groups=groups.filter(function(g){return g.items.length;});
  var max=Math.max(1,...groups.flatMap(function(g){return stats(g.items,names).map(function(x){return x.n;});}));
  return '<figure class="rpt-chart-panel rpt-quarter-panel"><figcaption><h2>توزيع '+(state.report.kind==='projects'?'المشاريع':'المواضيع')+' حسب الربع ومستوى الإنجاز</h2><p>'+state.data.year+'</p></figcaption>'+(groups.length?'<div class="rpt-quarter-grid">'+groups.map(function(g){return '<section class="rpt-quartile" data-label="'+e(g.name)+'"><h3>'+e(g.name)+' <span>'+count(g.items.length)+'</span></h3><div class="rpt-bars">'+stats(g.items,names).map(function(x){return '<div class="rpt-bar-row" data-label="'+e(x.name)+'" data-value="'+x.n+'" style="color:'+S.ui.statusTextColor(x.name)+'"><span class="rpt-bar-label">'+e(x.name)+'</span><div class="rpt-bar-track"><span class="rpt-bar" role="img" aria-label="'+e(g.name+'، '+x.name+': '+x.n)+'" style="width:'+x.n/max*100+'%;background:'+colour(x.name)+';border:1px solid '+S.ui.chartStatusBorder(x.name)+'"></span></div><strong>'+count(x.n)+'</strong></div>';}).join('')+'</div></section>';}).join('')+'</div>':empty('لا توجد '+(state.report.kind==='projects'?'مشاريع':'مواضيع')+' بمواعيد ضمن أرباع سنة التقرير'))+'</figure>';
 }
 function definitions(state){var defs=S.agendaReport.definitions;return '<section class="rpt-definitions"><h2>تعريفات مستويات الإنجاز</h2><dl>'+O.statuses(state.data,'agenda').filter(function(name){return defs[name];}).map(function(name){return '<div><dt>'+e(name)+'</dt><dd>'+e(defs[name])+'</dd></div>';}).join('')+'</dl></section>';}
 function sectorChart(state,items){var sectors=[...new Set(items.map(function(it){return it.sector||'غير مسجل';}))].sort(function(a,b){return O.compare(state.data,'Sectors',a,b);});return barChart(sectors.map(function(s){return {name:s,n:items.filter(function(it){return (it.sector||'غير مسجل')===s;}).length};}),'توزيع المشاريع حسب القطاع','القطاعات وفق ترتيب ملف المتابعة','#115E67');}
 // HH ordering is status LOV first, then the recorded end date, undated last.
 function hhDate(it){var t=it.t||{},m=U.monthIndexAr(t.endMonth),y=Number(t.endYear);return m&&Number.isInteger(y)&&y>=1900&&y<=9999?Date.UTC(y,m,0):Infinity;}
 function hhCompare(data,a,b){var c=O.status(data,status(a),status(b),'special');if(c)return c;var da=hhDate(a),db=hhDate(b);return (da===db?0:da<db?-1:1)||(a.seq||0)-(b.seq||0)||String(a.key).localeCompare(String(b.key));}
 function projectCompare(data,a,b){var c=O.status(data,status(a),status(b),'secretariat');if(c)return c;var da=Number.isFinite(a.dateSort)&&a.dateSort>0&&a.dateSort<2958466?a.dateSort:Infinity,db=Number.isFinite(b.dateSort)&&b.dateSort>0&&b.dateSort<2958466?b.dateSort:Infinity;return (da===db?0:da<db?-1:1)||(a.seq||0)-(b.seq||0)||String(a.key).localeCompare(String(b.key));}
 function hhLeadMatches(it,selection){var selected=U.selection(S.ui.reportLeadSelection(selection));return !selected.length||selected.some(function(v){var key=U.key(v),record=U.key((it.t||{}).lead);return key===U.key('لا')?record!==U.key('نعم'):key===record;});}
 function hhModel(state){var items=state.data.items.filter(function(it){return it.pf==='special'&&it.title&&R.inScope(it,state.dash)&&hhLeadMatches(it,state.report.lead);}).sort(function(a,b){return hhCompare(state.data,a,b);}),completed=items.filter(done),open=items.filter(function(it){return !done(it);});return {items:open.concat(completed),done:completed,open:open,names:namesFor(state.data,'special',items)};}
 function hhInProgress(it){return ['قيد المراجعة','قيد التطوير','قيد العمل','جاري العمل','قيد التنفيذ','متأخر','active'].map(U.key).includes(U.key(status(it)));}
 function hhSummary(state,m){
  var lead=m.items.filter(function(it){return U.key(it.t.lead)===U.key('نعم');}),names=m.names.filter(function(n){return m.items.some(function(it){return n==='حالات أخرى'?!m.names.includes(status(it))||status(it)===n:status(it)===n;});});
  function stat(items,n){return items.filter(function(it){return n==='حالات أخرى'?!m.names.includes(status(it))||status(it)===n:status(it)===n;}).length;}
  var sectors=[...new Set(m.items.map(function(it){return it.sector||'غير متوفر';}))].sort(function(a,b){return O.compare(state.data,'Sectors',a,b);});
  // Inclusion in this year's portfolio is distinct from project start date. No inclusion field exists in the supplied schema.
  return {inProgress:m.items.filter(hhInProgress).length,leadInProgress:lead.filter(hhInProgress).length,otherOpen:m.open.filter(function(it){return !hhInProgress(it);}).length,leadOtherOpen:lead.filter(function(it){return !done(it)&&!hhInProgress(it);}).length,leadOnly:m.items.length>0&&lead.length===m.items.length,total:m.items.length,lead:lead.length,done:m.done.length,leadDone:lead.filter(done).length,remaining:m.open.length,leadRemaining:lead.filter(function(it){return !done(it);}).length,added:null,leadAdded:null,names:names,statuses:names.map(function(n){return {name:n,total:stat(m.items,n),lead:stat(lead,n)};}),sectors:sectors.map(function(sector){var its=m.items.filter(function(it){return (it.sector||'غير متوفر')===sector;});return {name:sector,values:names.map(function(n){return stat(its,n);})};})};
 }
 function model(state){
  if(state.report.kind==='hh')return hhModel(state);
  var items;if(state.report.kind==='council'&&S.views.councilPage)return S.views.councilPage.render(state);
  if(state.report.kind==='projects'&&S.projectsReport)return S.projectsReport.model(state);
  if(state.report.kind==='projects')items=state.data.items.filter(function(it){return it.pf==='secretariat'&&R.MET.secTotal.test(it)&&R.inScope(it,state.dash);});
  else{items=S.agendaReport.model(state.data,state.dash).items;if(U.hasSelection(state.report.type))items=items.filter(function(it){return U.selected(it.t.type,state.report.type);});}
  items=state.report.kind==='projects'?items.sort(function(a,b){return projectCompare(state.data,a,b);}):sorted(state.data,items);return {items:items,done:items.filter(done),names:namesFor(state.data,state.report.kind==='projects'?'secretariat':'agenda',items)};
 }
 function dashboard(state,m){
  var kind=state.report.kind,agenda=kind==='agenda',total=m.items.length,late=m.items.filter(function(it){return kind==='projects'?R.MET.secLate.test(it):U.key(status(it))===U.key('متأخر');}).length;
  var body=metrics([[agenda?'إجمالي المواضيع':'إجمالي المشاريع',count(total)],['منجز',count(m.done.length),'rpt-metric-done'],['متأخر',count(late),'rpt-metric-late'],['نسبة المنجز',pct(m.done.length,total)]]);
  if(agenda){var am=S.agendaReport.model(state.data,state.dash),types=[...new Set(am.items.map(function(it){return it.t.type||'غير مصنف';}))].sort(function(a,b){return O.compare(state.data,'TopicTypes',a,b);});body+='<div class="rpt-type-overview"><span>الأجندة ضمن النطاق</span>'+types.map(function(t){return '<span>'+e(t)+' <b>'+count(am.items.filter(function(it){return (it.t.type||'غير مصنف')===t;}).length)+'</b></span>';}).join('')+'</div>';}
  body+=agenda?quarterChart(state,m.items,m.names)+definitions(state):'<div class="rpt-chart-grid">'+barChart(stats(m.items,m.names),'مستوى الإنجاز')+(kind==='hh'?sectorChart(state,m.items):quarterChart(state,m.items,m.names))+'</div>';
  if(kind==='projects'){var b=R.dashboard(state.data,state.dash).budget;body+='<section class="rpt-budget">'+heading('الموازنة','درهم إماراتي')+metrics([['الموازنة المعتمدة',count(b.approved)],['المخصص',count(b.allocated)],['غير المخصص',count(b.unallocated)],['المنفق',count(b.spent)]])+'</section>';}
  return '<section id="report-dashboard" class="rpt-dashboard">'+heading('الملخص التنفيذي')+reportReturn('report-contents')+body+'</section>';
 }
 function table(state,m,options){
  options=options||{};
  var agenda=state.report.kind==='agenda',hh=state.report.kind==='hh';
  var head=hh?['م',S.ui.contentHeader(m.items,'special'),'الجهة المعنية','الحالة','نسبة الإنجاز','موعد الإنجاز']:['م',S.ui.contentHeader(m.items,agenda?'agenda':'secretariat'),agenda?'النوع':'القطاع',agenda?'الجهة المعنية':'مدير المشروع','الحالة',agenda?'موعد الإنجاز الأصلي والمحدّث':'نسبة الإنجاز',agenda?'القطاع':'تاريخ الانتهاء'];
  var widths=hh?[4,33,23,14,11,15]:[4,30,15,16,13,10,12];
  function cellAttributes(index,role){return hh?' class="rpt-record-'+role+'" data-report-label="'+e(head[index])+'"':'';}
  return '<section id="'+(options.id||'report-table')+'" class="rpt-table-section">'+heading(options.title||(agenda?'جدول المواضيع':'جدول المشاريع'),S.terms.count(m.items.length,agenda?'agenda':hh?'special':'secretariat'))+reportReturn('report-contents')+(m.items.length?'<div class="rpt-table-scroll" role="region" tabindex="0" aria-label="'+e(options.title||(agenda?'جدول المواضيع':'جدول المشاريع'))+'"><table class="rpt-table'+(hh?' hh-project-table':'')+'"><colgroup>'+widths.map(function(width){return '<col style="width:'+width+'%">';}).join('')+'</colgroup><thead><tr>'+head.map(function(h){return '<th scope="col">'+h+'</th>';}).join('')+'</tr></thead><tbody>'+m.items.map(function(it,i){return '<tr id="record-'+e(it.key)+'" data-record="'+e(it.key)+'" data-report-number="'+(i+1)+'"><td'+cellAttributes(0,'number')+'>'+count(i+1)+'</td><th scope="row"'+cellAttributes(1,'title')+' data-label="'+e(S.ui.contentLabel(it))+'" data-content-label="'+e(S.ui.contentLabel(it))+'">'+(state.report.kind==='projects'?e(it.title):'<a href="#topic-'+e(it.key)+'" class="rpt-topic-link" data-act="report-jump" data-target="topic-'+e(it.key)+'">'+e(it.title)+U.icon('left',15)+'</a>')+'</th><td'+cellAttributes(2,'entity')+'>'+e(U.tableCellText(agenda?it.t.type:hh?it.entity:it.sector))+'</td>'+(hh?'':'<td>'+e(U.tableCellText(agenda?it.entity:it.coord||it.t.pm))+'</td>')+'<td'+cellAttributes(3,'status')+'>'+badge(it)+'</td><td'+cellAttributes(4,'progress')+'>'+(agenda?e(S.agendaReport.deadline(it)):hh?(progressValue(it).valid?progressMarkup(it):''):it.progress==null?'':e(progress(it)))+'</td><td'+cellAttributes(5,'date')+'>'+e(U.tableCellText(agenda?it.sector:end(it)))+'</td></tr>';}).join('')+'</tbody></table></div>':empty())+'</section>';
 }
 function optional(it,label){var found=(it.all||[]).find(function(f){return U.key(f.label)===U.key(label);});return found&&found.value;}
 function progressValue(it){var p=it.progress,valid=typeof p==='number'&&Number.isFinite(p)&&p>=0&&p<=100;return {valid:valid,label:valid?U.displayNumber(p,1,'%'):''};}
 function progressMarkup(it){var h=progressValue(it);return h.valid?'<span class="recorded-progress" aria-label="نسبة الإنجاز '+e(U.fmtNum(it.progress,1)+'%')+'"><bdi>'+e(h.label)+'</bdi></span>':'';}
 function statusField(it){
  if(it.pf!=='special')return '<div class="rpt-field rpt-status-field"><h3>الحالة والإنجاز</h3><div class="rpt-status-progress">'+badge(it)+progressMarkup(it)+'</div></div>';
  var h=progressValue(it),numeric=h.valid?'<div class="hh-progress-value" aria-label="نسبة إنجاز المشروع المسجلة '+e(U.fmtNum(it.progress,1)+'%')+'"><bdi>'+e(h.label)+'</bdi><span>نسبة الإنجاز</span></div>':'';
  return '<div class="rpt-field rpt-status-field hh-project-progress"><h3><span>الحالة</span>'+badge(it)+'</h3><div class="rpt-status-progress">'+numeric+'</div></div>';
 }
 function titleField(it){return '<div class="rpt-field rpt-title-field'+(it.title.length>85?' is-long-title':it.title.length>45?' is-medium-title':'')+'"><h3>'+e(S.ui.contentLabel(it))+'</h3><p>'+e(text(it.title))+'</p></div>';}
 // HH follows HH_v4 field-by-field; absent required values remain explicit.
 function hhBullets(value){var str=value==null?'':String(value).trim();if(!str)str='غير متوفر';return '<ul class="hh-info-bullets">'+str.split(/\r?\n/).filter(function(x){return x.trim();}).map(function(x){return '<li>'+e(x.trim())+'</li>';}).join('')+'</ul>';}
 function hhOptional(label,value,cls){var narrative=['المنجز للآن','ملاحظات إضافية','توصيات الأمانة العامة','المخطط في المرحلة المقبلة'].includes(label);return narrative?'<div class="rpt-field '+(cls||'')+'"><h3>'+e(label)+'</h3>'+hhBullets(value)+'</div>':field(label,value!=null&&String(value).trim()?value:'غير متوفر',cls);}

 function hhRecommendations(it){return hhOptional('توصيات الأمانة العامة',it.t.recs||'غير متوفر','rpt-recommendation rpt-horizontal');}
 function hhRoadmap(it){
  return '<section class="hh-roadmap" aria-label="خارطة الطريق"><h3>خارطة الطريق – المخطط في المرحلة المقبلة</h3><div class="hh-roadmap-line"><div class="hh-endpoint"><b>البدء</b><span>'+e(start(it)||'غير متوفر')+'</span></div><div class="hh-next">'+hhBullets(it.t.next)+'</div><div class="hh-endpoint"><b>الانتهاء</b><span>'+e(end(it)||'غير متوفر')+'</span></div></div></section>';
 }
 // One source-driven card for both recorded completion states. Empty optional
 // fields disappear; zero values and populated follow-up are never discarded.
 function hhHas(v){return v!=null&&String(v).replace(/[\u200B\uFEFF]/g,'').trim()!==''&&!['غير مسجل','غير مسجلة','غير متوفر','غير متوفرة'].includes(String(v).trim());}
 function hhUnifiedField(label,v,key,cls,bullets){
  if(!hhHas(v))return '';
  return '<section class="hh-unified-field '+(cls||'')+'" data-source-field="'+e(key)+'"><h3>'+e(label)+'</h3>'+(bullets?hhBullets(v):'<p>'+e(typeof v==='number'?U.displayNumber(v,1):v)+'</p>')+'</section>';
 }
 function hhUnifiedProgress(it){
  var h=progressValue(it);
  return h.valid?'<div class="hh-unified-progress" data-source-field="progress"><bdi class="hh-progress-number" aria-label="نسبة إنجاز المشروع المسجلة '+e(U.fmtNum(it.progress,1)+'%')+'">'+e(h.label)+'</bdi><span>نسبة الإنجاز المسجلة</span></div>':'';
 }
 function specialCard(it){
  var t=it.t||{},completed=done(it),primary=hhUnifiedField('مدير المشروع',t.pm||it.coord||'غير متوفر','pm')+hhUnifiedField('البدء',start(it)||'غير متوفر','startMonth startYear')+hhUnifiedField('الانتهاء',end(it)||'غير متوفر','endMonth endYear');
  var outcomes=hhUnifiedField('ما تم إنجازه',t.achieved,'achieved','hh-unified-achieved',true)+hhUnifiedField(completed?'المتابعة بعد الإنجاز':'المخطط في المرحلة المقبلة',t.next,'next','hh-unified-next',true);
  var context=hhUnifiedField('ملاحظات مدير المشروع',t.notes,'notes','',true)+hhUnifiedField('نبذة حول المشروع',t.desc,'desc');
  var extra=hhUnifiedField('القطاع',it.sector,'sector')+hhUnifiedField('الجهات المساهمة',t.entities,'entities','',true)+hhUnifiedField('الإدارة',t.unit,'unit')+hhUnifiedField('إدارات مساهمة',t.units,'units','',true)+hhUnifiedField('الميزانية المخصصة إن وجدت',t.budget,'budget');
  var covered=['lead','pm','title','desc','entity','entities','sector','unit','units','startMonth','startYear','endMonth','endYear','status','progress','budget','achieved','next','notes','recs','sourceName'];
  (it.all||[]).filter(function(f){return !f.calc&&f.label!=='Source.Name'&&(!f.field||!covered.includes(f.field))&&hhHas(f.value);}).forEach(function(f){extra+=hhUnifiedField(f.label,f.value,f.field||f.label);});
  return '<div class="hh-unified-card" data-card-layout="option-1" data-recorded-completion="'+(completed?'done':'open')+'"><div class="hh-unified-header"><div class="hh-unified-identity"><h3 data-source-field="title">'+e(text(it.title))+'</h3>'+(U.key(t.lead)===U.key('نعم')?'<span class="hh-lead-badge" data-source-field="lead">مشاريع القيادة</span>':'')+(hhHas(t.entity||it.entity)?'<p class="hh-unified-entity" data-source-field="entity">'+e(t.entity||it.entity)+'</p>':'')+'</div><div class="hh-unified-status" data-source-field="status">'+badge(it)+'</div>'+hhUnifiedProgress(it)+'</div><div class="hh-unified-meta">'+primary+'</div><div class="hh-unified-body">'+(outcomes?'<div class="hh-unified-outcomes">'+outcomes+'</div>':'')+hhUnifiedField('توصيات إدارة الأداء والتنفيذ',t.recs,'recs','hh-unified-recommendation',true)+(context?'<div class="hh-unified-context">'+context+'</div>':'')+(extra?'<div class="hh-unified-additional">'+extra+'</div>':'')+'</div></div>';
 }

 function hhReturn(){return reportLink('report-contents','العودة إلى محتويات التقرير','hh-return-link rpt-return-link');}
 function hhContents(state,m){var entries=[{id:'hh-summary',label:'الملخص التنفيذي',count:m.items.length},{id:'report-table',label:'القائمة الرئيسية للمشاريع',count:m.items.length}];if(m.open.length)entries.push({id:'hh-followup',label:'المستجدات التفصيلية للمشاريع قيد المتابعة',count:m.open.length});if(m.done.length)entries.push({id:'hh-completed',label:'المستجدات التفصيلية للمشاريع المنجزة',count:m.done.length});var o=S.reportEditorial.options(state);if(o.notes.trim()||o.recommendations.trim())entries.push({id:'report-editorial',label:'ملاحظات وتوصيات'});return reportContents('report-contents',entries,'hh-contents');}
 function hhAppendix(state,items,completed,offset){
  if(!items.length)return '';
  var id=completed?'hh-completed':'hh-followup',title=completed?'المستجدات التفصيلية للمشاريع المنجزة':'المستجدات التفصيلية للمشاريع قيد المتابعة';
  return '<section id="'+id+'" class="hh-appendix">'+heading(title,S.terms.count(items.length,'special'))+'<div class="hh-section-return rpt-section-return">'+hhReturn()+'</div>'+items.map(function(it,i){var number=(offset||0)+i+1;return '<article id="topic-'+e(it.key)+'" class="rpt-topic '+(completed?'rpt-completed':'rpt-ongoing')+'" data-project="'+e(it.key)+'" data-report-number="'+number+'"><div class="rpt-card-body">'+specialCard(it)+'</div><footer class="hh-card-nav">'+hhReturn()+reportLink('record-'+it.key,'العودة إلى المشروع في القائمة الرئيسية')+'</footer></article>';}).join('')+'</section>';
 }
 function hhCompact(state,key,id){var value=key==='lead'?S.ui.reportLeadSelection(state.report.lead):state.dash[key];return S.filterOptions.compactText(value,(state.multiOptions||{})[id]||[],'الكل',id);}
 function hhEntityText(state){var value=hhCompact(state,'entity','d:entity');return value==='الكل'?'':value;}
 function hhFilters(state,m){
  var lead=S.ui.multiSelect(state,'r:lead','جهة الطلب',state.report.lead,[{v:'نعم',label:'القيادة'},{v:'لا',label:'الأمانة العامة'}].concat(U.selection(state.report.lead).some(function(v){return !U.key(v);})?[{v:'',label:''}]:[]));
  var controls=S.ui.reportFilterControls(state,R.dashboard(state.data,state.dash,S.comparison&&S.comparison.dashboardHistory?S.comparison.dashboardHistory(state):null),lead),defs=[['sector','d:sector','القطاع'],['unit','d:unit','الوحدة التنظيمية'],['entity','d:entity','الجهة المعنية'],['lead','r:lead','جهة الطلب']],host=document.createElement('div');host.innerHTML=controls;
  var fields=defs.map(function(d){var field=host.querySelector('[data-multi-wrap="'+d[1]+'"]');if(!field)return '';var b=field.querySelector('.multi-trigger>b');if(b)b.textContent=hhCompact(state,d[0],d[1]);return field.outerHTML;}).join('');
  var selected=defs.filter(function(d){return hhCompact(state,d[0],d[1])!=='الكل';}).map(function(d){return d[2]+': '+hhCompact(state,d[0],d[1]);}),open=!!(state.filterPanels&&state.filterPanels['report-scope']);
  return '<section class="tec-workspace-filters hh-report-filters'+(open?' is-open':'')+'" data-filter-panel="report-scope" aria-label="نطاق تقرير المشاريع الخاصة"><div class="tec-core-filter-fields" id="hh-filter-fields"'+(open?'':' hidden')+'>'+fields+'</div><div class="tec-filter-summary-row"><p class="tec-filter-scope" role="status"><span>النطاق: </span><bdi dir="auto">'+e(selected.join(' · ')||'الكل')+'</bdi><span class="hh-scope-count"> · '+S.terms.count(m.items.length,'special')+'</span></p><div class="tec-filter-tools"><button class="tec-text-action hh-filter-toggle" type="button" data-act="toggle-filters" data-filter-panel="report-scope" aria-controls="hh-filter-fields" aria-expanded="'+open+'"><span class="hh-filter-closed-label">تصفية</span><span class="hh-filter-open-label">إغلاق التصفية</span>'+U.icon('down',20)+'</button>'+(selected.length?'<button type="button" class="tec-text-action ui-filter-reset" data-act="reset-report-filters">مسح التصفية</button>':'')+'</div></div></section>';
 }
 function hhEditor(state){var host=document.createElement('div');host.innerHTML=S.reportEditorial.editor(state);var fields=host.querySelector('.ag-editor-fields');return '<details class="ag-editor hh-editor"><summary>إعداد التقرير</summary>'+S.reportDisplay.controls(state)+(fields?fields.outerHTML:'')+'</details>';}
 function hhWorkspace(state,m){
  var filters=hhFilters(state,m),display=S.reportDisplay.get(state),entity=hhEntityText(state),masthead='<div class="wb-reference-title tec-page-title"><h1 data-report-title>'+e(display.title)+'</h1>'+(entity?'<p class="hh-report-entity"><bdi dir="auto">'+e(entity)+'</bdi></p>':'')+'<p class="wb-reference-context" data-report-period-label>'+e(display.period)+'</p></div>';
  return '<div class="screen reports hh-report" data-screen="reports">'+S.ui.appHeader(state,'reports',{masthead:masthead})+'<main class="rpt-main hh-main">'+filters+'<div class="tec-report-navigation'+(m.items.length?'':' is-empty')+'">'+(m.items.length?hhContents(state,m):'')+'<div class="hh-report-utilities app-screen-only">'+hhEditor(state)+'</div></div>'+hhBody(state,m)+'</main></div>';
 }
 function hhCover(state){var entity=hhEntityText(state);return '<section id="hh-cover" class="ag-cover ag-page hh-cover" data-report-long="'+(S.reportDisplay.long(state)?'true':'false')+'"><div class="hh-section-return hh-cover-return rpt-cover-return">'+hhReturn()+'</div><img class="ag-cover-logos" src="assets/img/agenda-logos.png" alt="حكومة دبي والمجلس التنفيذي"><div class="ag-cover-title"><h1 data-report-title>'+e(S.reportDisplay.get(state).title)+'</h1>'+(entity?'<p class="hh-report-entity"><bdi dir="auto">'+e(entity)+'</bdi></p>':'')+'<p data-report-period-label>'+e(S.reportDisplay.get(state).period)+'</p></div></section>';}
 function hhCompletion(n,total,label){return '<div class="hh-completion"><div class="hh-completion-copy"><span>'+e(label)+'</span><small>'+count(n)+' من أصل '+count(total)+' مشروعًا</small></div><bdi>'+pct(n,total)+'</bdi></div>';}
 function hhMetrics(d){var out=[['إجمالي المشاريع الخاصة',d.total,'total']];if(!d.leadOnly&&d.lead>0)out.push(['منها مشاريع للقيادة',d.lead,'lead']);out.push(['المشاريع المنجزة',d.done,'done'],['المشاريع قيد العمل',d.inProgress,'open']);if(d.otherOpen)out.push(['حالات أخرى غير منجزة',d.otherOpen,'other']);return out;}
 function hhDashboard(state,m){
  var d=hhSummary(state,m);
  return '<section id="report-dashboard" class="hh-summary-dashboard hh-r3-summary" data-lead-only="'+d.leadOnly+'"><div class="hh-screen-summary">'+S.hhCharts.render(state,m)+'</div></section>';
 }
 // A source-driven vector print composition, not a screenshot or scale-to-fit page.
 // Six ordinary sector rows form one landscape page; additional sectors continue.
 function hhPrintSummary(state,d){
  var max=Math.max(1,...d.sectors.map(function(g){return g.values.reduce(function(a,b){return a+b;},0);})),metric=hhMetrics(d),period=S.reportDisplay.get(state).period;
  function wrap(str,n){var lines=[],line='';String(str).split(/\s+/).forEach(function(word){while(word.length>n){if(line){lines.push(line);line='';}lines.push(word.slice(0,n));word=word.slice(n);}if((line+' '+word).trim().length>n){lines.push(line);line=word;}else line=(line+' '+word).trim();});if(line)lines.push(line);return lines;}
  var groups=[],current=[],height=0;d.sectors.forEach(function(g){var h=Math.max(60,wrap(g.name,34).length*27+18);if(current.length&&(current.length===6||height+h>404)){groups.push(current);current=[];height=0;}current.push({g:g,h:h});height+=h;});if(current.length||!groups.length)groups.push(current);
  return '<div class="hh-print-summary" aria-hidden="true">'+groups.map(function(rows,page){
   var out=[];
   function rect(x,y,w,h,c,options){
    options=options||{};out.push('<rect x="'+x+'" y="'+y+'" width="'+w+'" height="'+h+'" fill="'+c+'" data-summary-role="'+e(options.role||'chart-rect')+'"'+(options.key?' data-summary-key="'+e(options.key)+'"':'')+(options.radius?' rx="'+options.radius+'" ry="'+options.radius+'"':'')+(options.stroke?' stroke="'+options.stroke+'" stroke-width="1"':'')+'/>');
   }
   function tx(x,y,str,size,color,rtl,anchor,options){
    options=options||{};var role=options.role||'label',fontRole=role==='heading'?'heading':['primary-figure','completion-figure','chart-value','axis-value'].includes(role)?'figure':'body',family=fontRole==='heading'?'TEC DIN, DIN Next Arabic':fontRole==='figure'?'TEC DIN LT, DIN Next LT Arabic':'TEC Dubai, Dubai';
    out.push('<text x="'+x+'" y="'+y+'" font-family="'+family+'" font-weight="400" font-size="'+size+'" fill="'+(color||'#4F4E4E')+'" data-font-role="'+fontRole+'" data-summary-role="'+e(role)+'"'+(options.key?' data-summary-key="'+e(options.key)+'"':'')+' direction="'+(rtl===false?'ltr':'rtl')+'" unicode-bidi="embed" text-anchor="'+(anchor||'start')+'">'+e(str)+'</text>');
   }
   rect(0,0,1560,1000,'#FCFBFB',{role:'page-surface'});tx(1550,48,'ملخص تقرير المشاريع الاستراتيجية الخاصة',36,'#333333',true,'start',{role:'heading'});
   /* The page masthead already supplies its required date. Do not repeat
    * period or selected-filter context below this printed section heading. */
   // SVG coordinates scale to 277mm; convert the shared 18 CSS px radius.
   var cardRadius=18*1560/(277*96/25.4);
   var gap=20,w=(1540-gap*(metric.length-1))/metric.length;metric.forEach(function(k,i){var x=1550-(i+1)*w-i*gap;rect(x,162,w,115,'#FCFBFB',{role:'metric-card',key:k[2],radius:cardRadius,stroke:'#E7E0D3'});tx(x+w-18,194,k[0],23);tx(x+w-18,253,count(k[1]),48,k[2]==='done'?'#01831E':'#333333',false,'end',{role:'primary-figure',key:k[2]});});
   var comps=[[d.done,d.total,d.leadOnly?'نسبة المشاريع المنجزة للقيادة':'نسبة المشاريع المنجزة']];if(!d.leadOnly&&d.lead)comps.push([d.leadDone,d.lead,'نسبة المشاريع المنجزة للقيادة']);comps.forEach(function(c,i){var cg=20,cw=(1540-cg*(comps.length-1))/comps.length,x=1550-(i+1)*cw-i*cg;rect(x,300,cw,96,'#FCFBFB',{role:'completion-card',radius:cardRadius,stroke:'#E7E0D3'});tx(x+cw-22,334,c[2],23);tx(x+cw-22,372,'عدد المشاريع: '+count(c[0])+' من أصل '+count(c[1]),21,'#756B5F');tx(x+22,361,pct(c[0],c[1]),43,'#01831E',false,'start',{role:'completion-figure'});});
   tx(1550,444,'توزيع المشاريع حسب القطاع',29,'#333333',true,'start',{role:'heading'});var y=491,zero=1050,bw=870;
   [0,.5,1].forEach(function(t){var xx=zero-bw*t;out.push('<path d="M'+xx+' 463V889" stroke="#E7E0D3" stroke-width="1"/>');});
   rows.forEach(function(item){var g=item.g,values=g.values,total=values.reduce(function(a,b){return a+b;},0);wrap(g.name,34).forEach(function(line,j){tx(1550,y+j*27,line,24);});var cur=zero;values.forEach(function(v,i){if(v){var sw=bw*v/max;rect(cur-sw,y-23,sw,34,colour(d.names[i]),{role:'status-bar',key:d.names[i],stroke:S.ui.chartStatusBorder(d.names[i])});tx(cur-sw/2,y+2,count(v),22,hhChartInk(d.names[i]),false,'middle',{role:'chart-value',key:d.names[i]});cur-=sw;}});tx(cur-16,y+3,'(المجموع '+count(total)+')',20,'#333333',true,'start');y+=item.h;});
   if(!rows.length)tx(1550,580,'لا توجد مشاريع ضمن النطاق المحدد',28);

   tx(zero,921,count(0),19,'#756B5F',false,'middle',{role:'axis-value'});tx(zero-bw/2,921,U.fmtNum(max/2,1),19,'#756B5F',false,'middle',{role:'axis-value'});tx(zero-bw,921,count(max),19,'#756B5F',false,'middle',{role:'axis-value'});tx(1550,920,'عدد المشاريع',20,'#756B5F');
   var lx=1550;d.names.forEach(function(n){rect(lx-13,961,12,12,colour(n),{role:'legend-swatch',key:n,stroke:S.ui.chartStatusBorder(n)});tx(lx-22,974,n,22,S.ui.statusTextColor(n));lx-=190;});
   return '<div class="hh-print-summary-page" data-summary-page="'+(page+1)+'"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1560 1000" width="277mm" height="177.56mm" role="img" aria-label="ملخص المشاريع">'+out.join('')+'</svg></div>';
  }).join('')+'</div>';
 }
 function hhBody(state,m){if(!m.items.length)return '<section class="tec-report-empty" role="status"><p>لا توجد بيانات ضمن النطاق المحدد.</p></section>';return hhCover(state)+'<section id="hh-summary" class="hh-summary"><div class="hh-section-return rpt-section-return">'+hhReturn()+'</div>'+hhDashboard(state,m)+'</section>'+table(state,m,{title:'القائمة الرئيسية للمشاريع'})+hhAppendix(state,m.open,false,0)+hhAppendix(state,m.done,true,m.open.length)+S.reportEditorial.output(state);}
 function agendaCard(it){return field(S.ui.contentLabel(it),it.title,'rpt-title-field')+'<div class="rpt-detail-grid rpt-four">'+field('النوع',it.t.type)+field('الجهة المعنية',it.entity)+field('الحالة',status(it))+field('موعد الإنجاز الأصلي',end(it))+'</div><div class="rpt-detail-grid rpt-four">'+field('منسق الأمانة العامة',it.coord)+field('القطاع',it.sector)+field('الوحدة التنظيمية',it.unit)+field('الموعد الجديد إن وجد',it.t.newMonth)+'</div>'+field('الجهات المساهمة',it.t.entities)+field('ملاحظات وإيضاحات',it.notes||it.t.notes,'rpt-notes')+'<div class="rpt-detail-grid rpt-three">'+field('تاريخ العرض على مجلس الشؤون',it.t.dateSac)+field('تاريخ العرض على المجلس التنفيذي',it.t.dateEc)+field('ملاحظات مقرر المجالس',it.t.rapporteur)+'</div>';}
 function projectCard(it){return field(S.ui.contentLabel(it),it.title,'rpt-title-field')+'<div class="rpt-detail-grid rpt-four">'+field('القطاع',it.sector)+field('الوحدة التنظيمية',it.unit)+field('مدير المشروع',it.coord||it.t.pm)+statusField(it)+'</div>'+field('نبذة حول المشروع',it.t.desc)+'<div class="rpt-detail-grid rpt-four">'+field('نوع المشروع',({'Strategic':'استراتيجي','Operational':'تشغيلي'})[it.t.ptype]||it.t.ptype)+field('الأولوية',({'H':'عالية','M':'متوسطة','L':'منخفضة'})[it.t.priority]||it.t.priority)+field('البدء',start(it))+field('الانتهاء',end(it))+'</div><div class="rpt-detail-grid rpt-four">'+field('الموازنة المعتمدة',it.t.revised)+field('المخصص',it.t.committed)+field('غير المخصص',it.t.nonCommitted)+field('المنفق',it.t.spent)+'</div><div class="rpt-detail-grid rpt-two">'+field('ملاحظات مدير المشروع',it.t.ownerRemarks)+field('الملاحظات المالية',it.t.financeRemarks)+'</div>';}
 function detailCards(state,m){return '<section id="report-details" class="rpt-details">'+heading('البطاقات التفصيلية')+m.items.map(function(it,i){return '<article id="topic-'+e(it.key)+'" class="rpt-topic '+(it.pf==='special'?(done(it)?'rpt-completed':'rpt-ongoing'):'')+'" data-project="'+e(it.key)+'"><header class="rpt-topic-header"><span>'+e(it.pf==='agenda'?'بطاقة الموضوع':done(it)?'ملخص المشروع المنجز':'مستجدات المشروع')+' <b>'+count(i+1)+'</b></span>'+badge(it)+'<button type="button" data-act="report-jump" data-target="report-table">العودة إلى الجدول '+U.icon('up',15)+'</button></header><div class="rpt-card-body">'+(it.pf==='special'?specialCard(it):it.pf==='agenda'?agendaCard(it):projectCard(it))+'</div></article>';}).join('')+'</section>';}
 function reportMenu(state){return '<div class="menu-wrap report-wrap"><button type="button" class="btn" data-act="menu" data-menu="reports" aria-haspopup="menu"'+(state.menu==='reports'?' aria-controls="report-menu"':'')+' aria-expanded="'+(state.menu==='reports')+'">'+U.icon('file',17)+'التقارير'+U.icon('down',15)+'</button>'+(state.menu==='reports'?'<div id="report-menu" class="menu report-menu" role="menu" aria-label="التقارير">'+['agenda','council','hh'].map(function(k){var href=S.app&&S.app.href?S.app.href('reports',Object.assign({},state,{report:Object.assign({},state.report,{kind:k})})):'#/reports?kind='+k;return '<a href="'+e(href)+'" class="mopt" role="menuitem" data-screen-link="reports" data-act="show-report" data-report="'+k+'"'+(state.screen==='reports'&&state.report.kind===k?' aria-current="page"':'')+'>'+TITLES[k]+U.icon('left',17)+'</a>';}).join('')+'</div>':'')+'</div>';}

 function agendaAnnex(state,items){
  if(!items.length)return '';
  var names=namesFor(state.data,'agenda',items);
  return '<section id="agenda-emerging" class="rpt-emerging-annex">'+heading('ملحق المواضيع المستجدة '+state.data.year,S.terms.count(items.length,'agenda'))+'<div class="rpt-appendix-chart">'+barChart(stats(items,names),'مستوى إنجاز المواضيع المستجدة','عدد المواضيع حسب الحالة المسجلة')+'</div>'+table(state,{items:items},{id:'agenda-emerging-table',title:'المواضيع المستجدة'})+'</section>';
 }
 function render(state){
  if(state.report.kind==='agenda'&&S.views.agendaPage)return S.views.agendaPage.render(state);
  if(state.report.kind==='council'&&S.views.councilPage)return S.views.councilPage.render(state);
  if(state.report.kind==='projects'&&S.projectsReport)return S.projectsReport.render(state);
  var kind=state.report.kind,m=model(state),title=S.reportDisplay.get(state).title,D=R.dashboard(state.data,state.dash,S.comparison&&S.comparison.dashboardHistory?S.comparison.dashboardHistory(state):null);
  if(kind==='hh')return hhWorkspace(state,m);

  var filters='';if(kind==='hh')filters+=S.ui.multiSelect(state,'r:lead','جهة الطلب',state.report.lead,[{v:'نعم',label:'القيادة'},{v:'لا',label:'الأمانة العامة'}].concat(U.selection(state.report.lead).some(function(v){return !U.key(v);})?[{v:'',label:''}]:[]));if(kind==='agenda')filters+=S.ui.multiSelect(state,'r:type','نوع الموضوع',state.report.type,Array.from(new Set(O.list(state.data,'TopicTypes').concat(state.data.byPf.agenda.filter(function(i){return i.hasTitle;}).map(function(i){return i.t.type||'';})))));
  filters=S.ui.reportFilterControls(state,D,filters);
  var filterLabel=kind==='hh'&&U.hasSelection(state.report.lead)?'جهة الطلب: '+S.filterOptions.compactText(state.report.lead,(state.multiOptions||{})['r:lead'],'الكل','r:lead'):kind==='agenda'&&U.hasSelection(state.report.type)?'نوع الموضوع: '+U.selectionText(state.report.type):'';
  var activeCount=['sector','unit','entity'].filter(function(k){return U.hasSelection(state.dash[k]);}).length+(kind==='hh'&&U.hasSelection(S.ui.reportLeadSelection(state.report.lead))||kind==='agenda'&&U.hasSelection(state.report.type)?1:0);
  var filterSummary=[['القطاع',state.dash.sector,'d:sector'],['الوحدة التنظيمية',state.dash.unit,'d:unit'],['الجهة المعنية',state.dash.entity,'d:entity']].filter(function(f){return U.hasSelection(f[1]);}).map(function(f){var selected=S.filterOptions.selectionGroups(f[1],(state.multiOptions||{})[f[2]],f[2]);return f[0]+': '+selected.slice(0,2).map(function(o){return o.label;}).join('، ')+(selected.length>2?' +'+(selected.length-2):'');}).concat(filterLabel?[filterLabel]:[]).join(' · ')||'جميع ' + S.terms.words(S.terms.reportPf(state)).definitePlural + ' ضمن التقرير';
  filters=S.ui.filterPanel(state,{id:'report-scope',resetAction:'reset-report-filters',title:'تصفية التقرير',body:filters,summary:filterSummary+' · '+S.terms.count(m.items.length,S.terms.reportPf(state)),activeCount:activeCount});
  var caption=[scope(state),filterLabel].filter(Boolean).join(' · '),emerging=kind==='agenda'&&S.filterOptions.single(state.report.type)===null?m.items.filter(function(it){return R.MET.agendaEmerging.test(it);}):[];
  var tableItems=emerging.length?m.items.filter(function(it){return !R.MET.agendaEmerging.test(it);}):m.items;
  return '<div class="screen reports'+(kind==='hh'?' hh-report':'')+'" data-screen="reports">'+S.ui.appHeader(state,'reports')+'<main class="rpt-main"><section class="rpt-intro app-page-heading"><div><h1 data-report-title>'+e(title)+'</h1></div><div class="rpt-source"><span data-report-period-label>'+e(S.reportDisplay.get(state).period)+'</span><small class="source-screen-moved">التاريخ المرجعي للحسابات <bdi dir="ltr">'+e(U.fmtDate(state.data.today))+'</bdi></small></div></section><div class="rpt-controls">'+filters+'</div><p class="rpt-body-source-note">'+e(S.terms.words(S.terms.reportPf(state)).definitePlural)+' من الملف وفق عوامل التصفية؛ التاريخ لا يستبعدها تلقائياً.</p>'+S.reportDisplay.controls(state)+S.reportEditorial.editor(state)+(kind==='hh'?hhBody(state,m):reportJumps('report-shortcuts',[{id:'report-contents',label:'المحتويات'},{id:'report-dashboard',label:'الملخص التنفيذي'},{id:'report-table',label:'جدول المشاريع'}])+reportContents('report-contents',[{id:'report-dashboard',label:'الملخص التنفيذي',count:m.items.length},{id:'report-table',label:'جدول المشاريع',count:tableItems.length}])+dashboard(state,m)+S.reportEditorial.output(state)+table(state,{items:tableItems},{title:kind==='agenda'?(emerging.length?'جدول الأجندة المعتمدة':'جدول المواضيع'):'جدول المشاريع'})+(kind==='projects'?'':detailCards(state,m))+agendaAnnex(state,emerging))+'</main></div>';
 }
 S.views.reports={render:render,menu:reportMenu,title:function(kind){return TITLES[kind]||TITLES.agenda;},hhModel:hhModel,hhLeadMatches:hhLeadMatches,hhSummary:hhSummary,hhPrintSummary:hhPrintSummary,hhMetrics:hhMetrics,hhCompare:hhCompare,hhEntityText:hhEntityText,model:model,projectCompare:projectCompare,progressValue:progressValue,progressMarkup:progressMarkup,harvey:progressValue,harveyMarkup:progressMarkup};
})(window.Saytara=window.Saytara||{});
