/* Separate source-issuer charts share one count scale and status palette. */
(function(S){
 'use strict';
 var U=S.util;
 function esc(value){return U.esc(value==null?'':String(value));}
 function number(value,cls){return '<bdi dir="ltr" class="cr-chart-number '+(cls||'')+'">'+esc(U.metricText(value))+'</bdi>';}
 function spec(state,model){return (model||S.councilReport.model(state.data,state.dash,S.views.councilPage.options(state))).issuerCharts;}
 function statusRow(row,data){
  return '<div class="cr-status-row" data-status="'+esc(row.name)+'" data-count="'+row.count+'"><span class="cr-status-label" style="color:'+row.textColor+'">'+esc(row.name)+'</span><div class="cr-status-bar-cell"><div class="cr-status-bar" data-count-fits="false" data-count="'+row.count+'" style="width:'+row.count/data.max*100+'%;background:'+row.fill+';border-color:'+row.border+';color:'+row.ink+'" role="img" aria-label="'+esc(row.name+'، '+row.count)+'">'+number(row.count,'cr-bar-in-count')+'<span class="cr-bar-end-count" style="color:'+row.textColor+'">'+number(row.count)+'</span></div></div></div>';
 }
 function issuerPanel(panel,i,data){
  var missing=!panel.issuer;
  return '<figure class="cr-issuer-panel'+(missing?' cr-unassigned-panel':'')+'" data-issuer="'+esc(panel.issuer)+'" data-issuer-key="'+esc(panel.key)+'" data-total="'+panel.total+'" aria-labelledby="council-issuer-'+i+'"><figcaption class="cr-issuer-title"><h3 id="council-issuer-'+i+'">'+esc(panel.title)+'</h3><div class="cr-issuer-total">'+number(panel.total)+'<span>الإجمالي</span></div></figcaption>'+(data.statusAvailable?(!missing?'<div class="cr-status-axis" aria-hidden="true"><span>الحالة</span><div class="cr-status-ticks">'+data.ticks.map(function(t){return '<span style="inset-inline-start:'+t/data.max*100+'%">'+number(t)+'</span>';}).join('')+'</div></div>':'')+'<div class="cr-status-bars">'+panel.statuses.map(function(row){return statusRow(row,data);}).join('')+'</div>':'<p class="cr-status-unavailable">مستويات الإنجاز غير متاحة في المصدر.</p>')+'</figure>';
 }
 function render(state,model){
  var data=spec(state,model);if(!data.total)return '';
  var named=[],unassigned='';
  data.panels.forEach(function(panel,i){var html=issuerPanel(panel,i,data);if(panel.issuer)named.push(html);else unassigned=html;});
  var panels=named.length?'<div class="cr-chart-panels'+(data.panels.length===1?' cr-single-issuer':'')+'">'+named.join('')+'</div>':'';
  var legend=data.definitions.length?'<section class="cr-detailed-legend"><h3>تعريفات مستويات الإنجاز</h3><dl>'+data.definitions.map(function(d){return '<div><dt style="color:'+d.textColor+'"><i aria-hidden="true" style="background:'+d.fill+';border-color:'+d.border+'"></i>'+esc(d.name)+'</dt><dd>'+esc(d.text)+'</dd></div>';}).join('')+'</dl></section>':'';
  return '<section class="cr-chart-overview" data-total="'+data.total+'" data-chart-max="'+data.max+'" data-scale-basis="largest-status-count" dir="rtl"><header class="cr-overview-lead"><h2>القرارات التي تتطلب المتابعة</h2><div class="cr-grand-total">'+number(data.total)+'<span>الإجمالي</span></div></header><div class="cr-chart-heading"><h3>مستويات الإنجاز حسب جهة الإصدار</h3><span>عدد القرارات</span></div>'+panels+unassigned+legend+'</section>';
 }
 function fitCounts(root){
  root=root||document;var bars=Array.from(root.querySelectorAll('.cr-status-bar'));
  bars.forEach(function(bar){if(!bar.isConnected)return;var label=bar.querySelector('.cr-bar-in-count'),view=bar.ownerDocument.defaultView,style=view.getComputedStyle(label),canvas=bar.ownerDocument.createElement('canvas'),ctx=canvas.getContext('2d');if(!ctx)return;ctx.font=style.fontWeight+' '+style.fontSize+' '+style.fontFamily;var ink=ctx.measureText(label.textContent),height=(ink.actualBoundingBoxAscent||0)+(ink.actualBoundingBoxDescent||0),fits=ink.width+8<=bar.clientWidth&&height+6<=bar.clientHeight;bar.dataset.countFits=String(fits);bar.dataset.countInkWidth=String(ink.width);bar.dataset.countInkHeight=String(height);});
 }
 var frame=0;
 function scheduleFit(){if(frame)return;frame=requestAnimationFrame(function(){frame=0;fitCounts();});}
 if(!S.councilCharts||!S.councilCharts.eventsInstalled){
  window.addEventListener('resize',scheduleFit);window.addEventListener('beforeprint',function(){fitCounts();});window.addEventListener('afterprint',scheduleFit);
  if(document.fonts&&document.fonts.ready){document.fonts.ready.then(scheduleFit);if(document.fonts.addEventListener)document.fonts.addEventListener('loadingdone',scheduleFit);}
  if(typeof MutationObserver==='function')new MutationObserver(function(records){if(records.some(function(record){return Array.from(record.addedNodes).some(function(n){return n.nodeType===1&&((n.matches&&n.matches('.cr-chart-overview'))||(n.querySelector&&n.querySelector('.cr-chart-overview')));});}))scheduleFit();}).observe(document.documentElement,{childList:true,subtree:true});
 }
 S.councilCharts={spec:spec,render:render,fitCounts:fitCounts,eventsInstalled:true};
})(window.Saytara=window.Saytara||{});
