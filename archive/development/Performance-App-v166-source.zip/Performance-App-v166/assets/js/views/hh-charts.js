/* Approved HH sector charts. One filtered model supplies UI and native exports. */
(function(S){
 'use strict';
 var U=S.util,O=S.order;
 var descriptions={
  'متأخر':'مشروع متأخر وفق الحالة المسجلة في المتابعة.',
  'جاهز للعرض':'مشروع جاهز للعرض وفق الحالة المسجلة في المتابعة.',
  'قيد المراجعة':'مشروع قيد المراجعة؛ يُحتسب ضمن المشاريع قيد العمل.',
  'قيد التطوير':'مشروع قيد التطوير؛ يُحتسب ضمن المشاريع قيد العمل.',
  'منجز':'مشروع مكتمل وفق الحالة المسجلة في المتابعة؛ نسبة الإنجاز وحدها لا تحدد الحالة.',
  'حالات أخرى':'مشاريع بحالة أخرى أو دون حالة محددة، وتبقى مشمولة في الإجمالي.'
 };
 function esc(v){return U.esc(v==null?'':String(v));}
 function number(v){return '<bdi class="hh-chart-number" dir="ltr">'+esc(U.metricText(v))+'</bdi>';}
 function statusStyle(name){return {fill:S.ui.chartStatusColor(name),ink:S.ui.chartStatusInk(name),border:S.ui.chartStatusBorder(name),textInk:S.ui.statusTextColor(name)};}
 function label(it,names){var value=it.statusLabel||(it.t||{}).status||'';return names.includes(value)?value:'حالات أخرى';}
 function spec(state,model){
  model=model||S.views.reports.hhModel(state);
  var items=model.items,names=model.names.slice();
  if(items.some(function(it){return !names.includes(it.statusLabel||(it.t||{}).status||'');})&&!names.includes('حالات أخرى'))names.push('حالات أخرى');
  names=names.filter(function(n){return items.some(function(it){return label(it,names)===n;});});
  var sectors=Array.from(new Set(items.map(function(it){return it.sector||'';}))).sort(function(a,b){return O.compare(state.data,'Sectors',a,b);});
  var cohorts=[{key:'leadership',title:'مشاريع القيادة',items:items.filter(function(it){return U.key((it.t||{}).lead)===U.key('نعم');})},{key:'tec',title:'مشاريع الأمانة العامة',items:items.filter(function(it){return U.key((it.t||{}).lead)!==U.key('نعم');})}].filter(function(c){return c.items.length;}).map(function(c){
   var rows=sectors.map(function(n){var rowItems=c.items.filter(function(it){return (it.sector||'')===n;});return {key:c.key+'|'+n,name:n,total:rowItems.length,recordKeys:rowItems.map(function(it){return it.key;}),values:names.map(function(s){return rowItems.filter(function(it){return label(it,names)===s;}).length;})};}).filter(function(r){return r.total;});
   return {key:c.key,title:c.title,total:c.items.length,recordKeys:c.items.map(function(it){return it.key;}),rows:rows,statuses:names.map(function(n){return {name:n,total:c.items.filter(function(it){return label(it,names)===n;}).length};}).filter(function(s){return s.total;})};
  });
  var largest=Math.max(0,...cohorts.flatMap(function(c){return c.rows.map(function(r){return r.total;});})),max=Math.max(5,Math.ceil(largest/5)*5),step=Math.max(5,Math.ceil(max/25)*5),ticks=[];
  for(var t=0;t<=max;t+=step)ticks.push(t);if(ticks[ticks.length-1]!==max)ticks.push(max);
  // Keep the approved workflow definitions, adding any source status not in the standard set.
  var definitionNames=['متأخر','جاهز للعرض','قيد المراجعة','قيد التطوير','منجز'].filter(function(n){return n!=='جاهز للعرض'||names.includes(n);}).concat(names.filter(function(n){return !['متأخر','جاهز للعرض','قيد المراجعة','قيد التطوير','منجز'].includes(n);}));
  return {total:items.length,recordKeys:items.map(function(it){return it.key;}),names:names,max:max,ticks:ticks,cohorts:cohorts,definitions:definitionNames.map(function(n){return Object.assign({name:n,text:descriptions[n]||'وفق الحالة المسجلة في ملف المتابعة.'},statusStyle(n));})};
 }
 function render(state,model){
  var data=spec(state,model);
  if(!data.total)return '<section class="hh-chart-overview"><h2>توزيع المشاريع حسب القطاع</h2><p class="rpt-empty">لا توجد مشاريع ضمن النطاق المحدد.</p></section>';
  var panels=data.cohorts.map(function(c){return '<section class="hh-cohort-panel" data-cohort="'+c.key+'" data-total="'+c.total+'"><header class="hh-cohort-title"><h3>'+esc(c.title)+'</h3><div class="hh-cohort-total">'+number(c.total)+'<span>الإجمالي</span></div></header><div class="hh-cohort-axis" aria-hidden="true"><span>القطاع</span><div class="hh-cohort-ticks">'+data.ticks.map(function(t){return '<span style="inset-inline-start:'+t/data.max*100+'%">'+number(t)+'</span>';}).join('')+'</div></div><div class="hh-cohort-rows">'+c.rows.map(function(r){
    var detail=data.names.map(function(n,i){return r.values[i]?n+': '+r.values[i]:'';}).filter(Boolean).join('، ');
    return '<div class="hh-cohort-row" data-sector="'+esc(r.name)+'" data-row-key="'+esc(r.key)+'" data-total="'+r.total+'"><div class="hh-cohort-sector">'+esc(r.name)+'</div><div class="hh-cohort-bar-cell"><div class="hh-cohort-bar" role="img" aria-label="'+esc(c.title+'، '+r.name+'، الإجمالي '+r.total+'، '+detail)+'">'+data.names.map(function(n,i){var v=r.values[i],s=statusStyle(n);return v?'<span class="hh-cohort-segment" data-status="'+esc(n)+'" data-value="'+v+'" style="width:'+v/data.max*100+'%;background:'+s.fill+';color:'+s.ink+';border-color:'+s.border+'" title="'+esc(n+': '+v)+'"><bdi class="hh-chart-number hh-count-digits-'+String(v).length+'" aria-hidden="true" dir="ltr">'+esc(U.metricText(v))+'</bdi></span>':'';}).join('')+'<span class="hh-cohort-end-total" style="inset-inline-start:calc('+r.total/data.max*100+'% + 8px)" aria-label="الإجمالي '+r.total+'">'+number(r.total)+'</span></div></div></div>';
   }).join('')+'</div><div class="hh-cohort-status-summary"><p class="hh-cohort-status-context">الإجمالي حسب الحالة</p><div class="hh-cohort-status-totals" aria-label="الإجمالي حسب الحالة">'+c.statuses.map(function(x){return '<div class="hh-cohort-status" data-status="'+esc(x.name)+'" data-value="'+x.total+'" style="color:'+statusStyle(x.name).textInk+'"><span>'+esc(x.name)+'</span>'+number(x.total)+'</div>';}).join('')+'</div></div></section>';}).join('');
  return '<section class="hh-chart-overview" data-chart-max="'+data.max+'" data-source-total="'+data.total+'" dir="rtl" aria-label="ملخص المشاريع الخاصة حسب القطاع"><header class="a-overview-lead hh-overview-lead"><h2>المشاريع الخاصة</h2><div class="a-grand-total hh-grand-total"><bdi class="a-total-number hh-total-number" dir="ltr">'+esc(U.metricText(data.total))+'</bdi><span>الإجمالي</span></div></header><div class="hh-cohort-grid'+(data.cohorts.length===1?' hh-single-cohort':'')+'">'+panels+'</div><section class="hh-detailed-legend"><h3>تعريفات مستويات الإنجاز</h3><dl>'+data.definitions.map(function(s){return '<div><dt style="color:'+s.textInk+'"><i aria-hidden="true" style="background:'+s.fill+';border-color:'+s.border+'"></i>'+esc(s.name)+'</dt><dd>'+esc(s.text)+'</dd></div>';}).join('')+'</dl></section></section>';
 }
 S.hhCharts={spec:spec,render:render,statusStyle:statusStyle,definitions:descriptions};
})(window.Saytara=window.Saytara||{});
