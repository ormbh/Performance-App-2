/* Approved agenda workspace, source-backed matrix and report records. */
(function(S){
 'use strict';
 var U=S.util,A=S.agendaReport,O=S.order;
 function e(v){return U.esc(v==null?'':String(v));}
 function n(v){return U.metricText(v);}
 function color(name){return S.ui.chartStatusColor(name);}
 function statusTextColor(name){return S.ui.statusTextColor(name);}
 function text(v){return U.presentationText(v);}
 // Keep the literal source status, using the approved shared badge treatment.
 function statusCell(it){var label=U.tableCellText(it.t.status?it.statusLabel||it.t.status:null);return label?S.ui.statusChip(Object.assign({},it,{statusLabel:label,statusCat:it.statusCat||S.rules.catOf(label)})):'';}
 function legacyKey(state){return ['saytara.agenda',state.data.file.name,state.data.file.size||'',state.data.year,U.selection(state.dash.sector).sort().join(','),U.selection(state.dash.unit).sort().join(','),...(U.hasSelection(state.dash.entity)?['concernedEntity='+JSON.stringify(U.selection(state.dash.entity).sort())]:[]),U.selection(state.report.type).sort().join(',')].join('|');}
 function key(state){return JSON.stringify(['saytara.agenda.v2',S.reportEditorial.sourceKey(state.data),state.data.year,U.selection(state.dash.sector).sort(),U.selection(state.dash.unit).sort(),U.selection(state.dash.entity).sort(),U.selection(state.report.type).sort()]);}
 function normalized(saved){return {notes:saved&&typeof saved.notes==='string'?saved.notes:'',recommendations:saved&&typeof saved.recommendations==='string'?saved.recommendations:''};}
 function legacy(state){var raw=U.store.get('sessionStorage',legacyKey(state));if(!raw)return null;var value={};try{value=JSON.parse(raw);}catch(ignore){}return {raw:raw,value:normalized(value)};}
 function options(state){
  var k=key(state);state.report.agendaOptions=state.report.agendaOptions||{};
  if(!state.report.agendaOptions[k]){var saved={};try{saved=JSON.parse(U.store.get('sessionStorage',k)||'{}');}catch(ignore){}
   state.report.agendaOptions[k]=normalized(saved);
  }Object.assign(state.report.agendaOptions[k],S.reportDisplay.options(state));return state.report.agendaOptions[k];
 }
 function save(state){var ok=U.store.set('sessionStorage',key(state),JSON.stringify(options(state)));U.persistence(state,'agenda-notes',ok?'':'تعذّر حفظ نصوص الأجندة للجلسة؛ تبقى التعديلات متاحة الآن. انسخ النصوص قبل تحديث الصفحة.');}
 function restoreLegacy(state){var old=legacy(state);if(!old)return false;var current=options(state);if(current.notes.trim()||current.recommendations.trim())return false;Object.assign(current,old.value);save(state);return true;}
 function downloadLegacy(state){var old=legacy(state);if(old)U.download('agenda-legacy-notes.json',old.raw,'application/json;charset=utf-8');}
 function legacyPanel(state){var old=legacy(state);if(!old)return '';var current=options(state),populated=!!(current.notes.trim()||current.recommendations.trim());return '<details class="ag-legacy-editorial app-screen-only"><summary>نصوص سابقة تحتاج مراجعة المصدر</summary><p>حُفظت هذه النصوص بإصدار سابق دون بصمة الملف. لم تُضف إلى التقرير الحالي. راجع المصدر قبل استعادتها.</p>'+[['notes','ملاحظات'],['recommendations','توصيات']].filter(function(x){return old.value[x[0]].trim();}).map(function(x){return '<h4>'+x[1]+'</h4><p class="ag-legacy-text">'+e(old.value[x[0]])+'</p>';}).join('')+'<button type="button" class="btn" data-act="download-agenda-legacy">تنزيل النصوص السابقة</button>'+(!populated&&(old.value.notes.trim()||old.value.recommendations.trim())?'<button type="button" class="btn" data-act="restore-agenda-legacy">استخدام النصوص في التقرير الحالي</button>':'')+'</details>';}
 function editorial(o){return [['notes','ملاحظات'],['recommendations','توصيات']].filter(function(x){return String(o[x[0]]||'').trim();}).map(function(x){return '<section class="ag-editorial-section ag-'+x[0]+'"><h3>'+x[1]+'</h3><p>'+e(o[x[0]].trim())+'</p></section>';}).join('');}
 function updateEditorial(state){var el=document.getElementById('report-editorial'),html=editorial(options(state));if(el){el.innerHTML=html?sectionReturn()+html:'';el.hidden=!html;el.parentElement.classList.toggle('has-editorial',!!html);}S.reportNavigation.updateEditorial(!!html);}
 function sectionReturn(){return S.reportNavigation.returnLink('report-contents');}
 function definitions(state){return '<section class="ag-definitions"><h2>تعريفات مستويات الإنجاز</h2><dl>'+O.statuses(state.data,'agenda').filter(function(s){return A.definitions[s];}).map(function(s){return '<div data-agenda-status="'+e(s)+'"><dt style="color:'+statusTextColor(s)+'"><span class="ag-definition-swatch" style="background-color:'+e(S.ui.chartStatusColor(s))+';border:1px solid '+e(S.ui.chartStatusBorder(s))+'" aria-hidden="true"></span><span>'+e(s)+'</span></dt><dd>'+e(A.definitions[s])+'</dd></div>';}).join('')+'</dl></section>';}
 function sectionHeading(title,total){return '<div class="rpt-section-heading"><h2>'+e(title)+'</h2><span class="rpt-heading-count">'+e(S.terms.count(total,'agenda'))+'</span></div>';}
 function table(state,items,heading,id,numbers){
  if(!items.length)return '';
  return '<section id="'+e(id)+'" class="ag-table-section ag-page" dir="rtl">'+sectionHeading(heading,items.length)+sectionReturn()+'<div class="ag-table-scroll" role="region" tabindex="0" aria-label="'+e(heading)+'"><table class="ag-table"><colgroup><col style="width:4%"><col style="width:40%"><col style="width:25%"><col style="width:16%"><col style="width:15%"></colgroup><thead><tr>'+['م',S.ui.contentHeader(items,'agenda'),'الجهة المعنية','الحالة','موعد الإنجاز'].map(function(s){return '<th scope="col"'+(s==='موعد الإنجاز'?' class="ag-deadline-heading"':'')+'>'+s+'</th>';}).join('')+'</tr></thead><tbody>'+items.map(function(it){var number=++numbers.current,q=A.effectivePeriod(state.data,it).quarter;return '<tr id="record-'+e(it.key)+'" data-record="'+e(it.key)+'" data-report-number="'+number+'"><td>'+n(number)+'</td><th scope="row" data-label="'+e(S.ui.contentLabel(it))+'" data-content-label="'+e(S.ui.contentLabel(it))+'">'+e(it.title)+'</th><td>'+e(U.tableCellText(it.entity))+'</td><td class="ag-status-cell" data-source-field="status">'+statusCell(it)+'</td><td class="ag-date">'+e(q||'لم يُحدَّد الموعد')+'</td></tr>';}).join('')+'</tbody></table></div></section>';
 }
 function tables(state,items,id,numbers){return A.groups(state.data,items).map(function(g,i){return table(state,g.items,g.name,id+'-'+i,numbers);}).join('');}
 function annex(state,items,numbers){
  if(!items.length)return '';
  items=items.slice().sort(function(a,b){return A.compare(state.data,a,b);});
  return '<section id="agenda-emerging" class="ag-emerging ag-page" dir="rtl"><div class="ag-emerging-content">'+table(state,items,'المواضيع المستجدة','agenda-emerging-table',numbers)+'</div></section>';
 }
 function editor(state){var o=options(state);return legacyPanel(state)+'<details class="ag-editor"><summary>إعداد التقرير</summary>'+S.reportDisplay.controls(state)+'<div class="ag-editor-fields"><label class="ag-editor-text">ملاحظات<textarea data-agenda-text="notes" rows="4" placeholder="أضف الملاحظات لعرضها في التقرير">'+e(o.notes)+'</textarea></label><label class="ag-editor-text">توصيات<textarea data-agenda-text="recommendations" rows="4" placeholder="أضف التوصيات لعرضها في التقرير">'+e(o.recommendations)+'</textarea></label></div></details>';}


 function compact(state,key,id){var value=key==='type'?state.report.type:state.dash[key];return S.filterOptions.compactText(value,(state.multiOptions||{})[id]||[],'الكل',id);}
 function entityText(state){var value=compact(state,'entity','d:entity');return value==='الكل'?'':value;}
 function filters(state,m){
  var controls=S.ui.reportFilterControls(state,S.rules.dashboard(state.data,state.dash,S.comparison&&S.comparison.dashboardHistory?S.comparison.dashboardHistory(state):null),S.ui.multiSelect(state,'r:type','نوع الموضوع',state.report.type,Array.from(new Set(O.list(state.data,'TopicTypes').concat(state.data.byPf.agenda.filter(function(i){return i.hasTitle;}).map(function(i){return i.t.type||'';}))))));
  var defs=[['sector','d:sector','القطاع'],['unit','d:unit','الوحدة التنظيمية'],['entity','d:entity','الجهة المعنية'],['type','r:type','نوع الموضوع']],host=document.createElement('div');host.innerHTML=controls;
  var fields=defs.map(function(d){var field=host.querySelector('[data-multi-wrap="'+d[1]+'"]');if(!field)return '';var b=field.querySelector('.multi-trigger>b');if(b)b.textContent=compact(state,d[0],d[1]);return field.outerHTML;}).join('');
  var selected=defs.filter(function(d){return compact(state,d[0],d[1])!=='الكل';}).map(function(d){return d[2]+': '+compact(state,d[0],d[1]);}),open=!!(state.filterPanels&&state.filterPanels['report-scope']);
  return '<section class="tec-workspace-filters ag-report-filters'+(open?' is-open':'')+'" data-filter-panel="report-scope" aria-label="نطاق تقرير الأجندة"><div class="tec-core-filter-fields" id="agenda-filter-fields"'+(open?'':' hidden')+'>'+fields+'</div><div class="tec-filter-summary-row"><p class="tec-filter-scope" role="status"><span>النطاق: </span><bdi dir="auto">'+e(selected.join(' · ')||'الكل')+'</bdi><span class="ag-scope-count"> · عدد المواضيع: '+n(m.total)+'</span></p><div class="tec-filter-tools"><button class="tec-text-action ag-filter-toggle" type="button" data-act="toggle-filters" data-filter-panel="report-scope" aria-controls="agenda-filter-fields" aria-expanded="'+open+'"><span class="ag-filter-closed-label">تصفية</span><span class="ag-filter-open-label">إغلاق التصفية</span>'+U.icon('down',20)+'</button>'+(selected.length?'<button type="button" class="tec-text-action ui-filter-reset" data-act="reset-report-filters">مسح التصفية</button>':'')+'</div></div></section>';
 }
 function labelTableCells(html){var host=document.createElement('div');host.innerHTML=html;host.querySelectorAll('.ag-table').forEach(function(table){var labels=Array.from(table.querySelectorAll('thead th')).map(function(x){return x.textContent;});table.querySelectorAll('tbody tr').forEach(function(row){Array.from(row.children).forEach(function(cell,i){cell.dataset.agLabel=labels[i];if(i===0)cell.classList.add('ag-record-number');if(cell.tagName==='TH')cell.classList.add('ag-record-title');});});});return host.innerHTML;}
 function render(state){
  var o=options(state),m=A.model(state.data,state.dash,state.report.type||'',o),scope=filters(state,m),display=S.reportDisplay.get(state),entity=entityText(state);
  var masthead='<div class="wb-reference-title tec-page-title"><h1 data-report-title>'+e(display.title)+'</h1>'+(entity?'<p class="ag-report-entity"><bdi dir="auto">'+e(entity)+'</bdi></p>':'')+'<p class="wb-reference-context" data-report-period-label>'+e(display.period)+'</p></div>';
  var sections=[{id:'report-dashboard',label:'الملخص التنفيذي',count:m.total,countLabel:'عدد المواضيع'}];
  if(m.planned.length)sections.push({id:'report-table',label:'الأجندة المعتمدة',count:m.planned.length,countLabel:'عدد المواضيع'});
  if(m.emerging.length)sections.push({id:'agenda-emerging',label:'المواضيع المستجدة',count:m.emerging.length,countLabel:'عدد المواضيع'});
  if(m.other.length)sections.push({id:'agenda-other',label:'مواضيع غير مصنفة',count:m.other.length,countLabel:'عدد المواضيع'});
  var ed=editorial(o),numbers={current:0};if(ed)sections.push({id:'report-editorial',label:'ملاحظات وتوصيات'});
  var records=(m.planned.length?'<section id="report-table" class="ag-cohort">'+sectionHeading('الأجندة المعتمدة',m.planned.length)+tables(state,m.planned,'agenda-quarter',numbers)+'</section>':'')+annex(state,m.emerging,numbers)+(m.other.length?'<section id="agenda-other" class="ag-cohort">'+sectionHeading('مواضيع غير مصنفة',m.other.length)+tables(state,m.other,'agenda-other-quarter',numbers)+'</section>':'');
  var body=m.total?'<section id="report-dashboard" class="ag-summary" dir="rtl">'+sectionReturn()+S.agendaMatrix.render(state)+'</section>'+definitions(state)+labelTableCells(records)+'<div class="ag-report-tail'+(ed?' has-editorial':'')+'"><aside id="report-editorial" class="ag-editorial rpt-editorial" aria-label="ملاحظات وتوصيات التقرير"'+(!ed?' hidden':'')+'>'+(ed?sectionReturn()+ed:'')+'</aside></div>':'<section class="tec-report-empty" role="status"><p>لا توجد بيانات ضمن النطاق المحدد.</p></section>';
  return '<div class="screen reports agenda-report agenda-approved" data-screen="reports">'+S.ui.appHeader(state,'reports',{masthead:masthead})+'<main class="rpt-main ag-main">'+scope+'<div class="tec-report-navigation'+(m.total?'':' is-empty')+'">'+(m.total?S.reportNavigation.contents('report-contents',sections):'')+'<div class="ag-report-utilities app-screen-only">'+editor(state)+'</div></div>'+body+'</main></div>';
 }
 S.views.agendaPage={render:render,options:options,save:save,updateEditorial:updateEditorial,restoreLegacy:restoreLegacy,downloadLegacy:downloadLegacy,entityText:entityText};
})(window.Saytara=window.Saytara||{});
