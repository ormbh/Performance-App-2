# Current design standard — Revision 27 / v162

Read DESIGN-PRINCIPLES-v162.md for the current consolidated standard. The special-project report uses the shared title/overall-total chart lead without a separate metric summary. Detail cards omit repeated group titles, visible card numbers and duplicate yes/no leadership metadata, retaining one consistent outlined badge with project identity. Monthly metrics and all source definitions remain unchanged.

VERIFICATION-v162.md records implementation checks and limitations. Older documents in this source archive retain their historical scope.
