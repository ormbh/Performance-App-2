# Performance App v162 development source

This is the readable development source, including the build tool and historical development notes. The clean user package is published separately as Performance-App-v162.zip.

v162 removes the separate special-project summary card, repeated detail-card section/number strip and raw yes/no leadership field. The project title/overall total precede the two charts, and one outlined leadership badge matches screen/PDF/PowerPoint. Source records and calculations remain unchanged.

Build: `python tools/build-bundles.py`; verify freshness with `--check`. Runtime dependencies are listed in the current release evidence. See VERIFICATION-v162.md for actual checks and limits.
