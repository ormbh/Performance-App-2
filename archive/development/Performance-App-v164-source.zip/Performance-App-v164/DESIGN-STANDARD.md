# Current design standard — Revision 28 / v164

DESIGN-PRINCIPLES-v163.md remains the approved consolidated standard. v164 changes PDF square-bullet compatibility only: preserve original source text and Arabic font files, and render the known missing square glyph through the licensed embedded symbol fallback. Screen layout, report structure, status colors, source eligibility and calculations remain unchanged. VERIFICATION-v164.md records the focused checks and limits.
