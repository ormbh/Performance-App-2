# Performance App v164 development source

PDF compatibility fix for legacy Office square bullet U+F0A7, preserving source Unicode and original approved Arabic font files. The clean user package is Performance-App-v164.zip.

Build the PDF engine with `python3 tools/build-offline-pdf.py`, then app bundles with `python3 tools/build-bundles.py`. Check bundle freshness with `--check`. Design principles remain Revision 28 in DESIGN-PRINCIPLES-v163.md. See VERIFICATION-v164.md for this fix and its test limits.
