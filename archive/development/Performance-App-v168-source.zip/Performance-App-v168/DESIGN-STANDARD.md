# Current design standard — Revision 32 / v168

Read DESIGN-PRINCIPLES-v168.md and VERIFICATION-v168.md. The approved entity-report illustration is implemented. Preserve all preceding portfolio, monthly, agenda, council and special-project contracts. Source scope and status/date meanings remain distinct.
