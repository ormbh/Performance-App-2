/* Projects workspace: named source records, shared filters and traceable drilldowns.
   This deliberately reuses the report's scoped rows and numeric-cell rules. */
(function(S){
 'use strict';
 var U=S.util,R=S.rules,O=S.order,P=S.projectsReport;
 var KEYS=['sector','unit','entity','projectType','priority','quarter','projectStatus','pm'];
 var TYPE={Strategic:'استراتيجي',Operational:'تشغيلي'},PRIORITY={H:'عالية',M:'متوسطة',L:'منخفضة'};
 var Q=['Q1','Q2','Q3','Q4','other'],QL={Q1:'الربع الأول',Q2:'الربع الثاني',Q3:'الربع الثالث',Q4:'الربع الرابع',other:'خارج سنة التقرير / غير مؤرخ'};
 var FIELDS=[['approved','الموازنة الأصلية'],['revised','الموازنة المعتمدة'],['committed','المخصص'],['nonCommitted','غير المخصص'],['workDone','قيمة الأعمال المنجزة'],['spent','المنفق حسب الفواتير']];
 var LABELS={sector:'القطاع',unit:'الوحدة التنظيمية',entity:'الجهة المعنية',projectType:'نوع المشروع',priority:'الأولوية',quarter:'ربع الانتهاء',projectStatus:'الحالة',pm:'مدير المشروع'};
 function esc(v){return U.esc(v==null?'':String(v));}
 function n(v){return v===0?'–':U.metricText(v);}
 function display(v,dec,suffix){return U.displayNumber(v,dec,suffix);}
 function val(v){return U.presentationText(v);}
 function status(it){return it.statusLabel||it.t.status||'';}
 function owner(it){return it.coord||it.t.pm||'';}
 function defaults(){return {tab:'delivery',view:'dashboard',focus:'all',value:'',sector:'',unit:'',entity:'',entityMode:'concerned',projectType:'',priority:'',quarter:'',projectStatus:'',pm:''};}
 function adapter(state){return Object.assign({},state,{dash:state.projects,report:Object.assign({},state.report,state.projects,{kind:'projects'})});}
 function reportState(state){var p=Object.assign(defaults(),state.dash);['projectType','priority','quarter','projectStatus','pm'].forEach(function(k){p[k]=state.report[k]||'';});return Object.assign({},state,{projects:p});}
 function get(it,key){return key==='sector'?it.sector||'':key==='unit'?it.unit||'':key==='projectType'?it.t.ptype||'':key==='priority'?it.t.priority||'':key==='quarter'?P.quarter(it):key==='projectStatus'?status(it):key==='pm'?it.t.pm||'':key==='owner'?owner(it):'';}
 function label(key,v){if(key==='projectStatus')return val(S.schema.value('status',v));var labels=key==='projectType'?TYPE:key==='priority'?PRIORITY:key==='quarter'?QL:{};return Object.prototype.hasOwnProperty.call(labels,v)?labels[v]:val(v);}
 function group(state,items,key){return [...new Set(items.map(function(it){return get(it,key);}))].map(function(k){var rows=items.filter(function(it){return get(it,key)===k;});return {key:k,name:label(key,k),n:rows.length,done:rows.filter(R.MET.secDone.test).length};}).sort(function(a,b){return key==='quarter'?Q.indexOf(a.key)-Q.indexOf(b.key):key==='projectStatus'?O.status(state.data,a.key,b.key,'secretariat'):O.compare(state.data,{sector:'Sectors',unit:'Departments',projectType:'ProjectType',priority:'ProjectPriority'}[key]||'Departments',a.key,b.key);});}
 function model(state){var m=P.model(adapter(state));m.finance=FIELDS.map(function(f){return {key:f[0],name:f[1],...P.amount(m.items,f[0])};});
  var pairs=m.items.filter(function(it){return P.money(it.c.revised)!=null&&P.money(it.c.spent)!=null;});
  m.remaining={key:'remaining',name:'المتبقي من الموازنة بعد المنفق',value:pairs.length?pairs.reduce(function(sum,it){return sum+P.money(it.c.revised)-P.money(it.c.spent);},0):null,known:pairs.length,total:m.items.length};
  m.noOwner=m.items.filter(function(it){return !String(owner(it)).trim();});
  m.namesCount=new Set(m.items.map(function(it){return String(it.title).trim();})).size;
  m.groups={};['sector','unit','projectType','priority','quarter','projectStatus','pm','owner'].forEach(function(k){m.groups[k]=group(state,m.items,k);});m.pmo=S.projectsPMO.model(state,m);m.delivery=S.portfolioDelivery.model(state,m);return m;
 }
 function known(it,key){return key==='remaining'?S.portfolioDelivery.money(it,'revised')!=null&&S.portfolioDelivery.money(it,'spent')!=null:S.portfolioDelivery.money(it,key)!=null;}
 function deliveryHelpers(){return {esc:esc,n:n,val:val,status:status,owner:owner,label:label,link:link,attrs:attrs,head:head,badge:badge,moneyText:moneyText,coverage:coverage};}
 function renderDelivery(state,m){var h=deliveryHelpers();h.resetAction=state.screen==='reports'?'reset-report-filters':'projects-reset';return S.views.portfolioDelivery.render(state,m||model(state).delivery,h);}
 function sourceNotice(state){var p=state.projects,noticeState=Object.assign({},state,{dash:p,data:Object.assign({},state.data,{items:state.data.items.filter(function(it){return it.pf==='secretariat'&&P.matches(it,p);})})});return '<div class="app-screen-only">'+S.views.dashboard.sourceTitleNotice(noticeState,false)+'</div><div class="pw-source-print-only">'+S.views.dashboard.sourceTitleNotice(noticeState,true)+'</div>';}
 function emptyState(state,m){
  var p=state.projects||defaults(),active=KEYS.some(function(k){return U.hasSelection(p[k]);}),reset=state.screen==='reports'?'reset-report-filters':'projects-reset';
  var source=state.data.items.filter(function(it){return it.pf==='secretariat';}),named=source.filter(R.MET.secTotal.test),untitled=source.filter(function(it){return !R.MET.secTotal.test(it)&&R.inScope(it,p)&&P.matches(it,p);});
  var filtered=active&&named.length>0,kind=filtered?'filtered':untitled.length?'source-titles':'source-empty';
  var title=filtered?'لا توجد مشاريع تطابق عوامل التصفية':untitled.length?'لا توجد مشاريع مسماة قابلة للحساب':'لا توجد مشاريع مسجلة في هذا النطاق';
  var note=filtered?'جرّب توسيع النطاق أو إعادة ضبط عوامل التصفية.':untitled.length?'يحتوي النطاق على '+n(untitled.length)+' صفاً بلا اسم مشروع. تستبعدها معادلات القالب من الإجمالي؛ راجع أسماء المشاريع في المصدر.':'راجع بيانات المشاريع في الملف أو اختر ملف بيانات آخر.';
  return '<section class="pw-empty pw-source-empty" data-project-empty="'+kind+'"><h2>'+title+'</h2><p class="pw-empty-count">عدد المشاريع القابلة للحساب: <strong aria-label="صفر">–</strong></p><p>'+note+'</p><div class="pw-empty-actions">'+(filtered?'<button type="button" class="dbtn" data-act="'+reset+'">إعادة ضبط عوامل التصفية</button>':'<button type="button" class="dbtn" data-act="go-checks">مراجعة بيانات المصدر</button><button type="button" class="btn" data-act="change-file">اختيار ملف آخر</button>')+'</div></section>';
 }
 function summary(state,m){
  if(!m.items.length)return '';
  var d=m.delivery,g=d.overall,b=g.budget,progress=g.progress;
  var cards=[{label:'إجمالي المشاريع',value:n(g.total),id:g.id,note:'المشاريع المسماة ضمن النطاق'},
   {label:'منجز بحسب الحالة',value:g.completed==null?'غير متاح':n(g.completed),id:g.completedId,note:'وفق الحالة المسجلة في المصدر'},
   {label:'يتطلب المتابعة',value:n(d.issues.length),id:'issues:all',note:'المشاريع المشمولة في جدول المتابعة'},
   {label:'الموازنة المعتمدة',value:b.available?display(b.value/1000000,2):'غير متاح',id:b.id,note:'مليون درهم'},
   {label:'متوسط الإنجاز المسجل',value:progress.available?display(progress.value,1,'%'):'غير متاح',id:progress.id,note:coverage(progress)+' · دون وزن بالموازنة'}];
  return '<section class="pw-portfolio-summary" aria-label="ملخص محفظة المشاريع ضمن عوامل التصفية الحالية">'+cards.map(function(c){return '<button type="button" class="pw-summary-card"'+attrs('delivery',c.id)+' aria-label="'+esc(c.label+': '+c.value+' · '+c.note+' · يعرض المشاريع المطابقة')+'"><span>'+esc(c.label)+'</span><strong><bdi>'+esc(c.value)+'</bdi></strong><small>'+esc(c.note)+'</small></button>';}).join('')+'</section>';
 }
 function updateScrollHints(){
  if(typeof document==='undefined'||!document.querySelectorAll)return;
  document.querySelectorAll('.screen.projects-pmo .pd-table-region').forEach(function(region){var overflow=region.scrollWidth>region.clientWidth+1,hint=region.nextElementSibling;region.setAttribute('data-pd-overflow',String(overflow));if(hint&&hint.classList.contains('pd-scroll-hint'))hint.hidden=!overflow;});
 }
 if(window.addEventListener)window.addEventListener('resize',updateScrollHints);
 if(typeof document!=='undefined'&&document.fonts&&document.fonts.ready)document.fonts.ready.then(updateScrollHints);
 function defaultTitle(state){return 'مستجدات محفظة المشاريع'+(state.data&&U.validDateSerial(state.data.today)?' '+U.ymd(state.data.today).y:'');}
 function masthead(state,m,reportDisplay){
  var cutoff=U.validDateSerial(state.data.today)?'حتى تاريخ '+U.fmtDate(state.data.today):'تاريخ البيانات غير متاح';
  return '<div class="project-masthead"><h1 id="projects-heading" tabindex="-1"'+(reportDisplay?' data-report-title':'')+'>'+esc(reportDisplay?reportDisplay.title:defaultTitle(state))+'</h1><p class="project-masthead-period"'+(reportDisplay?' data-report-period-label':'')+'>'+esc(reportDisplay?reportDisplay.period:cutoff)+'</p>'+(reportDisplay?'<p class="project-masthead-cutoff" data-project-cutoff'+(reportDisplay.period===cutoff?' hidden':'')+'>التاريخ المرجعي للحسابات: '+esc(U.validDateSerial(state.data.today)?U.fmtDate(state.data.today):'غير متاح')+'</p>':'')+'</div>';
 }
 function printScope(state){return '<p class="pd-report-scope"><span>نطاق التقرير: </span>'+esc(scope(state))+'<br><span>التاريخ المرجعي للحسابات: </span><bdi>'+esc(U.validDateSerial(state.data.today)?U.fmtDate(state.data.today):'')+'</bdi></p>';}
 function pageLinks(state){var report=state.screen==='reports';return '<nav class="portfolio-page-links" aria-label="روابط محفظة المشاريع">'+link('القائمة الرئيسية للمشاريع','all','','portfolio-main-list-link')+'<button type="button" class="pw-link" data-act="'+(report?'go-projects':'projects-report')+'">'+(report?'العودة إلى محفظة المشاريع':'تقرير محفظة المشاريع')+'</button></nav>';}
 function focusRows(m,p){if(p.focus==='delivery')return S.portfolioDelivery.select(m.delivery,p.value);if(p.focus==='record')return m.items.filter(function(it){return it.key===p.value;});if(p.focus==='done')return m.done;if(p.focus==='active')return m.active;if(p.focus==='notes')return m.notes;if(p.focus==='high')return m.high;if(p.focus==='noOwner')return m.noOwner;if(p.focus==='pmo')return S.projectsPMO.select(m.pmo,p.value);if(p.focus==='known'||p.focus==='missing')return FIELDS.some(function(f){return f[0]===p.value;})||p.value==='remaining'?m.items.filter(function(it){return known(it,p.value)===(p.focus==='known');}):[];if(p.focus==='group'){var pair;try{pair=JSON.parse(p.value);}catch(e){return [];}return Array.isArray(pair)&&m.groups[pair[0]]?m.items.filter(function(it){return get(it,pair[0])===pair[1];}):[];}return m.items;}
 function focusLabel(p,m){if(p.focus==='delivery'&&p.value==='issues:all')return 'المشاريع التي تتطلب المتابعة';if(p.focus==='delivery')return m?S.portfolioDelivery.label(m.delivery,p.value):'تفصيل محفظة المشاريع';if(p.focus==='pmo')return S.projectsPMO.label(p.value);if(p.focus==='group'){try{var pair=JSON.parse(p.value);return (LABELS[pair[0]]||'مدير المشروع')+': '+label(pair[0],pair[1]);}catch(e){return 'نطاق غير صالح';}}if(p.focus==='known'||p.focus==='missing'){var f=FIELDS.find(function(f){return f[0]===p.value;});return (p.focus==='missing'?'القيم غير المسجلة: ':'القيم المتاحة: ')+(f?f[1]:p.value==='remaining'?'المتبقي من الموازنة':'حقل غير صالح');}var labels={all:'قائمة المشاريع',done:'منجز حسب الحالة',active:'قيد العمل',notes:'مشاريع بملاحظات مصدرية',high:'أولوية عالية',noOwner:'مدير المشروع غير مسجل',record:'تفاصيل المشروع'};return Object.prototype.hasOwnProperty.call(labels,p.focus)?labels[p.focus]:'قائمة المشاريع';}
 function attrs(focus,value){return ' data-act="projects-drill" data-focus="'+esc(focus||'all')+'" data-value="'+esc(value||'')+'"';}
 function link(text,focus,value,cls){return '<button type="button" class="pw-link '+(cls||'')+'"'+attrs(focus,value)+' aria-label="'+esc(text+(focus&&focus!=='all'&&focus!=='record'?' · '+focusLabel({focus:focus,value:value||''}):''))+' · يعرض المشاريع المطابقة">'+esc(text)+'</button>';}
 function scope(state){return P.scope(adapter(state));}
 function filters(state,m,forReport){
  var p=state.projects,all=state.data.items.filter(function(it){return it.pf==='secretariat'&&R.MET.secTotal.test(it);});
  var active=KEYS.filter(function(k){return U.hasSelection(p[k]);}).length;
  function filterId(k){return (forReport?(['sector','unit','entity'].includes(k)?'d:':'r:'):'p:')+k;}
  var controls=KEYS.map(function(k){var rows=k==='unit'?all.filter(function(it){return S.filterOptions.selected(it.sector,p.sector,'sector');}):forReport&&!['sector','entity'].includes(k)?m.base:all,opts=k==='entity'?[{v:'الأمانة العامة للمجلس التنفيذي',label:'الأمانة العامة للمجلس التنفيذي'}]:group(state,rows,k).filter(function(g){return k!=='sector'||S.filterOptions.key(g.key,'sector')!==S.filterOptions.key('الأمانة العامة للمجلس التنفيذي','sector');}).map(function(g){return {v:g.key,label:g.name,n:g.n};});var id=filterId(k),html=S.ui.multiSelect(state,id,LABELS[k],p[k],opts),allText={sector:'جميع القطاعات',unit:'جميع الوحدات',entity:'جميع الجهات'}[k]||'الكل',compact=S.filterOptions.compactText(p[k],state.multiOptions[id]||[],allText,id);return html.replace(/<b dir="auto">[^<]*<\/b>/,'<b dir="auto">'+esc(compact)+'</b>');}).join('');
  var summary=KEYS.filter(function(k){return U.hasSelection(p[k]);}).map(function(k){var id=filterId(k),values=S.filterOptions.selectionGroups(p[k],(state.multiOptions||{})[id],id);return LABELS[k]+': '+values.slice(0,1).map(function(o){return k==='projectStatus'?label(k,o.label):o.label;}).join('، ')+(values.length>1?' +'+(values.length-1):'');}).join(' · ')||'جميع المشاريع';
  return '<section class="tec-workspace-filters portfolio-filter-panel" data-filter-panel="projects" aria-label="عوامل تصفية محفظة المشاريع"><div class="portfolio-filter-fields">'+controls+'</div><div class="tec-filter-summary-row"><p class="tec-filter-scope" role="status" aria-live="polite" aria-atomic="true"><span>النطاق: </span><bdi dir="auto">'+esc(summary)+'</bdi></p>'+(active?'<button type="button" class="tec-text-action ui-filter-reset" data-act="'+(forReport?'reset-report-filters':'projects-reset')+'"'+(state.reporting?' disabled':'')+'>مسح التصفية</button>':'')+'</div></section><p class="visually-hidden" role="status" aria-live="polite" aria-atomic="true">عدد المشاريع: '+n(m.items.length)+' من أصل '+n(all.length)+' · '+esc(scope(state))+'</p>';
 }

 function head(name,note,action){return '<div class="pw-panel-head"><h2>'+esc(name)+'</h2>'+(note?'<span class="pw-results-count">'+esc(note)+'</span>':'')+(action||'')+'</div>';}
 function badge(it){return S.ui.statusChip(it);}
 function moneyText(f){return display(f.value,2);}
 function coverage(f){return 'عدد المشاريع: '+n(f.known)+' من أصل '+n(f.total)+(f.known<f.total?' · تغطية جزئية':'');}
 function contextLine(name,value){var text=U.tableCellText(value);return text?'<small class="portfolio-record-context"><span>'+esc(name)+': </span><bdi dir="auto">'+esc(text)+'</bdi></small>':'';}
 function identity(it){return link(it.title,'record',it.key,'pd-issue-project')+contextLine('نوع المشروع',label('projectType',it.t.ptype))+contextLine('الأولوية',label('priority',it.t.priority))+contextLine('مدير المشروع',owner(it));}
 function entityCell(it){return '<bdi dir="auto">'+esc(it.pf==='secretariat'?'الأمانة العامة للمجلس التنفيذي':U.tableCellText(it.entity||it.t.entity))+'</bdi>'+contextLine('القطاع',it.sector)+contextLine('الوحدة التنظيمية',it.unit);}
 function noteCell(it){var parts=[['ملاحظات مدير المشروع',it.t.ownerRemarks],['ملاحظات المالية',it.t.financeRemarks]].filter(function(p){return U.tableCellText(p[1]);});return parts.map(function(p){return '<p class="pd-source-note">'+(parts.length>1||p[0]==='ملاحظات المالية'?'<span>'+esc(p[0])+'</span>':'')+'<bdi dir="auto">'+esc(U.tableCellText(p[1]))+'</bdi></p>';}).join('');}
 // The same table is used for the main list and every operational drilldown.
 // The displayed ordinal is independent of the immutable source-record key.
 function recordTableMarkup(rows,options){
  options=options||{};var issueRows=Array.isArray(options.issues)?options.issues:[],hasNotes=Array.isArray(options.issues),issues=new Map(issueRows.map(function(issue){return [issue.item.key,issue];}));
  var headings=['م','المشروع','الجهة المعنية','الحالة','نسبة الإنجاز','موعد الإنجاز'];if(hasNotes)headings.push('ملاحظات');
  var widths=hasNotes?[4,22,19,11,10,12,22]:[4,32,24,13,12,15],caption=options.caption||'القائمة الرئيسية للمشاريع',kind=hasNotes?'pd-issues-table':'pw-record-table';
  return '<div class="pd-table-region pw-table-scroll portfolio-record-region" tabindex="0" role="region" data-pd-table-kind="'+kind+'" aria-label="'+esc(caption)+'"><table role="table" class="portfolio-record-table '+(hasNotes?'pd-table pd-issues-table pw-issues-table':'pw-record-table')+'"><caption class="visually-hidden">'+esc(caption)+'</caption><colgroup>'+widths.map(function(w){return '<col style="width:'+w+'%">';}).join('')+'</colgroup><thead role="rowgroup"><tr role="row">'+headings.map(function(h){return '<th role="columnheader" scope="col">'+esc(h)+'</th>';}).join('')+'</tr></thead><tbody role="rowgroup">'+rows.map(function(it,index){
   var issue=issues.get(it.key)||{},progress=Object.prototype.hasOwnProperty.call(issue,'progress')?issue.progress:it.progress,late=issue.daysOverdue>0?'<small class="portfolio-record-late">'+esc('متأخر '+n(issue.daysOverdue)+' يوماً')+'</small>':'';
   var cells=['<bdi>'+(index+1)+'</bdi>',identity(it),entityCell(it),badge(it)+late,'<bdi class="portfolio-record-progress">'+esc(progress==null?'':display(progress,1,'%'))+'</bdi>','<bdi dir="auto">'+esc(U.tableCellText(it.dateLabel||it.t.end))+'</bdi>'];if(hasNotes)cells.push(noteCell(it));
   return '<tr role="row" data-record="'+esc(it.key)+'" data-project-key="'+esc(it.key)+'" data-source-reference="'+esc(it.ref||it.seq||'')+'">'+cells.map(function(value,i){var tag=i===1?'th':'td';return '<'+tag+(i===1?' role="rowheader" scope="row"':' role="cell"')+' data-label="'+esc(headings[i])+'">'+value+'</'+tag+'>';}).join('')+'</tr>';
  }).join('')+'</tbody></table></div><p class="pd-scroll-hint" hidden>اسحب الجدول أفقياً لعرض جميع الأعمدة.</p>';
 }
 function recordDetails(rows,p){return '<div class="pw-record-details">'+rows.map(function(it){var ref=U.tableCellText(it.ref||it.seq);return '<article><h3><bdi dir="auto">'+esc(it.title)+'</bdi>'+(ref?' <small>· مرجع المشروع <bdi>'+esc(ref)+'</bdi></small>':'')+'<div class="portfolio-record-details-context">'+contextLine('مدير المشروع',owner(it))+contextLine('نوع المشروع',label('projectType',it.t.ptype))+contextLine('الأولوية',label('priority',it.t.priority))+contextLine('القطاع',it.sector)+contextLine('الوحدة التنظيمية',it.unit)+'</div>'+(p.focus==='record'&&U.tableCellText(it.t.desc)?'<p dir="auto">'+esc(it.t.desc)+'</p>':'')+noteCell(it)+(p.focus!=='notes'?'<dl class="pw-record-finance">'+FIELDS.map(function(f){var v=S.portfolioDelivery.money(it,f[0]);return '<div><dt>'+esc(f[1])+'</dt><dd><bdi>'+esc(v==null?'':display(v,2))+'</bdi></dd></div>';}).join('')+'</dl>':'')+'</article>';}).join('')+'</div>';}
 function recordTable(state,m){
  var p=state.projects,rows=focusRows(m,p),showIssues=p.focus==='delivery'&&p.value==='issues:all',options={caption:focusLabel(p,m)};if(showIssues)options.issues=m.delivery.issues||[];
  var table=rows.length?recordTableMarkup(rows,options):'<div class="pw-empty"><h3>لا توجد مشاريع لهذا التفصيل</h3></div>';
  var details=rows.length&&(p.focus==='record'||p.focus==='notes'||p.focus==='known'||p.focus==='missing')?recordDetails(rows,p):'';
  return '<section class="pw-panel pw-records" id="projects-records" tabindex="-1">'+head(focusLabel(p,m),'عدد المشاريع: '+n(rows.length)+' من أصل '+n(m.items.length),'<button type="button" class="dbtn" data-act="projects-overview">'+(p.returnScreen==='reports'?'العودة إلى تقرير محفظة المشاريع':'العودة إلى محفظة المشاريع')+'</button>')+table+details+'</section>';
 }
 function method(state,m){
  var duplicate=m.namesCount<m.items.length?'<p>عدد المشاريع: '+n(m.items.length)+'؛ الأسماء المختلفة: '+n(m.namesCount)+'. لا تُدمج المشاريع بالاسم.</p>':'';
  var schedule=m.pmo.schedule.known?'<p>الزمن المنقضي = المدة من البداية إلى تاريخ البيانات ÷ مدة المشروع، بين 0% و100%. المقارنة تستخدم تواريخ كاملة للبداية والانتهاء ونسبة إنجاز صالحة؛ الشهر وحده لا يحدد مدة بالأيام.</p>':'';
  var excluded=m.excludedFinancial?'<p class="pw-caveat">بنود مالية بلا اسم مشروع مستبعدة: '+n(m.excludedFinancial)+'. مبالغها ضمن النطاق التنظيمي قبل عوامل تصفية المشروع: '+m.excludedAmounts.filter(function(f){return f.known;}).map(function(f){return esc(f.name)+': '+esc(display(f.value,2));}).join(' · ')+' درهم.</p>':'';
  return '<details class="pw-method"><summary>تعريف المؤشرات</summary><p>يُحسب كل مشروع مسمى مرة واحدة؛ وقد ينطبق أكثر من مؤشر متابعة على المشروع نفسه.</p>'+duplicate+'<p>متأخر: مشروع مفتوح بعد نهاية شهر الانتهاء. الشهر دون سنة يتبع سنة مرجع بيانات الملف؛ والتاريخ الكامل يحتفظ بسنته. الإنجاز بحسب الحالة المسجلة.</p><p>المبالغ تجمع القيم المتاحة لكل حقل. المقارنات المالية تستخدم المشاريع ذات القيمتين؛ نسب الموازنة تتطلب موازنة موجبة وقيمة مقارنة غير سالبة.</p>'+schedule+excluded+'</details>';
 }

 function render(state){
  if(!state.data)return '<div class="screen projects-workspace">'+S.ui.appHeader(state,'projects')+'<main class="pw-main"><div class="pw-empty"><h1>مستجدات محفظة المشاريع</h1><p>ارفع ملف البيانات لعرض المشاريع.</p><button type="button" class="dbtn" data-act="change-file">رفع الملف</button></div></main></div>';
  var p=state.projects||defaults(),m=model(state);
  var pageTools='<button type="button" class="btn app-utility" data-act="projects-report">تقرير المشاريع</button>'+S.projectPrint.utilityButton(state)+'<button type="button" class="btn app-utility pw-print" data-act="download-pdf" aria-label="تنزيل العرض الحالي بصيغة PDF حسب عوامل التصفية الحالية"'+((state.reporting||state.pdfDownloading)?' disabled':'')+(state.pdfDownloading?' aria-busy="true"':'')+'>'+(state.pdfDownloading?'<span class="tec-command-spinner" role="status" aria-label="جارٍ إعداد PDF…"></span>':U.icon('download',20))+' تنزيل PDF</button>';
  // Reuse the approved completeness notice on the same project scope, retaining
  // unnamed source rows for review without changing the named-project metric.
  var content=p.view==='records'?recordTable(state,m):!m.items.length?emptyState(state,m):renderDelivery(state,m.delivery);
  return '<div class="screen projects-workspace projects-pmo" data-screen="projects">'+S.ui.appHeader(state,'projects',{masthead:masthead(state,m),actions:pageTools})+'<main class="pw-main">'+filters(state,m)+pageLinks(state)+printScope(state)+sourceNotice(state)+'<div id="projects-panel">'+content+'</div>'+method(state,m)+'</main></div>';
 }

 S.projects={defaults:defaults,keys:KEYS,model:model,adapter:adapter,reportState:reportState,renderDelivery:renderDelivery,sourceNotice:sourceNotice,emptyState:emptyState,summary:summary,updateScrollHints:updateScrollHints,masthead:masthead,focusRows:focusRows,focusLabel:focusLabel,scope:scope,filters:filters,pageLinks:pageLinks,printScope:printScope,recordTableMarkup:recordTableMarkup};S.views.projects={render:render};
})(window.Saytara=window.Saytara||{});
