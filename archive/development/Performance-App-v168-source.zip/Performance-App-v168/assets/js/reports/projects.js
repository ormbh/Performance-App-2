/* Projects report: the same scoped portfolio layout as the projects dashboard. */
(function(S){
 'use strict';
 var U=S.util,R=S.rules,O=S.order,QUARTERS=['Q1','Q2','Q3','Q4','other'];
 var QLABEL={Q1:'الربع الأول',Q2:'الربع الثاني',Q3:'الربع الثالث',Q4:'الربع الرابع',other:'خارج سنة التقرير / غير مؤرخ'};
 var TYPE={Strategic:'استراتيجي',Operational:'تشغيلي'},PRIORITY={H:'عالية',M:'متوسطة',L:'منخفضة'};
 var FIELDS=[['revised','الموازنة المعتمدة'],['committed','المخصص'],['nonCommitted','غير المخصص'],['workDone','قيمة الأعمال المنجزة'],['spent','المنفق الفعلي حسب الفواتير']];
 function e(v){return U.esc(v==null?'':String(v));}
 function n(v){return U.metricText(v);}
 function val(v){return U.presentationText(v);}
 function status(it){return it.statusLabel||it.t.status||'';}
 function quarter(it){return QUARTERS.includes(it.calc.quarter)?it.calc.quarter:'other';}
 function money(cell){return U.decimalCellNumber(cell);}
 function amount(items,key){var values=items.map(function(it){return money(it.c[key]);}).filter(function(v){return v!=null;});return {value:values.length?values.reduce(function(a,b){return a+b;},0):null,known:values.length,total:items.length};}
 function matches(it,f){f=f||{};return U.selected(it.t.ptype||'',f.projectType)&&U.selected(it.t.priority||'',f.priority)&&U.selected(quarter(it),f.quarter)&&U.selected(status(it),f.projectStatus)&&U.selected(it.t.pm||'',f.pm);}
 function model(state){var base=state.data.items.filter(function(it){return it.pf==='secretariat'&&R.MET.secTotal.test(it)&&R.inScope(it,state.dash);}),f=state.report;
  var items=base.filter(function(it){return matches(it,f);}).sort(function(a,b){return S.views.reports.projectCompare(state.data,a,b);});
  var names=O.statuses(state.data,'secretariat').slice();items.forEach(function(it){if(!names.includes(status(it)))names.push(status(it));});
  var done=items.filter(function(it){return R.MET.secDone.test(it);});
  var untitled=state.data.items.filter(function(it){return it.pf==='secretariat'&&!R.MET.secTotal.test(it)&&R.inScope(it,state.dash)&&matches(it,f)&&FIELDS.some(function(f){return money(it.c[f[0]])!=null;});});
  return {excludedFinancial:untitled.length,excludedAmounts:FIELDS.map(function(f){return {name:f[1],...amount(untitled,f[0])};}),base:base,items:items,done:done,names:names,late:items.filter(function(it){return R.MET.secLate.test(it);}),active:items.filter(function(it){return R.MET.secActive.test(it);}),high:items.filter(function(it){return it.t.priority==='H';}),notes:items.filter(function(it){return String(it.t.ownerRemarks||'').trim()||String(it.t.financeRemarks||'').trim();}),finance:FIELDS.map(function(f){return {key:f[0],name:f[1],...amount(items,f[0])};})};
 }
 function filters(state,m){state.multiOptions=state.multiOptions||{};return S.projects.filters(S.projects.reportState(state),m,true);}
 function scope(state){return [['القطاع',state.dash.sector,null,'d:sector'],['الوحدة التنظيمية',state.dash.unit,null,'d:unit'],['الجهة المعنية',state.dash.entity,null,'d:entity'],['نوع المشروع',state.report.projectType,TYPE,'r:projectType'],['الأولوية',state.report.priority,PRIORITY,'r:priority'],['ربع الانتهاء',state.report.quarter,QLABEL,'r:quarter'],['الحالة',state.report.projectStatus,null,'r:projectStatus'],['مدير المشروع',state.report.pm,null,'r:pm']].filter(function(x){return U.hasSelection(x[1]);}).map(function(x){return x[0]+': '+S.filterOptions.selectionGroups(x[1],(state.multiOptions||{})[x[3]],x[3]).map(function(o){var v=S.filterOptions.display(o.v);return x[3]==='r:projectStatus'?val(S.schema.value('status',o.label)):x[2]?x[2][v]||val(o.label):val(o.label);}).join('، ');}).join(' · ')||'جميع المشاريع';}
 function excludedFinance(m){return m.excludedFinancial?'<aside class="pr-excluded"><strong>بنود مالية بلا اسم مشروع مستبعدة من إجماليات هذا التقرير: '+n(m.excludedFinancial)+'.</strong><p>'+m.excludedAmounts.filter(function(f){return f.known;}).map(function(f){return e(f.name)+': '+e(U.displayNumber(f.value,2));}).join(' · ')+' درهم إماراتي</p></aside>':'';}
 function method(){return '<p class="pr-note pd-report-method">تُحسب المشاريع المسماة ضمن عوامل التصفية مرة واحدة. المنجز بحسب الحالة المسجلة، والإنجاز متوسط النسب المسجلة. المفقود ليس صفراً. جدول المتابعة يقتصر على المشاريع التي تتطلب متابعة؛ الملاحظات نصوص مصدرية كاملة.</p>';}
 function updateEditorialContents(){
  if(typeof document==='undefined')return;
  var contents=document.querySelector('.projects-report .pd-contents'),editorial=document.querySelector('.projects-report #report-editorial');
  if(!contents||!editorial)return;
  var link=contents.querySelector('a[href="#report-editorial"]'),visible=!editorial.hidden&&!!editorial.textContent.trim();
  if(visible&&!link){link=document.createElement('a');link.href='#report-editorial';link.textContent='معلومات إضافية';contents.appendChild(link);}
  else if(!visible&&link)link.remove();
 }
 function render(state){
  if(!state.data)return '<div class="screen reports projects-report" data-screen="reports">'+S.ui.appHeader(state,'reports')+'<main class="rpt-main"><div class="pw-empty"><h1>مستجدات محفظة المشاريع</h1><p>ارفع ملف البيانات لعرض المشاريع.</p><button type="button" class="dbtn" data-act="change-file">رفع الملف</button></div></main></div>';
  state.multiOptions=state.multiOptions||{};var projectState=S.projects.reportState(state),m=S.projects.model(projectState),display=S.reportDisplay.get(state);
  return '<div class="screen reports projects-report projects-pmo" data-screen="reports">'+S.ui.appHeader(state,'reports',{masthead:S.projects.masthead(projectState,m,display),actions:S.projectPrint.utilityButton(state)})+'<main class="rpt-main"><div class="rpt-controls">'+filters(state,m)+'</div>'+S.projects.pageLinks(projectState)+S.projects.printScope(projectState)+S.reportDisplay.controls(state)+S.reportEditorial.editor(state)+'<p class="pr-result-count visually-hidden" role="status" aria-live="polite">عدد المشاريع: '+(m.items.length===0?'0':n(m.items.length))+' من أصل '+(m.base.length===0?'0':n(m.base.length))+' ضمن النطاق التنظيمي · '+e(scope(state))+'</p>'+S.projects.sourceNotice(projectState)+excludedFinance(m)+'<div id="projects-panel">'+(m.items.length?S.projects.renderDelivery(projectState,m.delivery):S.projects.emptyState(projectState,m))+'</div>'+S.reportEditorial.output(state)+method()+'</main></div>';
 }
 S.projectsReport={model:model,render:render,updateEditorialContents:updateEditorialContents,money:money,amount:amount,quarter:quarter,scope:scope,matches:matches};
})(window.Saytara=window.Saytara||{});
