# Performance App v168 development source

Approved entity report: one scoped screen/PDF renderer, separate recorded statuses and date alerts, consistent source tables, exact entity/contributor navigation and content-driven native pagination. Unnamed special-project rows are excluded consistently.

Build with `python3 tools/build-bundles.py`; check freshness with `--check`. Read DESIGN-PRINCIPLES-v168.md and VERIFICATION-v168.md. The clean end-user runtime is published separately as Performance-App-v168.zip. No workbook is included. Original fonts and native PDF engine remain unchanged.
