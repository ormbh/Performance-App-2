# Performance App v163 development source

Readable source and build tool for the council decisions report redesign. The clean user package is published separately as Performance-App-v163.zip.

Council has dynamic issuing-body status charts and the six approved columns. Decision number, issuing body and meeting date appear only when populated, above the full latest-decision text. Source eligibility, records and metrics are preserved.

Build: `python3 tools/build-bundles.py`. Check freshness with `--check`. See DESIGN-PRINCIPLES-v163.md and VERIFICATION-v163.md. Current execution evidence is published separately in repository docs/checks.
