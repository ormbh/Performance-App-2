# Current design standard — Revision 28 / v163

Read DESIGN-PRINCIPLES-v163.md for the current consolidated TEC standard. Council follows the shared report roles while retaining its explicit six-column table and source-defined follow-up charts. Decision-reference metadata omits each blank field. Agenda, HH, monthly calculations and data-quality observations remain unchanged.

VERIFICATION-v163.md records the checks and limits. Older documents retain their historical scope.
