/* Council decisions · native editable TEC PowerPoint export. Generated locally from the council report model. */
(function(S){
 'use strict';
 var U=S.util,A='http://schemas.openxmlformats.org/drawingml/2006/main',P='http://schemas.openxmlformats.org/presentationml/2006/main',C='http://schemas.openxmlformats.org/drawingml/2006/chart',R='http://schemas.openxmlformats.org/officeDocument/2006/relationships',PK='http://schemas.openxmlformats.org/package/2006/relationships',CT='http://schemas.openxmlformats.org/package/2006/content-types';
 var encoder=new TextEncoder(),decoder=new TextDecoder(),templatePromise;
 function xml(s){var d=new DOMParser().parseFromString(s,'application/xml');if(d.getElementsByTagName('parsererror').length)throw new Error('تعذّر قراءة قالب التقرير');return d;}
 // Darken neutral text only. Chart fills, approved status accents and logo artwork stay intact.
 function readableText(d){
  ['rPr','defRPr','endParaRPr'].forEach(function(tag){all(d,A,tag).forEach(function(pr){
   var fill=first(pr,A,'solidFill'),c=fill&&first(fill,A,'srgbClr');if(!c)return;
   var v=c.getAttribute('val').toUpperCase();
   if(['756B5F','ABA394','808080','C8C7C7'].includes(v))c.setAttribute('val',Number(pr.getAttribute('sz')||0)>=1800?'333333':'4F4E4E');
   if(v==='00ACA0')c.setAttribute('val','115E67');
  });});
 }
 function serial(d){readableText(d);return new XMLSerializer().serializeToString(d);}
 function all(e,ns,name){return Array.from(e.getElementsByTagNameNS(ns,name));}
 function first(e,ns,name){return e.getElementsByTagNameNS(ns,name)[0];}
 function node(d,ns,name,attrs){var n=d.createElementNS(ns,name);Object.keys(attrs||{}).forEach(function(k){if(k==='xmlns'||k.indexOf('xmlns:')===0)n.setAttributeNS('http://www.w3.org/2000/xmlns/',k,String(attrs[k]));else n.setAttribute(k,String(attrs[k]));});return n;}
 // The generated deck replaces every template slide ID. PowerPoint sections use
 // the Office 2010 namespace, not PML. Schema validation does not resolve these
 // IDs, so stale section references can survive a schema-clean export.
 function clearTemplateSlideLists(presentation){
  all(presentation,'http://schemas.microsoft.com/office/powerpoint/2010/main','sectionLst').forEach(function(list){
   var ext=list.parentNode;list.remove();
   if(ext&&ext.namespaceURI===P&&ext.localName==='ext'&&!ext.children.length){var extensions=ext.parentNode;ext.remove();if(extensions&&!extensions.children.length)extensions.remove();}
  });
  all(presentation,P,'custShowLst').forEach(function(n){n.remove();});
 }
 function clean(s){return String(s==null?'':s).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g,'');}
 function esc(s){return U.esc(clean(s));}
 function fmt(n){return U.metricText(n);}
 function pct(n,total){return total?U.displayNumber(100*n/total,1,'%'):'—';}
 function loadTemplate(){
  if(S.agendaTemplateBase64)return Promise.resolve();
  if(!templatePromise)templatePromise=new Promise(function(resolve,reject){var s=document.createElement('script');s.src='assets/js/reports/agenda-template.js';s.onload=resolve;s.onerror=function(){s.remove();templatePromise=null;reject(new Error('ملف قالب PowerPoint غير موجود. فك ضغط مجلد التطبيق كاملاً.'));};document.head.appendChild(s);});
  return templatePromise;
 }
 // ZIP writer for PPTX and its small chart workbooks. Stored entries work offline in Edge/Chrome.
 var crcTable;
 function crc32(bytes){if(!crcTable){crcTable=new Uint32Array(256);for(var i=0;i<256;i++){var c=i;for(var j=0;j<8;j++)c=c&1?0xedb88320^(c>>>1):c>>>1;crcTable[i]=c;}}var crc=0xffffffff;for(var k=0;k<bytes.length;k++)crc=crcTable[(crc^bytes[k])&255]^(crc>>>8);return (crc^0xffffffff)>>>0;}
 function zip(parts,type){
  var body=[],central=[],offset=0;
  parts.forEach(function(value,name){var bytes=typeof value==='string'?encoder.encode(value):value,n=encoder.encode(name),crc=crc32(bytes),l=new Uint8Array(30+n.length),v=new DataView(l.buffer);v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,0x800,true);v.setUint32(14,crc,true);v.setUint32(18,bytes.length,true);v.setUint32(22,bytes.length,true);v.setUint16(26,n.length,true);l.set(n,30);body.push(l,bytes);var ch=new Uint8Array(46+n.length),cv=new DataView(ch.buffer);cv.setUint32(0,0x02014b50,true);cv.setUint16(4,20,true);cv.setUint16(6,20,true);cv.setUint16(8,0x800,true);cv.setUint32(16,crc,true);cv.setUint32(20,bytes.length,true);cv.setUint32(24,bytes.length,true);cv.setUint16(28,n.length,true);cv.setUint32(42,offset,true);ch.set(n,46);central.push(ch);offset+=l.length+bytes.length;});
  var size=central.reduce(function(n,b){return n+b.length;},0),end=new Uint8Array(22),ev=new DataView(end.buffer);ev.setUint32(0,0x06054b50,true);ev.setUint16(8,parts.size,true);ev.setUint16(10,parts.size,true);ev.setUint32(12,size,true);ev.setUint32(16,offset,true);return new Blob(body.concat(central,[end]),{type:type||'application/zip'});
 }
 function shape(doc,id){return all(doc,P,'sp').find(function(s){var p=first(s,P,'cNvPr');return p&&p.getAttribute('id')===String(id);});}
 function position(el,x,y,w,h){var xf=first(el,A,'xfrm')||first(el,P,'xfrm');if(!xf)return;var off=first(xf,A,'off'),ext=first(xf,A,'ext');if(x!=null)off.setAttribute('x',Math.round(x*9525));if(y!=null)off.setAttribute('y',Math.round(y*9525));if(w!=null)ext.setAttribute('cx',Math.round(w*9525));if(h!=null)ext.setAttribute('cy',Math.round(h*9525));}
 function textProperties(doc,tag,size,font,color,rtl){
  var pr=node(doc,A,'a:'+tag,{lang:rtl?'ar-AE':'en-US',altLang:rtl?'en-US':'ar-AE',sz:Math.round(size*100),b:'0',i:'0',dirty:'0'}),fill=node(doc,A,'a:solidFill');fill.appendChild(node(doc,A,'a:srgbClr',{val:color||'4F4E4E'}));pr.appendChild(fill);
  ['latin','ea','cs'].forEach(function(n){pr.appendChild(node(doc,A,'a:'+n,{typeface:n==='latin'&&/^DIN /.test(font||'')?'Ample':font||'Dubai'}));});pr.appendChild(node(doc,A,'a:rtl',{val:rtl?'1':'0'}));return pr;
 }
 function paragraphs(doc,text,size,font,color,align){
  return clean(text).split('\n').map(function(line){
   var p=node(doc,A,'a:p'),pr=node(doc,A,'a:pPr',{algn:align||'r',rtl:'1',marL:'0',marR:'0',indent:'0'});pr.appendChild(node(doc,A,'a:lnSpc'));pr.lastChild.appendChild(node(doc,A,'a:spcPct',{val:110000}));['spcBef','spcAft'].forEach(function(n){var space=node(doc,A,'a:'+n);space.appendChild(node(doc,A,'a:spcPts',{val:0}));pr.appendChild(space);});pr.appendChild(node(doc,A,'a:buNone'));pr.appendChild(textProperties(doc,'defRPr',size,font,color,true));p.appendChild(pr);
   // Separate Latin identifiers and numbers from Arabic runs without changing source text.
   var spans=[],at=0,re=/[A-Za-z][A-Za-z0-9]*(?:[ \t]+[A-Za-z][A-Za-z0-9]*)*|[0-9]+(?:[.,:/+–-][0-9]+)*(?:[ \t]?%)?/g,m;
   while((m=re.exec(line))){if(m.index>at)spans.push({text:line.slice(at,m.index),rtl:true});spans.push({text:m[0],rtl:false});at=re.lastIndex;}if(at<line.length)spans.push({text:line.slice(at),rtl:true});if(!spans.length)spans.push({text:line,rtl:true});
   spans.forEach(function(span){var run=node(doc,A,'a:r');run.appendChild(textProperties(doc,'rPr',size,font,color,span.rtl));var t=node(doc,A,'a:t');t.textContent=span.text;run.appendChild(t);p.appendChild(run);});p.appendChild(textProperties(doc,'endParaRPr',size,font,color,true));return p;
  });
 }
 function cleanBody(doc,bp){
  ['spAutoFit','normAutofit','noAutofit'].forEach(function(n){all(bp,A,n).forEach(function(x){x.remove();});});bp.setAttribute('wrap','square');bp.setAttribute('vert','horz');bp.setAttribute('rtlCol','1');bp.setAttribute('anchorCtr','0');bp.appendChild(node(doc,A,'a:noAutofit'));
 }
 function applyBaseTextDefaults(doc){
  all(doc,A,'pPr').concat(['defPPr','lvl1pPr','lvl2pPr','lvl3pPr','lvl4pPr','lvl5pPr','lvl6pPr','lvl7pPr','lvl8pPr','lvl9pPr'].flatMap(function(n){return all(doc,A,n);})).forEach(function(pr){pr.setAttribute('rtl','1');pr.setAttribute('algn','r');});
  ['rPr','defRPr','endParaRPr'].forEach(function(tag){all(doc,A,tag).forEach(function(pr){pr.setAttribute('lang','ar-AE');pr.setAttribute('altLang','en-US');var isTitle=false,n=pr;while(n&&n!==doc){if(n.localName==='titleStyle')isTitle=true;n=n.parentNode;}var font=isTitle?'DIN Next LT Arabic':'Dubai';['latin','ea','cs'].forEach(function(tag){var f=first(pr,A,tag);if(f)f.setAttribute('typeface',font);else pr.appendChild(node(doc,A,'a:'+tag,{typeface:font}));});var rtl=first(pr,A,'rtl');if(rtl)rtl.setAttribute('val','1');else pr.appendChild(node(doc,A,'a:rtl',{val:'1'}));});});
 }
 function normalizeTemplateFonts(parts){
  parts.forEach(function(value,name){if(!/^ppt\/(theme|slideMasters|slideLayouts)\/[^/]+\.xml$/.test(name))return;var doc=xml(decoder.decode(value));
   if(name.indexOf('/theme/')>=0){['majorFont','minorFont'].forEach(function(tag){all(doc,A,tag).forEach(function(group){var font=tag==='majorFont'?'DIN Next LT Arabic':'Dubai';['latin','ea','cs'].forEach(function(n){var f=first(group,A,n);if(f)f.setAttribute('typeface',font);});all(group,A,'font').filter(function(f){return ['Arab','Latn'].includes(f.getAttribute('script'));}).forEach(function(f){f.setAttribute('typeface',font);});});});}
   else applyBaseTextDefaults(doc);parts.set(name,serial(doc));
  });
 }
 var fontPromise;
 function loadFonts(){if(S.agendaFonts)return Promise.resolve();if(!fontPromise)fontPromise=new Promise(function(resolve,reject){var s=document.createElement('script');s.src='assets/js/reports/agenda-fonts.js';s.onload=resolve;s.onerror=function(){s.remove();fontPromise=null;reject(new Error('ملفات خطوط PowerPoint غير موجودة. فك ضغط مجلد التطبيق كاملاً.'));};document.head.appendChild(s);});return fontPromise;}
 function embedReportFonts(parts,presentation,rels){
  all(presentation,P,'embeddedFontLst').forEach(function(n){n.remove();});Array.from(rels.documentElement.children).filter(function(n){return n.getAttribute('Type')===R+'/font';}).forEach(function(n){n.remove();});
  var list=node(presentation,P,'p:embeddedFontLst'),entry=node(presentation,P,'p:embeddedFont');entry.appendChild(node(presentation,P,'p:font',{typeface:S.agendaFonts.family}));
  S.agendaFonts.faces.forEach(function(face){parts.set(face.partName,S.agendaFonts.bytes(face));rels.documentElement.appendChild(node(rels,PK,'Relationship',{Id:face.relationshipId,Type:S.agendaFonts.relationshipType,Target:face.partName.replace(/^ppt\//,'')}));var font=node(presentation,P,'p:'+face.style);font.setAttributeNS(R,'r:id',face.relationshipId);entry.appendChild(font);});list.appendChild(entry);
  var root=presentation.documentElement,before=Array.from(root.children).find(function(n){return ['custShowLst','photoAlbum','custDataLst','kinsoku','defaultTextStyle','modifyVerifier','extLst'].includes(n.localName);});root.insertBefore(list,before||null);root.setAttribute('embedTrueTypeFonts','1');root.setAttribute('saveSubsetFonts','0');
 }
 function textShape(doc,id,text,opts){
  opts=opts||{};var s=shape(doc,id);if(!s)return;
  var tb=first(s,P,'txBody');if(!tb)return;
  var bp=first(tb,A,'bodyPr');bp.setAttribute('wrap','square');bp.setAttribute('lIns','0');bp.setAttribute('rIns','0');bp.setAttribute('tIns','0');bp.setAttribute('bIns','0');bp.setAttribute('anchor',opts.anchor||'t');
  all(tb,A,'p').forEach(function(p){p.remove();});cleanBody(doc,bp);
  paragraphs(doc,text,opts.size||16,opts.font||'Dubai',opts.color||'4F4E4E',opts.align).forEach(function(p){tb.appendChild(p);});
  if(opts.box)position.apply(null,[s].concat(opts.box));return s;
 }
 function slide(source){return xml(source);}
 function footer(doc,id){var el=shape(doc,id);if(el)el.remove();}
 function title(doc,id,text,box){textShape(doc,id,text,{size:21,font:'DIN Next LT Arabic',box:box||[70,35,1130,75]});}
 var canvas;
 function wrap(text,width,size){
  canvas=canvas||document.createElement('canvas');var ctx=canvas.getContext('2d');ctx.font=(size||16)+'px "TEC Dubai"';var lines=[];
  clean(text).split('\n').forEach(function(p){var line='';p.split(/\s+/).forEach(function(word){if(!word)return;var next=line?line+' '+word:word;if(ctx.measureText(next).width>width&&line){lines.push(line);line='';}if(ctx.measureText(word).width>width){for(var ch of word){if(ctx.measureText(line+ch).width>width){lines.push(line);line='';}line+=ch;}}else line=line?line+' '+word:word;});lines.push(line);});
  return lines;
 }
 async function workbook(categories,series){
  var rows=[['الفئة'].concat(series.map(function(s){return s.name;}))].concat(categories.map(function(c,i){return [c].concat(series.map(function(s){return s.values[i];}));}));
  var sheet='<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'+rows.map(function(row,r){return '<row r="'+(r+1)+'">'+row.map(function(v,c){var ref=String.fromCharCode(65+c)+(r+1);return typeof v==='number'?'<c r="'+ref+'"><v>'+v+'</v></c>':'<c r="'+ref+'" t="inlineStr"><is><t>'+esc(v)+'</t></is></c>';}).join('')+'</row>';}).join('')+'</sheetData></worksheet>';
  var parts=new Map([
   ['[Content_Types].xml','<Types xmlns="'+CT+'"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>'],
   ['_rels/.rels','<Relationships xmlns="'+PK+'"><Relationship Id="rId1" Type="'+R+'/officeDocument" Target="xl/workbook.xml"/></Relationships>'],
   ['xl/workbook.xml','<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="'+R+'"><sheets><sheet name="Data" sheetId="1" r:id="rId1"/></sheets></workbook>'],
   ['xl/_rels/workbook.xml.rels','<Relationships xmlns="'+PK+'"><Relationship Id="rId1" Type="'+R+'/worksheet" Target="worksheets/sheet1.xml"/></Relationships>'],['xl/worksheets/sheet1.xml',sheet]]);
  return new Uint8Array(await zip(parts).arrayBuffer());
 }
 function fresh(source,keep){
  var doc=slide(source),tree=first(doc,P,'spTree');
  Array.from(tree.children).forEach(function(el){if(['sp','graphicFrame','pic','grpSp','cxnSp'].includes(el.localName)){var id=first(el,P,'cNvPr');if(!id||!keep.includes(Number(id.getAttribute('id'))))el.remove();}});
  return doc;
 }
 function addText(doc,text,box,size,font,color,align){
  var tree=first(doc,P,'spTree'),id=Math.max(100,...all(doc,P,'cNvPr').map(function(n){return Number(n.getAttribute('id'));}))+1;
  var sp=node(doc,P,'p:sp'),nv=node(doc,P,'p:nvSpPr');nv.appendChild(node(doc,P,'p:cNvPr',{id:id,name:'Report text '+id}));nv.appendChild(node(doc,P,'p:cNvSpPr',{txBox:1}));nv.appendChild(node(doc,P,'p:nvPr'));sp.appendChild(nv);
  var pr=node(doc,P,'p:spPr'),xf=node(doc,A,'a:xfrm');xf.appendChild(node(doc,A,'a:off',{x:Math.round(box[0]*9525),y:Math.round(box[1]*9525)}));xf.appendChild(node(doc,A,'a:ext',{cx:Math.round(box[2]*9525),cy:Math.round(box[3]*9525)}));pr.appendChild(xf);pr.appendChild(node(doc,A,'a:noFill'));sp.appendChild(pr);
  var tb=node(doc,P,'p:txBody');tb.appendChild(node(doc,A,'a:bodyPr',{wrap:'square',lIns:0,rIns:0,tIns:0,bIns:0}));tb.appendChild(node(doc,A,'a:lstStyle'));sp.appendChild(tb);tree.appendChild(sp);textShape(doc,id,text,{box:box,size:size||16,font:font||'Dubai',color:color||'4F4E4E',align:align||'r'});return sp;
 }
 function cleanRels(source){var rel=xml(source);Array.from(rel.documentElement.children).filter(function(n){return !n.getAttribute('Type').endsWith('/slideLayout')&&!n.getAttribute('Type').endsWith('/image');}).forEach(function(n){n.remove();});return rel;}
 // Shared status appearance: OOXML uses hex without the CSS prefix.
 function statusFill(name){return S.ui.chartStatusColor(name).replace(/^#/,'');}
 function statusBorder(name){return S.ui.chartStatusBorder(name).replace(/^#/,'');}
 function statusText(name){return S.ui.statusTextColor(name).replace(/^#/,'');}
 function chartText(size,color){return '<c:txPr><a:bodyPr/><a:lstStyle/><a:p><a:pPr algn="ctr" rtl="0"><a:defRPr sz="'+(size*100)+'" lang="en-US"><a:solidFill><a:srgbClr val="'+color+'"/></a:solidFill><a:latin typeface="Ample"/><a:ea typeface="Dubai"/><a:cs typeface="Dubai"/></a:defRPr></a:pPr><a:endParaRPr lang="en-US"/></a:p></c:txPr>';}
 function chartRef(kind,formula,values){return '<c:'+kind+'Ref><c:f>'+formula+'</c:f><c:'+kind+'Cache>'+(kind==='num'?'<c:formatCode>0</c:formatCode>':'')+'<c:ptCount val="'+values.length+'"/>'+values.map(function(v,i){return '<c:pt idx="'+i+'"><c:v>'+esc(v)+'</c:v></c:pt>';}).join('')+'</c:'+kind+'Cache></c:'+kind+'Ref>';}
 function hex(value){return String(value).replace(/^#/,'');}
 function panel(doc,b,fill,border){var sp=addText(doc,'',b,12),pr=first(sp,P,'spPr');all(pr,A,'noFill').forEach(function(n){n.remove();});var geo=node(doc,A,'a:prstGeom',{prst:'roundRect'});geo.appendChild(node(doc,A,'a:avLst'));pr.appendChild(geo);var sf=node(doc,A,'a:solidFill');sf.appendChild(node(doc,A,'a:srgbClr',{val:fill||'FCFBFB'}));pr.appendChild(sf);var ln=node(doc,A,'a:ln',{w:6350}),lf=node(doc,A,'a:solidFill');lf.appendChild(node(doc,A,'a:srgbClr',{val:border||'E7E0D3'}));ln.appendChild(lf);pr.appendChild(ln);return sp;}
 async function nativeStatusBars(parts,doc,rel,index,issuer,b,spec){
  var rows=issuer.statuses,names=rows.map(function(r){return r.name;}),values=rows.map(function(r){return r.count;}),plotX=.09,plotW=.86;
  var points=rows.map(function(r,i){return '<c:dPt><c:idx val="'+i+'"/><c:spPr><a:solidFill><a:srgbClr val="'+hex(r.fill)+'"/></a:solidFill><a:ln w="9525"><a:solidFill><a:srgbClr val="'+hex(r.border)+'"/></a:solidFill></a:ln></c:spPr></c:dPt>';}).join('');
  var labels=rows.map(function(r,i){var fits=r.count/spec.max*b[2]*plotW>=String(r.count).length*9+12;return '<c:dLbl><c:idx val="'+i+'"/>'+chartText(12,hex(fits?r.ink:r.textColor))+'<c:dLblPos val="'+(fits?'ctr':'outEnd')+'"/><c:showLegendKey val="0"/><c:showVal val="1"/><c:showCatName val="0"/><c:showSerName val="0"/><c:showPercent val="0"/></c:dLbl>';}).join('');
  var chart='<?xml version="1.0" encoding="UTF-8"?><c:chartSpace xmlns:c="'+C+'" xmlns:a="'+A+'" xmlns:r="'+R+'"><c:lang val="ar-AE"/><c:chart><c:autoTitleDeleted val="1"/><c:plotArea><c:layout><c:manualLayout><c:layoutTarget val="inner"/><c:xMode val="factor"/><c:yMode val="factor"/><c:wMode val="factor"/><c:hMode val="factor"/><c:x val="'+plotX+'"/><c:y val="0"/><c:w val="'+plotW+'"/><c:h val="1"/></c:manualLayout></c:layout><c:barChart><c:barDir val="bar"/><c:grouping val="clustered"/><c:varyColors val="0"/><c:ser><c:idx val="0"/><c:order val="0"/><c:tx>'+chartRef('str','Data!$B$1',['عدد القرارات'])+'</c:tx>'+points+'<c:dLbls>'+labels+'<c:dLblPos val="ctr"/><c:showLegendKey val="0"/><c:showVal val="1"/><c:showCatName val="0"/><c:showSerName val="0"/><c:showPercent val="0"/></c:dLbls><c:cat>'+chartRef('str','Data!$A$2:$A$'+(rows.length+1),names)+'</c:cat><c:val>'+chartRef('num','Data!$B$2:$B$'+(rows.length+1),values)+'</c:val></c:ser><c:gapWidth val="80"/><c:overlap val="0"/><c:axId val="501"/><c:axId val="502"/></c:barChart><c:catAx><c:axId val="501"/><c:scaling><c:orientation val="maxMin"/></c:scaling><c:delete val="1"/><c:axPos val="r"/><c:tickLblPos val="none"/><c:crossAx val="502"/><c:crosses val="max"/><c:auto val="1"/><c:lblAlgn val="ctr"/></c:catAx><c:valAx><c:axId val="502"/><c:scaling><c:orientation val="maxMin"/><c:max val="'+spec.max+'"/><c:min val="0"/></c:scaling><c:delete val="1"/><c:axPos val="b"/><c:numFmt formatCode="0;-0;&quot;–&quot;" sourceLinked="0"/><c:tickLblPos val="none"/><c:crossAx val="501"/><c:crosses val="max"/><c:crossBetween val="between"/><c:majorUnit val="'+spec.step+'"/></c:valAx></c:plotArea><c:plotVisOnly val="1"/><c:dispBlanksAs val="zero"/></c:chart><c:spPr><a:noFill/><a:ln><a:noFill/></a:ln></c:spPr><c:externalData r:id="rIdData"><c:autoUpdate val="0"/></c:externalData></c:chartSpace>';
  parts.set('ppt/charts/chart'+index+'.xml',serial(xml(chart)));parts.set('ppt/charts/_rels/chart'+index+'.xml.rels','<Relationships xmlns="'+PK+'"><Relationship Id="rIdData" Type="'+R+'/package" Target="../embeddings/report-chart'+index+'.xlsx"/></Relationships>');parts.set('ppt/embeddings/report-chart'+index+'.xlsx',await workbook(names,[{name:'عدد القرارات',values:values}]));
  var id='rIdReportChart'+index;rel.documentElement.appendChild(node(rel,PK,'Relationship',{Id:id,Type:R+'/chart',Target:'../charts/chart'+index+'.xml'}));
  var tree=first(doc,P,'spTree'),frame=node(doc,P,'p:graphicFrame'),nv=node(doc,P,'p:nvGraphicFramePr');nv.appendChild(node(doc,P,'p:cNvPr',{id:Math.max(100,...all(doc,P,'cNvPr').map(function(n){return Number(n.getAttribute('id'));}))+1,name:'Council issuer chart '+issuer.key}));nv.appendChild(node(doc,P,'p:cNvGraphicFramePr'));nv.appendChild(node(doc,P,'p:nvPr'));frame.appendChild(nv);var xf=node(doc,P,'p:xfrm');xf.appendChild(node(doc,A,'a:off',{x:Math.round(b[0]*9525),y:Math.round(b[1]*9525)}));xf.appendChild(node(doc,A,'a:ext',{cx:Math.round(b[2]*9525),cy:Math.round(b[3]*9525)}));frame.appendChild(xf);var graphic=node(doc,A,'a:graphic'),gd=node(doc,A,'a:graphicData',{uri:C}),c=node(doc,C,'c:chart');c.setAttributeNS(R,'r:id',id);gd.appendChild(c);graphic.appendChild(gd);frame.appendChild(graphic);tree.appendChild(frame);
 }
 function compactDefinitions(doc,defs,y){
  addText(doc,'تعريفات مستويات الإنجاز',[52,y,1156,25],14,'DIN Next LT Arabic','333333','r');
  defs.forEach(function(def,i){var w=1156/3,x=1208-(i%3+1)*w,top=y+29+Math.floor(i/3)*66;panel(doc,[x+w-12,top+4,9,9],hex(def.fill),hex(def.border));addText(doc,def.name,[x+6,top,w-28,21],11,'Dubai',hex(def.textColor),'r');addText(doc,def.text,[x+6,top+22,w-22,44],10.5,'Dubai','4F4E4E','r');});
 }
 // Every source decision stays in a native table, with readable continuation for long cells.
 var TABLE_WIDTHS=[46,207,391,196,126,184],TABLE_FONT=12;
 function sourceValue(value){return U.presentationText(U.tableCellText(clean(value)));}
 function sourceField(data,it,field,value){var meta=data.meta&&data.meta.council,definition=S.schema.PF.council.fields[field];if(meta&&(!meta.found||(meta.missing||[]).includes(definition.h)))return '';return sourceValue(value===undefined?(it.t||{})[field]:value);}
 function latestMeta(it,data){return [['no','رقم القرار'],['issuer','صادر عن'],['meetingDate','تاريخ الاجتماع']].map(function(f){var value=sourceField(data,it,f[0]);return value?f[1]+': '+value:'';}).filter(Boolean).join(' · ');}
 function itemValues(it,data,number){var t=it.t||{};return [String(number),sourceField(data,it,'title',t.title||it.title),sourceField(data,it,'latest'),sourceField(data,it,'entity',t.entity||it.entity),sourceField(data,it,'status',t.status?S.councilReport.status(it,data):''),sourceField(data,it,'notes')];}
 function tablePages(items,data,offset){
  var pages=[],current=[],used=0,capacity=520;
  items.forEach(function(it,index){var number=offset+index+1,values=itemValues(it,data,number),meta=latestMeta(it,data),cells=values.map(function(value,i){var lines=[];if(i===2&&meta)wrap(meta,TABLE_WIDTHS[i]-18,14).forEach(function(text){lines.push({text:text,size:10.5,color:'756B5F',height:16});});if(value)wrap(value,TABLE_WIDTHS[i]-18,16).forEach(function(text,j){lines.push({text:text,size:12,color:i===4?statusText(value):'4F4E4E',height:18,before:i===2&&meta&&!j?4:0});});return lines;}),at=cells.map(function(){return 0;}),part=0;
   do{var shown=cells.map(function(lines,i){var out=[],height=0;while(at[i]<lines.length&&height+lines[at[i]].height+(lines[at[i]].before||0)<=capacity-20){var line=lines[at[i]++];out.push(line);height+=line.height+(line.before||0);}return out;});if(part)shown[0]=[{text:String(number)+' (تابع)',size:10.5,color:'756B5F',height:16}];var height=Math.max(48,Math.max(...shown.map(function(lines){return lines.reduce(function(n,line){return n+line.height+(line.before||0);},0);}))+20);if(current.length&&used+height>capacity){pages.push(current);current=[];used=0;}current.push({cells:shown,height:height,key:it.key,seq:it.seq,number:number,continuation:part>0});used+=height;part++;}while(cells.some(function(lines,i){return at[i]<lines.length;}));
  });if(current.length)pages.push(current);return pages;
 }
 function populateTable(doc,rows){
  var frame=first(doc,P,'graphicFrame'),old=first(frame,A,'tbl'),tbl=node(doc,A,'a:tbl'),pr=node(doc,A,'a:tblPr',{rtl:'0',firstRow:'0',bandRow:'0'}),grid=node(doc,A,'a:tblGrid');tbl.appendChild(pr);tbl.appendChild(grid);TABLE_WIDTHS.slice().reverse().forEach(function(w){grid.appendChild(node(doc,A,'a:gridCol',{w:Math.round(w*9525)}));});
  function row(cells,height,header){var tr=node(doc,A,'a:tr',{h:Math.round(height*9525)});cells.map(function(lines,i){return {lines:lines,index:i};}).reverse().forEach(function(item){var tc=node(doc,A,'a:tc'),body=node(doc,A,'a:txBody'),bp=node(doc,A,'a:bodyPr',{vert:'horz',wrap:'square',anchor:'t',rtlCol:'1'});bp.appendChild(node(doc,A,'a:noAutofit'));body.appendChild(bp);body.appendChild(node(doc,A,'a:lstStyle'));(item.lines.length?item.lines:[{text:'',size:12,color:'4F4E4E'}]).forEach(function(line){paragraphs(doc,line.text,line.size,'Dubai',line.color,item.index===0?'ctr':'r').forEach(function(p){if(header)all(p,A,'rPr').concat(all(p,A,'defRPr')).forEach(function(pr){pr.setAttribute('b','1');});if(line.before){var before=first(first(p,A,'pPr'),A,'spcBef');first(before,A,'spcPts').setAttribute('val',line.before*75);}body.appendChild(p);});});tc.appendChild(body);var props=node(doc,A,'a:tcPr',{marL:60000,marR:60000,marT:38000,marB:38000,anchor:'t'});['lnL','lnR','lnT','lnB'].forEach(function(edge){var ln=node(doc,A,'a:'+edge,{w:6350});if(edge==='lnB'){var fill=node(doc,A,'a:solidFill');fill.appendChild(node(doc,A,'a:srgbClr',{val:'EFEBE7'}));ln.appendChild(fill);}else ln.appendChild(node(doc,A,'a:noFill'));props.appendChild(ln);});var fill=node(doc,A,'a:solidFill');fill.appendChild(node(doc,A,'a:srgbClr',{val:header?'EFEBE7':'FCFBFB'}));props.appendChild(fill);tc.appendChild(props);tr.appendChild(tc);});return tr;}
  tbl.appendChild(row(['م','الموضوع','القرار الأخير','الجهة المعنية','الحالة','ملاحظات'].map(function(text){return [{text:text,size:12,color:'4F4E4E'}];}),42,true));rows.forEach(function(r){tbl.appendChild(row(r.cells,r.height,false));});old.parentNode.replaceChild(tbl,old);position(frame,52,116,1150,42+rows.reduce(function(n,r){return n+r.height;},0));
 }
 function slideLink(doc,rels,textShape,target,id){
  var rp=first(textShape,A,'rPr'),link=node(doc,A,'a:hlinkClick',{action:'ppaction://hlinksldjump'});link.setAttributeNS(R,'r:id',id);rp.insertBefore(link,first(rp,A,'rtl'));rels.documentElement.appendChild(node(rels,PK,'Relationship',{Id:id,Type:R+'/slide',Target:'slide'+target+'.xml'}));
 }
 async function build(data,scope,options){
  options=Object.assign({},options||{});
  var m=S.councilReport.model(data,scope||{},options);
  if(!m.allTotal)throw new Error('لا توجد قرارات ضمن النطاق المحدد.');
  await loadTemplate();await loadFonts();await document.fonts.ready;
  var bin=atob(S.agendaTemplateBase64),bytes=new Uint8Array(bin.length);for(var i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i);
  var archive=await S.zip.open(bytes.buffer),parts=new Map();await Promise.all(archive.names().map(async function(name){parts.set(name,await archive.read(name));}));
  normalizeTemplateFonts(parts);
  var sources={},rels={};[1,4,5].forEach(function(i){sources[i]=decoder.decode(parts.get('ppt/slides/slide'+i+'.xml'));rels[i]=decoder.decode(parts.get('ppt/slides/_rels/slide'+i+'.xml.rels'));});
  Array.from(parts.keys()).forEach(function(n){if(/^ppt\/(slides\/(slide\d+\.xml|_rels\/slide\d+\.xml\.rels)|charts\/|embeddings\/|notesSlides\/)/.test(n))parts.delete(n);});
  var slides=[],chartCount=0,contentsEntries=[],manifest=[];
  function add(doc,index){var rel=cleanRels(rels[index]);slides.push({doc:doc,rels:rel});return rel;}
  function sectionEntry(label,doc,count){contentsEntries.push({label:label,doc:doc,count:count});}
  function textPages(label,text,size){
   var lines=wrap(text,1110,(size||16)*4/3),perPage=20;
   for(var at=0;at<lines.length;at+=perPage){var d=fresh(sources[5],[2,4]);title(d,2,label+(at?' (تابع)':''),[65,35,1150,65]);footer(d,4);addText(d,lines.slice(at,at+perPage).join('\n'),[70,135,1135,510],size||16);add(d,5);if(at===0)sectionEntry(label,d,null);}
  }
  var cv=S.reportDisplay.cover(options),cover=slide(sources[1]),coverTitle=S.reportDisplay.clean(options.reportTitle,140)||('مستجدات قرارات المجالس '+U.ymd(data.today).y),entityState={data:data,dash:m.scope,report:{kind:'council'},multiOptions:S.app&&S.app.state&&S.app.state.multiOptions||{}},entity=S.views.councilPage.entityText(entityState);
  var titleHeight=Math.max(60,wrap(coverTitle,920,cv.titleSize*4/3).length*cv.titleSize*1.5),entityHeight=entity?Math.max(35,wrap(entity,920,24).length*27):0,periodHeight=Math.max(38,wrap(m.period,920,cv.periodSize*4/3).length*cv.periodSize*1.5),coverY=(720-titleHeight-entityHeight-periodHeight-(entity?32:16))/2;
  textShape(cover,4,coverTitle,{size:cv.titleSize,font:'DIN Next LT Arabic',align:'ctr',box:[180,coverY,920,titleHeight]});var nextY=coverY+titleHeight+16;if(entity){addText(cover,entity,[180,nextY,920,entityHeight],18,'Dubai','4F4E4E','ctr');nextY+=entityHeight+16;}addText(cover,m.period,[180,nextY,920,periodHeight],cv.periodSize,'Dubai','4F4E4E','ctr');add(cover,1);
  var contents=fresh(sources[5],[2,4]);title(contents,2,'محتويات التقرير',[65,35,1150,65]);footer(contents,4);var contentsRels=add(contents,5),spec=m.issuerCharts;
  for(var at=0;at<spec.panels.length;at+=2){
   var issuers=spec.panels.slice(at,at+2),summary=fresh(sources[5],[]),sr=add(summary,5);if(!at)sectionEntry('الملخص التنفيذي',summary,null);addText(summary,'القرارات التي تتطلب المتابعة',[200,28,1008,36],23,'DIN Next LT Arabic','333333','r');var grand=addText(summary,U.metricText(spec.total),[52,20,130,43],29,'DIN Next LT Arabic','333333','l');first(grand,P,'cNvPr').setAttribute('name','Council eligible total');addText(summary,'الإجمالي',[52,59,130,20],10,'Dubai','4F4E4E','l');
   var maxRows=Math.max(1,...issuers.map(function(c){return c.statuses.length;})),defsHeight=29+Math.ceil(spec.definitions.length/3)*66,rowH=Math.min(68,(674-defsHeight-30-164)/maxRows),columns=Math.min(2,spec.panels.length),w=(1156-(columns-1)*24)/columns,legendY=Math.max(310,164+maxRows*rowH+30);
   for(var pi=0;pi<issuers.length;pi++){var issuer=issuers[pi],x=52+(columns-1-pi)*(w+24),chartW=w-166,chartX=x+12,chartY=164;panel(summary,[x,94,w,Math.max(150,issuer.statuses.length*rowH+94)]);addText(summary,issuer.title,[x+90,106,w-108,50],18,'DIN Next LT Arabic','333333','r');addText(summary,U.metricText(issuer.total),[x+16,106,72,38],25,'Dubai','333333','l');
    if(issuer.statuses.length){spec.ticks.forEach(function(t){var tx=chartX+chartW*(.09+.86*(1-t/spec.max));addText(summary,U.metricText(t),[tx-16,chartY-23,32,19],10,'Dubai','4F4E4E','ctr');});issuer.statuses.forEach(function(st,ri){addText(summary,st.name,[x+w-143,chartY+(ri+.5)*rowH-13,130,30],12,'Dubai',hex(st.textColor),'r');});await nativeStatusBars(parts,summary,sr,++chartCount,issuer,[chartX,chartY,chartW,issuer.statuses.length*rowH],spec);}else addText(summary,'بيانات مستوى الإنجاز غير متاحة في المصدر.',[x+20,170,w-40,60],13,'Dubai','4F4E4E','r');
   }
   if(spec.definitions.length)compactDefinitions(summary,spec.definitions,legendY);
  }
  var other=(m.other||m.excluded.concat(m.undetermined)).slice(),otherGroups=m.otherGroups||S.councilReport.groups(data,other),recordOffset=0;
  [{groups:m.groups,label:'القرارات التي تتطلب المتابعة',count:m.items.length},{groups:otherGroups,label:m.eligibilityAvailable?'قرارات أخرى مسجلة':'قرارات لا يتاح تصنيف متابعتها',count:other.length}].forEach(function(section){var firstPage=true;section.groups.forEach(function(group){var pages=tablePages(group.items,data,recordOffset);recordOffset+=group.items.length;pages.forEach(function(rows,pageIndex){var d=fresh(sources[4],[9,4,2]);title(d,9,section.label+' — '+group.name+(pageIndex?' (تابع)':''),[62,32,1155,68]);if(!m.eligibilityAvailable)addText(d,'تصنيف متطلبات المتابعة غير متاح بسبب نقص أعمدة المصدر.',[62,91,1155,21],11,'Dubai','4F4E4E','r');footer(d,2);populateTable(d,rows);add(d,4);manifest.push({slide:slides.length,section:section.label,group:group.key,rows:rows.map(function(r){return {key:r.key,seq:r.seq,number:r.number,continuation:r.continuation};})});if(firstPage){sectionEntry(section.label,d,null);firstPage=false;}});});});
  var sourceNotes=[],sourceNoteManifest=[];
  [{key:'notes',label:'ملاحظات'},{key:'recommendations',label:'توصيات'}].forEach(function(x){if(String(options[x.key]||'').trim())textPages(x.label,options[x.key],16);});
  addText(contents,'الصفحة',[70,100,135,28],12,'Dubai','4F4E4E','l');contentsEntries.forEach(function(entry,i){var y=140+i*70,target=slides.findIndex(function(s){return s.doc===entry.doc;})+1;addText(contents,String(i+1).padStart(2,'0'),[1130,y,80,42],22,'Dubai','756B5F','r');var label=addText(contents,entry.label,[240,y,850,48],20,'DIN Next LT Arabic','333333','r'),page=addText(contents,String(target-1),[70,y,135,42],18,'Dubai','4F4E4E','l');slideLink(contents,contentsRels,label,target,'rIdCouncilContents'+i);slideLink(contents,contentsRels,page,target,'rIdCouncilPage'+i);});
  slides.forEach(function(entry,i){if(i){addText(entry.doc,String(i),[25,690,40,18],9,'Dubai','756B5F','l');addText(entry.doc,'الأمانة العامة للمجلس التنفيذي لإمارة دبي · حقوق النشر © '+U.ymd(data.today).y+' · جميع الحقوق محفوظة',[150,686,1080,22],10,'Dubai','4F4E4E','r');}if(entry.doc!==contents&&entry.doc!==cover){var nav=addText(entry.doc,'العودة إلى محتويات التقرير',[50,3,290,20],10,'DIN Next LT Arabic','756B5F','r');slideLink(entry.doc,entry.rels,nav,2,'rIdCouncilContents');}parts.set('ppt/slides/slide'+(i+1)+'.xml',serial(entry.doc));parts.set('ppt/slides/_rels/slide'+(i+1)+'.xml.rels',serial(entry.rels));});
  var presentation=xml(decoder.decode(parts.get('ppt/presentation.xml'))),ids=first(presentation,P,'sldIdLst');while(ids.firstChild)ids.firstChild.remove();var presRels=xml(decoder.decode(parts.get('ppt/_rels/presentation.xml.rels')));Array.from(presRels.documentElement.children).filter(function(r){return r.getAttribute('Type').endsWith('/slide');}).forEach(function(r){r.remove();});
  slides.forEach(function(s,i){var id=node(presentation,P,'p:sldId',{id:256+i});id.setAttributeNS(R,'r:id','rIdCouncilSlide'+i);ids.appendChild(id);presRels.documentElement.appendChild(node(presRels,PK,'Relationship',{Id:'rIdCouncilSlide'+i,Type:R+'/slide',Target:'slides/slide'+(i+1)+'.xml'}));});clearTemplateSlideLists(presentation);applyBaseTextDefaults(presentation);embedReportFonts(parts,presentation,presRels);parts.set('ppt/presentation.xml',serial(presentation));parts.set('ppt/_rels/presentation.xml.rels',serial(presRels));
  var types=xml(decoder.decode(parts.get('[Content_Types].xml')));Array.from(types.documentElement.children).filter(function(t){return /^\/ppt\/(slides\/slide\d+\.xml|charts\/|notesSlides\/|embeddings\/)/.test(t.getAttribute('PartName')||'');}).forEach(function(t){t.remove();});slides.forEach(function(s,i){types.documentElement.appendChild(node(types,CT,'Override',{PartName:'/ppt/slides/slide'+(i+1)+'.xml',ContentType:'application/vnd.openxmlformats-officedocument.presentationml.slide+xml'}));});for(var ci=1;ci<=chartCount;ci++)types.documentElement.appendChild(node(types,CT,'Override',{PartName:'/ppt/charts/chart'+ci+'.xml',ContentType:'application/vnd.openxmlformats-officedocument.drawingml.chart+xml'}));if(!Array.from(types.documentElement.children).some(function(n){return n.getAttribute('Extension')==='xlsx';}))types.documentElement.appendChild(node(types,CT,'Default',{Extension:'xlsx',ContentType:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}));if(!Array.from(types.documentElement.children).some(function(n){return n.getAttribute('Extension')==='fntdata';}))types.documentElement.appendChild(node(types,CT,'Default',{Extension:'fntdata',ContentType:S.agendaFonts.contentType}));parts.set('[Content_Types].xml',serial(types));
  var app=xml(decoder.decode(parts.get('docProps/app.xml'))),slideCount=app.getElementsByTagName('Slides')[0];if(slideCount)slideCount.textContent=slides.length;['TitlesOfParts','HeadingPairs'].forEach(function(tag){Array.from(app.getElementsByTagName(tag)).forEach(function(n){n.remove();});});parts.set('docProps/app.xml',serial(app));
  return {blob:zip(parts,'application/vnd.openxmlformats-officedocument.presentationml.presentation'),name:S.reportDisplay.fileTitle(options.reportFileTitle||('مستجدات قرارات المجالس '+U.ymd(data.today).y))+'.pptx',model:m,slides:slides.length,manifest:manifest,chartCount:chartCount,chartSpec:spec,sourceNotes:sourceNotes,sourceNoteManifest:sourceNoteManifest};
 }
 S.councilExport={build:build};
})(window.Saytara=window.Saytara||{});
