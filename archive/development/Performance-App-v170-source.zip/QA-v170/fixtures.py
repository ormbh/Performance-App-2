from pathlib import Path
import zipfile,xml.etree.ElementTree as X,hashlib,json,datetime,collections
import openpyxl
from openpyxl.formula.translate import Translator
from openpyxl.formula import Tokenizer
def norm(t):return [(x.type,x.subtype,x.value) for x in Tokenizer(t).items if x.type!="WHITE-SPACE"]
O=Path(__file__).parent
P=Path('/workspace/attachments/b603228d-d174-48ff-b672-8a36465c74b8/Performance_2026_Mold_v4.xlsx')
original_sha=hashlib.sha256(P.read_bytes()).hexdigest()
NS={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'};N='{'+NS['s']+'}'
f=openpyxl.load_workbook(P);v=openpyxl.load_workbook(P,data_only=True)
checks=[]
def ck(ok,name):checks.append({'name':name,'pass':bool(ok)});assert ok,name
def formula(ref):
 c=f['Logic'][ref];return c.value.text if hasattr(c.value,'text') else c.value
base=formula('L3')
for col in 'LMNOPQ':ck(norm(formula(col+'3'))==norm(Translator(base,origin='L3').translate_formula(col+'3')),'summary formula '+col+'3')
for col in ['BH','BI','BJ','CD']:
 for row in range(40,67):ck(norm(formula(col+str(row)))==norm(Translator(formula('BH40'),origin='BH40').translate_formula(col+str(row))),'department formula '+col+str(row))
for ref in ['L3','P10','M10','CL2','BH40']:
 t=formula(ref)
 for word in ['2026','Resolutions[تاريخ إصدار خطاب المتابعة]','Resolutions[مرجع الخطاب الصادر بالقرار]','Resolutions[سنة الاجتماع]','مغلق (لا يتطلب متابعة)','ملغي']:
  ck(word in t,ref+' contains '+word)
ck(not [(s.title,c.coordinate) for s in v for row in s for c in row if c.data_type=='e'],'no saved Excel errors')
# Patch only synthetic identification text in a separate ZIP copy. Preserve every
# other XML part including query/validation/extensions, formulas and original file.
book=X.fromstring(zipfile.ZipFile(P).read('xl/workbook.xml'))
sheets=[e.attrib['name'] for e in book.find(N+'sheets')]
columns={'المشاريع_الخاصة':'E','مشاريع_الأمانة':'F','الأجندة_السنوية':'D','القرارات':'D','التشريعات':'D'}
# Derive actual title columns from headers rather than assuming source layout.
headers={'المشاريع_الخاصة':'اسم المشروع','مشاريع_الأمانة':'اسم المشروع','الأجندة_السنوية':'الموضوع','القرارات':'الموضوع','التشريعات':'عنوان التشريع'}
changes={}
for sheet,header in headers.items():
 sh=v[sheet];column=next(c.column_letter for c in sh[1] if str(c.value or '').strip()==header)
 changes[sheet]={f'{column}{r}':f'موضوع توضيحي {sheets.index(sheet)+1}-{r-1}' for r in range(2,sh.max_row+1)}
 if sheet=='القرارات':
  for r in range(2,sh.max_row+1):changes[sheet].update({f'A{r}':'SYNTHETIC-council.xlsx',f'E{r}':f'TEST-{r-1:03}'})
def patch(dest,edits):
 with zipfile.ZipFile(P)as zin,zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED)as zout:
  for entry in zin.infolist():
   data=zin.read(entry.filename)
   for sheet,values in edits.items():
    if entry.filename!=f'xl/worksheets/sheet{sheets.index(sheet)+1}.xml':continue
    root=X.fromstring(data);sd=root.find(N+'sheetData')
    for addr,value in values.items():
     rn=''.join(filter(str.isdigit,addr));row=next((r for r in sd if r.attrib['r']==rn),None)
     if row is None:row=X.SubElement(sd,N+'row',{'r':rn})
     cell=next((c for c in row if c.attrib.get('r')==addr),None)
     if cell is None:cell=X.SubElement(row,N+'c',{'r':addr})
     for child in list(cell):cell.remove(child)
     cell.attrib['t']='inlineStr';X.SubElement(X.SubElement(cell,N+'is'),N+'t').text=value
    # New cells appended after existing ones need actual worksheet column order.
    for row in sd:row[:]=sorted(row,key=lambda c:openpyxl.utils.cell.column_index_from_string(''.join(filter(str.isalpha,c.attrib['r']))))
    data=X.tostring(root,encoding='utf-8',xml_declaration=True)
   zout.writestr(entry,data)
patch(O/'SYNTHETIC-current.xlsx',changes)
# Controlled previous snapshot changes exactly one newly eligible closed record.
s=v['القرارات']
def clean(x):return '' if x is None else str(x).replace('\xa0',' ').strip()
def year(x):
 if isinstance(x,(datetime.date,datetime.datetime)):return x.year==2026
 if isinstance(x,(int,float)):
  try:return openpyxl.utils.datetime.from_excel(x,v.epoch).year==2026
  except:return False
 return '2026' in clean(x)
eligible=[]
for row in s.iter_rows(min_row=2):
 r=[c.value for c in row];fu=clean(r[14]);ym=year(r[15])or'2026'in clean(r[9])or clean(r[7])=='2026'
 if fu in ['رسالة رسمية','بريد من الوحدة التنظيمية']or(fu in ['مغلق (لا يتطلب متابعة)','ملغي']and ym):eligible.append(r)
counts=collections.Counter(clean(r[17])for r in eligible)
ck(len(eligible)==84 and counts['منجز']==45 and counts['قيد التطوير']==29 and counts['قيد المراجعة']==5 and counts['']==5,'independent v4 raw data eligibility84 statuses45/29/5/5')
prev={k:dict(x)for k,x in changes.items()};target=next(row[0].row for row in s.iter_rows(min_row=2)if clean(row[14].value)=='مغلق (لا يتطلب متابعة)'and clean(row[17].value)=='منجز'and (year(row[15].value)or'2026'in clean(row[9].value)or clean(row[7].value)=='2026'))
prev['القرارات'].update({f'H{target}':'2025',f'J{target}':'TEST-2025',f'P{target}':'01/01/2025'})
patch(O/'SYNTHETIC-previous.xlsx',prev)
ck(hashlib.sha256(P.read_bytes()).hexdigest()==original_sha,'original retained read-only')
(O/'workbook-checks.json').write_text(json.dumps({'checks':checks,'source':P.name,'sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'expected':{'total':84,'done':45,'work':34,'late':0,'withoutStatus':5},'syntheticChangedRow':target,'excelRecalculation':'NOT RUN: no Excel calculation engine; stored formulas inspected and independent source logic tested','powerQueryRefresh':'NOT RUN'},ensure_ascii=False,indent=2))
print('PASS',len(checks),'workbook structural/source checks; controlled row',target)
