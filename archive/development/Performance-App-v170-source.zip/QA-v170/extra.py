exec(open('/workspace/saytara-work/v170-qa/verify.py').read().split('try:\n with h.Session()as ss:')[0])
E={'checks':[],'pdfs':[]}
def save():
 E['errors']=h.E['errors'];E['verdict']='PASS'if all(x['pass']for x in E['checks'])and not E['errors']else'FAIL';(O/'extra-evidence.json').write_text(json.dumps(E,ensure_ascii=False,indent=2))
try:
 with h.Session()as ss:
  p=ss.p;load(p,ss.url)
  # Explicit FollowUp selection must intersect eligibility, not redefine it.
  for fu in ['مغلق (لا يتطلب متابعة)','ملغي','رسالة رسمية','بريد من الوحدة التنظيمية','']:
   m=p.evaluate('''fu=>{const S=Saytara,d=S.app.state.data,m=S.councilReport.model(d,{},fu?{followup:[fu]}:{});return {total:m.total,all:m.allTotal,status:m.done+m.progress+m.late+m.unknownStatus,keys:m.items.map(i=>i.key)}}''',fu)
   ck(m['total']==m['status']and m['total']<=m['all'],'follow-up selection population/status reconciliation '+(fu or'All'))
  # Verify every included source row's exact organizational assignment in direct totals.
  r=p.evaluate('''()=>{const S=Saytara,d=S.app.state.data,rs=d.items.filter(i=>i.pf==='council'&&S.rules.test('councilTotal',i)),units=[...new Set(rs.map(i=>i.unit))],sectors=[...new Set(rs.map(i=>i.sector))];return {total:rs.length,units:units.map(u=>S.rules.dashboard(d,{unit:[u]}).n.councilTotal),sectors:sectors.map(s=>S.rules.dashboard(d,{sector:[s]}).n.councilTotal)}}''')
  ck(sum(r['units'])==r['total']==sum(r['sectors']),'all units and sectors conserve84 eligible source records')
  # Unknown source fields remain source; title anonymization never guessed into named records.
  load(p,ss.url,file='/workspace/attachments/b603228d-d174-48ff-b672-8a36465c74b8/Performance_2026_Mold_v4.xlsx')
  ck(p.evaluate('Saytara.rules.dashboard(Saytara.app.state.data,{}).n.councilTotal')==0,'original anonymized v4 still excluded by nonblank-title requirement')
  ck(p.evaluate('Saytara.app.state.data.items.filter(i=>i.pf==="council").length')==152,'all nonempty anonymized source rows retained; fully blank rows skipped')
  # Entity reports intentionally remain the full entity register, not follow-up-only.
  load(p,ss.url)
  p.evaluate("Saytara.app.state.entity={entity:['دائرة الأراضي والأملاك'],role:['primary'],areas:[],mode:'',area:'',status:[],q:'',kind:''};Saytara.app.go('entities')")
  pr=export(p,'entity-regression','.er-record-table');p.screenshot(path=str(O/'entity-screen.png'),full_page=True)
  # Selected monthly entity scope uses the shared follow-up rule, distinct from full register.
  p.evaluate("Saytara.app.state.dash.entity=['دائرة الأراضي والأملاك'];Saytara.app.state.dash.entityMode='concerned';Saytara.app.go('dashboard')")
  r=p.evaluate('''()=>{const S=Saytara,s=S.app.state;return {total:S.rules.dashboard(s.data,s.dash).n.councilTotal,report:S.councilReport.model(s.data,s.dash,{}).total}}''')
  ck(r['total']==r['report'],'monthly entity filter and council report follow-up total match')
  # All excluded rows: charts and legend disappear; register remains intact.
  load(p,ss.url);p.evaluate('''()=>{const s=Saytara.app.state;for(const i of s.data.items.filter(i=>i.pf==='council')){for(const [k,v]of Object.entries({followup:'مغلق (لا يتطلب متابعة)',year:2025,letterRef:'TEST/2025',letterDate:'01/01/2025'})){i.c[k]={t:typeof v==='number'?'n':'s',v};i.t[k]=String(v);i.x[k]=String(v).toLowerCase();}}s.report.kind='council';Saytara.app.go('reports')}''')
  ck(p.locator('main .cr-issuer-panel').count()==0 and p.locator('main .cr-chart-overview').count()==0,'no eligible decisions hides chart and legend')
  ck(p.locator('main .cr-table tbody tr').count()==153,'no eligible decisions retains full other-record register')
  pr=export(p,'council-excluded-only','.cr-table');ck('قرارات أخرى مسجلة'in pr['rootText'],'excluded-only PDF identifies other registered decisions')
  ck(not h.E['errors'],'no shared entity/report runtime regressions');save()
except Exception:
 E['exception']=traceback.format_exc();save();raise
print(E['verdict'],len(E['checks']),'extra checks',flush=True);assert E['verdict']=='PASS'
