from pathlib import Path
import sys,json,hashlib,fitz,traceback
sys.path.insert(0,'/workspace/saytara-work/v155-qa');import harness as h
sys.path.insert(0,'/workspace/saytara-work/v167-qa/pdf');import check as pq
O=Path(__file__).parent;E={'checks':[],'pdfs':[]};ROOT='/v170-clean/Performance-App/index.html'
def ck(ok,name,detail=None):
 E['checks'].append({'pass':bool(ok),'name':name,'detail':detail if not ok else None})
 if not ok:print('FAIL',name,str(detail)[:500],flush=True)
def save():
 E['errors']=h.E['errors'];E['verdict']='PASS' if all(x['pass'] for x in E['checks'])and not E['errors']else'FAIL';(O/'evidence.json').write_text(json.dumps(E,ensure_ascii=False,indent=2))
def load(p,url,file=O/'SYNTHETIC-current.xlsx',version=ROOT):
 if p.url.startswith('http'):p.evaluate('sessionStorage.clear()')
 p.goto(url+version);p.locator('input[type=file]').first.set_input_files(file);p.wait_for_function('(name)=>!!Saytara.app.state.data&&Saytara.app.state.data.file.name===name',arg=Path(file).name);p.evaluate('document.fonts.ready');p.locator('#toast').wait_for(state='hidden',timeout=10000)
def export(p,name,selector=None):
 p.evaluate('document.fonts.ready');p.locator('#toast').wait_for(state='hidden',timeout=10000)
 # Each export uses one collector hook; its selector can be changed between screens.
 if not p.evaluate('!!window.__pdfProofHook'):p.evaluate(pq.HOOK.replace('.portfolio-record-table',('#entity-print-report .er-record-table' if selector=='.er-record-table' else selector or '.cr-table')))
 rows=p.locator('main '+selector+' tbody tr').evaluate_all('es=>es.map(e=>e.dataset.record)')if selector else None
 with p.expect_download(timeout=120000)as dl:p.locator('[data-act="download-pdf"]').first.click()
 file=O/(name+'.pdf');dl.value.save_as(file);p.wait_for_function('!Saytara.app.state.pdfDownloading',timeout=120000)
 pr=p.evaluate('window.__pdfProof');(O/(name+'-proof.json')).write_text(json.dumps(pr,ensure_ascii=False,indent=2));doc=fitz.open(file)
 ck(len(doc)==len(pr['plan']),name+' native page plan');ck(not pr['overflow'],name+' no print overflow');ck(not pr['omitted'],name+' all native text lines placed',pr['omitted'][:5]);ck(all((abs(pg.rect.width-841.89)<1 and pg.rect.height>841.89) if name=='monthly-continuous' else ((abs(pg.rect.width-841.89)<1 and abs(pg.rect.height-595.28)<1) if name.startswith('council-') else (abs(pg.rect.width-595.28)<1 and abs(pg.rect.height-841.89)<1)) for pg in doc),name+' approved page geometry')
 if rows is not None:ck(rows==pr['rows'],name+' screen/PDF source row sequence',{'screen':len(rows),'pdf':len(pr['rows'])})
 bad=[];blank=[]
 for i,pg in enumerate(doc):
  if not pg.get_text().strip():blank.append(i+1)
  for b in pg.get_text('dict')['blocks']:
   for l in b.get('lines',[]):
    for s in l['spans']:
     box=s['bbox']
     if '\ufffd'in s['text']or box[0]<-1 or box[1]<-1 or box[2]>pg.rect.width+1 or box[3]>pg.rect.height+1:bad.append((i+1,s['text'],box))
  pg.get_pixmap(matrix=fitz.Matrix(.65,.65)).save(O/f'{name}-{i+1}.png')
 ck(not bad,name+' native glyphs and page bounds',bad[:10]);ck(not blank,name+' no blank pages',blank)
 ck(all(l.get('page',0)<len(doc)for pg in doc for l in pg.get_links()),name+' valid PDF link destinations')
 E['pdfs'].append({'name':name,'pages':len(doc),'rows':len(rows)if rows is not None else None,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()});save();return pr
MODEL=r'''()=>{const S=Saytara,R=S.rules,d=S.app.state.data,template=d.items.find(x=>x.pf==='council'),tests=[],clone=x=>structuredClone(x);
 const ck=(pass,name,detail)=>tests.push({pass:!!pass,name,detail:pass?null:detail});
 const f=(i,k,v)=>{if(v==null){delete i.c[k];i.t[k]='';i.x[k]='';i.k[k]='';return}i.c[k]={t:typeof v==='number'?'n':'s',v};i.t[k]=String(v);i.x[k]=String(v).toLowerCase();i.k[k]=String(v).toLowerCase();i[k]=v};
 const item=(followup,opts={})=>{let i=clone(template);['year','letterRef','letterDate'].forEach(k=>f(i,k,null));f(i,'title','قرار توضيحي');f(i,'followup',followup);f(i,'status','منجز');Object.entries(opts).forEach(([k,v])=>f(i,k,v));return i};
 for(const fu of ['رسالة رسمية','بريد من الوحدة التنظيمية','مغلق (لا يتطلب متابعة)','ملغي','','غير معتمد']){
  const unconditional=['رسالة رسمية','بريد من الوحدة التنظيمية'].includes(fu),conditional=['مغلق (لا يتطلب متابعة)','ملغي'].includes(fu);
  for(const [label,opts,match]of [['no year',{},false],['numeric meeting year',{year:2026},true],['text meeting year',{year:'2026'},true],['numeric date',{letterDate:S.util.serial(2026,2,2)},true],['text date',{letterDate:'02/02/2026'},true],['letter reference',{letterRef:'TEC/2026/123'},true],['all alternatives',{year:2026,letterDate:S.util.serial(2026,2,2),letterRef:'2026'},true],['old year',{year:2025,letterDate:S.util.serial(2025,12,31),letterRef:'2025'},false],['future year',{year:2027},false]]){
   const i=item(fu,opts),expected=unconditional||conditional&&match;ck(R.test('councilTotal',i)===expected,fu+' '+label+' eligibility');ck(R.test('councilDone',i)===expected,fu+' '+label+' completed does not override');
  }
 }
 for(const title of ['', '  ', '\u00a0'])ck(!R.test('councilTotal',item('رسالة رسمية',{title})),'blank/whitespace subject excluded '+JSON.stringify(title));
 ck(R.test('councilTotal',item('  ملغي\u00a0',{year:' 2026 '})),'Excel trim/NBSP compatibility');
 ck(!R.test('councilTotal',item('مغلق (لا يتطلب متابعة)',{meetingDate:S.util.serial(2026,1,1)})),'meeting date is not an approved eligibility alternative');
 for(const status of ['منجز','قيد التطوير','قيد المراجعة','متأخر','', 'ملغى']){const i=item('ملغي',{year:2026,status});ck(R.test('councilTotal',i),'included conditional independent of status '+status);ck(R.test('councilDone',i)===(status==='منجز'),'done classification '+status);ck(R.test('councilProgress',i)===['قيد التطوير','قيد المراجعة'].includes(status),'work classification '+status);}
 const one=i=>{let z=clone(d);z.items=[i];z.byPf={...z.byPf,council:[i]};return z};
 let z=one(item('ملغي'));z.meta.council.missing=[S.schema.PF.council.fields.letterDate.h];ck(!R.metricAvailable(z,'councilTotal',{}),'missing year alternative reports unavailable when classification ambiguous');
 z=one(item('رسالة رسمية'));z.meta.council.missing=[S.schema.PF.council.fields.letterDate.h];ck(R.metricAvailable(z,'councilTotal',{}),'default follow-up requires no year columns');
 z=one(item('ملغي',{year:2026}));z.meta.council.missing=[S.schema.PF.council.fields.letterDate.h];ck(R.metricAvailable(z,'councilTotal',{}),'known positive witness sufficient with another alternative missing');
 const before=one(item('مغلق (لا يتطلب متابعة)',{year:2025})),after=clone(before);f(after.items[0],'year',2026);after.byPf.council=after.items;
 for(const metric of ['councilTotal','councilDone']){const x=S.comparison.insights.detail(before,after,{},metric);ck(x.previous===0&&x.current===1&&x.residual===0&&x.stats.in===1,'year-only entry exact contribution '+metric,x)}
 return tests}'''
try:
 with h.Session()as ss:
  p=ss.p;load(p,ss.url)
  for x in p.evaluate(MODEL):ck(x['pass'],x['name'],x.get('detail'))
  actual=p.evaluate("(()=>{const n=Saytara.rules.dashboard(Saytara.app.state.data,{}).n;return [n.councilTotal,n.councilDone,n.councilProgress,n.councilLate,n.councilNoStatus,n.councilExcluded]})()")
  ck(actual==[84,45,34,0,5,69],'synthetic v4 independent/source/app reconciliation',actual)
  # All noncouncil calculations must agree exactly with verified v169 for same source.
  new=p.evaluate('Saytara.rules.dashboard(Saytara.app.state.data,{}).n');load(p,ss.url,version='/v169-clean/Performance-App/index.html');old=p.evaluate('Saytara.rules.dashboard(Saytara.app.state.data,{}).n');ck({k:v for k,v in new.items()if not k.startswith('council')}=={k:v for k,v in old.items()if not k.startswith('council')},'shared noncouncil aggregate regression against v169')
  load(p,ss.url);ss.scope('council')
  model=p.evaluate('Saytara.councilReport.model(Saytara.app.state.data,{},{}).issuerCharts');ck(sum(x['total']for x in model['panels'])==84,'issuer chart totals reconcile84');ck(all(sum(y['count']for y in x['statuses'])==x['total']for x in model['panels']),'issuer status distributions reconcile');ck(p.locator('main .cr-table tbody tr').count()==153,'register retains all153 rows including69 excluded')
  for width in [1440,768,390]:
   p.set_viewport_size({'width':width,'height':1100});ck(not p.evaluate('document.documentElement.scrollWidth>innerWidth+1'),f'council {width} no body overflow')
  p.set_viewport_size({'width':1440,'height':1100});p.screenshot(path=str(O/'council-screen.png'),full_page=True)
  pr=export(p,'council-all','.cr-table');ck('2026'in pr['rootText'],'council source periods preserved')
  # Sector/unit/union/intersection selections reconcile shared metric and report model.
  results=p.evaluate('''()=>{const S=Saytara,d=S.app.state.data,rows=d.items.filter(i=>i.pf==='council'),units=[...new Set(rows.map(i=>i.unit))].slice(0,2),sectors=[...new Set(rows.map(i=>i.sector))].slice(0,2);return [{unit:[units[0]]},{sector:[sectors[0]]},{unit:units},{sector:[sectors[0]],unit:[units[0]]},{unit:['__EMPTY__']}].map(scope=>{const n=S.rules.dashboard(d,scope).n,m=S.councilReport.model(d,scope,{});return {scope,n:n.councilTotal,total:m.total,reconciled:m.reconciled,keys:m.items.map(i=>i.key)}})}''')
  for r in results:ck(r['n']==r['total']and r['reconciled'],'sector/unit/union/intersection report agreement '+str(r['scope']))
  unit=p.evaluate("Saytara.app.state.data.items.find(i=>i.pf==='council'&&Saytara.rules.test('councilTotal',i)).unit");ss.scope('council',unit=[unit]);p.screenshot(path=str(O/'council-filtered-screen.png'),full_page=True);export(p,'council-filtered','.cr-table')
  ss.scope('council',unit=['__EMPTY__']);ck(p.locator('main .cr-table').count()==0 and p.locator('main .cr-issuer-panel').count()==0,'empty scope hides tables/charts');export(p,'council-empty','.cr-table')
  # Fresh document resets collector to match monthly instead of council tables.
  load(p,ss.url);p.evaluate("Saytara.app.go('dashboard')");ck('84'in p.locator('.wb-council').inner_text()and'45'in p.locator('.wb-council').inner_text(),'monthly card agrees84/45');p.screenshot(path=str(O/'monthly-screen.png'),full_page=True);pr=export(p,'monthly-continuous');ck('84'in pr['rootText']and'45'in pr['rootText'],'monthly native PDF same source totals')
  p.evaluate("Saytara.monthlyTools.setLayout(Saytara.app.state,'a4');Saytara.app.go('dashboard')");pr=export(p,'monthly-a4');ck('84'in pr['rootText']and'45'in pr['rootText'],'monthly A4 same council totals')
  # Current/previous complete pair: single closed-row 2025→2026 entry.
  p.evaluate("Saytara.app.go('comparison')");p.locator('#previous-file-input').set_input_files(O/'SYNTHETIC-previous.xlsx');p.wait_for_function('!!Saytara.app.state.previous&&!Saytara.app.state.comparison.busy');p.evaluate("""()=>{const s=Saytara.app.state;s.comparison.previous={date:'2026-08-31',confirmed:true};s.comparison.current={date:'2026-09-30',confirmed:true};Saytara.app.saveComparison();Saytara.app.go('dashboard')}""")
  cmp=p.evaluate("Saytara.comparison.insights.detail(Saytara.app.state.previous,Saytara.app.state.data,{},'councilDone')");ck(cmp['previous']==44 and cmp['current']==45 and cmp['residual']==0 and cmp['stats']['in']==1,'paired source comparison44→45 only correct contributor')
  p.locator('[data-act="compare-metric"][data-metric="councilDone"]').first.click();ck(p.evaluate('Saytara.app.state.comparison.view.metric')=='councilDone','monthly delta lands on exact councilDone');ck(p.locator('main .cmp-record-table tbody tr').count()==1,'monthly delta highlights single council change');p.screenshot(path=str(O/'comparison-screen.png'),full_page=True)
  # The hook installed earlier captures monthly rows; install fresh selector by restoring original via reload.
  p.reload();p.wait_for_function('typeof Saytara!=="undefined"&&!!Saytara.app?.state.previous&&!Saytara.app.state.comparison.busy');pr=export(p,'comparison-council','.cmp-record-table');ck('2026-08-31'in pr['rootText']and'2026-09-30'in pr['rootText'],'comparison native PDF retains both periods')
  ck(not h.E['errors'],'no browser runtime errors');ck(not h.E['blockedRequests'],'no external workbook/asset requests');E['assets']=h.E.get('loadedAssetHashes');save()
except Exception:
 E['exception']=traceback.format_exc();save();raise
print(E['verdict'],len(E['checks']),'focused checks',flush=True)
assert E['verdict']=='PASS'
