exec(open('/workspace/saytara-work/v169-qa/verify.py').read().split('try:\n with h.Session()as ss:')[0])
E={'checks':[],'pdfs':[]}
def save():
 E['errors']=h.E['errors'];E['verdict']='PASS'if all(x['pass']for x in E['checks'])and not E['errors']else'FAIL';(O/'final-checks.json').write_text(json.dumps(E,ensure_ascii=False,indent=2))
try:
 with h.Session()as ss:
  p=ss.p;load(p,ss.url);pair(p)
  model=p.evaluate('''()=>{const S=Saytara,I=S.comparison.insights,base=S.app.state.data,one=pf=>{let d=structuredClone(base);d.items=[structuredClone(base.items.find(i=>i.pf===pf&&i.hasTitle))];return d},clone=d=>structuredClone(d),f=(i,k,v)=>{i[k]=v;i.t[k]=String(v);i.x[k]=String(v).toLowerCase();i.c[k]={t:typeof v==='number'?'n':'s',v}};
   let a=one('special'),b=clone(a);f(a.items[0],'status','قيد التطوير');f(b.items[0],'status','منجز');a.items[0].statusLabel='قيد التطوير';b.items[0].statusLabel='منجز';f(a.items[0],'unit','أ');f(b.items[0],'unit','ب');let d=I.detail(a,b,{},'specialDone');let e=d.rows[0].organizationEffects.filter(x=>x.level==='unit');
   let rawNotes=clone(a);f(rawNotes.items[0],'notes','نص توضيحي');let raw=S.comparison.compare(a,rawNotes,{});
   let q=one('secretariat'),z=clone(q);f(q.items[0],'status','Active');f(z.items[0],'status','Active');f(q.items[0],'end',S.util.serial(2026,9,1));f(z.items[0],'end',S.util.serial(2026,9,1));S.rules.calc(q.items[0],S.util.serial(2026,9,30));S.rules.calc(z.items[0],S.util.serial(2026,10,1));let timing=I.detail(q,z,{},'secLate');
   return {unitEffects:e,rawNotes:raw.rows[0].changes.some(x=>x.key==='notes'),timing:{before:timing.previous,after:timing.current,contribution:timing.rows[0]?.contribution,calculated:timing.rows[0]?.calculatedOnly}}}''')
  ck(model['unitEffects']==[{'level':'unit','label':'ب','value':1}],'compound change does not subtract a done item the old unit never held',model)
  ck(model['rawNotes'],'entity/shared raw comparison sees source note edits')
  ck(model['timing']=={'before':0,'after':1,'contribution':1,'calculated':True},'real date recalculation separated from source edits',model['timing'])
  # Persist a full-record comparison view through reload, including its list intent.
  p.evaluate("Saytara.app.state.comparison.showRecords=true;Saytara.app.state.comparison.view={metric:'',type:'changes',q:''};Saytara.app.go('comparison')");p.evaluate('Saytara.app.saveComparison()');p.reload();p.wait_for_function('typeof Saytara!=="undefined"&&!!Saytara.app?.state.previous&&!Saytara.app.state.comparison.busy');ck(p.locator('#cmp-detail').count()==1,'all-record changes route survives refresh')
  # Verify populated transfer presentation with an in-memory unit change only.
  p.evaluate('''()=>{const s=Saytara.app.state,i=s.data.items.find(x=>x.pf==='special'&&x.hasTitle);i.unit='وحدة توضيحية';i.t.unit=i.unit;i.x.unit=i.unit;i.c.unit={t:'s',v:i.unit};s.comparison.view={metric:'specialGsDone',type:'impact',q:''};Saytara.app.go('comparison')}''');ck(p.locator('.cmp-movements table').count()>0,'affected organizational levels visible');pr=pdf(p,'comparison-transfer');ck('وحدة توضيحية'in pr['rootText'],'transfer counterpart retained in native PDF');p.screenshot(path=str(O/'transfer-final.png'),full_page=True)
  # Color and field emphasis use real data and text, not color alone.
  ck(p.locator('main .cmp-field-focus').count()>0,'relevant changed fields highlighted');colors=p.locator('.cmp-status-legend span').evaluate_all('es=>es.slice(0,3).map(x=>getComputedStyle(x).color)');ck(colors==['rgb(17, 94, 103)','rgb(1, 131, 30)','rgb(192, 0, 0)'],'approved ready/done/late colors',colors)
  p.evaluate("Saytara.app.state.comparison.view={metric:'',type:'unresolved',q:'__NO_MATCH__'};Saytara.app.state.comparison.showRecords=true;Saytara.app.go('comparison')");ck(p.locator('main .cmp-record-table tbody tr').count()==0,'unresolved search filters its actual rows');pr=pdf(p,'comparison-unresolved-search');ck('__NO_MATCH__' in pr['rootText'] and not pr['rows'],'unresolved query and zero matching rows agree in native PDF')
  p.locator('[data-act="comparison-back"]').click();p.evaluate("window.open=()=>null");p.locator('[data-act="compare-metric"]').first.evaluate('(e)=>e.dispatchEvent(new MouseEvent("click",{bubbles:true,ctrlKey:true}))');ck(p.evaluate('Saytara.app.state.screen')=='dashboard'and p.evaluate('!!Saytara.app.state.previous'),'blocked popup preserves current view and pair');
  # One shared entity export is unchanged by expanded comparison fields and collector support.
  p.evaluate("Saytara.app.state.entity={entity:['دائرة الأراضي والأملاك'],role:['primary'],areas:[],mode:'',area:'',status:[],q:'',kind:''};Saytara.app.go('entities')");
  with p.expect_download(timeout=60000)as dl:p.locator('[data-act="download-pdf"]').first.click()
  dl.value.save_as(O/'entity-regression-v169.pdf');doc=fitz.open(O/'entity-regression-v169.pdf');ck(len(doc)==4,'entity native PDF retains verified four-page plan');
  p.evaluate("Saytara.app.state.comparison.view={metric:'specialTotal',type:'impact',q:''};Saytara.app.go('comparison')");p.locator('.cmp-setup').evaluate('(e)=>e.open=true');p.locator('[data-act="clear-comparison-file"][data-role="previous"]').click();ck(p.evaluate('Saytara.app.state.comparison.view.metric')=='specialTotal','clearing a file retains intended drill for replacement')
  # No source mutation by the full test run.
  ck(hashlib.sha256(h.FIX.read_bytes()).hexdigest()=='4b10d057090cf522d73c28667d29b1875b0d7b37e75892f5eb676c82b7fbcf08','original illustrative workbook unchanged')
  E['assets']=h.E.get('loadedAssetHashes',{});save()
except Exception:
 E['exception']=traceback.format_exc();save();raise
print(E['verdict'],len(E['checks']),'final focused checks',flush=True)
