from pathlib import Path
import sys,json,hashlib,fitz,traceback
sys.path.insert(0,'/workspace/saytara-work/v155-qa');import harness as h
sys.path.insert(0,'/workspace/saytara-work/v167-qa/pdf');import check as pdfqa
O=Path('/workspace/saytara-work/v169-qa');E={'checks':[],'pdfs':[]}
def ck(b,n,d=None):
 E['checks'].append({'name':n,'pass':bool(b),'detail':d if not b else None})
 if not b:print('FAIL',n,str(d)[:600],flush=True)
def save():
 E['errors']=h.E['errors'];E['verdict']='PASS'if all(x['pass']for x in E['checks'])and not E['errors']else'FAIL';(O/'evidence.json').write_text(json.dumps(E,ensure_ascii=False,indent=2))
def load(p,url,file=h.FIX):
 p.goto(url+'/v169-clean/Performance-App/index.html');p.locator('input[type=file]').first.set_input_files(file);p.wait_for_function('!!Saytara.app.state.data');p.evaluate('Saytara.app.saveComparison()');p.locator('#toast').wait_for(state='hidden',timeout=10000)
def pair(p):
 p.evaluate("Saytara.app.go('comparison')");p.locator('#previous-file-input').set_input_files('/workspace/saytara-work/comparison-study/ILLUSTRATIVE-previous.xlsx');p.wait_for_function('!!Saytara.app.state.previous&&!Saytara.app.state.comparison.busy');p.evaluate("""()=>{const s=Saytara.app.state;s.comparison.previous={date:'2026-08-31',confirmed:true};s.comparison.current={date:'2026-09-30',confirmed:true};Saytara.app.saveComparison();Saytara.app.go('dashboard')}""")
def pdf(p,name):
 pdfqa.OUT=O;pdfqa.E={'checks':[],'pdfs':[],'errors':[]};hook=pdfqa.HOOK.replace('.portfolio-record-table','.cmp-record-table');p.evaluate(hook);p.evaluate('document.fonts.ready');p.locator('#toast').wait_for(state='hidden',timeout=10000)
 keys=p.locator('main .cmp-record-table tbody tr').evaluate_all('es=>es.map(x=>x.dataset.record)')
 with p.expect_download(timeout=30000)as dl:p.locator('[data-act="download-pdf"]').first.click()
 path=O/(name+'.pdf');dl.value.save_as(path);p.wait_for_function('!Saytara.app.state.pdfDownloading',timeout=180000);pr=p.evaluate('window.__pdfProof');(O/(name+'-proof.json')).write_text(json.dumps(pr,ensure_ascii=False,indent=2));d=fitz.open(path)
 ck(len(d)==len(pr['plan']),name+' exact native page plan');ck(keys==pr['rows'],name+' same ordered source rows',{'screen':keys,'pdf':pr['rows']});ck(not pr['overflow'],name+' no print overflow');ck('2026-08-31' in pr['rootText'] and '2026-09-30' in pr['rootText'],name+' prints both snapshot dates');ck(not [x for x in pr['headerBounds'] if any(r['x']<x['cell']['x']-.5 or r['x']+r['w']>x['cell']['x']+x['cell']['w']+.5 for r in x['rects'])],name+' Arabic headings fit their columns');ck(not pr['omitted'],name+' all native text lines placed',pr['omitted'][:10]);ck(all(abs(pg.rect.width-595.28)<1 and abs(pg.rect.height-841.89)<1 for pg in d),name+' A4 portrait')
 bad=[];fonts=set()
 for i,pg in enumerate(d):
  pg.get_pixmap(matrix=fitz.Matrix(1.2,1.2)).save(O/f'{name}-{i+1}.png')
  for b in pg.get_text('dict')['blocks']:
   for l in b.get('lines',[]):
    for s in l['spans']:
     fonts.add(s['font']);b=s['bbox']
     if b[0]<-1 or b[1]<-1 or b[2]>pg.rect.width+1 or b[3]>pg.rect.height+1 or '\ufffd'in s['text']:bad.append((i,s['text'],b))
 ck(not bad,name+' native glyphs and bounds',bad[:10]);E['pdfs'].append({'name':name,'pages':len(d),'rows':len(keys),'fonts':sorted(fonts),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()});save();return pr
MODEL=r'''()=>{const S=Saytara,C=S.comparison,I=C.insights,d=S.app.state.data,clone=x=>structuredClone(x),tests=[];
const one=pf=>{let z=clone(d);z.items=[clone(d.items.find(i=>i.pf===pf&&i.hasTitle&&C.identity(i).value))];return z};
const f=(i,k,v)=>{i[k]=v;i.t[k]=String(v);i.x[k]=String(v).toLowerCase();i.c[k]={t:typeof v==='number'?'n':'s',v}};
const ck=(pass,name,detail)=>tests.push({pass:!!pass,name,detail:pass?null:detail});
const a=one('special'),b=clone(a),u=a.items[0].unit;f(b.items[0],'unit','وحدة اختبار');f(a.items[0],'status','قيد التطوير');f(b.items[0],'status','منجز');a.items[0].statusLabel='قيد التطوير';b.items[0].statusLabel='منجز';
for(const [name,scope,metric,p,c,i,o]of[['old-unit',{unit:u},'specialTotal',1,0,0,1],['new-unit',{unit:'وحدة اختبار'},'specialTotal',0,1,1,0],['global-conservation',{},'specialTotal',1,1,0,0],['compound-status',{},'specialDone',0,1,1,0],['unit-union',{unit:[u,'وحدة اختبار']},'specialTotal',1,1,0,0]]){const x=I.detail(a,b,scope,metric);ck(x.previous===p&&x.current===c&&x.stats.in===i&&x.stats.out===o&&x.residual===0,name,x);ck(x.rows.every(r=>r.before&&r.after&&r.organizational),name+' exact match retained',x.rows)}
let q=one('special'),z=clone(q);f(z.items[0],'notes','ملاحظة توضيحية معدلة');let n=I.detail(q,z,{},'specialTotal');ck(n.stats.changed===1&&n.rows[0].contribution===0&&I.filtered(n,{type:'impact'}).total===0&&I.filtered(n,{type:'other'}).total===1,'notes edit detected outside count impact',n.stats);
for(const pf of ['secretariat','legislation']){let p=one(pf),c=clone(p);f(c.items[0],'sector','قطاع اختبار');let r=I.detail(p,c,{},pf==='secretariat'?'secTotal':'legTotal');ck(r.rows.length===0&&r.unresolved.length===2,pf+' mutable key quarantined, no guessed match',r)}
q=one('special');z=clone(q);z.items.push(clone(z.items[0]));n=C.compare(q,z,{});ck(n.rows.length===0&&n.unresolved.length===3,'duplicate keys quarantine both sides',n);
q=one('special');z=clone(q);delete z.items[0].c.sourceName;n=C.compare(q,z,{});ck(n.rows.length===0&&n.unresolved.length===2,'blank keys unresolved',n);
q=one('secretariat');z=clone(q);f(q.items[0],'revised',100000);f(z.items[0],'revised',120000);n=I.detail(q,z,{},'budApproved');ck(n.previous===100000&&n.current===120000&&n.contributionTotal===20000&&n.residual===0,'money uses amount contribution',n);
z.meta.secretariat.found=false;n=I.detail(q,z,{},'budApproved');ck(n.current===null,'missing table is unavailable, not zero',n.current);
q=one('special');z=clone(q);let two=clone(q.items[0]);f(two,'title','مشروع مختلف');two.title='مشروع مختلف';f(q.items[0],'unit','أ');f(z.items[0],'unit','ب');f(two,'unit','ب');q.items.push(two);let moved=clone(two);f(moved,'unit','أ');z.items.push(moved);n=I.detail(q,z,{unit:'أ'},'specialTotal');ck(n.current===1&&n.previous===1&&n.stats.in===1&&n.stats.out===1&&I.filtered(n,{type:'impact'}).total===2,'zero-net includes both directions',n);
q=one('special');z=clone(q);z.items[0].health=q.items[0].health==='delayed'?'doneLate':'delayed';n=I.detail(q,z,{},'specialTotal');ck(n.rows[0].calculatedOnly&&n.rows[0].contribution===0,'calculation-only timing change separated',n.rows[0]);return tests}'''
try:
 with h.Session()as ss:
  p=ss.p;load(p,ss.url);E['model']=p.evaluate(MODEL)
  for x in E['model']:ck(x['pass'],x['name'],x['detail'])
  pair(p);p.locator('#toast').wait_for(state='hidden',timeout=10000);p.locator('[data-act="compare-metric"][data-metric="specialGsDone"]').first.click();p.wait_for_timeout(500)
  ck(len(ss.ctx.pages)==1,'ordinary delta uses same tab');ck(p.evaluate('Saytara.app.state.comparison.view.metric')=='specialGsDone','exact metric retained');ck(p.evaluate('document.activeElement.id')=='cmp-detail','focus lands on explanation');ck(p.locator('#cmp-detail').bounding_box()['y']<p.viewport_size['height'],'explanation within viewport');ck(p.locator('main .cmp-record-table tbody tr').count()==1,'only +1 contributor shown')
  for width in [1440,768,390,320]:
   p.set_viewport_size({'width':width,'height':1100});ck(not p.evaluate('document.documentElement.scrollWidth>innerWidth+1'),f'focused {width} no viewport overflow');ck(not p.locator('main .cmp-table .ui-table-stacked').count(),f'focused {width} real scrolling table');ck(p.locator('main .cmp-table').first.get_attribute('tabindex')=='0',f'focused {width} keyboard scroll region')
  p.set_viewport_size({'width':1440,'height':1100});p.locator('[data-act="cmp-record-details"]').first.click();ck(p.locator('.cmp-source-dialog').evaluate('(e)=>e.open'),'source details dialog opens');p.keyboard.press('Escape');ck(p.locator('[data-act="cmp-record-details"]').first.evaluate('(e)=>document.activeElement===e'),'source dialog returns focus');p.screenshot(path=str(O/'focused-final.png'),full_page=True);pdf(p,'comparison-focused')
  p.locator('[data-act="comparison-back"]').click();ck(p.evaluate('Saytara.app.state.screen')=='dashboard','back restores monthly');
  # Optional new tab preserves pair and scope, then publishes a new version without silently replacing the parent.
  with p.expect_popup()as pop:p.locator('[data-act="compare-metric"][data-metric="specialGsDone"]').first.click(modifiers=['Control'])
  q=pop.value;q.wait_for_function('typeof Saytara!=="undefined"&&!!Saytara.app?.state.previous&&!Saytara.app.state.comparison.busy');ck(q.evaluate('Saytara.app.state.comparison.view.metric')=='specialGsDone','explicit new tab exact metric');ck(q.evaluate('Saytara.app.sessionInfo().ref.id')==p.evaluate('Saytara.app.sessionInfo().ref.id'),'tabs share session identity')
  q.evaluate('Saytara.app.saveComparison()');p.wait_for_function('!!Saytara.app.sessionInfo().pending');ck(p.locator('#workbook-session-notice').count()==1,'older tab notified of new version');p.locator('[data-act="session-refresh"]').click();p.wait_for_function('(rev)=>!Saytara.app.state.sessionRestoring && !Saytara.app.state.comparison.busy && Saytara.app.sessionInfo().ref.rev===rev',arg=q.evaluate('Saytara.app.sessionInfo().ref.rev'));ck(p.evaluate('Saytara.app.sessionInfo().ref.rev')==q.evaluate('Saytara.app.sessionInfo().ref.rev'),'explicit refresh adopts complete newer pair');q.close()
  p.locator('[data-act="compare-metric"][data-metric="specialGsDone"]').first.click();p.evaluate('Saytara.app.saveComparison()');p.reload();p.wait_for_function('typeof Saytara!=="undefined"&&!!Saytara.app?.state.previous&&!Saytara.app.state.comparison.busy');ck(p.evaluate('!!Saytara.app.state.data'),'binary pair survives reload');ck(bool(p.evaluate('Saytara.app.state.comparison.origin?.hash')),'reload retains monthly return scope')
  p.evaluate("Saytara.app.state.comparison.view={};Saytara.app.state.comparison.showRecords=false;Saytara.app.go('comparison')");p.screenshot(path=str(O/'overview-final.png'),full_page=True);ck(not p.locator('.cmp-kpis,.cmp-bars').count(),'mixed total and paired bars removed');pdf(p,'comparison-overview')
  p.evaluate("Saytara.app.state.comparison.view={metric:'specialTotal',type:'other',q:''};Saytara.app.go('comparison')");ck(p.locator('main .cmp-record-table tbody tr').count()==2,'other edits remain separate from count effects');pdf(p,'comparison-other')
  # Empty selection is not silently broadened.
  p.evaluate("Saytara.app.state.comparison.scope.unit=['__NO_MATCH__'];Saytara.app.go('comparison')");ck(p.locator('main .cmp-record-table tbody tr').count()==0,'unmatched unit yields no rows');pdf(p,'comparison-empty')
  save()
except Exception:
 E['exception']=traceback.format_exc();save();raise
print(E['verdict'],len(E['checks']),'checks',flush=True)
