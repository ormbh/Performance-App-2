exec(open('/workspace/saytara-work/v169-qa/verify.py').read().split('try:\n with h.Session()as ss:')[0])
E={'checks':[],'pdfs':[]}
def save():
 E['errors']=h.E['errors'];E['verdict']='PASS'if all(x['pass']for x in E['checks'])and not E['errors']else'FAIL';(O/'extra-evidence.json').write_text(json.dumps(E,ensure_ascii=False,indent=2))
try:
 with h.Session() as ss:
  p=ss.p;load(p,ss.url)
  # Verify all shared source/summary calculations against the verified v168 baseline.
  import ast
  tree=ast.parse(Path('/workspace/saytara-work/v167-qa/regression/regression.py').read_text());snap=next(ast.literal_eval(n.value)for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='SNAP'for t in n.targets))
  current=p.evaluate(snap);p2=ss.ctx.new_page();p2.goto(ss.url+'/v168-clean/Performance-App/index.html');p2.locator('input[type=file]').first.set_input_files(h.FIX);p2.wait_for_function('!!Saytara.app.state.data');baseline=p2.evaluate(snap);p2.close()
  for k in ['raw','monthly','agenda','hh','council','sourceDate','portfolio']:ck(current[k]==baseline[k],'v168 shared '+k+' calculation fingerprint unchanged')
  ck([{k:v for k,v in r.items()if k!='label'}for r in current['comparison']]==[{k:v for k,v in r.items()if k!='label'}for r in baseline['comparison']],'comparison domain values unchanged, wording updated')
  pair(p)
  # Controlled average: two matching measured records and a newly measured third.
  model=p.evaluate('''()=>{const S=Saytara,I=S.comparison.insights,base=structuredClone(S.app.state.data),rows=base.items.filter(i=>i.pf==='kpi').slice(0,3),a=structuredClone(base),b=structuredClone(base);a.items=structuredClone(rows);b.items=structuredClone(rows);a.items.forEach((i,j)=>{i.calc.result=j<2?[.8,.9][j]:null;i.calc.measurementStateExplicit=false;});b.items.forEach((i,j)=>{i.calc.result=[.8,.9,1][j];i.calc.measurementStateExplicit=false;});let d=I.detail(a,b,{},'kpiAvg');return {previous:d.previous,current:d.current,previousCount:d.counts.previous,currentCount:d.counts.current,additive:d.rows.some(r=>r.contribution!=null),impact:I.filtered(d,{type:'impact'}).total};}''')
  ck(abs(model['previous']-.85)<1e-12 and abs(model['current']-.9)<1e-12 and model['previousCount']==2 and model['currentCount']==3 and not model['additive'],'average coverage and non-additive attribution',model)
  # Long source-field edit exercises the shared native oversized table row continuation.
  p.evaluate('''()=>{const s=Saytara.app.state,i=s.data.items.find(x=>x.pf==='special'&&x.hasTitle);i.t.notes=Array.from({length:85},(_,j)=>'سطر متابعة توضيحي '+String(j+1).padStart(3,'0')+' نص كامل محفوظ للتحقق والقراءة').join('\\n');i.c.notes={t:'s',v:i.t.notes};s.comparison.view={metric:'specialTotal',type:'other',q:''};Saytara.app.go('comparison')}''');pr=pdf(p,'comparison-long-notes');ck('085'in pr['rootText']and '001'in pr['rootText'],'full85line note retained');
  # Native selected financial and average views.
  p.evaluate("Saytara.app.state.comparison.view={metric:'budApproved',type:'impact',q:''};Saytara.app.go('comparison')");pdf(p,'comparison-financial')
  p.evaluate("Saytara.app.state.comparison.view={metric:'kpiAvg',type:'impact',q:''};Saytara.app.go('comparison')");pdf(p,'comparison-average')
  # Shared native collector must preserve portfolio pagination and source sequence.
  p.evaluate("Saytara.app.state.projects=Saytara.projects.defaults();Saytara.app.go('projects')");pdfqa.OUT=O/'portfolio-regression';pdfqa.OUT.mkdir(exist_ok=True);pdfqa.E={'checks':[],'pdfs':[],'errors':[]};p.evaluate('window.__pdfProofHook=false');pdfqa.export(p,'portfolio-regression-v169');ck(all(x['pass']for x in pdfqa.E['checks']),'shared native collector portfolio regression',pdfqa.E['checks']);E['portfolioRegression']=pdfqa.E
  save()
except Exception:
 E['exception']=traceback.format_exc();save();raise
print(E['verdict'],len(E['checks']),'extra checks',flush=True)
