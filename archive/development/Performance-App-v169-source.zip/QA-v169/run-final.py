import subprocess,sys,json
from pathlib import Path
for name in ['verify.py','extra.py','storage.py','final-checks.py']:
 print('Checking',name,flush=True)
 subprocess.run([sys.executable,'/workspace/saytara-work/v169-qa/'+name],check=True)
 evidence={'verify.py':'evidence.json','extra.py':'extra-evidence.json','storage.py':'storage-evidence.json','final-checks.py':'final-checks.json'}[name]
 assert json.loads((Path('/workspace/saytara-work/v169-qa')/evidence).read_text())['verdict']=='PASS',evidence
