#!/usr/bin/env python3
"""Build local assets in their original cascade/execution order.

Run from any directory with Python 3. No dependencies or minifier are required.
Edit the readable source modules, then run this script. ``--check`` exits with
status 1 when either generated bundle differs from its current sources.

The manifest below remains available after index.html switches to the bundles.
CSS stays in assets/css so relative image/font URLs retain their meaning.
"""

from __future__ import annotations

import argparse
import base64
import json
from pathlib import Path
import re
import sys


ROOT = Path(__file__).resolve().parents[1]
CSS = (
    ("base.css", ""),
    ("search.css", ""),
    ("dashboard.css", ""),
    ("workbook.css", ""),
    ("branding.css", ""),
    ("print.css", ""),
    ("reports.css", ""),
    ("agenda.css", ""),
    ("comparison.css", ""),
    ("entities.css", ""),
    ("refinement.css", ""),
    ("comparison-dashboard.css", ""),
    ("consistency.css", ""),
    ("entity-workspace.css", ""),
    ("special-report.css", ""),
    ("legislation-group.css", ""),
    ("report-unified.css", ""),
    ("display-density.css", "screen"),
    ("search-results-v58.css", ""),
    ("projects-report.css", ""),
    ("projects-workspace.css", ""),
    ("usability.css", "screen"),
    ("filter-system.css", ""),
    ("table-system.css", ""),
    ("projects-pmo.css", ""),
    ("entities-leadership.css", ""),
    ("dashboard-cohesion.css", ""),
    ("interface-simplicity.css", ""),
    ("performance-v76.css", ""),
    ("entities-report.css", ""),
    ("search-title.css", ""),
    ("monthly-tools.css", ""),
    ("monthly-report.css", ""),
    ("monthly-rag.css", ""),
    ("council.css", ""),
    ("strategy-portfolio.css", ""),
    ("search-workflow.css", ""),
    ("audit-v102.css", ""),
    ("checks-review.css", ""),
    ("workspace-navigation.css", "screen"),
    ("workspace-cards.css", "screen"),
    ("workspace-layout.css", ""),
    ("table-visibility.css", ""),
    ("workspace-flow.css", ""),
    ("portfolio-delivery.css", ""),
    ("project-print.css", ""),
    ("tec-apple-shared.css", ""),
    ("tec-apple-monthly.css", ""),
    ("tec-apple-monthly-shell.css", "screen"),
    ("tec-apple-projects.css", ""),
    ("tec-apple-search-upload.css", ""),
    ("tec-approved-standard.css", ""),
    ("tec-approved-projects.css", ""),
    ("tec-approved-upload.css", ""),
    ("tec-approved-search.css", ""),
    ("tec-approved-results.css", ""),
    ("tec-workspace-revision5.css", ""),
    ("tec-print-revision5.css", ""),
    ("tec-approved-revision7.css", ""),
    ("tec-approved-source-roles.css", ""),
    ("tec-approved-revision9.css", ""),
    ("tec-print-revision8.css", ""),
    ("tec-approved-audit134.css", ""),
    ("tec-monthly-print-revision10.css", ""),
    ("tec-continuous-monthly-revision12.css", ""),
    ("tec-print-header-revision14.css", ""),
    ("tec-completion-revision19.css", ""),
    ("tec-search-revision20.css", ""),
    ("tec-agenda-workspace.css", ""),
    ("tec-agenda-matrix.css", ""),
    ("tec-agenda-print.css", ""),
    ("tec-hh-report.css", ""),
    ("tec-display-revision22.css", ""),
    ("tec-monthly-legislation-revision24.css", ""),
    ("tec-report-consistency-revision25.css", ""),
    ("tec-report-consistency-revision26.css", ""),
    ("tec-council-revision28.css", ""),
    ("tec-monthly-revision30.css", ""),
    ("tec-portfolio-revision31.css", ""),
    ("tec-portfolio-tables31.css", ""),
    ("tec-portfolio-print31.css", ""),
    ("tec-entity-revision32.css", ""),
    ("tec-comparison-revision33.css", ""),
)
JS = (
    "model/util.js",
    "model/organization-reference.js",
    "model/filter-options.js",
    "model/terms.js",
    "lib/zip.js",
    "lib/xlsx.js",
    "model/schema.js",
    "model/order.js",
    "model/rules.js",
    "model/search.js",
    "model/checks.js",
    "model/loader.js",
    "views/common.js",
    "views/upload.js",
    "views/home.js",
    "views/results.js",
    "views/detail.js",
    "views/monthly-tools.js",
    "views/monthly-coverage.js",
    "views/monthly-print.js",
    "views/monthly-rag.js",
    "views/dashboard.js",
    "views/checks.js",
    "reports/chart-template.js",
    "reports/pie-template.js",
    "reports/source-notes.js",
    "reports/agenda.js",
    "reports/hh.js",
    "views/hh-charts.js",
    "views/reports.js",
    "reports/projects.js",
    "views/agenda-matrix.js",
    "views/agenda.js",
    "reports/council.js",
    "views/council-charts.js",
    "reports/council-export.js",
    "views/council.js",
    "model/workbook-session.js",
    "model/comparison.js",
    "views/comparison.js",
    "model/entities.js",
    "model/entities-leadership.js",
    "views/entities.js",
    "views/entity-report.js",
    "model/projects-pmo.js",
    "views/projects-pmo.js",
    "model/portfolio-delivery.js",
    "views/portfolio-delivery.js",
    "views/projects.js",
    "views/project-print.js",
    "views/agenda-print.js",
    "views/print-pagination.js",
    "lib/pdf-image-data.js",
    "views/pdf-download.js",
    "app.js",
    "site-tools.js",
)
HEADER = "/* Generated by tools/build-bundles.py. Edit source files, then rebuild. */\n"


def source(path: str) -> str:
    # Preserve the source verbatim apart from the final newline and an optional
    # BOM; a BOM only has special meaning at the start of a separate file.
    return (ROOT / path).read_text(encoding="utf-8-sig").rstrip("\n") + "\n"


def css_bundle() -> str:
    parts = [HEADER]
    for name, media in CSS:
        path = "assets/css/" + name
        text = source(path)
        if "@charset" in text or "@import" in text:
            raise ValueError(f"{path}: move @charset/@import before bundling")
        parts.append(f"\n/* Source: {path} */\n")
        parts.append(f"@media {media} {{\n{text}}}\n" if media else text)
    return "".join(parts)


def pdf_image_data() -> str:
    image_types = {"assets/img/tec-red.png": "image/png", "assets/img/agenda-logos.png": "image/png", "assets/img/agenda-cover.jpg": "image/jpeg"}
    data = {name: "data:" + mime + ";base64," + base64.b64encode((ROOT / name).read_bytes()).decode("ascii") for name, mime in image_types.items()}
    return HEADER + "window.Saytara=window.Saytara||{};window.Saytara.pdfImages=" + json.dumps(data,separators=(",",":")) + ";\n"


def js_bundle() -> str:
    parts = [HEADER]
    for name in JS:
        path = "assets/js/" + name
        # A separator before every source also protects an IIFE from accidental
        # continuation of the previous file's final expression or comment.
        parts.append(f"\n;\n/* Source: {path} */\n")
        parts.append(pdf_image_data() if name == "lib/pdf-image-data.js" else source(path))
    return "".join(parts)


def print_media_query(query: str) -> str:
    """Evaluate typed media against print in the measuring frame's screen.

    Split only top-level commas. A disabled screen branch is exactly ``not
    all``: ``not all and (condition)`` would negate the whole conjunction and
    incorrectly enable the branch when its dimension condition is false.
    Feature-only branches retain their dimensions and the original cascade.
    """
    branches, start, depth = [], 0, 0
    for i, char in enumerate(query):
        if char == "(": depth += 1
        elif char == ")": depth -= 1
        elif char == "," and depth == 0:
            branches.append(query[start:i]); start = i + 1
    branches.append(query[start:])
    result = []
    for branch in branches:
        match = re.match(r"\s*(?:(only|not)\s+)?(screen|print)\b(.*)", branch, re.I | re.S)
        if not match:
            result.append(branch.strip()); continue
        modifier, medium, rest = match.groups()
        if medium.lower() == "screen":
            # In print, screen is false regardless of its feature conditions.
            result.append("all" if modifier and modifier.lower() == "not" else "not all")
        else:
            result.append(("not all" if modifier and modifier.lower() == "not" else "all") + rest)
    return ", ".join(result)


def print_measure_bundle(text: str) -> str:
    """Rewrite media headers, never comments, strings, declarations or URLs."""
    result, i, length = [], 0, len(text)
    while i < length:
        if text.startswith("/*", i):
            end = text.find("*/", i + 2)
            end = length if end < 0 else end + 2
        elif text[i] in "\"'":
            quote, end = text[i], i + 1
            while end < length:
                if text[end] == "\\": end += 2; continue
                if text[end] == quote: end += 1; break
                end += 1
        elif text[i:i + 6].lower() == "@media" and (i + 6 == length or not (text[i + 6].isalnum() or text[i + 6] in "_-")):
            end, depth = i + 6, 0
            while end < length:
                if text[end] == "(": depth += 1
                elif text[end] == ")": depth -= 1
                elif text[end] == "{" and depth == 0: break
                end += 1
            if end == length: raise ValueError("Unterminated CSS @media header")
            result.append("@media " + print_media_query(text[i + 6:end]) + " ")
            i = end; continue
        else:
            end = i + 1
        result.append(text[i:end]); i = end
    # These two square bullets are absent from the approved text faces. The
    # same embedded subset measures them here and draws them in the PDF core.
    # Match each text face's weight descriptor exactly so Chromium keeps the
    # fallback and original face in one composite family. A broader weight
    # range would displace some original faces even outside the Unicode range.
    font = base64.b64encode((ROOT / 'assets/vendor/tec-pdf-symbols.ttf').read_bytes()).decode('ascii')
    faces = ''.join(
        "@font-face{font-family:'" + name + "';src:url(data:font/ttf;base64," + font +
        ") format('truetype');font-style:normal;font-weight:" + weight + ";font-display:block;unicode-range:U+25AA,U+F0A7;}\n"
        for name, weight in [('TEC Dubai', '400 500'), ('TEC Dubai', '600 800'), ('TEC DIN', '400'), ('TEC DIN LT', '400')]
    )
    return "".join(result) + '\n/* Shared PDF square-bullet fallback; original text faces stay intact. */\n' + faces


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="Check without writing files")
    args = parser.parse_args()
    try:
        css = css_bundle()
        bundles = {
            "assets/css/app-bundle.css": css,
            "assets/css/print-measure-bundle.css": print_measure_bundle(css),
            "assets/js/lib/pdf-image-data.js": pdf_image_data(),
            "assets/js/app-bundle.js": js_bundle(),
        }
    except (OSError, ValueError) as error:
        print(f"Bundle build failed: {error}", file=sys.stderr)
        return 1
    stale = []
    for name, text in bundles.items():
        path = ROOT / name
        data = text.encode("utf-8")
        if args.check:
            if not path.is_file() or path.read_bytes() != data:
                stale.append(name)
        else:
            # Skip unchanged files so an ordinary rebuild does not invalidate
            # their modification time in a local development server.
            if not path.is_file() or path.read_bytes() != data:
                path.write_bytes(data)
    if stale:
        print("Stale bundles: " + ", ".join(stale), file=sys.stderr)
        print("Run: python tools/build-bundles.py", file=sys.stderr)
        return 1
    print(f"{'Checked' if args.check else 'Built'} {len(CSS)} CSS files and {len(JS)} JavaScript files.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
