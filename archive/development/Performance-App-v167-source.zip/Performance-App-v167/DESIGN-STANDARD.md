# Current design standard — Revision 31 / v167

Read DESIGN-PRINCIPLES-v167.md. The approved portfolio illustration and audit fixes are implemented. Retain all prior monthly, council, agenda and special-project contracts. VERIFICATION-v167.md records actual checks and limits.
