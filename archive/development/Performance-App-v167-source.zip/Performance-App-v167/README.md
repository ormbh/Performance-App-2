# Performance App v167 development source

Approved whole-page project portfolio: count-scaled deadlines, consistent financial eligibility, shared record tables, compact status definitions, scoped navigation and matching native A4 output.

Build with `python3 tools/build-bundles.py`; verify freshness with `--check`. Read DESIGN-PRINCIPLES-v167.md and VERIFICATION-v167.md. The clean end-user runtime is published separately as Performance-App-v167.zip. No workbook is included. Original fonts and native PDF engine remain unchanged.
