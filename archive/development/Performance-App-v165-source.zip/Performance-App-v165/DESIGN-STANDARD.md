# Current design standard — Revision 29 / v165

Read DESIGN-PRINCIPLES-v165.md. Council's unassigned issuing-body group spans both columns below the named charts, retaining counts and physical scale. Existing report semantics and the v164 PDF glyph compatibility fix remain intact. Monthly audit and illustrations are proposals only. VERIFICATION-v165.md records implementation checks and limitations.
