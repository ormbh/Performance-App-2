# Performance App v165 development source

Council decisions without an issuing body now use a full-width box below named charts, with a shared physical count scale. Monthly report redesign remains an audit/illustration proposal, outside this implementation.

Build `python3 tools/build-bundles.py`; check freshness with `--check`. Original PDF engine and fonts from v164 remain unchanged. See DESIGN-PRINCIPLES-v165.md and VERIFICATION-v165.md. Clean end-user runtime is published separately as Performance-App-v165.zip.
