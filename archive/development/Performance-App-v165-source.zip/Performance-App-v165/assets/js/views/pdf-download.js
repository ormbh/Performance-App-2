/* Offline native PDF export. Browser layout owns wrapping and geometry;
 * the local font engine writes selectable text and vector shapes. No workbook
 * data is recomputed here, and no report is sent to an external service. */
(function (S) {
  'use strict';
  var PX_PT = 72 / 96, MM_PT = 72 / 25.4, enginePromise;
  function loadEngine() {
    if (S.pdfEngine) return Promise.resolve(S.pdfEngine);
    if (!enginePromise) enginePromise = new Promise(function (resolve, reject) {
      var script = document.createElement('script');
      var build=document.querySelector('meta[name="performance-build"]');
      script.src = new URL('assets/js/lib/offline-pdf-engine.js?v='+encodeURIComponent(build?build.content:'164'), document.baseURI).href;
      script.onload = function () { if (S.pdfEngine) resolve(S.pdfEngine); else { enginePromise=null; reject(new Error('PDF engine unavailable')); } };
      script.onerror = function () { script.remove(); enginePromise=null; reject(new Error('تعذر تحميل مكونات PDF المحلية. استخرج ملف التطبيق كاملاً ثم حاول مجدداً.')); };
      document.head.appendChild(script);
    });
    return enginePromise;
  }
  function opaque(color) { return color && color !== 'transparent' && !/rgba\([^)]*,\s*0\s*\)/.test(color) && color !== 'none'; }
  function color(doc, css, stroke) {
    var m = css && css.match(/rgba?\(([^)]+)\)/), c = css, a=1;
    if(m){var parts=m[1].split(',').map(Number);c=parts.slice(0,3);if(parts.length>3)a=parts[3];}
    if(stroke){doc.strokeColor(c);doc.strokeOpacity(a);}else {doc.fillColor(c);doc.fillOpacity(a);}
  }
  // Contents are built from the rendered section navigation. The number cell
  // has fixed geometry; its text is filled from the final PDF page plan, never
  // from record counts or an independently calculated report model.
  function reportContents(artifact) {
    var source=artifact.root.querySelector('.tec-report-contents');
    if(!source)return null;
    var doc=artifact.document,nav=doc.createElement('nav');nav.className='tec-pdf-contents';nav.id='report-contents';nav.dir='rtl';
    var title=doc.createElement('h2');title.textContent='محتويات التقرير';nav.appendChild(title);
    var caption=doc.createElement('div');caption.className='tec-pdf-contents-heading';caption.textContent='الصفحة';nav.appendChild(caption);
    Array.from(source.querySelectorAll('[data-target]')).forEach(function(entry){
      var row=doc.createElement('a'),label=entry.querySelector('span'),number=doc.createElement('bdi'),text=doc.createElement('span');
      row.dataset.target=entry.dataset.target;row.href='#'+entry.dataset.target;
      text.textContent=label?label.textContent.trim():entry.textContent.trim();
      number.dir='ltr';number.className='tec-pdf-page-number';number.dataset.pdfPageTarget=entry.dataset.target;number.textContent='0000';
      row.appendChild(text);row.appendChild(number);nav.appendChild(row);
    });
    var style=doc.createElement('style');
    style.textContent='body[data-tec-print] #app .tec-pdf-contents{display:block!important;margin:0!important;padding:5mm 0!important;border:0!important;border-radius:0!important;background:transparent!important;break-inside:avoid!important}body[data-tec-print] #app .tec-pdf-contents h2{font:400 20pt/1.4 "TEC DIN",sans-serif!important;margin:0 0 6mm!important;color:#333!important}body[data-tec-print] #app .tec-pdf-contents-heading{text-align:left;font:400 10.5pt/1.5 "TEC Dubai",sans-serif!important;color:#756B5F;padding-bottom:2mm}body[data-tec-print] #app .tec-pdf-contents a{display:flex!important;align-items:center!important;justify-content:space-between!important;gap:8mm!important;padding:4mm 0!important;margin:0!important;min-height:12mm!important;border-bottom:1px solid #E7E0D3!important;text-decoration:none!important;color:#4F4E4E!important;font:400 13pt/1.5 "TEC Dubai",sans-serif!important;break-inside:avoid!important}body[data-tec-print] #app .tec-pdf-contents a span{flex:1!important}body[data-tec-print] #app .tec-pdf-page-number{display:block!important;flex:0 0 14mm!important;width:14mm!important;text-align:left!important;font:400 14pt/1.5 "TEC DIN",sans-serif!important;color:#115E67!important}';
    doc.head.appendChild(style);return nav;
  }
  S.pdfReportContents={create:reportContents};
  // HH uses the same native full-bleed cover contract as the agenda. The
  // chart specification is already frozen by the screen; only composition
  // changes here, without deriving another set of project counts.
  function prepareHH(artifact, state) {
    if (!(state.screen === 'reports' && state.report && state.report.kind === 'hh')) return false;
    var root=artifact.root, doc=artifact.document, overview=root.querySelector('.hh-chart-overview');
    function el(tag,cls){var n=doc.createElement(tag);n.className=cls;return n;}
    var container=el('div','ag-pdf-document hh-report hh-pdf-document'),cover=el('section','ag-pdf-cover'),display=S.reportDisplay.get(state),esc=S.util.esc;
    var entity=S.views.reports.hhEntityText(state);
    cover.innerHTML='<img class="ag-pdf-cover-photo" src="assets/img/agenda-cover.jpg" alt=""><div class="ag-pdf-cover-wash" aria-hidden="true"></div><img class="ag-pdf-cover-logos" src="assets/img/agenda-logos.png" alt="حكومة دبي والمجلس التنفيذي"><div class="ag-pdf-cover-title"><h1>'+esc(display.title)+'</h1>'+(entity?'<p>'+esc(entity)+'</p>':'')+'<p>'+esc(display.period)+'</p></div>';
    container.appendChild(cover);
    var contents=reportContents(artifact);if(contents&&overview)container.appendChild(contents);
    var first=el('section','hh-pdf-first-block');first.id='hh-summary';
    if(overview)first.appendChild(overview.cloneNode(true));else{var empty=el('p','rpt-empty');empty.textContent='لا توجد بيانات ضمن النطاق المحدد';first.appendChild(empty);}
    container.appendChild(first);
    var rest=el('section','hh-pdf-rest'),main=root.querySelector('.rpt-main').cloneNode(true);
    // The paired cohort charts already summarize this scope on the first
    // content page. Keep the screen overview out of the remaining PDF body.
    Array.from(main.querySelectorAll('.hh-chart-overview,.hh-overview-card,#hh-cover,.tec-report-contents,.rpt-intro,.rpt-controls,.hh-report-filters,.hh-report-utilities,.rpt-body-source-note,.report-display-controls,.report-editorial-controls,#hh-shortcuts,.rpt-empty,.tec-report-empty')).forEach(function(n){n.remove();});
    var summary=main.querySelector('#hh-summary');if(summary)summary.remove();
    rest.appendChild(main);container.appendChild(rest);root.replaceChildren(container);artifact.hh={};artifact.report=container;
    var style=doc.createElement('style');style.textContent='.hh-pdf-first-block{margin:0!important;padding:0!important;break-inside:avoid!important}.hh-pdf-rest>.rpt-main{margin:0!important;padding:0!important;width:100%!important;max-width:none!important}.hh-pdf-rest #hh-summary{break-before:auto!important}.hh-pdf-rest .hh-summary-dashboard:empty{display:none!important}.hh-pdf-first-block .hh-chart-overview{margin:0!important}';doc.head.appendChild(style);
    return true;
  }
  function collectHH(artifact,bounds){if(!artifact.hh)return null;var contents=artifact.root.querySelector('.tec-pdf-contents');return {cover:bounds(artifact.root.querySelector('.ag-pdf-cover')),contents:contents&&bounds(contents),first:bounds(artifact.root.querySelector('.hh-pdf-first-block')),rest:bounds(artifact.root.querySelector('.hh-pdf-rest'))};}
  function hhPages(data,geometry){
    var h=data.hh,capacity=182*96/25.4,plans=[{regions:[{source:h.cover,x:0,y:0}],fullBleed:true,noFooter:true}];
    if(h.contents){
      var contentsData=Object.assign({},data,{hh:null,height:h.contents.y+h.contents.h});
      plans=plans.concat(pagePlan(contentsData,Object.assign({},geometry,{sourceStart:h.contents.y,capacityPx:capacity})));
    }
    if(h.first.h>capacity+.5){
      throw new Error('يتجاوز مخطط المشاريع وتعريفاته مساحة الصفحة؛ يرجى مراجعة مستويات الإنجاز والقطاعات في المصدر.');
    }else plans.push({regions:[{source:h.first,x:h.first.x,y:0}]});
    if(h.rest.h>.5){var remaining=Object.assign({},data,{hh:null,height:h.rest.y+h.rest.h});var restPlan=pagePlan(remaining,Object.assign({},geometry,{sourceStart:h.rest.y,capacityPx:capacity}));plans=plans.concat(restPlan);}
    plans.forEach(function(p,i){if(!p.noFooter){p.footerPage=i;p.footerTotal=plans.length-1;}});return plans;
  }
  function fitHHCounts(artifact){
    if(!artifact.hh)return;
    var first=artifact.root.querySelector('.hh-pdf-first-block'),capacity=182*96/25.4;
    if(first.getBoundingClientRect().height>capacity+.5)first.dataset.chartSpacing='compact';
    var cover=artifact.root.querySelector('.ag-pdf-cover'),title=cover.querySelector('.ag-pdf-cover-title');
    function coverOverflows(inset){var a=title.getBoundingClientRect(),b=cover.getBoundingClientRect(),safe=inset*96/25.4;return a.top<b.top+safe||a.bottom>b.bottom-safe||a.left<b.left+safe||a.right>b.right-safe;}
    if(coverOverflows(8))cover.dataset.agendaSpacing='compact';
    if(coverOverflows(4))throw new Error('يتجاوز نص الغلاف المساحة المتاحة؛ يرجى تقليل طول عنوان التقرير أو الفترة المعروضة.');
    var win=artifact.window,canvas=artifact.document.createElement('canvas'),ctx=canvas.getContext('2d');
    Array.from(artifact.root.querySelectorAll('.hh-cohort-segment bdi')).forEach(function(label){
      var segment=label.closest('.hh-cohort-segment'),style=win.getComputedStyle(label),box=win.getComputedStyle(segment);
      ctx.font=style.fontStyle+' '+style.fontWeight+' '+style.fontSize+' '+style.fontFamily;
      var metrics=ctx.measureText(label.textContent.trim()),inner=segment.clientWidth-(parseFloat(box.paddingLeft)||0)-(parseFloat(box.paddingRight)||0);
      var inkHeight=(metrics.actualBoundingBoxAscent||0)+(metrics.actualBoundingBoxDescent||0),fits=metrics.width+4<=inner&&inkHeight+4<=segment.clientHeight;
      // This is a visibility decision only. Counts never stretch their source
      // bars or reduce the approved physical text size to squeeze into a mark.
      label.style.visibility=fits?'visible':'hidden';label.dataset.pdfCountFit=String(fits);label.dataset.pdfCountWidth=String(metrics.width);label.dataset.pdfCountRoom=String(inner);
    });
  }
  S.hhPrint={prepare:prepareHH,fit:fitHHCounts};
  function prepareCouncil(artifact,state){
    if(!(state.screen==='council'||state.screen==='reports'&&state.report&&state.report.kind==='council'))return false;
    var root=artifact.root,doc=artifact.document,overview=root.querySelector('.cr-chart-overview'),contents=reportContents(artifact);
    function el(tag,cls){var n=doc.createElement(tag);n.className=cls;return n;}
    var container=el('div','ag-pdf-document council-report cr-pdf-document'),cover=el('section','ag-pdf-cover');
    var display=S.reportDisplay.get(state),entity=S.views.councilPage.entityText(state),esc=S.util.esc;
    cover.innerHTML='<img class="ag-pdf-cover-photo" src="assets/img/agenda-cover.jpg" alt=""><div class="ag-pdf-cover-wash" aria-hidden="true"></div><img class="ag-pdf-cover-logos" src="assets/img/agenda-logos.png" alt="حكومة دبي والمجلس التنفيذي"><div class="ag-pdf-cover-title"><h1>'+esc(display.title)+'</h1>'+(entity?'<p>'+esc(entity)+'</p>':'')+'<p>'+esc(display.period)+'</p></div>';
    container.appendChild(cover);if(contents)container.appendChild(contents);
    var availability=root.querySelector('.cr-data-availability');
    // Named issuers retain their shared two-column scale. The unassigned
    // group follows every named issuer in a single full-width box.
    if(overview){
      var panels=Array.from(overview.querySelectorAll('.cr-chart-panels .cr-issuer-panel')),count=Math.max(1,Math.ceil(panels.length/2));
      for(var i=0;i<count;i++){
        var first=el('section','cr-pdf-first-block'),copy=overview.cloneNode(true);
        if(!i){first.id='council-summary';if(availability)first.appendChild(availability.cloneNode(true));}
        Array.from(copy.querySelectorAll('.cr-chart-panels .cr-issuer-panel')).forEach(function(panel,index){if(index<i*2||index>=i*2+2)panel.remove();});
        var grid=copy.querySelector('.cr-chart-panels');if(grid&&!grid.children.length)grid.remove();
        var missing=copy.querySelector('.cr-unassigned-panel');if(missing&&i<count-1)missing.remove();
        first.appendChild(copy);container.appendChild(first);
      }
    }
    if(availability&&!overview){var notice=availability.cloneNode(true);notice.classList.add('cr-pdf-availability');container.appendChild(notice);}
    var expectedKeys=[],assigned={},seenHeadings=[],groups=Array.from(root.querySelectorAll('.cr-quarter-group')).filter(function(group){return group.querySelector('.cr-table');});
    groups.forEach(function(source){
      var group=el('section','cr-pdf-table-group'),titles=el('header','cr-pdf-group-title'),ancestors=[],node=source;
      while(node&&!node.matches('.rpt-main')){ancestors.unshift(node);node=node.parentElement;}
      ancestors.forEach(function(parent){
        if((parent.id==='council-tables'||parent.id==='council-other')&&!assigned[parent.id]){group.id=parent.id;assigned[parent.id]=true;}
        var heading=parent.querySelector(':scope > .rpt-section-heading,:scope > h2,:scope > h3,:scope > h4');
        if(heading&&seenHeadings.indexOf(heading)<0){titles.appendChild(heading.cloneNode(true));seenHeadings.push(heading);}
      });
      if(titles.children.length)group.appendChild(titles);
      var table=source.querySelector('.cr-table').cloneNode(true);
      Array.from(table.querySelectorAll('tbody tr[data-record]')).forEach(function(row){expectedKeys.push(row.dataset.record);});
      group.appendChild(table);container.appendChild(group);
    });
    if(!overview&&!groups.length){var sourceEmpty=root.querySelector('.tec-report-empty'),empty=sourceEmpty?sourceEmpty.cloneNode(true):el('section','tec-report-empty');empty.classList.add('cr-pdf-empty');if(!sourceEmpty)empty.innerHTML='<p class="rpt-empty">لا توجد بيانات ضمن النطاق المحدد.</p>';container.appendChild(empty);}
    var editorial=root.querySelector('#report-editorial');
    if(editorial&&!editorial.hidden){var tail=editorial.cloneNode(true);tail.classList.add('cr-pdf-tail');Array.from(tail.querySelectorAll('.rpt-section-return,.rpt-return-link')).forEach(function(n){n.remove();});container.appendChild(tail);}
    root.replaceChildren(container);artifact.council={expectedKeys:expectedKeys};artifact.report=container;
    return true;
  }
  function fitCouncil(artifact){
    if(!artifact.council)return;
    var capacity=182*96/25.4,cover=artifact.root.querySelector('.ag-pdf-cover'),title=cover.querySelector('.ag-pdf-cover-title');
    function overflow(inset){var a=title.getBoundingClientRect(),b=cover.getBoundingClientRect(),safe=inset*96/25.4;return a.top<b.top+safe||a.bottom>b.bottom-safe||a.left<b.left+safe||a.right>b.right-safe;}
    if(overflow(8))cover.dataset.agendaSpacing='compact';
    if(overflow(4))throw new Error('يتجاوز نص الغلاف المساحة المتاحة؛ يرجى تقليل طول عنوان التقرير أو الفترة المعروضة.');
    Array.from(artifact.root.querySelectorAll('.cr-pdf-first-block')).forEach(function(block){
      if(block.getBoundingClientRect().height<=capacity+.5)return;
      block.dataset.chartSpacing='compact';
      var missing=block.querySelector('.cr-unassigned-panel'),grid=block.querySelector('.cr-chart-panels');
      if(block.getBoundingClientRect().height<=capacity+.5||!missing||!grid)return;
      // Keep full source labels and readable count marks if an unusual scope
      // cannot fit with the named charts. Continue the box before the tables.
      var continuation=block.ownerDocument.createElement('section');continuation.className='cr-pdf-first-block';
      var overview=block.querySelector('.cr-chart-overview'),copy=overview.cloneNode(true);
      Array.from(copy.querySelectorAll('.cr-chart-panels')).forEach(function(n){n.remove();});
      continuation.appendChild(copy);block.after(continuation);missing.remove();
      if(continuation.getBoundingClientRect().height>capacity+.5)continuation.dataset.chartSpacing='compact';
    });
    if(S.councilCharts&&S.councilCharts.fitCounts)S.councilCharts.fitCounts(artifact.root);
  }
  function collectCouncil(artifact,bounds){
    if(!artifact.council)return null;
    var root=artifact.root,contents=root.querySelector('.tec-pdf-contents'),empty=root.querySelector('.cr-pdf-empty'),notice=root.querySelector('.cr-pdf-availability');
    return {cover:bounds(root.querySelector('.ag-pdf-cover')),contents:contents&&bounds(contents),empty:empty&&bounds(empty),notice:notice&&bounds(notice),
      firsts:Array.from(root.querySelectorAll('.cr-pdf-first-block')).map(bounds),
      tables:Array.from(root.querySelectorAll('.cr-pdf-table-group')).map(function(group){
        var table=group.querySelector('table'),heading=group.querySelector('.cr-pdf-group-title');
        return{rect:bounds(group),heading:heading&&bounds(heading),head:table.tHead&&bounds(table.tHead),
          rows:Array.from(table.tBodies[0].rows).map(function(row){return{rect:bounds(row),key:row.dataset.record,cells:Array.from(row.children).map(bounds)};})};
      }),tails:Array.from(root.querySelectorAll('.cr-pdf-tail')).map(bounds),expectedKeys:artifact.council.expectedKeys};
  }
  function councilPages(data){
    var c=data.council,capacity=182*96/25.4,gap=5*96/25.4,plans=[{regions:[{source:c.cover,x:0,y:0}],fullBleed:true,noFooter:true}],page=null,cursor=0,keys=[];
    function next(){page={regions:[],council:true};plans.push(page);cursor=0;}
    function place(rect){page.regions.push({source:rect,x:rect.x,y:cursor});cursor+=rect.h;}
    function safeCut(rect,from,to){
      // One column at a time: latest-decision metadata and long notes can
      // wrap at different vertical positions. Never require their line gaps
      // to coincide across the entire six-column row.
      var previous;
      do{previous=to;var crossing=data.lines.filter(function(line){return line.x<rect.x+rect.w-.1&&line.x+line.w>rect.x+.1&&line.y<to-.1&&line.y+line.h>to+.1;});
        if(crossing.length)to=Math.min.apply(null,crossing.map(function(line){return line.y;}));
      }while(to<previous-.1&&to>from+.5);
      if(to<=from+.5)throw new Error('تعذّر توزيع نص طويل في تقرير القرارات دون اقتطاعه.');
      return to;
    }
    function block(rect){
      if(!page||cursor&&cursor+Math.min(rect.h,capacity)+gap>capacity+.2)next();
      if(cursor)cursor+=gap;
      var from=rect.y,end=rect.y+rect.h;
      while(from<end-.1){var cut=safeCut(rect,from,Math.min(end,from+capacity-cursor));place({x:rect.x,y:from,w:rect.w,h:cut-from});from=cut;if(from<end-.1)next();}
    }
    if(c.contents){next();block(c.contents);}
    c.firsts.forEach(function(first){if(first.h>capacity+.5)throw new Error('يتجاوز مخطط القرارات وتعريفاته مساحة الصفحة؛ يرجى مراجعة طول أسماء الجهات والحالات.');next();place(first);});
    if(c.empty){next();block(c.empty);}
    if(c.tables.length)next();
    if(c.notice)block(c.notice);
    c.tables.forEach(function(group){
      if(!group.rows.length)return;
      var first=group.rows[0],head=group.head,start=group.heading?group.heading.y:head.y;
      var lead={x:group.rect.x,y:start,w:group.rect.w,h:first.rect.y-start};
      var minRow=Math.min(first.rect.h,Math.max(40,capacity-lead.h));
      if(cursor&&cursor+gap+lead.h+minRow>capacity+.2)next();
      if(cursor)cursor+=gap;place(lead);
      group.rows.forEach(function(row){
        var reserve=head?head.h:0;
        if(row.rect.h<=capacity-reserve+.2){
          if(cursor+row.rect.h>capacity+.2){next();if(head)place(head);}
          place(row.rect);
        }else{
          var pending=row.cells.map(function(cell){return{rect:cell,from:cell.y,end:cell.y+cell.h};});
          while(pending.some(function(cell){return cell.from<cell.end-.1;})){
            if(capacity-cursor<40){next();if(head)place(head);}
            var used=0;
            pending.forEach(function(cell){if(cell.from>=cell.end-.1)return;var cut=safeCut(cell.rect,cell.from,Math.min(cell.end,cell.from+capacity-cursor));var height=cut-cell.from;page.regions.push({source:{x:cell.rect.x,y:cell.from,w:cell.rect.w,h:height},x:cell.rect.x,y:cursor});used=Math.max(used,height);cell.from=cut;});
            cursor+=used;if(pending.some(function(cell){return cell.from<cell.end-.1;})){next();if(head)place(head);}
          }
        }
        keys.push(row.key);
      });
    });
    c.tails.forEach(block);
    if(JSON.stringify(keys)!==JSON.stringify(c.expectedKeys))throw new Error('تعذّر التحقق من اكتمال صفوف تقرير القرارات في PDF.');
    plans.forEach(function(p,i){if(!p.noFooter){p.footerPage=i;p.footerTotal=plans.length-1;}});return plans;
  }
  S.councilPrint={prepare:prepareCouncil,fit:fitCouncil};
  function collect(artifact) {
    var root=artifact.root, win=root.ownerDocument.defaultView, origin=root.getBoundingClientRect();
    var ops=[], lines=[], avoids=[], breaks=[], tables=[], destinations=[], links=[];
    var canvas=root.ownerDocument.createElement('canvas'), ctx=canvas.getContext('2d');
    var segmenter=typeof Intl.Segmenter==='function'?new Intl.Segmenter('ar',{granularity:'grapheme'}):null;
    function bounds(el){var r=el.getBoundingClientRect();return {x:r.left-origin.left,y:r.top-origin.top,w:r.width,h:r.height};}
    function text(node, style) {
      if(!node.textContent.trim())return;
      var raw=node.textContent, range=root.ownerDocument.createRange(), chunks=[];
      var svgParent=node.parentElement.namespaceURI==='http://www.w3.org/2000/svg',matrix=svgParent&&node.parentElement.getScreenCTM(),fontScale=matrix?Math.hypot(matrix.c,matrix.d):1;
      if(segmenter)Array.from(segmenter.segment(raw)).forEach(function(s){chunks.push({index:s.index,text:s.segment});});
      else {var pos=0;Array.from(raw).forEach(function(s){chunks.push({index:pos,text:s});pos+=s.length;});}
      var groups=[];
      chunks.forEach(function(ch){
        range.setStart(node,ch.index);range.setEnd(node,ch.index+ch.text.length);
        var rects=Array.from(range.getClientRects()).filter(function(r){return r.width>.01&&r.height>.01;});
        if(!rects.length)return;
        var r=rects[0],key=Math.round(r.top*4),g=groups.find(function(x){return x.key===key;});
        if(!g){g={key:key,text:'',left:r.left,right:r.right,top:r.top,bottom:r.bottom};groups.push(g);}
        g.text+=ch.text;g.left=Math.min(g.left,r.left);g.right=Math.max(g.right,r.right);g.bottom=Math.max(g.bottom,r.bottom);
      });
      ctx.font=style.fontStyle+' '+style.fontWeight+' '+style.fontSize+' '+style.fontFamily;
      groups.forEach(function(g){
        var str=g.text.replace(/[\t\r\n\f]/g,' ');
        if(!/pre/.test(style.whiteSpace))str=str.replace(/ +/g,' ');
        if(!str.trim())return;
        var tm=ctx.measureText(str),ascent=tm.fontBoundingBoxAscent;
        if(!Number.isFinite(ascent))ascent=parseFloat(style.fontSize)*.8;
        var exactBaseline=null;
        if(svgParent&&matrix&&node.parentElement.getStartPositionOfChar){try{var pt=node.parentElement.getStartPositionOfChar(0);exactBaseline=matrix.b*pt.x+matrix.d*pt.y+matrix.f-origin.top;}catch(ignore){}}
        var baseline=exactBaseline===null?g.top-origin.top+ascent*fontScale:exactBaseline;
        // Browser Range rectangles include the font's full ascent/descent.
        // For Dubai these boxes overlap adjacent lines at the approved line
        // height, so they cannot define a safe page cut. Measure the actual
        // glyph ink around the unchanged browser baseline instead: a cut in
        // the interline gap then assigns every complete line to exactly one
        // page, without reducing type size or dropping a straddling line.
        var inkAscent=Number.isFinite(tm.actualBoundingBoxAscent)?tm.actualBoundingBoxAscent:ascent;
        var inkDescent=Number.isFinite(tm.actualBoundingBoxDescent)?tm.actualBoundingBoxDescent:Math.max(0,(g.bottom-g.top)/fontScale-ascent);
        var op={type:'text',text:str,x:g.left-origin.left,y:baseline-inkAscent*fontScale,w:g.right-g.left,h:Math.max(.01,(inkAscent+inkDescent)*fontScale),
          headerText:!!node.parentElement.closest('.mp-header,.tec-print-first-header,.ag-pdf-group-title,.cr-pdf-group-title,.a-overview-lead,.a-panel-title,.hh-cohort-title'),
          baseline:baseline,size:parseFloat(style.fontSize)*fontScale,font:style.fontFamily,bold:Number(style.fontWeight)>=600,
          direction:style.direction,color:svgParent?style.fill:style.color,letterSpacing:parseFloat(style.letterSpacing)||0};
        var pageNumber=node.parentElement.closest('[data-pdf-page-target]');
        if(pageNumber)op.pageTarget=pageNumber.dataset.pdfPageTarget;
        lines.push(op);ops.push(op);
      });
      range.detach();
    }
    function svg(el, style) {
      var tag=el.tagName.toLowerCase(),matrix=el.getScreenCTM&&el.getScreenCTM();
      if(!matrix)return false;
      if(tag==='text'||tag==='tspan')return false;
      var allowed=['rect','circle','ellipse','path','line','polygon','polyline'];
      if(allowed.indexOf(tag)<0)return false;
      var attrs={};Array.from(el.attributes).forEach(function(a){attrs[a.name]=a.value;});
      ops.push({type:'svg',tag:tag,attrs:attrs,matrix:[matrix.a,matrix.b,matrix.c,matrix.d,matrix.e-origin.left,matrix.f-origin.top],
        x:bounds(el).x,y:bounds(el).y,w:bounds(el).w,h:bounds(el).h,fill:style.fill,stroke:style.stroke,strokeWidth:parseFloat(style.strokeWidth),opacity:parseFloat(style.opacity)});
      return true;
    }
    function visit(el){
      var st=win.getComputedStyle(el),r=bounds(el);
      if(st.display==='none'||st.visibility==='hidden'||Number(st.opacity)===0)return;
      if(el.tagName.toLowerCase()==='defs'||el.tagName.toLowerCase()==='title'||el.tagName.toLowerCase()==='desc')return;
      // display:contents has no own rectangle, but its source text and child
      // boxes remain visible. Printable report links use it intentionally.
      if(!el.getClientRects().length){
        if(st.display!=='contents')return;
        Array.from(el.childNodes).forEach(function(n){if(n.nodeType===1)visit(n);else if(n.nodeType===3)text(n,st);});
        return;
      }
      if(st.breakBefore==='page'||st.breakBefore==='always'||st.pageBreakBefore==='always')breaks.push(r.y);
      if(st.breakAfter==='page'||st.breakAfter==='always'||st.pageBreakAfter==='always')breaks.push(r.y+r.h);
      if((/avoid/.test(st.breakInside)||/avoid/.test(st.pageBreakInside)||el.tagName==='TR'||el.matches('.mp-metrics,.mp-card-head,.mp-requester h4,.mp-kpi-metric,.mp-money-main'))&&r.h>0)avoids.push({top:r.y,bottom:r.y+r.h,x:r.x,w:r.w,row:el.tagName==='TR'});
      if(el.tagName==='TABLE'&&el.tHead){
        var hr=bounds(el.tHead),first=el.tBodies[0]&&Array.from(el.tBodies[0].rows).find(function(row){return row.getClientRects().length;}),fr=first&&bounds(first);
        tables.push({top:r.y,bottom:r.y+r.h,head:hr});
        if(fr){var top=hr.y;
          // A title can be a sibling of the table or of its scroll wrapper.
          // Keep the nearby visible heading chain with the first source row.
          Array.from(root.querySelectorAll('h2,h3,h4,[role="heading"]')).forEach(function(title){
            if(!title.getClientRects().length||!(title.compareDocumentPosition(el)&4))return;
            var tr=bounds(title),overlap=Math.min(tr.x+tr.w,hr.x+hr.w)-Math.max(tr.x,hr.x);
            if(tr.y<=hr.y&&hr.y-tr.y<160&&overlap>Math.min(tr.w,hr.w)*.5)top=Math.min(top,tr.y);
          });
          avoids.push({top:top,bottom:fr.y+fr.h,x:hr.x,w:hr.w,row:true});}
      }
      if(el.namespaceURI==='http://www.w3.org/2000/svg'&&svg(el,st))return;
      if(el.namespaceURI!=='http://www.w3.org/2000/svg'){
        if(el.matches('.hh-progress-ring')){var before=win.getComputedStyle(el,'::before'),palette=st.backgroundImage.match(/rgba?\([^)]+\)/g)||[];ops.push({type:'ring',x:r.x,y:r.y,w:r.w,h:r.h,value:Math.max(0,Math.min(100,parseFloat(st.getPropertyValue('--progress'))||0)),color:st.getPropertyValue('--progress-color').trim()||'#115E67',track:palette[palette.length-1]||'#E7E0D3',inner:before.backgroundColor,inset:parseFloat(before.left)||6});}
        else if(opaque(st.backgroundColor)&&r.w>0&&r.h>0)ops.push({type:'box',x:r.x,y:r.y,w:r.w,h:r.h,radius:parseFloat(st.borderTopLeftRadius)||0,fill:st.backgroundColor});
        var sides=['Top','Right','Bottom','Left'],uniform=sides.every(function(side){return st['border'+side+'Width']===st.borderTopWidth&&st['border'+side+'Color']===st.borderTopColor&&st['border'+side+'Style']===st.borderTopStyle;});
        if(uniform&&parseFloat(st.borderTopWidth)>0&&st.borderTopStyle!=='none'&&opaque(st.borderTopColor))ops.push({type:'outline',x:r.x,y:r.y,w:r.w,h:r.h,radius:parseFloat(st.borderTopLeftRadius)||0,width:parseFloat(st.borderTopWidth),color:st.borderTopColor});
        if(!uniform)sides.forEach(function(side){var width=parseFloat(st['border'+side+'Width']);if(width>0&&st['border'+side+'Style']!=='none'&&opaque(st['border'+side+'Color']))ops.push({type:'border',x:r.x,y:r.y,w:r.w,h:r.h,side:side,width:width,color:st['border'+side+'Color']});});
      }
      if(el.tagName==='IMG'){
        var embedded=S.pdfImages&&S.pdfImages[el.getAttribute('src')];
        if(!embedded&&S.pdfImages)Object.keys(S.pdfImages).some(function(key){if(el.src.endsWith('/'+key)){embedded=S.pdfImages[key];return true;}return false;});
        if(embedded){ops.push({type:'image',x:r.x,y:r.y,w:r.w,h:r.h,data:embedded});return;}
        var c=root.ownerDocument.createElement('canvas');c.width=el.naturalWidth;c.height=el.naturalHeight;
        if(c.width&&c.height){c.getContext('2d').drawImage(el,0,0);ops.push({type:'image',x:r.x,y:r.y,w:r.w,h:r.h,data:c.toDataURL('image/png')});}
        return;
      }
      var clip=/(hidden|clip)/.test(st.overflowX+' '+st.overflowY)&&r.w>0&&r.h>0;
      if(clip)ops.push({type:'clip-start',x:r.x,y:r.y,w:r.w,h:r.h,radius:parseFloat(st.borderTopLeftRadius)||0});
      var closedDetails=el.tagName==='DETAILS'&&!el.open;
      Array.from(el.childNodes).forEach(function(n){
        // Chromium can expose Range rectangles inside collapsed disclosures;
        // those descendants do not belong to the visible export.
        if(closedDetails&&!(n.nodeType===1&&n.tagName==='SUMMARY'))return;
        if(n.nodeType===1)visit(n);else if(n.nodeType===3)text(n,st);
      });
      if(clip)ops.push({type:'clip-end'});
    }
    visit(root);
    // Native links use the same visible rectangles as their browser text.
    // Range geometry also supports display:contents links in printed tables.
    function visibleRects(el){
      if(el.closest('[hidden]'))return [];
      for(var node=el;node&&node!==root.parentElement;node=node.parentElement){var st=win.getComputedStyle(node);if(st.display==='none'||st.visibility==='hidden')return [];}
      var rects=Array.from(el.getClientRects()).filter(function(r){return r.width>.1&&r.height>.1;});
      if(!rects.length){var range=root.ownerDocument.createRange();range.selectNodeContents(el);rects=Array.from(range.getClientRects()).filter(function(r){return r.width>.1&&r.height>.1;});range.detach();}
      return rects.map(function(r){return{x:r.left-origin.left,y:r.top-origin.top,w:r.width,h:r.height};});
    }
    Array.from(root.querySelectorAll('[id]')).forEach(function(el){var rects=visibleRects(el);if(rects.length)destinations.push({id:el.id,rect:rects[0]});});
    Array.from(root.querySelectorAll('[data-target],a[href^="#"]')).forEach(function(el){
      var target=el.dataset.target||(el.getAttribute('href')||'').slice(1);if(!target)return;
      visibleRects(el).forEach(function(rect){links.push({target:target,rect:rect});});
    });
    var monthly=null,report=root.querySelector('.mp-report');
    if(report){var columns=Array.from(report.querySelectorAll('.mp-portfolios>div')).map(function(col){return Array.from(col.children).map(function(el){var r=bounds(el);return {x:r.x,y:r.y,w:r.w,h:r.h};});});
      var header=report.querySelector('.mp-header'),follow=report.querySelector('.mp-followups,.mp-empty-followups');
      monthly={header:header&&bounds(header),columns:columns,follow:follow&&bounds(follow)};}
    // The last visible font rectangle can overhang its element by a fraction
    // of a pixel. Include it so pagination neither drops that line nor creates
    // a trailing sheet containing only the footer.
    var textBottom=lines.reduce(function(bottom,line){return Math.max(bottom,line.y+line.h);},0);
    return {ops:ops,lines:lines,avoids:avoids,breaks:breaks,tables:tables,monthly:monthly,destinations:destinations,links:links,
      agenda:S.agendaPrint ? S.agendaPrint.collect(artifact,bounds) : null,
      hh:collectHH(artifact,bounds),
      council:collectCouncil(artifact,bounds),
      height:Math.max(origin.height,root.scrollHeight,Math.ceil(textBottom)),width:origin.width};
  }
  function pagePlan(data, geometry){
    if(geometry.layout==='continuous')return [{start:0,end:data.height,head:null}];
    if(data.agenda&&S.agendaPrint)return S.agendaPrint.pagePlan(data);
    if(data.hh)return hhPages(data,geometry);
    if(data.council)return councilPages(data);
    if(data.monthly&&data.monthly.columns.length)return monthlyPages(data,geometry);
    var pageH=(geometry.direction==='landscape'?210:297)-20;
    var capacity=geometry.capacityPx||pageH*96/25.4,plans=[],start=geometry.sourceStart||0;
    while(start<data.height-.5){
      var table=data.tables.find(function(t){return start>=t.head.y+t.head.h-.5&&start<t.bottom-.5;});
      var head=table?table.head:null,reserve=head?head.h:0,limit=Math.min(data.height,start+capacity-reserve);
      var forced=data.breaks.filter(function(y){return y>start+capacity*.2&&y<limit;}).sort(function(a,b){return a-b;})[0];
      if(forced!==undefined)limit=forced;
      var end=limit,cutting=data.avoids.filter(function(a){return a.top<end-.5&&a.bottom>end+.5&&a.bottom-a.top<capacity-reserve;});
      // Avoid splitting a fitting row/card. Re-evaluate when two adjacent
      // columns overlap, while retaining a useful amount of content per page.
      for(var n=0;n<30&&cutting.length;n++){
        var eligible=cutting.filter(function(a){return a.top>start+capacity*.25;});
        if(!eligible.length)break;
        var candidate=Math.min.apply(null,eligible.map(function(a){return a.top;}));
        end=candidate;cutting=data.avoids.filter(function(a){return a.top<end-.5&&a.bottom>end+.5&&a.bottom-a.top<capacity-reserve;});
      }
      // A genuinely oversized row/card may continue, but never cut a text line.
      var crossing=data.lines.filter(function(l){return l.y<end-.1&&l.y+l.h>end+.1;});
      if(crossing.length){var lineTop=Math.min.apply(null,crossing.map(function(l){return l.y;}));if(lineTop>start+1)end=lineTop;}
      if(end<=start+1)end=limit;
      plans.push({start:start,end:end,head:head});start=end;
      if(plans.length>2000)throw new Error('التقرير أطول من الحد المتاح لتصدير PDF.');
    }
    return plans.length?plans:[{start:0,end:0,head:null}];
  }

  function monthlyPages(data,geometry){
    var cap=((geometry.direction==='landscape'?210:297)-20)*96/25.4,pages=[],m=data.monthly;
    function page(i){while(pages.length<=i)pages.push({regions:[]});return pages[i];}
    function region(r,at,y){page(at).regions.push({source:r,x:r.x,y:y});}
    function portions(r,at,cursor){
      var start=r.y,end=r.y+r.h;
      while(start<end-.2){
        var table=data.tables.find(function(t){return start>=t.head.y+t.head.h-.5&&start<t.bottom-.5&&t.head.x<r.x+r.w&&t.head.x+t.head.w>r.x;});
        if(cursor>cap-2){at++;cursor=0;}
        if(table&&start>r.y+.5){region(table.head,at,cursor);cursor+=table.head.h;}
        var available=cap-cursor,cut=Math.min(end,start+available);
        var crossing=data.avoids.filter(function(a){return a.top<cut-.2&&a.bottom>cut+.2&&a.bottom-a.top<cap&&a.x<r.x+r.w&&a.x+a.w>r.x&&a.top>start+1;});
        if(crossing.length)cut=Math.min.apply(null,crossing.map(function(a){return a.top;}));
        var text=data.lines.filter(function(l){return l.x<r.x+r.w&&l.x+l.w>r.x&&l.y<cut-.2&&l.y+l.h>cut+.2;});
        if(text.length)cut=Math.min.apply(null,text.map(function(l){return l.y;}));
        if(cut<=start+.5){at++;cursor=0;continue;}
        region({x:r.x,y:start,w:r.w,h:cut-start},at,cursor);cursor+=cut-start;start=cut;
        if(start<end-.2){at++;cursor=0;}
      }
      return {at:at,cursor:cursor};
    }
    if(m.header)region(m.header,0,m.header.y);
    var endings=m.columns.map(function(nodes){
      var at=0,cursor=nodes.length?nodes[0].y:0,previous=null;
      nodes.forEach(function(r){
        var gap=previous?Math.max(0,r.y-previous.y-previous.h):0;
        if(r.h<=cap){if(cursor+gap+r.h>cap+.1){at++;cursor=0;gap=0;}cursor+=gap;region(r,at,cursor);cursor+=r.h;}
        else {if(cursor>0){at++;cursor=0;}var result=portions(r,at,cursor);at=result.at;cursor=result.cursor;}
        previous=r;
      });return {at:at,cursor:cursor};
    });
    if(m.follow){
      var at=Math.max.apply(null,endings.map(function(x){return x.at;})),cursor=Math.max.apply(null,endings.filter(function(x){return x.at===at;}).map(function(x){return x.cursor;}));
      var sourceBottom=Math.max.apply(null,m.columns.map(function(nodes){var last=nodes[nodes.length-1];return last.y+last.h;}));
      var gap=Math.max(0,m.follow.y-sourceBottom);
      if(m.follow.h<=cap){if(cursor+gap+m.follow.h>cap){at++;cursor=0;gap=0;}region(m.follow,at,cursor+gap);}
      else {cursor+=gap;if(cursor>cap-40){at++;cursor=0;}portions(m.follow,at,cursor);}
    }
    return pages;
  }
  function textFits(op,start,end){
    // Font Range rectangles may extend beyond mastheads and agenda group
    // headings even when their baseline and visible glyphs are inside. Assign
    // heading text by baseline; retain strict line bounds for report rows.
    return op.headerText ? op.baseline>=start-.2&&op.baseline<=end+.2 : op.y>=start-.2&&op.y+op.h<=end+.2;
  }
  function planNavigation(data,plans,inset){
    var destinations={},pageLinks=plans.map(function(){return[];}),pageDestinations=plans.map(function(){return[];});
    function placements(page){
      if(page.regions)return page.regions;
      var reserve=page.head?page.head.h:0;
      return [{source:{x:0,y:page.start,w:data.width,h:page.end-page.start},x:0,y:reserve}];
    }
    (data.destinations||[]).forEach(function(destination){
      if(destinations[destination.id])return;
      plans.some(function(page,index){return placements(page).some(function(place){
        var r=place.source,d=destination.rect;
        if(d.y>=r.y+r.h-.1||d.y+d.h<=r.y+.1||d.x>=r.x+r.w||d.x+d.w<=r.x)return false;
        var margin=page.fullBleed?0:inset;
        var value={id:destination.id,page:index,number:page.footerPage==null?index+1:page.footerPage,
          x:margin+(place.x+Math.max(r.x,d.x)-r.x)*PX_PT,y:margin+(place.y+Math.max(r.y,d.y)-r.y)*PX_PT};
        destinations[destination.id]=value;pageDestinations[index].push(value);return true;
      });});
    });
    data.lines.forEach(function(line){
      if(!line.pageTarget)return;
      var destination=destinations[line.pageTarget];
      if(!destination)throw new Error('تعذّر ربط قسم من محتويات التقرير بالصفحة المطابقة.');
      line.text=String(destination.number);
    });
    (data.links||[]).forEach(function(link){
      if(!destinations[link.target])return;
      plans.forEach(function(page,index){placements(page).forEach(function(place){
        var r=place.source,l=link.rect,left=Math.max(r.x,l.x),top=Math.max(r.y,l.y),right=Math.min(r.x+r.w,l.x+l.w),bottom=Math.min(r.y+r.h,l.y+l.h);
        if(right-left<.5||bottom-top<.5)return;
        var margin=page.fullBleed?0:inset;
        pageLinks[index].push({target:link.target,x:margin+(place.x+left-r.x)*PX_PT,y:margin+(place.y+top-r.y)*PX_PT,w:(right-left)*PX_PT,h:(bottom-top)*PX_PT});
      });});
    });
    return {destinations:pageDestinations,links:pageLinks};
  }
  function paintRegion(doc,engine,data,placement,xInset,yInset){
    var r=placement.source,x=xInset+placement.x*PX_PT,y=yInset+placement.y*PX_PT;
    doc.save();doc.rect(x-.4,y-.4,r.w*PX_PT+.8,r.h*PX_PT+.8).clip();doc.translate(x-r.x*PX_PT,y-r.y*PX_PT);
    data.ops.forEach(function(op){
      if(op.type==='clip-start'||op.type==='clip-end')paint(doc,engine,op);
      else if(op.x<r.x+r.w+.1&&op.x+op.w>r.x-.1&&op.y<r.y+r.h+.1&&op.y+op.h>r.y-.1){
        if(op.type!=='text'||textFits(op,r.y,r.y+r.h))paint(doc,engine,op);
      }
    });doc.restore();
  }

  function shape(doc,op){
    var a=op.attrs,m=op.matrix;
    doc.save();doc.transform(m[0]*PX_PT,m[1]*PX_PT,m[2]*PX_PT,m[3]*PX_PT,m[4]*PX_PT,m[5]*PX_PT);
    var num=function(k,d){var v=parseFloat(a[k]);return Number.isFinite(v)?v:(d||0);};
    if(op.tag==='rect')doc.roundedRect(num('x'),num('y'),num('width'),num('height'),Math.min(num('rx'),num('width')/2,num('height')/2));
    else if(op.tag==='circle')doc.circle(num('cx'),num('cy'),num('r'));
    else if(op.tag==='ellipse')doc.ellipse(num('cx'),num('cy'),num('rx'),num('ry'));
    else if(op.tag==='path')doc.path(a.d||'');
    else if(op.tag==='line')doc.moveTo(num('x1'),num('y1')).lineTo(num('x2'),num('y2'));
    else{var pts=(a.points||'').trim().split(/[\s,]+/).map(Number);for(var i=0;i+1<pts.length;i+=2){if(i)doc.lineTo(pts[i],pts[i+1]);else doc.moveTo(pts[i],pts[i+1]);}if(op.tag==='polygon')doc.closePath();}
    var fill=opaque(op.fill)&&op.tag!=='line',stroke=opaque(op.stroke)&&op.strokeWidth>0;
    if(fill)color(doc,op.fill);if(stroke){color(doc,op.stroke,true);doc.lineWidth(op.strokeWidth);}
    if(fill&&stroke)doc.fillAndStroke();else if(fill)doc.fill();else if(stroke)doc.stroke();
    doc.restore();
  }
  function paint(doc,engine,op){
    var x=op.x*PX_PT,y=op.y*PX_PT,w=op.w*PX_PT,h=op.h*PX_PT;
    if(op.type==='text'){
      engine.drawText(doc,op.text,{x:x,yBaseline:op.baseline*PX_PT,widthPt:w,sizePt:op.size*PX_PT,font:op.font,bold:op.bold,direction:op.direction,color:op.color,letterSpacing:op.letterSpacing*PX_PT});
    }else if(op.type==='ring'){
      var radius=Math.min(w,h)/2,cx=x+w/2,cy=y+h/2;
      color(doc,op.track);doc.circle(cx,cy,radius).fill();
      if(op.value>0){color(doc,op.color);if(op.value>=100)doc.circle(cx,cy,radius).fill();else {var angle=op.value/100*Math.PI*2,ex=cx+Math.sin(angle)*radius,ey=cy-Math.cos(angle)*radius;doc.path('M'+cx+' '+cy+' L'+cx+' '+(cy-radius)+' A'+radius+' '+radius+' 0 '+(op.value>50?1:0)+' 1 '+ex+' '+ey+' Z').fill();}}
      color(doc,op.inner);doc.circle(cx,cy,Math.max(0,radius-op.inset*PX_PT)).fill();
    }else if(op.type==='box'){
      color(doc,op.fill);doc.roundedRect(x,y,w,h,Math.min(op.radius*PX_PT,w/2,h/2)).fill();
    }else if(op.type==='outline'){
      color(doc,op.color,true);doc.lineWidth(op.width*PX_PT);doc.roundedRect(x,y,w,h,Math.min(op.radius*PX_PT,w/2,h/2)).stroke();
    }else if(op.type==='border'){
      color(doc,op.color,true);doc.lineWidth(op.width*PX_PT);
      if(op.side==='Top')doc.moveTo(x,y).lineTo(x+w,y);
      if(op.side==='Bottom')doc.moveTo(x,y+h).lineTo(x+w,y+h);
      if(op.side==='Left')doc.moveTo(x,y).lineTo(x,y+h);
      if(op.side==='Right')doc.moveTo(x+w,y).lineTo(x+w,y+h);
      doc.stroke();
    }else if(op.type==='image'){
      // Images must not inherit opacity from the preceding background wash.
      doc.save().opacity(1);
      doc.image(op.data,x,y,{width:w,height:h});
      doc.restore();
    }
    else if(op.type==='svg')shape(doc,op);
    else if(op.type==='clip-start'){doc.save();doc.roundedRect(x,y,w,h,Math.min(op.radius*PX_PT,w/2,h/2)).clip();}
    else if(op.type==='clip-end')doc.restore();
  }
  function paintSlice(doc,engine,data,start,end,x,y,repeat){
    doc.save();doc.rect(x,y,data.width*PX_PT,(end-start)*PX_PT).clip();doc.translate(x,y-start*PX_PT);
    data.ops.forEach(function(op){
      if(op.type==='clip-start'||op.type==='clip-end')paint(doc,engine,op);
      else if((op.type==='border'||op.type==='outline'||op.type==='box'||op.type==='svg'||op.type==='ring')&&op.y<end&&op.y+op.h>=start)paint(doc,engine,op);
      else if(op.type==='text'&&textFits(op,start,end))paint(doc,engine,op);
      else if(op.type==='image'&&op.y<end&&op.y+op.h>start)paint(doc,engine,op);
    });doc.restore();
  }
  // Official English names supplied by the user, 13 October 2026.
  // Filename presentation only: do not rewrite Arabic source scopes or report labels.
  var filenameScopeNames={
    sector:[
      ["الأمانة العامة للمجلس التنفيذي","الأمانة العامة للمجلس التنفيذي","General Secretariat of the Executive Council"],
      ["الحوكمة","قطاع الحوكمة","Governance Sector"],
      ["التنمية المستدامة","قطاع التنمية المستدامة","Sustainable Development Sector"],
      ["الاقتصاد والتنمية الاجتماعية","قطاع الاقتصاد والتنمية الاجتماعية","Socioeconomic Sector"],
      ["التميز والخدمات الحكومية","قطاع التميز والخدمات الحكومية","Excellence and Government Services Sector"],
      ["الاتصال الحكومي وشؤون الأمانة العامة","قطاع الاتصال الحكومي وشؤون الأمانة العامة","Government Communication & General Secretariat Affairs Sector"]
    ],
    unit:[
      ["مكتب الأمين العام","إدارة مكتب الأمين العام","Secretary General Department"],
      ["الشراكات والعلاقات الدولية","قسم الشراكات والعلاقات الدولية","Partnerships and International Relations Section"],
      ["مكتب التدقيق الداخلي","مكتب التدقيق الداخلي","Internal Audit Office"],
      ["مكتب خطة دبي","مكتب خطة دبي","Dubai Plan Office"],
      ["الأبحاث والرصد","إدارة الأبحاث والرصد","Research and Sensing Department"],
      ["الحوكمة","إدارة الحوكمة","Governance Department"],
      ["التشريعات الحكومية","إدارة التشريعات الحكومية","Government Legislations Department"],
      ["التنفيذ والأداء","إدارة التنفيذ والأداء","Performance & Effectiveness Department"],
      ["السياسات والاستراتيجيات الصحية والعدل","إدارة السياسات والاستراتيجيات الصحية والعدل","Health and Justice Policies and Strategies Department"],
      ["السياسات والاستراتيجيات البيئية والبنية التحتية","إدارة السياسات والاستراتيجيات البيئية والبنية التحتية","Environment and Infrastructure Policies and Strategies Department"],
      ["السياسات والإستراتيجيات الاجتماعية","إدارة السياسات والإستراتيجيات الاجتماعية","Social Policies and Strategies Department"],
      ["السياسات والإستراتيجيات الاقتصادية","إدارة السياسات والإستراتيجيات الاقتصادية","Economic Policies and Strategies Department"],
      ["التقييم والدراسات","إدارة التقييم والدراسات","Assessment and Studies Department"],
      ["التميز والخدمات الحكومية","إدارة التميز والخدمات الحكومية","Excellence and Government Services Department"],
      ["الاتصال الحكومي","إدارة الاتصال الحكومي","Government Communication Department"],
      ["الاتصال الداخلي","قسم الاتصال الداخلي","Internal Communication Section"],
      ["الخدمات المؤسسية","إدارة الخدمات المؤسسية","Corporate Services Department"],
      ["تميز الموارد البشرية","قسم تميز الموارد البشرية","People Excellence Section"],
      ["المشتريات والشؤون الإدارية","قسم المشتريات والشؤون الإدارية","Procurement and Administration Section"],
      ["تقنية المعلومات","قسم تقنية المعلومات","Information Technology Section"],
      ["المالية والحسابات","قسم المالية والحسابات","Finance & Accounts Section"],
      ["المراسلات والأرشفة","قسم المراسلات والأرشفة","Correspondence and Archiving Section"],
      ["تنفيذ ومتابعة المشاريع الميدانية","قسم تنفيذ ومتابعة المشاريع الميدانية","Operational Project Delivery and Follow-up Section"]
    ]
  };
  function filenameSlug(value){
    return value.replace(/&/g,' and ').replace(/[^A-Za-z0-9]+/g,'_').replace(/^_+|_+$/g,'');
  }
  function filenameScope(field,value){
    var label=S.filterOptions.canonical(value,'d:'+field);
    var row=filenameScopeNames[field].find(function(r){return label===r[0]||label===r[1]||label.toLowerCase()===r[2].toLowerCase();});
    // Unlisted Arabic scopes retain an explicit selected-scope marker until mapped.
    var english=row?row[2]:(/^[\x20-\x7E]+$/.test(label)&&/[A-Za-z]/.test(label)?label:'Selected_'+(field==='unit'?'Unit':'Sector'));
    // User-approved short filenames omit trailing Department/Section only.
    return filenameSlug(english).replace(/(?:^|_)(?:Department|Section)$/i,'')||('Selected_'+(field==='unit'?'Unit':'Sector'));
  }
  function downloadName(state,title){
    if(state.screen!=='dashboard')return title.replace(/[\\/:*?"<>|]/g,'-')+'.pdf';
    var U=S.util,F=S.filterOptions,base='TEC_Monthly';
    if(state.data&&U.validDateSerial(state.data.today)){
      var date=U.ymd(state.data.today),months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      base+='_'+months[date.m-1]+'_'+String(date.y).slice(-2);
    }
    var scope='',filters=state.dash||{};
    ['unit','sector'].some(function(field){
      if(!U.hasSelection(filters[field]))return false;
      var options=(state.multiOptions||{})['d:'+field];
      if(F.compactText(filters[field],options,'الكل','d:'+field)==='الكل')return false;
      var first=F.selectionGroups(filters[field],options,'d:'+field)[0];
      scope=filenameScope(field,first.v);
      return true;
    });
    // ASCII filenames need no bidi controls; retain the date, type suffix and extension.
    var limit=240-base.length-1-4;
    if(scope.length>limit){
      var tail=/_Sector$/.test(scope)?'_Sector':'';
      scope=scope.slice(0,limit-tail.length).replace(/_+$/,'')+tail;
    }
    return base+(scope?'_'+scope:'')+'.pdf';
  }
  async function exportPDF(state){
    var sourceTitle=document.title,fileName=downloadName(state,sourceTitle);
    var prepared=S.printPagination.preparedDocument(state),loading=loadEngine();
    var pair;
    try{pair=await Promise.all([loading,prepared]);}catch(error){prepared.then(function(a){if(a&&a.cleanup)a.cleanup();},function(){});throw error;}
    var engine=pair[0],artifact=pair[1];
    if(!artifact)throw new Error('تعذر تجهيز التقرير للتصدير.');
    try{
      var data=collect(artifact),g=Object.assign({},artifact.geometry,{layout:artifact.layout,direction:artifact.direction});
      // Honor the page-height ceiling even when the user chooses a long PDF.
      if(g.layout==='continuous'&&g.heightMM>5080){
        if(artifact.cleanup)artifact.cleanup();
        artifact=await S.printPagination.preparedDocument(state,{layout:'a4'});
        data=collect(artifact);g=Object.assign({},artifact.geometry,{layout:artifact.layout,direction:artifact.direction});
      }
      var plans=pagePlan(data,g),continuous=g.layout==='continuous';
      var width=(continuous?297:g.direction==='landscape'?297:210)*MM_PT;
      var height=(continuous?Math.max(80,Math.ceil(data.height*25.4/96)+27):g.direction==='landscape'?210:297)*MM_PT;
      var inset=(continuous?8:10)*MM_PT;
      var navigation=planNavigation(data,plans,inset);
      if(engine.ready)await engine.ready();
      var doc=await engine.create({size:[width,height],title:sourceTitle,author:'الأمانة العامة للمجلس التنفيذي لإمارة دبي'});
      for(var i=0;i<plans.length;i++){
        if(i)doc.addPage({size:[width,height],margin:0});
        doc.save();doc.rect(0,0,width,height).fill(continuous?'#EFEBE7':'#FCFBFB');doc.restore();
        var p=plans[i];
        var pageInset=p.fullBleed?0:inset;
        if(p.regions)p.regions.forEach(function(r){paintRegion(doc,engine,data,r,pageInset,pageInset);});
        else {var reserve=p.head?p.head.h*PX_PT:0;
          if(p.head)paintSlice(doc,engine,data,p.head.y,p.head.y+p.head.h,inset,inset);
          paintSlice(doc,engine,data,p.start,p.end,inset,inset+reserve);}
        navigation.destinations[i].forEach(function(target){doc.addNamedDestination(target.id,'XYZ',target.x,target.y,null);});
        navigation.links[i].forEach(function(link){doc.goTo(link.x,link.y,link.w,link.h,link.target);});
        if(!p.noFooter){
          var baseline=height-(continuous?11:data.agenda||data.hh||data.council?10:5)*MM_PT;
          var footerPage=p.footerPage==null?i+1:p.footerPage,footerTotal=p.footerTotal==null?plans.length:p.footerTotal;
          engine.drawText(doc,'صفحة '+footerPage+' من '+footerTotal,{x:inset,yBaseline:baseline,sizePt:10.5,font:'TEC Dubai',direction:'rtl',color:'#4F4E4E'});
          var copyright=S.ui.copyrightText();
          engine.drawText(doc,copyright,{x:width-inset,yBaseline:baseline,sizePt:10.5,font:'TEC Dubai',direction:'rtl',align:'right',color:'#4F4E4E'});
        }
        // Let the browser update the visible loading state for long report packs.
        if(i%5===4)await new Promise(function(resolve){setTimeout(resolve,0);});
      }
      var bytes=await engine.finish(doc),blob=new Blob([bytes],{type:'application/pdf'});
      return {blob:blob,name:fileName,pages:plans.length,layout:g.layout,
        widthMM:width/MM_PT,heightMM:height/MM_PT,nativeTextLines:data.lines.length};
    }finally{if(artifact.cleanup)artifact.cleanup();}
  }
  S.offlinePdf={export:exportPDF,collect:collect,pagePlan:pagePlan,downloadName:downloadName};
})(window.Saytara=window.Saytara||{});
