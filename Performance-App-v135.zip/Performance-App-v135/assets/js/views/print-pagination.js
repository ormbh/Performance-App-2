/* Native TEC print preparation. CSS paged media owns page count and flow.
 * Do not clone/filter/reorder data here: each view's full export DOM is retained. */
(function (S) {
  'use strict';
  var U = S.util;
  var TITLES = { dashboard:'التقرير الشهري للأداء والتنفيذ', projects:'مستجدات محفظة المشاريع', results:'نتائج البحث في الأداء', home:'البحث في الأداء', entities:'تقرير الجهات', comparison:'المقارنة الشهرية', agenda:'الأجندة السنوية', council:'تقرير قرارات المجالس', checks:'ملاحظات البيانات', detail:'تفاصيل البند', upload:'رفع ملف التقرير' };
  function title(state) {
    if (state.screen === 'reports' && S.reportDisplay) return S.reportDisplay.fileTitle(S.reportDisplay.get(state).fileTitle);
    var root = document.querySelector('#app .project-masthead h1, #app main h1');
    return TITLES[state.screen] || (root ? root.textContent.trim() : 'تقرير الأداء');
  }
  function orientation(state) {
    // A project report shares the reports route, but keeps the portrait rule.
    var landscape = state && (state.screen === 'agenda' || state.screen === 'council' ||
      state.screen === 'reports' && state.report && ['agenda', 'council', 'hh'].includes(state.report.kind));
    return landscape ? 'landscape' : 'portrait';
  }
  function legal() {
    return S.ui && S.ui.copyrightText ? S.ui.copyrightText() : 'الأمانة العامة للمجلس التنفيذي لإمارة دبي · حقوق النشر © ' + new Date().getFullYear() + ' · جميع الحقوق محفوظة';
  }
  function groupPanels() {
    document.querySelectorAll('#app .pd-reference-grid').forEach(function(grid) {
      if (grid.classList.contains('tec-print-grouped')) return;
      var panels = Array.from(grid.children);
      grid.classList.add('tec-print-grouped');
      for (var i = 0; i < panels.length;) {
        if (panels[i].classList.contains('pd-issues')) { i++; continue; }
        var pair = document.createElement('div'); pair.className = 'tec-print-panel-pair';
        grid.insertBefore(pair, panels[i]); pair.appendChild(panels[i++]);
        if (i < panels.length && !panels[i].classList.contains('pd-issues')) pair.appendChild(panels[i++]);
      }
    });
  }
  function measureRows(direction) {
    // Hidden paper DOM has no useful geometry before print media is active.
    // Measure synchronously on actual media entry, not just before window.print.
    if (window.matchMedia && !window.matchMedia('print').matches) return;
    direction = direction === 'landscape' || direction === 'portrait' ? direction :
      document.body.getAttribute('data-tec-print-orientation') || 'portrait';
    var max = (direction === 'landscape' ? 190 : 277) * 96 / 25.4;
    document.querySelectorAll('#app tbody tr').forEach(function (row) {
      var rect = row.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      var table = row.closest('table'), head = table && table.tHead;
      var available = Math.max(0, max - (head ? head.getBoundingClientRect().height : 0));
      row.classList.toggle('tec-print-tall-row', rect.height > available);
    });
    document.querySelectorAll('#app .mp-card, #app .pd-panel, #app .entity-print-summary, #app .cmp-kpi, #app .cmp-section, #app .cmp-record, #app .rpt-chart-panel').forEach(function (card) {
      var rect = card.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      card.classList.toggle('tec-print-tall-card', rect.height > max);
    });
  }
  function prepare(state) {
    var root = document.getElementById('app');
    if (!root || !state || !state.data) return;
    var direction = orientation(state), css = document.getElementById('tec-print-page-size');
    if (!css) { css = document.createElement('style'); css.id = 'tec-print-page-size'; document.head.appendChild(css); }
    css.textContent = '@page tec-report { size:A4 ' + direction + '; margin:10mm; }';
    document.documentElement.style.setProperty('--tec-print-legal', JSON.stringify(legal()));
    document.body.setAttribute('data-tec-print', 'a4');
    document.body.setAttribute('data-tec-print-orientation', direction);
    if (state.screen !== 'dashboard') {
      var heading = document.getElementById('tec-print-first-header');
      if (!heading) { heading = document.createElement('header'); heading.id = 'tec-print-first-header'; heading.className = 'tec-print-first-header'; heading.setAttribute('dir','rtl'); root.insertBefore(heading,root.firstChild); }
      heading.innerHTML = '<img src="assets/img/tec-red.png" alt="المجلس التنفيذي — The Executive Council"><h1>' + U.esc(title(state)) + ' - لتاريخ <bdi dir="ltr">' + U.esc(U.fmtDate(state.data.today)) + '</bdi></h1>';
    }
    groupPanels();
    measureRows(direction);
    requestAnimationFrame(function () { if (document.body.hasAttribute('data-tec-print')) measureRows(direction); });
  }
  function clear() {
    document.body.removeAttribute('data-tec-print');
    document.body.removeAttribute('data-tec-print-orientation');
    var heading = document.getElementById('tec-print-first-header'); if (heading) heading.remove();
    var css = document.getElementById('tec-print-page-size'); if (css) css.remove();
    document.documentElement.style.removeProperty('--tec-print-legal');
    document.querySelectorAll('.tec-print-panel-pair').forEach(function(pair){pair.replaceWith.apply(pair,Array.from(pair.children));});
    document.querySelectorAll('.tec-print-grouped').forEach(function(grid){grid.classList.remove('tec-print-grouped');});
    document.querySelectorAll('.tec-print-tall-row').forEach(function(row){row.classList.remove('tec-print-tall-row');});
    document.querySelectorAll('.tec-print-tall-card').forEach(function(card){card.classList.remove('tec-print-tall-card');});
  }
  if (window.matchMedia) {
    var printMedia = window.matchMedia('print');
    var mediaChanged = function (event) {
      if (event.matches && document.body.hasAttribute('data-tec-print')) measureRows();
    };
    if (printMedia.addEventListener) printMedia.addEventListener('change', mediaChanged);
    else if (printMedia.addListener) printMedia.addListener(mediaChanged);
  }
  S.printPagination = { prepare:prepare, clear:clear, measureRows:measureRows, orientation:orientation };
})(window.Saytara = window.Saytara || {});
