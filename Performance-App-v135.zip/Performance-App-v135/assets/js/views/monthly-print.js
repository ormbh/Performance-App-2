/* Native paper composition for the approved monthly dashboard.
 * Use the scoped dashboard model; presentation never changes source formulas. */
(function (S) {
  'use strict';
  var U = S.util, R = S.rules;
  function text(v) { return U.esc(v == null ? '' : String(v)); }
  function value(v, percent) {
    var shown = typeof v === 'number' && Number.isFinite(v) && v === 0 ? '-' :
      percent && typeof v === 'number' && Number.isFinite(v) ? U.fmtNum(v * 100, 1) + '%' : U.metricText(v, percent);
    return '<bdi dir="ltr">' + shown + '</bdi>';
  }
  function available(state, key) { return R.metricAvailable(state.data, key, state.dash || {}); }
  function amount(state, D, key, raw) { return available(state, key) ? (raw === undefined ? D.n[key] : raw) : null; }
  function delta(D, key, tone) {
    var c = D.change(key);
    if (c.state === 'same' || c.state === 'none') return '';
    var up = c.d > 0, color = tone === 'good' ? (up ? 'good' : 'bad') : tone === 'bad' ? (up ? 'bad' : 'good') : 'neutral';
    return '<span class="mp-change ' + color + '" data-print-change="' + key + '"><bdi dir="ltr">' +
      (up ? '↑ +' : '↓ −') + text(c.text) + '</bdi>' + (key === 'kpiAvg' ? ' نقطة مئوية' : '') + '</span>';
  }
  function metric(state, D, key, label, tone, raw, percent, compare, changeTone) {
    var caption = S.ui.slcCaption(label);
    return '<div class="mp-metric ' + (tone || '') + '"><span>' + caption + '</span><strong data-print-metric="' + key + '">' +
      value(amount(state, D, key, raw), percent) + '</strong>' + (compare === false ? '' : delta(D, key, changeTone === undefined ? tone : changeTone)) + '</div>';
  }
  function row(state, D, cells, extraClass) {
    cells = cells.filter(function (c) {
      var status = /^(?:special(?:Lead|Gs)(?:Late|Done|Progress)|sec(?:Late|Done|Active|Held)|agenda(?:Late|Done|Ready|Progress|NoStatus)|council(?:Late|Done|Progress|NoStatus)|leg(?:OnTime|Overrun|Progress|Pending|Late))$/.test(c[0]);
      var v = amount(state, D, c[0]);
      return !status || typeof v === 'number' && Number.isFinite(v) && v > 0;
    });
    return cells.length ? '<div class="mp-metrics' + (extraClass ? ' ' + extraClass : '') + '" style="--mp-cols:' + cells.length + '">' +
      cells.map(function (c) { return metric(state, D, c[0], c[1], c[2], c[3], c[4], c[5], c[6]); }).join('') + '</div>' : '';
  }
  function card(state, D, key, title, body, extraClass) {
    return '<section class="mp-card ' + (extraClass || '') + '"><header class="mp-card-head"><div><h3>' + text(title) + '</h3></div><div class="mp-total"><strong data-print-metric="' + key + '">' + value(amount(state, D, key)) +
      '</strong><span>الإجمالي</span>' + delta(D, key) + '</div></header>' + body + '</section>';
  }
  function note(s, warn) { return '<p class="mp-note' + (warn ? ' mp-warning' : '') + '">' + s + '</p>'; }
  function historyQuality(D) {
    var issues = D.historyIssues || [];
    return issues.length ? note('مراجعة المصدر للمقارنة: ' + Array.from(new Set(issues.map(function (issue) { return issue.reason; }))).map(text).join(' · '), true) : '';
  }
  function header(state) {
    return '<header class="mp-header"><img class="mp-tec-logo" src="assets/img/tec-red.png" alt="المجلس التنفيذي — The Executive Council"><div class="mp-title"><h1>التقرير الشهري للأداء والتنفيذ - لتاريخ <bdi dir="ltr">' +
      text(U.fmtDate(state.data.today)) + '</bdi></h1></div></header>';
  }
  function strategy(state, D) {
    var k = D.kpi, measured = amount(state, D, 'kpiMeasured', k.measured), total = amount(state, D, 'kpiTotal', k.total), coverage = typeof measured === 'number' && typeof total === 'number' && total > 0 ? measured / total : null;
    var avgResult = amount(state, D, 'kpiAvg', k.avgResult), avgTarget = amount(state, D, 'kpiTargeted', k.avgTarget);
    function tile(label, key, shown, caption, change) {
      return '<div class="mp-kpi-metric"><span>' + label + '</span><strong' + (key ? ' data-print-metric="' + key + '"' : ' data-print-ratio="kpi"') + '>' + shown + '</strong>' + ((caption || change) ? '<div class="mp-kpi-note">' + caption + (change || '') + '</div>' : '') + '</div>';
    }
    return '<section class="mp-card mp-strategy"><header class="mp-card-head"><div><h3>استراتيجية الأمانة العامة</h3></div><span class="mp-kpi-tag">مؤشرات الأداء' + delta(D, 'kpiTotal') + '</span></header><div class="mp-strategy-grid">' +
      tile('المؤشرات المقاسة / المسجلة', '', '<bdi dir="ltr">' + value(measured) + '<span class="mp-kpi-denominator"> / ' + value(total) + '</span></bdi>', (coverage == null ? '' : S.views.dashboard.meter(coverage, 'تغطية القياس', 'brand', true)), delta(D, 'kpiMeasured', 'good')) +
      tile('متوسط النتائج المقاسة', 'kpiAvg', value(avgResult, true), avgResult == null ? 'لم تُقَس بعد' : '', delta(D, 'kpiAvg', 'neutral')) +
      tile('متوسط المستهدفات المعتمدة', 'kpiTargeted', value(avgTarget, true), avgTarget == null ? 'لا توجد مستهدفات مسجلة' : '', '') + '</div>' +
      (k.explicitState ? note([['notMeasured', 'غير مقاس'], ['notApplicable', 'غير منطبق'], ['unavailable', 'غير متاح'], ['unknown', 'حالة غير معروفة'], ['conflict', 'تعارض']].filter(function (c) { return k[c[0]] !== 0; }).map(function (c) { return text(c[1]) + ': ' + value(k[c[0]]); }).join(' · ')) : '') + '</section>';
  }
  function special(state, D, area) {
    var groups = [['specialLead', 'للقيادة', 'specialLeadProgress', 'specialLeadDone', 'specialLeadLate'], ['specialGs', 'للأمانة العامة', 'specialGsProgress', 'specialGsDone', 'specialGsLate']].filter(function (g) { return !area || !area.groups || area.groups[g[0]]; });
    return card(state, D, 'specialTotal', 'المشاريع الخاصة', '<div class="mp-special-groups" style="--mp-groups:' + groups.length + '">' + groups.map(function (g) {
      return '<section class="mp-requester"><h4><span>' + text(g[1]) + '</span><strong data-print-metric="' + g[0] + '">' + value(amount(state, D, g[0])) + '</strong>' + delta(D, g[0]) + '</h4>' +
        row(state, D, [[g[4], 'متأخر', 'bad'], [g[3], 'منجز', 'good'], [g[2], 'قيد العمل']]) + S.views.dashboard.completion(D, g[3], g[0], true) + '</section>';
    }).join('') + '</div>' + (D.n.specialNoRequester ? '<p class="mp-note mp-special-unclassified">جهة الطلب غير مسجلة: <span data-print-metric="specialNoRequester">' + value(amount(state, D, 'specialNoRequester')) + '</span> · مشمولة في الإجمالي</p>' : ''), 'mp-special');
  }
  function secretariat(state, D, area) {
    var b = D.budget, approved = amount(state, D, 'budApproved', b.approved);
    function money(key, label, raw) {
      return '<div class="mp-money" data-print-money="' + key + '"><div class="mp-money-main"><span>' + text(label) + '</span><strong data-print-metric="' + key + '">' + value(amount(state, D, key, raw)) + '</strong></div>' + delta(D, key) + '</div>';
    }
    var allocated = amount(state, D, 'budAllocated', b.allocated), spent = amount(state, D, 'budSpent', b.spent);
    var allocation = typeof approved === 'number' && approved > 0 && typeof allocated === 'number' ? allocated / approved : null;
    var spending = typeof approved === 'number' && approved > 0 && typeof spent === 'number' ? spent / approved : null;
    return card(state, D, 'secTotal', 'مشاريع بموازنة استراتيجية', row(state, D, [['secLate', 'متأخر', 'bad'], ['secDone', 'منجز', 'good'], ['secActive', 'قيد العمل'], ['secHeld', 'مجمّد / ملغى']]) +
      '<section class="mp-quarter-section"><h4>موعد الانتهاء حسب الربع <span>' + text(state.data.year) + '</span></h4>' + row(state, D, [1, 2, 3, 4].map(function (q) { return ['secQ' + q, 'الربع ' + q]; }), 'mp-quarters') + S.monthlyCoverage.render(state, D, true) + '</section>' +
      (area && area.budget === false ? '' : '<section class="mp-budget"><div class="mp-budget-head"><h4>الموازنة المعتمدة</h4><span>درهم إماراتي</span></div><div class="mp-budget-total" data-print-money="budApproved"><strong data-print-metric="budApproved">' + value(approved) + '</strong>' + delta(D, 'budApproved') + '</div><div class="mp-allocation-grid">' +
        money('budAllocated', 'المخصص', b.allocated) + money('budUnallocated', 'غير المخصص', b.unallocated) + '</div>' + S.views.dashboard.meter(allocation, 'نسبة المخصص من الموازنة المعتمدة', 'active', true) + '<div class="mp-spending">' + money('budSpent', 'المنفق حسب الفواتير', b.spent) + S.views.dashboard.meter(spending, 'نسبة الإنفاق من الموازنة المعتمدة', 'brand', true) +
        (spending == null ? '' : '<p class="mp-note">الإنفاق ' + U.fmtNum(spending * 100, 1) + '% من الموازنة المعتمدة</p>') + '</div></section>'), 'mp-secretariat');
  }
  function agenda(state, D) {
    return card(state, D, 'agendaTotal', 'الأجندة السنوية', '<div class="mp-agenda-types">' + row(state, D, [['agendaPlanned', 'الأجندة المعتمدة'], ['agendaEmerging', 'المواضيع المستجدة']]) + '</div>' +
      row(state, D, [['agendaLate', 'متأخر', 'bad'], ['agendaDone', 'منجز', 'good'], ['agendaReady', 'جاهز للعرض'], ['agendaProgress', 'قيد العمل'], ['agendaNoStatus', 'غير مصنف', '', undefined, false, false]]) +
      S.views.dashboard.distribution(D, 'agendaTotal', [['agendaDone', 'منجز', 'complete'], ['agendaReady', 'جاهز للعرض', 'ready'], ['agendaProgress', 'قيد العمل', 'active'], ['agendaLate', 'متأخر', 'late']], true, false), 'mp-agenda');
  }
  function council(state, D) {
    return card(state, D, 'councilTotal', 'قرارات المجالس', row(state, D, [['councilLate', 'متأخر', 'bad'], ['councilDone', 'منجز', 'good'], ['councilProgress', 'قيد العمل']]) +
      S.views.dashboard.distribution(D, 'councilTotal', [['councilDone', 'منجز', 'complete'], ['councilProgress', 'قيد العمل', 'active'], ['councilLate', 'متأخر', 'late']], true, false) +
      '<p class="mp-note mp-council-footer">' + (D.n.councilNoStatus > 0 ? 'بدون حالة معتمدة: <span data-print-metric="councilNoStatus">' + value(amount(state, D, 'councilNoStatus')) + '</span> · ' : '') + 'يشمل نطاق المتابعة فقط</p>', 'mp-council');
  }
  function legislation(state, D) {
    return card(state, D, 'legTotal', 'التشريعات', '<div class="mp-legislation-statuses">' + row(state, D, [['legLate', 'متأخر', 'bad'], ['legOnTime', 'SLC منجز ضمن موعد', 'good'], ['legOverrun', 'SLC منجز بعد موعد', 'good', undefined, false, undefined, 'neutral'], ['legPending', 'قيد الإجراء']]) + '</div>' +
      S.views.dashboard.distribution(D, 'legTotal', [['legLate', 'متأخر', 'late'], ['legOnTime', 'SLC منجز ضمن موعد', 'complete'], ['legOverrun', 'SLC منجز بعد موعد', 'complete-after'], ['legPending', 'قيد الإجراء', 'active']], true) +
      (D.legislationProjection && !D.legislationProjection.disjoint ? note(text(D.legislationProjection.reason), true) : ''), 'mp-legislation');
  }
  function followups(state, D, sourceNotes) {
    var list = S.views.dashboard.followups(state, D);
    if (!list.length) return '<section class="mp-empty-followups"><h2>بنود المتابعة</h2><span>-</span><p>لا توجد بنود تتطلب المتابعة</p></section>';
    var labels = { delayed: 'متأخر', hold: 'مجمّد', cancelled: 'ملغى', transferred: 'منقول' };
    var counts = ['delayed', 'hold', 'cancelled', 'transferred'].map(function (cat) { var n = list.filter(function (x) { return x.category === cat; }).length; return n ? '<span class="' + (cat === 'delayed' ? 'bad' : '') + '">' + text(labels[cat]) + ' <bdi dir="ltr">' + U.fmtN(n) + '</bdi></span>' : ''; }).join('');
    return '<section class="mp-followups"><div class="mp-followup-card"><header class="mp-followup-heading"><div><h2>بنود المتابعة</h2></div><div class="mp-followup-count"><strong>' + U.fmtN(list.length) + '</strong><span>بنود</span>' + S.views.dashboard.followChange(state, D, true) + '</div></header><div class="mp-followup-summary">' + counts + '</div><table class="mp-notes-table"><colgroup>' + [15, 22, 14, 22, 27].map(function (width) { return '<col style="width:' + width + '%">'; }).join('') + '</colgroup><thead><tr>' + ['المحفظة', 'البند', 'مستوى الإنجاز', 'الوحدة التنظيمية / القطاع', 'الملاحظات'].map(function (label) { return '<th scope="col">' + text(label) + '</th>'; }).join('') + '</tr></thead><tbody>' + list.map(function (x) {
      var it = x.it, title = U.tableCellText(it.title), status = { statusLabel: U.tableCellText(S.views.dashboard.followStatusText(x)), statusCat: x.category };
      var unit = U.tableCellText(it.unit), sector = U.tableCellText(it.sector), noteText = U.tableCellText(x.note);
      return '<tr data-followup-category="' + x.category + '" data-print-key="' + text(it.key) + '"><td class="mp-followup-pf">' + text(U.tableCellText(S.ui.pfName(it.pf))) + '</td><td class="mp-followup-title"><span dir="' + text(it.dir || 'auto') + '">' + text(title) + '</span></td><td class="mp-followup-status">' + S.ui.statusChip(status) + '</td><td class="mp-followup-unit"><span dir="auto">' + text(unit || 'الوحدة غير مسجلة') + '</span>' + (sector ? '<small dir="auto">' + text(sector) + '</small>' : '') + '</td><td class="mp-followup-note"><p dir="auto">' + text(noteText || 'لا توجد ملاحظة مسجلة') + '</p></td></tr>';
    }).join('') + '</tbody></table>' + (sourceNotes || '') + '</div></section>';
  }
  function render(state, D) {
    var areas = S.views.dashboard.contribution(state, D), projects = (areas.special.visible ? special(state, D, areas.special) : '') + (areas.secretariat.visible ? secretariat(state, D, areas.secretariat) : ''), executive = (areas.agenda.visible ? agenda(state, D) : '') + (areas.council.visible ? council(state, D) : '') + (areas.legislation.visible ? legislation(state, D) : '') + (areas.kpi.visible ? strategy(state, D) : '');
    var sourceNotes = '<div class="mp-source-notes">' + S.views.dashboard.sourceTitleNotice(state, true) + historyQuality(D) + '</div>';
    var notesWithDetails = S.monthlyTools.layout(state) === 'a4' && S.views.dashboard.followups(state, D).length > 0;
    return '<article class="mp-report mp-apple mp-' + S.monthlyTools.layout(state) + '" dir="rtl"><section class="mp-summary">' + header(state) + '<div class="mp-portfolios' + (!projects || !executive ? ' mp-single' : '') + '">' +
      (executive ? '<div class="mp-executive-column"><h2 class="mp-portfolio-heading">محافظ المتابعة التنفيذية</h2>' + executive + '</div>' : '') + (projects ? '<div class="mp-project-column"><h2 class="mp-portfolio-heading">محفظة المشاريع</h2>' + projects + '</div>' : '') + '</div>' +
      (projects || executive ? '' : note('لا توجد بيانات ضمن النطاق المحدد.')) + (notesWithDetails ? '' : sourceNotes) + '</section>' + followups(state, D, notesWithDetails ? sourceNotes : '') + '</article>';
  }
  S.monthlyPrint = { render: render };
})(window.Saytara = window.Saytara || {});
