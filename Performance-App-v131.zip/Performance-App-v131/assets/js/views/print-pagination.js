/* Native TEC print preparation. CSS paged media owns page count and flow.
 * Do not clone/filter/reorder data here: each view's full export DOM is retained. */
(function (S) {
  'use strict';
  var U = S.util, prepared = false;
  var TITLES = { dashboard:'التقرير الشهري للأداء والتنفيذ', projects:'مستجدات محفظة المشاريع', results:'نتائج البحث في الأداء', home:'البحث في الأداء', entities:'تقرير الجهات', comparison:'المقارنة الشهرية', agenda:'الأجندة السنوية', council:'تقرير قرارات المجالس', checks:'ملاحظات البيانات', detail:'تفاصيل البند', upload:'رفع ملف التقرير' };
  function title(state) {
    if (state.screen === 'reports' && S.reportDisplay) return S.reportDisplay.fileTitle(S.reportDisplay.get(state).fileTitle);
    var root = document.querySelector('#app .project-masthead h1, #app main h1');
    return TITLES[state.screen] || (root ? root.textContent.trim() : 'تقرير الأداء');
  }
  function layout(state) {
    if (state.screen === 'dashboard' && S.monthlyTools) return S.monthlyTools.layout(state);
    return S.projectPrint && S.projectPrint.active(state) ? S.projectPrint.get(state).layout : 'a4';
  }
  function legal() {
    return S.ui && S.ui.copyrightText ? S.ui.copyrightText() : 'الأمانة العامة للمجلس التنفيذي لإمارة دبي · حقوق النشر © ' + new Date().getFullYear() + ' · جميع الحقوق محفوظة';
  }
  function groupPanels() {
    document.querySelectorAll('#app .pd-reference-grid').forEach(function(grid) {
      if (grid.classList.contains('tec-print-grouped')) return;
      var panels = Array.from(grid.children);
      grid.classList.add('tec-print-grouped');
      for (var i = 0; i < panels.length;) {
        if (panels[i].classList.contains('pd-issues')) { i++; continue; }
        var pair = document.createElement('div'); pair.className = 'tec-print-panel-pair';
        grid.insertBefore(pair, panels[i]); pair.appendChild(panels[i++]);
        if (i < panels.length && !panels[i].classList.contains('pd-issues')) pair.appendChild(panels[i++]);
      }
    });
  }
  function measureRows(paper) {
    // A row taller than the usable physical page must be allowed to continue.
    // There is no font shrink or fixed page count, and shorter rows stay together.
    var max = (paper === 'a3' ? 267 : 180) * 96 / 25.4;
    document.querySelectorAll('#app tbody tr').forEach(function (row) {
      row.classList.toggle('tec-print-tall-row', row.getBoundingClientRect().height > max);
    });
  }
  function prepare(state) {
    var root = document.getElementById('app');
    if (!root || !state || !state.data) return;
    var paper = layout(state), css = document.getElementById('tec-print-page-size');
    if (!css) { css = document.createElement('style'); css.id = 'tec-print-page-size'; document.head.appendChild(css); }
    css.textContent = '@page tec-report { size:' + (paper === 'a3' ? 'A3' : 'A4') + ' landscape; margin:10mm; }';
    document.documentElement.style.setProperty('--tec-print-legal', JSON.stringify(legal()));
    document.body.setAttribute('data-tec-print', paper);
    if (state.screen !== 'dashboard') {
      var heading = document.getElementById('tec-print-first-header');
      if (!heading) { heading = document.createElement('header'); heading.id = 'tec-print-first-header'; heading.className = 'tec-print-first-header'; heading.setAttribute('dir','rtl'); root.insertBefore(heading,root.firstChild); }
      heading.innerHTML = '<img src="assets/img/tec-red.png" alt="المجلس التنفيذي — The Executive Council"><h1>' + U.esc(title(state)) + ' - لتاريخ <bdi dir="ltr">' + U.esc(U.fmtDate(state.data.today)) + '</bdi></h1>';
    }
    groupPanels();
    measureRows(paper);
    if (!prepared) {
      prepared = true;
      requestAnimationFrame(function () { if (document.body.hasAttribute('data-tec-print')) measureRows(paper); });
    }
  }
  function clear() {
    prepared = false;
    document.body.removeAttribute('data-tec-print');
    var heading = document.getElementById('tec-print-first-header'); if (heading) heading.remove();
    var css = document.getElementById('tec-print-page-size'); if (css) css.remove();
    document.documentElement.style.removeProperty('--tec-print-legal');
    document.querySelectorAll('.tec-print-panel-pair').forEach(function(pair){pair.replaceWith.apply(pair,Array.from(pair.children));});
    document.querySelectorAll('.tec-print-grouped').forEach(function(grid){grid.classList.remove('tec-print-grouped');});
    document.querySelectorAll('.tec-print-tall-row').forEach(function(row){row.classList.remove('tec-print-tall-row');});
  }
  S.printPagination = { prepare:prepare, clear:clear, measureRows:measureRows };
})(window.Saytara = window.Saytara || {});
